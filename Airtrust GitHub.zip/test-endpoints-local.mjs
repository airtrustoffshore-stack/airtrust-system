#!/usr/bin/env node

/**
 * TESTE LOCAL DOS ENDPOINTS PARA VERIFICAR SE ESTÃO FUNCIONANDO
 */

import http from 'http';

const BASE_URL = 'http://localhost:5173';

async function testEndpoint(path, method = 'GET') {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 5173,
      path: path,
      method: method,
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Test-Local-Endpoints/1.0'
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({
            status: res.statusCode,
            statusMessage: res.statusMessage,
            data: parsed,
            isJson: true
          });
        } catch (e) {
          resolve({
            status: res.statusCode,
            statusMessage: res.statusMessage,
            data: data,
            isJson: false
          });
        }
      });
    });

    req.on('error', (err) => {
      reject(err);
    });

    req.setTimeout(5000, () => {
      req.destroy();
      reject(new Error('Timeout'));
    });

    req.end();
  });
}

async function testAllEndpoints() {
  console.log('🔍 TESTANDO ENDPOINTS LOCALMENTE...\n');
  
  const endpoints = [
    '/api/v2/historico-certificacoes/status',
    '/api/v2/import-certificacoes-batch/',
    '/api/v2/certificacoes-import-robust/status-robust',
    '/'
  ];

  for (const endpoint of endpoints) {
    try {
      console.log(`📡 Testando: ${endpoint}`);
      const result = await testEndpoint(endpoint);
      
      console.log(`  Status: ${result.status} ${result.statusMessage}`);
      console.log(`  JSON: ${result.isJson}`);
      
      if (result.isJson && result.data.success !== undefined) {
        console.log(`  Success: ${result.data.success}`);
      }
      
      if (result.status === 404) {
        console.log(`  ❌ ENDPOINT NÃO ENCONTRADO`);
      } else if (result.status >= 200 && result.status < 300) {
        console.log(`  ✅ ENDPOINT FUNCIONANDO`);
      } else {
        console.log(`  ⚠️ ENDPOINT COM PROBLEMAS`);
      }
      
    } catch (error) {
      console.log(`  ❌ ERRO: ${error.message}`);
    }
    
    console.log('');
  }
}

testAllEndpoints().catch(console.error);
