#!/bin/bash
echo "--- INICIANDO IMPORTAÇÃO DE DADOS PARA O AMBIENTE GREEN ---"

SNAPSHOT_FILE=$1

if [ -z "$SNAPSHOT_FILE" ]; then
  echo "ERRO: Nenhum arquivo de snapshot SQL fornecido."
  echo "Uso: ./scripts/import-to-green.sh <caminho-do-snapshot.sql>"
  exit 1
fi

echo "Alvo: DB_PROD_GREEN. Fonte: ${SNAPSHOT_FILE}"
echo "IMPORTANTE: O banco GREEN deve estar com o schema limpo antes desta operação."

# Comando do Wrangler para importar o arquivo SQL para o banco Green
wrangler d1 execute DB_PROD_GREEN --file=${SNAPSHOT_FILE}

if [ $? -eq 0 ]; then
  echo "--- SUCESSO: Importação para o banco GREEN concluída. ---"
else
  echo "--- FALHA CRÍTICA: Importação para o GREEN falhou! ---"
  exit 1
fi
