#!/bin/bash
echo "=== INICIANDO BATERIA DE TESTES MÓDULO 1 ==="

# Definir URL base (desenvolvimento local)
BASE_URL="http://localhost:5173"

echo " "
echo "=== TESTE 1: SCHEMA ==="
echo "Verificando se todas as tabelas foram criadas..."

echo " "
echo "=== TESTE 2: DADOS DE TESTE ==="
echo "Verificando se os dados de teste foram inseridos..."

echo " "
echo "=== TESTE 3: APIS (LEITURA) ==="
echo "Testando APIs de leitura..."
curl -s -w "GET Funcoes Status: %{http_code}\n" ${BASE_URL}/api/v2/funcoes > /dev/null
curl -s -w "GET Funcionarios Status: %{http_code}\n" ${BASE_URL}/api/v2/funcionarios > /dev/null

echo " "
echo "=== TESTE 4: HEALTH CHECK INICIAL ==="
echo "Testando health check..."
HEALTH_STATUS=$(curl -s ${BASE_URL}/api/v2/system/health | grep -o '"status":"[^"]*"' | cut -d'"' -f4)
echo "Health Status: ${HEALTH_STATUS}"

echo " "
echo "=== TESTE 5: INTEGRIDADE (HEALTH CHECK) ==="
echo "Verificando integridade referencial..."
curl -s ${BASE_URL}/api/v2/system/health | grep -o '"check":"referential_integrity_funcionario_funcao"[^}]*'

echo " "
echo "=== TESTE 6: CRUD COMPLETO (E VALIDAÇÃO DE INTEGRIDADE) ==="
echo "Criando nova função 'TESTE_FUNCAO'..."
curl -s -X POST ${BASE_URL}/api/v2/funcoes \
  -H "Content-Type: application/json" \
  -d '{"nome":"TESTE_FUNCAO","descricao":"Função de Teste","categoria":"TESTE"}' | head -c 100

echo ""
echo "Criando funcionário 'João Teste' com função válida..."
curl -s -X POST ${BASE_URL}/api/v2/funcionarios \
  -H "Content-Type: application/json" \
  -d '{"nome":"João Teste","matricula":"TST001","funcao":"TESTE_FUNCAO","email":"joao@teste.com"}' | head -c 100

echo ""
echo "=== TESTE 7: TESTE DE FALHA DE INTEGRIDADE (DEVE FALHAR 400) ==="
echo "Tentando criar funcionário com função INEXISTENTE..."
curl -s -w "Status de Falha Esperado: %{http_code}\n" -X POST ${BASE_URL}/api/v2/funcionarios \
  -H "Content-Type: application/json" \
  -d '{"nome":"Maria Falha","matricula":"FLH001","funcao":"FUNCAO_QUE_NAO_EXISTE","email":"maria@falha.com"}' > /dev/null

echo " "
echo "=== TESTE 8: HEALTH CHECK FINAL (DEVE CONTINUAR HEALTHY) ==="
FINAL_HEALTH_STATUS=$(curl -s ${BASE_URL}/api/v2/system/health | grep -o '"status":"[^"]*"' | cut -d'"' -f4)
echo "Final Health Status: ${FINAL_HEALTH_STATUS}"

echo " "
echo "=== BATERIA DE TESTES CONCLUÍDA ==="
