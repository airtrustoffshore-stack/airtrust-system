-- SCRIPT DE SINCRONIZAÇÃO PROD-DEV - AirTrust
-- Este script garante que produção tenha exatamente o mesmo schema de desenvolvimento
-- Executar em produção via: wrangler d1 execute airtrust-prod --file=sync-production-schema.sql

-- ==============================================
-- VERIFICAÇÃO E CORREÇÃO DE SCHEMA CRÍTICO
-- ==============================================

-- 1. Verificar se funcionarios tem deleted_at
-- Se não tiver, adicionar:
-- ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP;

-- 2. Verificar se funcoes tem deleted_at  
-- Se não tiver, adicionar:
-- ALTER TABLE funcoes ADD COLUMN deleted_at TIMESTAMP;

-- 3. Verificar se catalogo_treinamentos_v2 tem deleted_at
-- Se não tiver, adicionar:
-- ALTER TABLE catalogo_treinamentos_v2 ADD COLUMN deleted_at TIMESTAMP;

-- 4. Verificar se historico_certificacoes_v2 tem deleted_at
-- Se não tiver, adicionar:
-- ALTER TABLE historico_certificacoes_v2 ADD COLUMN deleted_at TIMESTAMP;

-- ==============================================
-- ÍNDICES PARA PERFORMANCE
-- ==============================================

CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at);
CREATE INDEX IF NOT EXISTS idx_funcionarios_matricula ON funcionarios(matricula) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_funcoes_deleted_at ON funcoes(deleted_at);
CREATE INDEX IF NOT EXISTS idx_catalogo_treinamentos_deleted_at ON catalogo_treinamentos_v2(deleted_at);
CREATE INDEX IF NOT EXISTS idx_historico_certificacoes_deleted_at ON historico_certificacoes_v2(deleted_at);

-- ==============================================
-- LIMPEZA DE DADOS INCONSISTENTES  
-- ==============================================

-- Garantir que deleted_at seja NULL ou timestamp válido
UPDATE funcionarios SET deleted_at = NULL WHERE deleted_at = '';
UPDATE funcoes SET deleted_at = NULL WHERE deleted_at = '';
UPDATE catalogo_treinamentos_v2 SET deleted_at = NULL WHERE deleted_at = '';
UPDATE historico_certificacoes_v2 SET deleted_at = NULL WHERE deleted_at = '';

-- ==============================================
-- VALIDAÇÃO PÓS-SINCRONIZAÇÃO
-- ==============================================

-- Verificar integridade referencial
-- SELECT COUNT(*) as funcionarios_inconsistentes 
-- FROM funcionarios f 
-- WHERE f.funcao NOT IN (SELECT nome FROM funcoes WHERE deleted_at IS NULL) 
-- AND f.deleted_at IS NULL;

-- Verificar soft delete funcionando
-- SELECT COUNT(*) as total_funcionarios, 
--        COUNT(CASE WHEN deleted_at IS NULL THEN 1 END) as ativos,
--        COUNT(CASE WHEN deleted_at IS NOT NULL THEN 1 END) as deletados
-- FROM funcionarios;

-- ==============================================
-- COMANDOS PARA EXECUTAR MANUALMENTE
-- ==============================================

-- Para verificar schema de uma tabela:
-- PRAGMA table_info(funcionarios);

-- Para verificar diferenças específicas:
-- SELECT sql FROM sqlite_master WHERE type='table' AND name='funcionarios';

-- Para backup antes da sincronização:
-- wrangler d1 backup create airtrust-prod --name "pre-schema-sync"

-- Para aplicar o script:
-- wrangler d1 execute airtrust-prod --file=sync-production-schema.sql

-- Para verificar resultado:
-- wrangler d1 execute airtrust-prod --command "SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL"
