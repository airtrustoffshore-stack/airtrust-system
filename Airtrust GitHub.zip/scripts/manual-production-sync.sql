-- COMANDOS MANUAIS PARA CORREÇÃO EM PRODUÇÃO
-- Execute um por vez usando: wrangler d1 execute airtrust --command "COMANDO"

-- 1. VERIFICAR SCHEMA ATUAL
-- wrangler d1 execute airtrust --command "PRAGMA table_info(funcionarios)"

-- 2. SE deleted_at NÃO EXISTIR, ADICIONAR:
-- wrangler d1 execute airtrust --command "ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP"

-- 3. CRIAR ÍNDICES PARA PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at);
CREATE INDEX IF NOT EXISTS idx_funcionarios_matricula ON funcionarios(matricula) WHERE deleted_at IS NULL;

-- 4. LIMPEZA DE DADOS INCONSISTENTES
UPDATE funcionarios SET deleted_at = NULL WHERE deleted_at = '';

-- 5. VERIFICAR SE FUNCIONOU
-- wrangler d1 execute airtrust --command "SELECT COUNT(*) as total, COUNT(CASE WHEN deleted_at IS NULL THEN 1 END) as ativos FROM funcionarios"

-- 6. TESTE DE EXCLUSÃO (OPCIONAL - para testar sem afetar dados reais)
-- INSERT INTO funcionarios (nome, funcao, matricula) VALUES ('TESTE DELETE', 'PILOTO', 'TEST999');
-- UPDATE funcionarios SET deleted_at = CURRENT_TIMESTAMP WHERE matricula = 'TEST999';
-- SELECT * FROM funcionarios WHERE matricula = 'TEST999';
