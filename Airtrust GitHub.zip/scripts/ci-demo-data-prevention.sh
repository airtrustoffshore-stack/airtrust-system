#!/bin/bash

# BLOQUEIO DEFINITIVO DE DADOS DE TESTE AIRTRUST
# Script obrigatório no CI/CD - ABORTARÁ publish/merge se detectar dados demo

echo "🔒 AIRTRUST DEMO DATA PREVENTION - Verificando dados de teste..."

# Nomes fictícios PROIBIDOS
FORBIDDEN_NAMES=(
  "Maria Oliveira Costa"
  "Ricardo Silva Santos" 
  "João Pedro Lima"
  "Ana Paula Ferreira"
  "Carlos Eduardo Souza"
  "funcionario_test"
  "teste_funcionario"
  "demo_user"
  "SGV-001"
  "mockFuncionarios"
  "exemploFuncionarios"
  "seedData"
  "devData"
  "populateDemo"
)

# Verificar arquivos fonte
echo "🔍 Verificando arquivos TypeScript, JavaScript e SQL..."

VIOLATIONS_FOUND=0

for name in "${FORBIDDEN_NAMES[@]}"; do
  echo "Verificando: $name"
  
  # Buscar em todos os arquivos de código, excluindo arquivos de controle
  MATCHES=$(grep -r -i "$name" ./src/ --include="*.ts" --include="*.tsx" --include="*.js" --include="*.sql" \
            --exclude="demo-data-blocker.ts" \
            --exclude="production-audit.ts" \
            2>/dev/null || true)
  
  # Filtrar matches que estão em contexto de array de strings de controle
  FILTERED_MATCHES=""
  if [ ! -z "$MATCHES" ]; then
    # Remover linhas que são arrays de controle (contém aspas e vírgulas)
    FILTERED_MATCHES=$(echo "$MATCHES" | grep -v -E "'\s*,\s*$|^\s*'.*',?\s*$" || true)
  fi
  
  if [ ! -z "$FILTERED_MATCHES" ]; then
    echo "❌ VIOLAÇÃO DETECTADA: '$name' encontrado em:"
    echo "$FILTERED_MATCHES"
    VIOLATIONS_FOUND=1
  fi
done

# Verificar SQL INSERT statements específicos
echo "🔍 Verificando INSERT statements com dados de teste..."

SQL_VIOLATIONS=$(grep -r -i "INSERT INTO funcionarios.*VALUES.*\('.*'," ./src/ --include="*.ts" --include="*.sql" 2>/dev/null | grep -i -E "(maria|ricardo|joão|ana|carlos|test|demo|mock)" || true)

if [ ! -z "$SQL_VIOLATIONS" ]; then
  echo "❌ VIOLAÇÃO SQL DETECTADA:"
  echo "$SQL_VIOLATIONS"
  VIOLATIONS_FOUND=1
fi

# Verificar arrays/objetos hardcoded
echo "🔍 Verificando arrays de exemplo no frontend..."

ARRAY_VIOLATIONS=$(grep -r -E "const\s+(exemplo|mock|demo).*funcionarios.*=" ./src/ --include="*.ts" --include="*.tsx" 2>/dev/null || true)

if [ ! -z "$ARRAY_VIOLATIONS" ]; then
  echo "❌ VIOLAÇÃO ARRAY DETECTADA:"
  echo "$ARRAY_VIOLATIONS"
  VIOLATIONS_FOUND=1
fi

# Resultado final
if [ $VIOLATIONS_FOUND -eq 1 ]; then
  echo ""
  echo "🚨 PUBLISH/MERGE ABORTADO! 🚨"
  echo "❌ Dados de teste/demo detectados no código"
  echo "❌ AirTrust Production Policy: ZERO dados fictícios permitidos"
  echo ""
  echo "🔧 AÇÕES NECESSÁRIAS:"
  echo "1. Remova todos os dados de teste listados acima"
  echo "2. Use apenas blank state ou dados importados pelo usuário"
  echo "3. Execute este script localmente até passar 100%"
  echo "4. Commit e push novamente"
  echo ""
  exit 1
else
  echo ""
  echo "✅ VERIFICAÇÃO APROVADA!"
  echo "✅ Nenhum dado de teste detectado"
  echo "✅ AirTrust ready for production"
  echo ""
  exit 0
fi
