#!/bin/bash
echo "--- INICIANDO EXPORTAÇÃO (BACKUP COMPLETO) DO BANCO DE PRODUÇÃO (BLUE) ---"

# Gerar um nome de arquivo único com timestamp
TIMESTAMP=$(date +"%Y%m%d-%H%M%S")
BACKUP_FILE="snapshot-prod-blue-${TIMESTAMP}.sql"

echo "Exportando DB_PROD_BLUE para ${BACKUP_FILE}..."

# Comando do Wrangler para exportar o banco de dados de produção (Blue)
# (Assumindo que o DB de produção 'Blue' está mapeado no wrangler.toml como 'DB_PROD_BLUE')
wrangler d1 export DB_PROD_BLUE --output=${BACKUP_FILE}

if [ $? -eq 0 ]; then
  echo "--- SUCESSO: Exportação concluída. Arquivo: ${BACKUP_FILE} ---"
  echo ${BACKUP_FILE} # Retorna o nome do arquivo para o script pai
else
  echo "--- FALHA CRÍTICA: Exportação do banco falhou! ---"
  exit 1
fi
