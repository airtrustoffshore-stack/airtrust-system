#!/bin/bash

# AirTrust CI/CD - Demo Data Prevention Script
# This script prevents deployment if demo data is detected

set -e

echo "🔍 AirTrust - Verificando dados demo/teste antes do deploy..."

# Define patterns to search for demo data
DEMO_PATTERNS=(
    "Maria Oliveira"
    "Ricardo Silva Santos" 
    "SGV-001"
    "funcionariosDemo"
    "demoData"
    "mockData"
    "seedData"
    "populateData"
    "testData"
    "sampleData"
    "João da Silva.*001"
    "Maria Santos.*002"
    "Pedro Costa.*003"
    "joao@empresa.com"
    "maria@empresa.com"
    "pedro@empresa.com"
    "RST001"
    "MFC002"
    "JPM003"
    "ricardo@airtrust.com"
    "maria@airtrust.com"
    "joao@airtrust.com"
)

# Define directories to check (exclude node_modules, cache, etc.)
CHECK_DIRS=("./src" "./scripts")

DEMO_DATA_FOUND=false

echo "📋 Verificando padrões de dados demo..."

for pattern in "${DEMO_PATTERNS[@]}"; do
    echo "  🔎 Buscando: $pattern"
    
    for dir in "${CHECK_DIRS[@]}"; do
        if [ -d "$dir" ]; then
            matches=$(grep -r -i "$pattern" "$dir" --include="*.ts" --include="*.tsx" --include="*.js" --include="*.json" --include="*.csv" --include="*.sql" 2>/dev/null | grep -v node_modules | grep -v "\.cache" | grep -v "\.bun" | grep -v "cleanupTestData" || true)
            
            if [ ! -z "$matches" ]; then
                echo "❌ DEMO DATA DETECTADO em $dir:"
                echo "$matches"
                DEMO_DATA_FOUND=true
            fi
        fi
    done
done

# Check for seed scripts/functions
echo "📋 Verificando scripts de seed..."

SEED_PATTERNS=(
    "\.seed\("
    "seedDatabase"
    "populateDatabase"
    "insertTestData"
    "createSampleData"
    "initializeWithDemo"
    "addDemoUsers"
    "generateMockData"
)

for pattern in "${SEED_PATTERNS[@]}"; do
    echo "  🔎 Buscando seed pattern: $pattern"
    
    matches=$(grep -r -E "$pattern" "./src" --include="*.ts" --include="*.tsx" --include="*.js" 2>/dev/null | grep -v node_modules | grep -v "\.cache" | grep -v "\.bun" || true)
    
    if [ ! -z "$matches" ]; then
        echo "❌ SEED SCRIPT DETECTADO:"
        echo "$matches"
        DEMO_DATA_FOUND=true
    fi
done

# Check for demo files
echo "📋 Verificando arquivos demo/teste..."

DEMO_FILES=(
    "*demo*"
    "*test*.csv"
    "*sample*"
    "*mock*"
    "*seed*"
    "funcionarios.json"
)

for file_pattern in "${DEMO_FILES[@]}"; do
    found_files=$(find . -name "$file_pattern" -not -path "./node_modules/*" -not -path "./.git/*" -not -path "./dist/*" -not -path "./build/*" -not -path "./.cache/*" -not -path "./.bun/*" -not -path "./scripts/ci-demo-data-check.sh" -not -path "./.github/workflows/demo-data-prevention.yml" 2>/dev/null || true)
    
    if [ ! -z "$found_files" ]; then
        echo "❌ ARQUIVOS DEMO DETECTADOS:"
        echo "$found_files"
        DEMO_DATA_FOUND=true
    fi
done

# Final result
if [ "$DEMO_DATA_FOUND" = true ]; then
    echo ""
    echo "❌ DEPLOY BLOQUEADO - DADOS DEMO/TESTE DETECTADOS"
    echo "🚫 Remova todos os dados demo antes de fazer deploy em produção"
    echo ""
    exit 1
else
    echo ""
    echo "✅ VERIFICAÇÃO APROVADA - Nenhum dado demo detectado"
    echo "🚀 Deploy pode prosseguir"
    echo ""
    exit 0
fi
