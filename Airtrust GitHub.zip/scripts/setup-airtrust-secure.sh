#!/bin/bash
# 🔐 SETUP AIRTRUST SECURE - Configuração inicial segura
# Prepara ambiente para deployment enterprise

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() {
  echo -e "${GREEN}[SETUP] $1${NC}"
}

info() {
  echo -e "${BLUE}[INFO] $1${NC}"
}

warn() {
  echo -e "${YELLOW}[WARNING] $1${NC}"
}

error() {
  echo -e "${RED}[ERROR] $1${NC}"
}

# Verificar pré-requisitos
check_prerequisites() {
  log "Verificando pré-requisitos..."
  
  # Verificar Node.js
  if ! command -v node &> /dev/null; then
    error "Node.js não encontrado. Instale Node.js 18+ primeiro."
    exit 1
  fi
  
  local node_version=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
  if [ "$node_version" -lt 18 ]; then
    error "Node.js versão 18+ necessária. Versão atual: $(node --version)"
    exit 1
  fi
  
  # Verificar npm
  if ! command -v npm &> /dev/null; then
    error "npm não encontrado."
    exit 1
  fi
  
  # Verificar se wrangler está disponível (opcional)
  if command -v wrangler &> /dev/null; then
    log "✅ Wrangler encontrado: $(wrangler --version)"
  else
    warn "⚠️ Wrangler não encontrado - instale com: npm install -g wrangler"
  fi
  
  log "✅ Pré-requisitos verificados"
}

# Instalar dependências
install_dependencies() {
  log "Instalando dependências do projeto..."
  
  if [ ! -f "package.json" ]; then
    error "package.json não encontrado. Execute este script na raiz do projeto."
    exit 1
  fi
  
  # Install dependencies
  npm install
  
  # Verificar se build funciona
  log "Testando build do projeto..."
  npm run build
  
  if [ $? -eq 0 ]; then
    log "✅ Build teste concluído com sucesso"
  else
    error "❌ Build teste falhou"
    exit 1
  fi
}

# Configurar scripts de deployment
setup_deployment_scripts() {
  log "Configurando scripts de deployment..."
  
  # Tornar scripts executáveis
  chmod +x scripts/deploy-airtrust.sh 2>/dev/null || warn "scripts/deploy-airtrust.sh não encontrado"
  chmod +x scripts/export-prod-blue.sh 2>/dev/null || warn "scripts/export-prod-blue.sh não encontrado"
  chmod +x scripts/import-to-green.sh 2>/dev/null || warn "scripts/import-to-green.sh não encontrado"
  
  # Criar arquivo de ambiente inicial
  if [ ! -f ".current_env" ]; then
    echo "blue" > .current_env
    log "✅ Ambiente inicial configurado: blue"
  fi
  
  # Criar diretório para backups
  mkdir -p backups
  log "✅ Diretório de backups criado"
}

# Configurar ambientes de desenvolvimento
setup_development_environment() {
  log "Configurando ambiente de desenvolvimento..."
  
  # Criar arquivo de configuração local se não existir
  if [ ! -f ".env.local" ]; then
    cat > .env.local << EOF
# Configurações locais do AirTrust
NODE_ENV=development
ENVIRONMENT=development

# Database
DATABASE_NAME=airtrust-dev

# Features
ENABLE_DEBUG=true
ENABLE_VERBOSE_LOGGING=true

# Deployment
DEPLOYMENT_MODE=single
CURRENT_ENVIRONMENT=blue
EOF
    log "✅ Arquivo .env.local criado"
  fi
  
  # Adicionar .env.local ao .gitignore se não estiver
  if [ -f ".gitignore" ] && ! grep -q ".env.local" .gitignore; then
    echo "" >> .gitignore
    echo "# Environment local" >> .gitignore
    echo ".env.local" >> .gitignore
    echo ".current_env" >> .gitignore
    echo "backups/" >> .gitignore
    log "✅ .gitignore atualizado"
  fi
}

# Verificar configuração de segurança
verify_security_config() {
  log "Verificando configuração de segurança..."
  
  # Verificar se arquivos de configuração existem
  if [ -f "src/config/secure-deployment.ts" ]; then
    log "✅ Configuração de deployment seguro encontrada"
  else
    warn "⚠️ Configuração de deployment seguro não encontrada"
  fi
  
  # Verificar se serviços de monitoramento existem
  if [ -f "src/worker/services/deployment-monitor.ts" ]; then
    log "✅ Serviço de monitoramento encontrado"
  else
    warn "⚠️ Serviço de monitoramento não encontrado"
  fi
  
  # Verificar estrutura de pastas críticas
  local critical_dirs=("src/worker/api" "src/worker/services" "src/config" "scripts")
  for dir in "${critical_dirs[@]}"; do
    if [ -d "$dir" ]; then
      log "✅ Diretório crítico encontrado: $dir"
    else
      warn "⚠️ Diretório crítico não encontrado: $dir"
    fi
  done
}

# Executar testes básicos
run_basic_tests() {
  log "Executando testes básicos..."
  
  # Verificar se TypeScript compila
  if command -v npx &> /dev/null; then
    info "Verificando TypeScript..."
    npx tsc --noEmit || warn "⚠️ Verificação TypeScript falhou"
  fi
  
  # Executar testes se disponíveis
  if npm run test --if-present 2>/dev/null; then
    log "✅ Testes executados com sucesso"
  else
    warn "⚠️ Testes não disponíveis ou falharam"
  fi
  
  # Executar linting se disponível
  if npm run lint --if-present 2>/dev/null; then
    log "✅ Linting executado com sucesso"
  else
    warn "⚠️ Linting não disponível"
  fi
}

# Criar documentação de uso
create_usage_docs() {
  log "Criando documentação de uso..."
  
  cat > DEPLOYMENT_GUIDE.md << 'EOF'
# 🚀 Guia de Deployment AirTrust

## Comandos Básicos

### Deployment Normal
```bash
# Deploy automático (blue-green)
./scripts/deploy-airtrust.sh deploy

# Verificar status
./scripts/deploy-airtrust.sh status

# Rollback de emergência
./scripts/deploy-airtrust.sh rollback
```

### Backup e Restore
```bash
# Criar backup manual
./scripts/deploy-airtrust.sh backup

# Exportar dados de produção
./scripts/export-prod-blue.sh

# Importar para ambiente verde
./scripts/import-to-green.sh backup-file.sql
```

### Monitoramento
```bash
# Validar sistema atual
./scripts/deploy-airtrust.sh validate

# Ver logs de deployment
curl https://airtrust.app/api/v2/system/health
```

## Estrutura de Ambientes

- **Development**: Desenvolvimento local
- **Blue**: Ambiente de produção ativo
- **Green**: Ambiente de produção standby

## Processo de Deployment

1. **Backup**: Sistema cria backup automático
2. **Build**: Compila e valida código
3. **Deploy**: Publica no ambiente standby
4. **Validate**: Executa health checks
5. **Switch**: Muda tráfego para novo ambiente
6. **Monitor**: Monitora estabilidade

## Rollback de Emergência

```bash
# Rollback imediato (30-60 segundos)
./scripts/deploy-airtrust.sh rollback
```

## Troubleshooting

### Deploy Falhou
1. Verificar logs: `./scripts/deploy-airtrust.sh status`
2. Validar build: `npm run build`
3. Verificar conectividade: `curl https://airtrust.app/health`

### Sistema Degradado
1. Executar health check: `/api/v2/system/health`
2. Verificar métricas de performance
3. Considerar rollback se necessário

## Contatos de Emergência

- **Tech Lead**: [contato-tech-lead]
- **DevOps**: [contato-devops]
- **Plantão**: [contato-plantao]
EOF
  
  log "✅ Documentação criada: DEPLOYMENT_GUIDE.md"
}

# Função principal
main() {
  log "🔐 SETUP AIRTRUST SECURE - Iniciando configuração..."
  
  # Executar todas as etapas
  check_prerequisites
  install_dependencies
  setup_deployment_scripts
  setup_development_environment
  verify_security_config
  run_basic_tests
  create_usage_docs
  
  log "🎉 SETUP CONCLUÍDO COM SUCESSO!"
  log ""
  log "📋 Próximos passos:"
  log "   1. Revisar configurações em .env.local"
  log "   2. Configurar credenciais do Cloudflare (se necessário)"
  log "   3. Executar primeiro deployment: ./scripts/deploy-airtrust.sh deploy"
  log "   4. Ler documentação: DEPLOYMENT_GUIDE.md"
  log ""
  log "🔧 Comandos úteis:"
  log "   - Status: ./scripts/deploy-airtrust.sh status"
  log "   - Deploy: ./scripts/deploy-airtrust.sh deploy"
  log "   - Ajuda: ./scripts/deploy-airtrust.sh help"
  log ""
  log "✅ Sistema pronto para deployment enterprise-grade!"
}

# Executar setup principal
main "$@"
