#!/bin/bash

# AIRTRUST PRODUCTION VALIDATION - ZERO DEMO DATA TOLERANCE
# Script para validar que sistema está 100% limpo de dados de teste

echo "🔒 VALIDANDO AIRTRUST PRODUCTION CLEAN..."

# Executar verificação de código
echo "1️⃣ Executando verificação de código..."
/app/scripts/ci-demo-data-prevention.sh

if [ $? -ne 0 ]; then
  echo "❌ Falha na verificação de código"
  exit 1
fi

# Executar build para verificar erros
echo "2️⃣ Verificando build..."
cd /app
npm run build > /tmp/build.log 2>&1

if [ $? -ne 0 ]; then
  echo "❌ Build falhou:"
  cat /tmp/build.log
  exit 1
fi

echo "✅ Build OK"

# Verificar se servidor está rodando
echo "3️⃣ Verificando servidor..."
curl -s http://localhost:5173/ > /dev/null

if [ $? -ne 0 ]; then
  echo "⚠️ Servidor não está rodando na porta 5173"
else
  echo "✅ Servidor respondendo"
fi

echo ""
echo "🎯 AIRTRUST PRODUCTION VALIDATION COMPLETA"
echo "✅ Sistema validado para produção"
echo "✅ Zero dados de teste detectados"
echo "✅ Build limpo"
echo ""
