#!/bin/bash
# 🚀 DEPLOY AIRTRUST - Sistema Blue-Green Enterprise
# Script de deployment automatizado com segurança máxima

set -e # Exit on error

# Configurações
PROJECT_NAME="airtrust"
BLUE_SUBDOMAIN="blue-airtrust"
GREEN_SUBDOMAIN="green-airtrust"
MAIN_DOMAIN="airtrust.app"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Função de log
log() {
  echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
  echo -e "${RED}[ERROR] $1${NC}"
}

warn() {
  echo -e "${YELLOW}[WARNING] $1${NC}"
}

info() {
  echo -e "${BLUE}[INFO] $1${NC}"
}

# Função para detectar ambiente ativo
detect_active_environment() {
  log "Detectando ambiente ativo..."
  
  # Verificar variável de ambiente primeiro
  if [ ! -z "$CURRENT_ENV" ]; then
    echo "$CURRENT_ENV"
    return
  fi
  
  # Verificar qual worker está respondendo (simulação)
  # Em produção real, verificaria DNS records
  if [ -f ".current_env" ]; then
    cat .current_env
  else
    echo "blue" # Default para blue
  fi
}

# Função para backup de dados
create_backup() {
  local env=$1
  log "Criando backup do ambiente $env..."
  
  local timestamp=$(date +%Y%m%d-%H%M%S)
  local backup_file="backup-${env}-${timestamp}.sql"
  
  # Backup usando wrangler D1
  if command -v wrangler &> /dev/null; then
    log "Executando backup D1..."
    wrangler d1 backup create ${PROJECT_NAME}-${env} \
      --name "pre-deployment-${timestamp}" || true
    
    # Export para arquivo local (se possível)
    wrangler d1 export ${PROJECT_NAME}-${env} --output="${backup_file}" 2>/dev/null || {
      warn "Backup D1 export falhou, continuando deployment..."
    }
  else
    warn "Wrangler não encontrado, pulando backup D1"
  fi
  
  log "Backup criado: ${backup_file}"
  echo "${backup_file}"
}

# Função para validar deployment
validate_deployment() {
  local subdomain=$1
  local max_attempts=5
  local attempt=1
  
  log "Validando deployment em ${subdomain}..."
  
  while [ $attempt -le $max_attempts ]; do
    info "Tentativa ${attempt}/${max_attempts}..."
    
    # Construir URL de health check
    local health_url=""
    if [[ $subdomain == *".workers.dev" ]]; then
      health_url="https://${subdomain}/api/v2/system/health"
    else
      health_url="https://${subdomain}.workers.dev/api/v2/system/health"
    fi
    
    # Fazer health check
    local response=$(curl -s -w "%{http_code}" -o /tmp/health_response "$health_url" --connect-timeout 10 --max-time 30 2>/dev/null || echo "000")
    
    if [ "$response" = "200" ] || [ "$response" = "206" ]; then
      if [ -f /tmp/health_response ]; then
        local status=$(cat /tmp/health_response | jq -r '.overall_status' 2>/dev/null || echo "UNKNOWN")
        if [ "$status" = "HEALTHY" ] || [ "$status" = "DEGRADED" ]; then
          log "✅ Deployment validado - Sistema: $status"
          return 0
        else
          warn "Sistema não está saudável: $status"
        fi
      else
        log "✅ Health check passou (status code: $response)"
        return 0
      fi
    else
      warn "Health check falhou - HTTP $response"
    fi
    
    if [ $attempt -lt $max_attempts ]; then
      warn "Aguardando 10s antes da próxima tentativa..."
      sleep 10
    fi
    
    attempt=$((attempt + 1))
  done
  
  error "❌ Validação falhou após $max_attempts tentativas"
  return 1
}

# Função para switch de ambiente (simulação)
switch_environment() {
  local target_env=$1
  log "Mudando ambiente ativo para $target_env..."
  
  # Salvar ambiente atual
  echo "$target_env" > .current_env
  
  # Em produção real, aqui faria:
  # - Update DNS records via Cloudflare API
  # - Update load balancer routing
  # - Update CDN configuration
  
  log "✅ Ambiente ativo alterado para: $target_env"
  log "⏱️ Em produção real, aguarde 2-5 minutos para propagação DNS"
}

# Função de rollback
rollback_deployment() {
  local current_env=$1
  local target_env=$2
  
  error "🚨 INICIANDO ROLLBACK..."
  
  # Voltar para ambiente anterior
  switch_environment $target_env
  
  # Validar rollback
  if validate_deployment "${target_env}-airtrust"; then
    log "✅ Rollback concluído para $target_env"
  else
    error "❌ Rollback falhou! Intervenção manual necessária"
    exit 1
  fi
}

# Função para build do projeto
build_project() {
  log "📦 Fazendo build do projeto..."
  
  # Verificar se package.json existe
  if [ ! -f "package.json" ]; then
    error "package.json não encontrado!"
    exit 1
  fi
  
  # Install dependencies se necessário
  if [ ! -d "node_modules" ]; then
    log "Instalando dependências..."
    npm install
  fi
  
  # Build
  npm run build
  if [ $? -ne 0 ]; then
    error "Build falhou"
    exit 1
  fi
  
  log "✅ Build concluído com sucesso"
}

# Função principal de deployment
deploy() {
  local target_env=""
  local current_env=$(detect_active_environment)
  
  log "🚀 Iniciando deployment AirTrust..."
  log "Ambiente atual detectado: $current_env"
  
  # Determinar ambiente de destino
  if [ "$current_env" = "blue" ]; then
    target_env="green"
  else
    target_env="blue"
  fi
  
  log "🎯 Fazendo deployment para ambiente: $target_env"
  
  # 1. Criar backup
  local backup_file=$(create_backup $target_env)
  
  # 2. Build do projeto
  build_project
  
  # 3. Deploy para ambiente target
  log "🚀 Fazendo deploy para ${target_env}..."
  
  # Configurar variáveis de ambiente para deployment
  export ENVIRONMENT=$target_env
  export NODE_ENV="production"
  
  # Deploy usando wrangler (simulação - adaptar conforme configuração real)
  if command -v wrangler &> /dev/null; then
    # Tentar deploy com wrangler
    if wrangler deploy --name "${PROJECT_NAME}-${target_env}" --compatibility-date="2023-12-01"; then
      log "✅ Deploy via wrangler concluído"
    else
      warn "Deploy via wrangler falhou, tentando deploy simples..."
      wrangler deploy || {
        error "Deploy falhou completamente"
        exit 1
      }
    fi
  else
    warn "Wrangler não encontrado, usando deploy simulado..."
    sleep 3 # Simular tempo de deploy
    log "✅ Deploy simulado concluído"
  fi
  
  # 4. Validar deployment
  if ! validate_deployment "${target_env}-airtrust"; then
    error "Validação falhou - iniciando rollback"
    rollback_deployment $current_env $current_env
    exit 1
  fi
  
  # 5. Switch environment
  switch_environment $target_env
  
  # 6. Validação final
  log "⏱️ Aguardando estabilização (15s)..."
  sleep 15
  
  # Tentar validação final
  if validate_deployment $MAIN_DOMAIN; then
    log "🎉 DEPLOYMENT CONCLUÍDO COM SUCESSO!"
    log "✅ Sistema ativo: ${target_env}"
    log "✅ URL principal: https://${MAIN_DOMAIN}"
    log "✅ URL de rollback: https://${current_env}-airtrust.workers.dev"
  else
    warn "⚠️ Deployment concluído mas validação final falhou"
    log "Verifique manualmente: https://${MAIN_DOMAIN}"
    log "Para rollback: $0 rollback"
  fi
  
  # Log final do deployment
  log "📊 Deployment Report:"
  log "   - Ambiente anterior: $current_env"
  log "   - Ambiente atual: $target_env"
  log "   - Backup criado: $backup_file"
  log "   - Timestamp: $(date)"
}

# Função para status do sistema
show_status() {
  local current_env=$(detect_active_environment)
  log "📊 Status do Sistema AirTrust"
  log "   - Ambiente atual: $current_env"
  log "   - URL principal: https://$MAIN_DOMAIN"
  log "   - URL blue: https://${BLUE_SUBDOMAIN}.workers.dev"
  log "   - URL green: https://${GREEN_SUBDOMAIN}.workers.dev"
  
  # Tentar health check
  info "Verificando saúde do sistema..."
  if validate_deployment $MAIN_DOMAIN; then
    log "✅ Sistema operacional"
  else
    warn "⚠️ Sistema com problemas"
  fi
}

# Menu de opções
case "${1:-deploy}" in
  "deploy")
    deploy
    ;;
  "status")
    show_status
    ;;
  "rollback")
    current_env=$(detect_active_environment)
    if [ "$current_env" = "blue" ]; then
      rollback_deployment blue green
    else
      rollback_deployment green blue
    fi
    ;;
  "validate")
    if validate_deployment $MAIN_DOMAIN; then
      log "✅ Sistema validado com sucesso"
    else
      error "❌ Validação falhou"
      exit 1
    fi
    ;;
  "backup")
    current_env=$(detect_active_environment)
    backup_file=$(create_backup $current_env)
    log "Backup criado: $backup_file"
    ;;
  "help")
    echo "AirTrust Deployment System"
    echo ""
    echo "Uso: $0 [comando]"
    echo ""
    echo "Comandos disponíveis:"
    echo "  deploy     - Fazer deployment blue-green automático"
    echo "  status     - Mostrar status atual do sistema"
    echo "  rollback   - Fazer rollback para ambiente anterior"
    echo "  validate   - Validar saúde do sistema atual"
    echo "  backup     - Criar backup manual do ambiente atual"
    echo "  help       - Mostrar esta ajuda"
    echo ""
    echo "Exemplos:"
    echo "  $0 deploy          # Deploy automático"
    echo "  $0 status          # Ver status"
    echo "  $0 rollback        # Rollback de emergência"
    ;;
  *)
    error "Comando inválido: $1"
    echo "Use '$0 help' para ver comandos disponíveis"
    exit 1
    ;;
esac
