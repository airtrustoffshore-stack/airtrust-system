-- 🚨 CORREÇÃO EMERGENCIAL PRODUÇÃO - Execute estes comandos em sequência
-- APLIQUE IMEDIATAMENTE EM PRODUÇÃO usando wrangler d1 execute

-- ========================================
-- PASSO 1: BACKUP DE SEGURANÇA
-- ========================================
-- wrangler d1 backup create airtrust --name "emergency-fix-$(date +%Y%m%d-%H%M%S)"

-- ========================================
-- PASSO 2: VERIFICAR SCHEMA ATUAL
-- ========================================
-- wrangler d1 execute airtrust --command "PRAGMA table_info(funcionarios)"

-- ========================================
-- PASSO 3: ADICIONAR CAMPO deleted_at SE NÃO EXISTIR
-- ========================================
-- Execute APENAS se deleted_at não aparecer no schema:
-- wrangler d1 execute airtrust --command "ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP"

-- ========================================
-- PASSO 4: CORRIGIR OUTRAS TABELAS
-- ========================================
-- Verificar e corrigir funcoes:
-- wrangler d1 execute airtrust --command "PRAGMA table_info(funcoes)"
-- Se não tiver deleted_at:
-- wrangler d1 execute airtrust --command "ALTER TABLE funcoes ADD COLUMN deleted_at TIMESTAMP"

-- Verificar e corrigir catalogo_treinamentos_v2:
-- wrangler d1 execute airtrust --command "PRAGMA table_info(catalogo_treinamentos_v2)"
-- Se não tiver deleted_at:
-- wrangler d1 execute airtrust --command "ALTER TABLE catalogo_treinamentos_v2 ADD COLUMN deleted_at TIMESTAMP"

-- Verificar e corrigir historico_certificacoes_v2:
-- wrangler d1 execute airtrust --command "PRAGMA table_info(historico_certificacoes_v2)"
-- Se não tiver deleted_at:
-- wrangler d1 execute airtrust --command "ALTER TABLE historico_certificacoes_v2 ADD COLUMN deleted_at TIMESTAMP"

-- ========================================
-- PASSO 5: CRIAR ÍNDICES DE PERFORMANCE
-- ========================================
CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at);
CREATE INDEX IF NOT EXISTS idx_funcionarios_matricula ON funcionarios(matricula) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_funcoes_deleted_at ON funcoes(deleted_at);
CREATE INDEX IF NOT EXISTS idx_catalogo_treinamentos_deleted_at ON catalogo_treinamentos_v2(deleted_at);
CREATE INDEX IF NOT EXISTS idx_historico_certificacoes_deleted_at ON historico_certificacoes_v2(deleted_at);

-- ========================================
-- PASSO 6: LIMPEZA DE DADOS INCONSISTENTES
-- ========================================
UPDATE funcionarios SET deleted_at = NULL WHERE deleted_at = '';
UPDATE funcoes SET deleted_at = NULL WHERE deleted_at = '';
UPDATE catalogo_treinamentos_v2 SET deleted_at = NULL WHERE deleted_at = '';
UPDATE historico_certificacoes_v2 SET deleted_at = NULL WHERE deleted_at = '';

-- ========================================
-- PASSO 7: VALIDAÇÃO PÓS-CORREÇÃO
-- ========================================
-- Verificar contagem após correção:
SELECT 
  COUNT(*) as total_funcionarios,
  COUNT(CASE WHEN deleted_at IS NULL THEN 1 END) as ativos,
  COUNT(CASE WHEN deleted_at IS NOT NULL THEN 1 END) as deletados
FROM funcionarios;

-- Verificar schema final:
-- wrangler d1 execute airtrust --command "PRAGMA table_info(funcionarios)"

-- ========================================
-- COMANDOS PARA EXECUTAR EM SEQUÊNCIA:
-- ========================================

-- 1. Backup:
-- wrangler d1 backup create airtrust --name "emergency-fix-$(date +%Y%m%d-%H%M%S)"

-- 2. Verificar schema:
-- wrangler d1 execute airtrust --command "PRAGMA table_info(funcionarios)"

-- 3. Se deleted_at não existir, adicionar:
-- wrangler d1 execute airtrust --command "ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP"

-- 4. Aplicar este arquivo SQL:
-- wrangler d1 execute airtrust --file=scripts/emergency-production-fix.sql

-- 5. Redeploy após correção:
-- wrangler deploy

-- 6. Teste final:
-- curl -s https://pwfo2d76v2u7u.mocha.app/api/v2/system/health

-- ========================================
-- VALIDAÇÃO FINAL - EXECUTE PARA CONFIRMAR:
-- ========================================
-- wrangler d1 execute airtrust --command "SELECT id, nome, deleted_at FROM funcionarios ORDER BY id DESC LIMIT 5"
