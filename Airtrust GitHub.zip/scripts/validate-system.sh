#!/bin/bash
# AirTrust - Validação do Sistema
echo "🔍 === VALIDAÇÃO AIRTRUST ==="

# Testar endpoints principais
echo "1. Testando endpoints..."
curl -s http://localhost:8787/api/funcionarios > /dev/null && echo "✅ Funcionários OK" || echo "❌ Funcionários FAIL"
curl -s http://localhost:8787/api/catalogo-treinamentos > /dev/null && echo "✅ Treinamentos OK" || echo "❌ Treinamentos FAIL"
curl -s http://localhost:8787/api/certificacoes > /dev/null && echo "✅ Certificações OK" || echo "❌ Certificações FAIL"

# Testar problemas conhecidos
echo ""
echo "2. Testando problemas críticos..."
ID_TEST=$(curl -s http://localhost:8787/api/debug/test-id-generation 2>/dev/null)
if [[ $ID_TEST =~ ^[0-9]{5}-[A-Z]+-[0-9]{4}-[0-9]{2}$ ]]; then
    echo "✅ Formato ID correto"
else
    echo "❌ Formato ID incorreto - CORRIGIR!"
fi

echo ""
echo "🚨 MOCHA: Corrija TODOS os ❌ antes de prosseguir!"
