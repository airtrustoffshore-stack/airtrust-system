#!/bin/bash
# 📋 PRODUCTION CHECKLIST - Verificação antes do deploy
# Baseado no docs/PRODUCTION_READY_CHECKLIST.md

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Contadores
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0

log() {
  echo -e "${GREEN}[CHECKLIST] $1${NC}"
}

info() {
  echo -e "${BLUE}[INFO] $1${NC}"
}

warn() {
  echo -e "${YELLOW}[WARNING] $1${NC}"
  WARNING_CHECKS=$((WARNING_CHECKS + 1))
}

error() {
  echo -e "${RED}[FAILED] $1${NC}"
  FAILED_CHECKS=$((FAILED_CHECKS + 1))
}

pass() {
  echo -e "${GREEN}[PASSED] $1${NC}"
  PASSED_CHECKS=$((PASSED_CHECKS + 1))
}

check() {
  TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
  echo -n "Verificando: $1... "
}

# 1. TESTES AUTOMATIZADOS (QA)
check_tests() {
  log "📊 1. VERIFICANDO TESTES AUTOMATIZADOS"
  
  # Verificar se tests passam
  check "Testes unitários"
  if npm run test --if-present >/dev/null 2>&1; then
    pass "Testes unitários executados com sucesso"
  else
    warn "Testes unitários não executados ou falharam"
  fi
  
  # Verificar coverage se disponível
  check "Coverage de testes"
  if npm run test:coverage --if-present >/dev/null 2>&1; then
    pass "Coverage de testes verificado"
  else
    warn "Coverage de testes não disponível"
  fi
  
  # Verificar E2E tests se disponíveis
  check "Testes E2E"
  if command -v cypress &> /dev/null && [ -d "cypress" ]; then
    pass "Cypress configurado para testes E2E"
  else
    warn "Testes E2E não configurados"
  fi
}

# 2. ACESSIBILIDADE (A11Y)
check_accessibility() {
  log "♿ 2. VERIFICANDO ACESSIBILIDADE"
  
  check "Estrutura HTML semântica"
  if [ -f "src/react-app/components" ]; then
    pass "Componentes React organizados"
  else
    warn "Estrutura de componentes não encontrada"
  fi
  
  check "Lucide React para ícones"
  if grep -q "lucide-react" package.json; then
    pass "Lucide React configurado para ícones acessíveis"
  else
    warn "Sistema de ícones acessíveis não configurado"
  fi
}

# 3. PERFORMANCE BENCHMARKS (SRE)
check_performance() {
  log "⚡ 3. VERIFICANDO PERFORMANCE"
  
  check "Build otimizado"
  if npm run build >/dev/null 2>&1; then
    pass "Build executa sem erros"
  else
    error "Build falha - crítico para produção"
  fi
  
  check "TypeScript compilação"
  if npx tsc --noEmit >/dev/null 2>&1; then
    pass "TypeScript compila sem erros"
  else
    error "Erros de TypeScript encontrados"
  fi
  
  check "Lighthouse config"
  if [ -f "lighthouse.config.js" ]; then
    pass "Configuração Lighthouse presente"
  else
    warn "Configuração Lighthouse não encontrada"
  fi
}

# 4. DOCUMENTAÇÃO (Engineering)
check_documentation() {
  log "📚 4. VERIFICANDO DOCUMENTAÇÃO"
  
  check "README atualizado"
  if [ -f "README.md" ] && [ -s "README.md" ]; then
    pass "README.md presente e não vazio"
  else
    warn "README.md ausente ou vazio"
  fi
  
  check "OpenAPI spec"
  if [ -f "openapi.yaml" ]; then
    pass "Documentação OpenAPI presente"
  else
    warn "Documentação da API não encontrada"
  fi
  
  check "Checklist de produção"
  if [ -f "docs/PRODUCTION_READY_CHECKLIST.md" ]; then
    pass "Checklist de produção documentado"
  else
    warn "Checklist de produção não encontrado"
  fi
  
  check "Guia de deployment"
  if [ -f "DEPLOYMENT_GUIDE.md" ]; then
    pass "Guia de deployment presente"
  else
    warn "Guia de deployment não encontrado"
  fi
}

# 5. FEATURE FLAGS (DevOps)
check_feature_flags() {
  log "🚩 5. VERIFICANDO FEATURE FLAGS"
  
  check "Sistema de feature flags"
  if [ -f "src/react-app/utils/featureFlags.ts" ]; then
    pass "Sistema de feature flags implementado"
  else
    warn "Feature flags não implementados"
  fi
  
  check "Configuração de deployment"
  if [ -f "src/config/secure-deployment.ts" ]; then
    pass "Configuração de deployment seguro presente"
  else
    error "Configuração de deployment não encontrada"
  fi
}

# 6. MONITORAMENTO CONTÍNUO (SRE)
check_monitoring() {
  log "📊 6. VERIFICANDO MONITORAMENTO"
  
  check "Health check endpoint"
  if grep -q "health" src/worker/api/v2/system.ts; then
    pass "Endpoint de health check implementado"
  else
    error "Health check não implementado"
  fi
  
  check "Serviço de monitoramento"
  if [ -f "src/worker/services/deployment-monitor.ts" ]; then
    pass "Serviço de monitoramento de deployment presente"
  else
    warn "Monitoramento de deployment não implementado"
  fi
  
  check "Auditoria avançada"
  if grep -q "auditoria_avancada_v2" src/worker/api/v2/system.ts; then
    pass "Sistema de auditoria implementado"
  else
    warn "Sistema de auditoria não encontrado"
  fi
}

# 7. PEER REVIEW PROCESS (Gestão)
check_peer_review() {
  log "👥 7. VERIFICANDO PROCESSO DE REVIEW"
  
  check "Template de Pull Request"
  if [ -f ".github/pull_request_template.md" ]; then
    pass "Template de PR configurado"
  else
    warn "Template de Pull Request não encontrado"
  fi
  
  check "ESLint configurado"
  if [ -f "eslint.config.js" ] && grep -q "eslint" package.json; then
    pass "ESLint configurado"
  else
    warn "ESLint não configurado adequadamente"
  fi
}

# 8. TESTES DE SEGURANÇA (SecOps)
check_security() {
  log "🔒 8. VERIFICANDO SEGURANÇA"
  
  check "Middleware de autenticação"
  if [ -f "src/worker/middleware/auth.ts" ]; then
    pass "Middleware de autenticação implementado"
  else
    error "Sistema de autenticação não implementado"
  fi
  
  check "Middleware de autorização"
  if [ -f "src/worker/middleware/authorize.ts" ]; then
    pass "Sistema de autorização presente"
  else
    warn "Sistema de autorização não encontrado"
  fi
  
  check "Validação de entrada"
  if [ -f "src/worker/services/validation.ts" ]; then
    pass "Serviço de validação implementado"
  else
    warn "Validação de entrada não implementada"
  fi
  
  check "Auditoria de dependências"
  if npm audit --audit-level=high >/dev/null 2>&1; then
    pass "Nenhuma vulnerabilidade crítica em dependências"
  else
    warn "Vulnerabilidades encontradas nas dependências"
  fi
}

# 9. COBERTURA DE TESTE (QA)
check_test_coverage() {
  log "📊 9. VERIFICANDO COBERTURA DE TESTE"
  
  check "Configuração de testes"
  if [ -f "vitest.config.ts" ]; then
    pass "Vitest configurado"
  else
    warn "Framework de testes não configurado"
  fi
  
  check "Testes de setup"
  if [ -f "src/test/setup.ts" ]; then
    pass "Setup de testes presente"
  else
    warn "Setup de testes não encontrado"
  fi
}

# 10. RETROSPECTIVA (Gestão Ágil)
check_retrospective() {
  log "🔄 10. VERIFICANDO DOCUMENTAÇÃO DE RETROSPECTIVA"
  
  check "Template de retrospectiva"
  if [ -f "docs/RETROSPECTIVE_TEMPLATE.md" ]; then
    pass "Template de retrospectiva presente"
  else
    warn "Template de retrospectiva não encontrado"
  fi
  
  check "Relatórios de módulos"
  local reports=$(find . -name "relatorio-final-modulo*.json" | wc -l)
  if [ $reports -gt 0 ]; then
    pass "Relatórios de módulos encontrados ($reports)"
  else
    warn "Relatórios de retrospectiva não encontrados"
  fi
}

# Função principal
main() {
  log "🚀 INICIANDO CHECKLIST DE PRODUÇÃO AIRTRUST"
  log "Baseado em: docs/PRODUCTION_READY_CHECKLIST.md"
  log ""
  
  # Executar todas as verificações
  check_tests
  check_accessibility
  check_performance
  check_documentation
  check_feature_flags
  check_monitoring
  check_peer_review
  check_security
  check_test_coverage
  check_retrospective
  
  # Resumo final
  log ""
  log "📊 RESUMO DO CHECKLIST"
  log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  
  info "Total de verificações: $TOTAL_CHECKS"
  pass "Verificações aprovadas: $PASSED_CHECKS"
  warn "Avisos: $WARNING_CHECKS"
  error "Falhas: $FAILED_CHECKS"
  
  log ""
  
  # Calcular percentual de aprovação
  local approval_rate=0
  if [ $TOTAL_CHECKS -gt 0 ]; then
    approval_rate=$((PASSED_CHECKS * 100 / TOTAL_CHECKS))
  fi
  
  # Determinar status geral
  if [ $FAILED_CHECKS -eq 0 ] && [ $approval_rate -ge 80 ]; then
    log "🎉 STATUS: APROVADO PARA PRODUÇÃO ($approval_rate% aprovação)"
    log "✅ Sistema pronto para deployment enterprise"
    exit 0
  elif [ $FAILED_CHECKS -eq 0 ] && [ $approval_rate -ge 60 ]; then
    warn "⚠️ STATUS: APROVADO COM RESTRIÇÕES ($approval_rate% aprovação)"
    warn "Corrija os avisos antes do próximo deployment"
    exit 0
  else
    error "❌ STATUS: NÃO APROVADO PARA PRODUÇÃO ($approval_rate% aprovação)"
    error "Corrija as falhas críticas antes do deployment"
    
    if [ $FAILED_CHECKS -gt 0 ]; then
      log ""
      error "FALHAS CRÍTICAS ENCONTRADAS:"
      error "- Execute 'npm run build' e corrija erros"
      error "- Implemente sistemas de segurança obrigatórios"
      error "- Configure monitoramento adequado"
    fi
    
    exit 1
  fi
}

# Executar checklist
main "$@"
