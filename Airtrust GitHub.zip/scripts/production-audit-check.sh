#!/bin/bash

# AirTrust - Production Database Audit Script
# Verifies production database is clean of demo/test data

set -e

echo "🔍 AirTrust - Auditoria pós-deploy da base de dados..."

# Function to check for demo data in database
check_database_demo_data() {
    echo "📋 Verificando dados demo na base..."
    
    # Note: This script should be adapted to your database connection method
    # For now, it provides the SQL queries that should be run
    
    echo "🔍 Execute as seguintes queries para verificar dados demo:"
    echo ""
    
    echo "-- Verificar funcionários com dados demo:"
    echo "SELECT id, nome, matricula, email FROM funcionarios WHERE"
    echo "  nome LIKE '%Maria Oliveira%' OR"
    echo "  nome LIKE '%Ricardo Silva Santos%' OR" 
    echo "  nome LIKE '%João da Silva%' OR"
    echo "  nome LIKE '%Maria Santos%' OR"
    echo "  nome LIKE '%Pedro Costa%' OR"
    echo "  matricula IN ('RST001', 'MFC002', 'JPM003', '001', '002', '003') OR"
    echo "  email LIKE '%@airtrust.com' OR"
    echo "  email LIKE '%@empresa.com' OR"
    echo "  telefone LIKE '%TEST%';"
    echo ""
    
    echo "-- Verificar treinamentos com códigos demo:"
    echo "SELECT id, codigo, nome FROM catalogo_treinamentos_v2 WHERE"
    echo "  codigo LIKE '%SGV-001%' OR"
    echo "  codigo LIKE '%DEMO%' OR"
    echo "  codigo LIKE '%TEST%' OR"
    echo "  nome LIKE '%teste%' OR"
    echo "  nome LIKE '%demo%';"
    echo ""
    
    echo "-- Verificar certificações com dados demo:"
    echo "SELECT id, funcionario_matricula, treinamento_id, instrutor FROM historico_certificacoes_v2 WHERE"
    echo "  funcionario_matricula IN ('RST001', 'MFC002', 'JPM003', '001', '002', '003') OR"
    echo "  instrutor LIKE '%João Silva%' OR"
    echo "  instrutor LIKE '%Maria Costa%' OR"
    echo "  instrutor LIKE '%Dr. Pedro%';"
    echo ""
    
    echo "-- Verificar certificações v3 com dados demo:"
    echo "SELECT id, funcionario_matricula, treinamento_codigo, instrutor FROM certificacoes_v3 WHERE"
    echo "  funcionario_matricula IN ('RST001', 'MFC002', 'JPM003', '001', '002', '003') OR"
    echo "  instrutor LIKE '%João Silva%' OR"
    echo "  instrutor LIKE '%Maria Costa%' OR"
    echo "  instrutor LIKE '%Dr. Pedro%';"
    echo ""
    
    echo "⚠️  IMPORTANTE: Se alguma query retornar resultados, há dados demo na base!"
    echo "🧹 Execute o script de limpeza antes de prosseguir"
}

# Function to generate cleanup script if demo data found
generate_cleanup_script() {
    echo "📋 Gerando script de limpeza de emergência..."
    
    cat > "./scripts/emergency-demo-cleanup.sql" << 'EOF'
-- AirTrust - Emergency Demo Data Cleanup Script
-- Execute ONLY if demo data is detected in production

BEGIN TRANSACTION;

-- Remove funcionários demo
DELETE FROM funcionarios WHERE 
  nome LIKE '%Maria Oliveira%' OR
  nome LIKE '%Ricardo Silva Santos%' OR
  nome LIKE '%João da Silva%' OR
  nome LIKE '%Maria Santos%' OR
  nome LIKE '%Pedro Costa%' OR
  matricula IN ('RST001', 'MFC002', 'JPM003', '001', '002', '003') OR
  email LIKE '%@airtrust.com' OR
  email LIKE '%@empresa.com' OR
  telefone LIKE '%TEST%';

-- Remove certificações vinculadas a funcionários demo  
DELETE FROM historico_certificacoes_v2 WHERE
  funcionario_matricula IN ('RST001', 'MFC002', 'JPM003', '001', '002', '003') OR
  instrutor LIKE '%João Silva%' OR
  instrutor LIKE '%Maria Costa%' OR
  instrutor LIKE '%Dr. Pedro%';

DELETE FROM certificacoes_v3 WHERE
  funcionario_matricula IN ('RST001', 'MFC002', 'JPM003', '001', '002', '003') OR
  instrutor LIKE '%João Silva%' OR
  instrutor LIKE '%Maria Costa%' OR
  instrutor LIKE '%Dr. Pedro%';

-- Remove compliance status de funcionários demo
DELETE FROM compliance_status_v2 WHERE
  funcionario_id IN (
    SELECT id FROM funcionarios WHERE matricula IN ('RST001', 'MFC002', 'JPM003', '001', '002', '003')
  );

-- Remove treinamentos demo
DELETE FROM catalogo_treinamentos_v2 WHERE
  codigo LIKE '%SGV-001%' OR
  codigo LIKE '%DEMO%' OR
  codigo LIKE '%TEST%' OR
  nome LIKE '%teste%' OR
  nome LIKE '%demo%';

-- Log cleanup operation
INSERT INTO auditoria_limpeza_dados (
  operacao, tabela_afetada, criterio_remocao, 
  usuario_responsavel, observacoes
) VALUES (
  'LIMPEZA_DEMO_EMERGENCIA', 'MULTIPLAS', 
  'Remoção de dados demo detectados pós-deploy',
  'SCRIPT_EMERGENCIA', 
  'Limpeza automática executada devido detecção de dados demo em produção'
);

COMMIT;
EOF

    echo "✅ Script de limpeza gerado: ./scripts/emergency-demo-cleanup.sql"
    echo "🚨 Execute apenas se dados demo forem detectados!"
}

# Main execution
echo "🚀 Iniciando auditoria pós-deploy..."

check_database_demo_data
generate_cleanup_script

echo ""
echo "📊 AUDITORIA CONCLUÍDA"
echo "📋 Próximos passos:"
echo "  1. Execute as queries de verificação"
echo "  2. Se dados demo forem encontrados, use o script de limpeza"
echo "  3. Documente os resultados"
echo ""

# Create audit log
TIMESTAMP=$(date -u +"%Y-%m-%d %H:%M:%S UTC")
echo "[$TIMESTAMP] Production audit script executed - Check queries provided" >> ./audit-log.txt

echo "✅ Log de auditoria atualizado: ./audit-log.txt"
