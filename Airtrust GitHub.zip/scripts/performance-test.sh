#!/bin/bash
echo "=== INICIANDO TESTES DE PERFORMANCE AIRTRUST ==="

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

BASE_URL="http://localhost:5173"
REPORT_DIR="performance-reports"
TIMESTAMP=$(date +"%Y%m%d-%H%M%S")

# Criar diretório de relatórios
mkdir -p ${REPORT_DIR}

echo -e "${YELLOW}🔍 Verificando se o servidor está rodando...${NC}"
if ! curl -s --fail ${BASE_URL} > /dev/null; then
    echo -e "${RED}❌ Servidor não está rodando em ${BASE_URL}${NC}"
    echo -e "${YELLOW}💡 Execute 'npm run dev' primeiro${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Servidor está online${NC}"

echo ""
echo -e "${YELLOW}⚡ TESTE 1: LIGHTHOUSE PERFORMANCE SCORE${NC}"
echo "Executando auditoria Lighthouse..."

if command -v lighthouse &> /dev/null; then
    # Testar página principal
    lighthouse ${BASE_URL} \
        --config-path=./lighthouse.config.js \
        --output=json \
        --output-path=${REPORT_DIR}/lighthouse-dashboard-${TIMESTAMP}.json \
        --chrome-flags="--headless --no-sandbox"
    
    # Extrair score de performance
    PERF_SCORE=$(cat ${REPORT_DIR}/lighthouse-dashboard-${TIMESTAMP}.json | jq '.categories.performance.score * 100' | cut -d'.' -f1)
    
    if [ "$PERF_SCORE" -ge 90 ]; then
        echo -e "${GREEN}✅ Lighthouse Performance Score: ${PERF_SCORE}/100 (EXCELENTE)${NC}"
    elif [ "$PERF_SCORE" -ge 70 ]; then
        echo -e "${YELLOW}⚠️  Lighthouse Performance Score: ${PERF_SCORE}/100 (BOM)${NC}"
    else
        echo -e "${RED}❌ Lighthouse Performance Score: ${PERF_SCORE}/100 (PRECISA MELHORIA)${NC}"
    fi
    
    # Testar página de funcionários
    lighthouse ${BASE_URL}/funcionarios \
        --config-path=./lighthouse.config.js \
        --output=html \
        --output-path=${REPORT_DIR}/lighthouse-funcionarios-${TIMESTAMP}.html \
        --chrome-flags="--headless --no-sandbox"
    
    echo -e "${GREEN}📊 Relatórios Lighthouse salvos em ${REPORT_DIR}/${NC}"
else
    echo -e "${RED}❌ Lighthouse não instalado. Execute: npm install -g lighthouse${NC}"
fi

echo ""
echo -e "${YELLOW}🚀 TESTE 2: CARGA DE TESTES (Apache Bench)${NC}"
echo "Testando APIs principais com 100 requests simultâneas..."

if command -v ab &> /dev/null; then
    # Teste API Funcionários
    echo "Testing GET /api/v2/funcionarios..."
    ab -n 100 -c 10 -g ${REPORT_DIR}/api-funcionarios-${TIMESTAMP}.tsv ${BASE_URL}/api/v2/funcionarios > ${REPORT_DIR}/ab-funcionarios-${TIMESTAMP}.txt
    
    # Extrair tempo médio de resposta
    AVG_TIME=$(grep "Time per request:" ${REPORT_DIR}/ab-funcionarios-${TIMESTAMP}.txt | head -n1 | awk '{print $4}')
    
    if (( $(echo "$AVG_TIME < 200" | bc -l) )); then
        echo -e "${GREEN}✅ API Funcionários: ${AVG_TIME}ms (< 200ms target)${NC}"
    else
        echo -e "${RED}❌ API Funcionários: ${AVG_TIME}ms (> 200ms target)${NC}"
    fi
    
    # Teste API System Health
    echo "Testing GET /api/v2/system/health..."
    ab -n 100 -c 10 ${BASE_URL}/api/v2/system/health > ${REPORT_DIR}/ab-health-${TIMESTAMP}.txt
    
    # Verificar taxa de sucesso
    SUCCESS_RATE=$(grep "Non-2xx responses:" ${REPORT_DIR}/ab-health-${TIMESTAMP}.txt | awk '{print $3}')
    if [ -z "$SUCCESS_RATE" ]; then
        SUCCESS_RATE=0
    fi
    
    TOTAL_REQUESTS=100
    SUCCESS_COUNT=$((TOTAL_REQUESTS - SUCCESS_RATE))
    SUCCESS_PERCENT=$((SUCCESS_COUNT * 100 / TOTAL_REQUESTS))
    
    if [ "$SUCCESS_PERCENT" -ge 99 ]; then
        echo -e "${GREEN}✅ Taxa de Sucesso: ${SUCCESS_PERCENT}% (≥99% target)${NC}"
    else
        echo -e "${RED}❌ Taxa de Sucesso: ${SUCCESS_PERCENT}% (<99% target)${NC}"
    fi
    
else
    echo -e "${RED}❌ Apache Bench não instalado. Execute: apt-get install apache2-utils${NC}"
    
    echo -e "${YELLOW}🔄 Executando teste alternativo com curl...${NC}"
    
    # Teste simples com curl
    START_TIME=$(date +%s%N)
    for i in {1..10}; do
        curl -s ${BASE_URL}/api/v2/funcionarios > /dev/null
    done
    END_TIME=$(date +%s%N)
    
    TOTAL_TIME=$(((END_TIME - START_TIME) / 1000000)) # Convert to milliseconds
    AVG_TIME=$((TOTAL_TIME / 10))
    
    echo -e "${GREEN}📊 Teste básico - Tempo médio: ${AVG_TIME}ms para 10 requests${NC}"
fi

echo ""
echo -e "${YELLOW}📈 TESTE 3: BUNDLE SIZE ANALYSIS${NC}"
echo "Analisando tamanho do bundle..."

if [ -d "dist/client" ]; then
    BUNDLE_SIZE=$(du -sh dist/client | cut -f1)
    echo -e "${GREEN}📦 Tamanho do Bundle: ${BUNDLE_SIZE}${NC}"
    
    # Listar maiores arquivos
    echo -e "${YELLOW}📊 Top 5 maiores arquivos:${NC}"
    find dist/client -type f -exec du -sh {} + | sort -hr | head -5
else
    echo -e "${YELLOW}⚠️  Bundle não encontrado. Execute 'npm run build' primeiro${NC}"
fi

echo ""
echo -e "${YELLOW}🎯 TESTE 4: CORE WEB VITALS SIMULATION${NC}"
echo "Simulando métricas de Core Web Vitals..."

# Teste simulado de carregamento
curl -w "@curl-format.txt" -s -o /dev/null ${BASE_URL} 2>/dev/null || {
    echo "time_namelookup:  %{time_namelookup}s" > curl-format.txt
    echo "time_connect:     %{time_connect}s" >> curl-format.txt  
    echo "time_appconnect:  %{time_appconnect}s" >> curl-format.txt
    echo "time_pretransfer: %{time_pretransfer}s" >> curl-format.txt
    echo "time_redirect:    %{time_redirect}s" >> curl-format.txt
    echo "time_starttransfer: %{time_starttransfer}s" >> curl-format.txt
    echo "time_total:       %{time_total}s" >> curl-format.txt
    
    curl -w "@curl-format.txt" -s -o /dev/null ${BASE_URL}
    rm curl-format.txt
}

echo ""
echo -e "${GREEN}🎉 TESTES DE PERFORMANCE CONCLUÍDOS${NC}"
echo -e "${YELLOW}📁 Relatórios salvos em: ${REPORT_DIR}/${NC}"
echo ""
echo -e "${YELLOW}📋 RESUMO DOS TARGETS:${NC}"
echo "✅ Lighthouse Performance Score: ≥90"
echo "✅ API Response Time: <200ms"
echo "✅ Success Rate: ≥99%"
echo "✅ Bundle Size: Monitorado"

# Cleanup
[ -f curl-format.txt ] && rm curl-format.txt

echo ""
echo "=== PERFORMANCE TEST COMPLETED ==="
