const GITHUB_CONFIG = {
  owner: 'airtrustoffshore-stack',
  repo: 'airtrust-storage',
  token: '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',
  branch: 'main',
  apiUrl: 'https://api.github.com'
};

export default GITHUB_CONFIG;
