import z from "zod";

/**
 * Types shared between the client and server go here.
 *
 * For example, we can add zod schemas for API input validation, and derive types from them:
 *
 * export const TodoSchema = z.object({
 *   id: z.number(),
 *   name: z.string(),
 *   completed: z.number().int(), // 0 or 1
 * })
 *
 * export type TodoType = z.infer<typeof TodoSchema>;
 */

// ✅ SCHEMA COMPLETO PARA FUNCIONÁRIOS
export const FuncionarioCompleteSchema = z.object({
  // Campos obrigatórios
  nome: z.string().min(1, "Nome é obrigatório"),
  matricula: z.string().min(1, "Matrícula é obrigatória"),
  funcao: z.string().min(1, "Função é obrigatória"),
  
  // Dados pessoais
  guerra: z.string().optional(),
  cpf: z.string().optional(),
  data_nascimento: z.string().optional(),
  data_admissao: z.string().optional(),
  
  // Contato
  email: z.string().email().optional().or(z.literal("")),
  telefone: z.string().optional(),
  
  // Profissional
  base: z.string().optional(),
  contrato: z.string().optional(),
  status: z.enum(["ATIVO", "INATIVO", "LICENCA"]).default("ATIVO"),
  aeronave_principal: z.string().optional(),
  anv: z.string().optional(),
  
  // Códigos regulamentares
  codigo_anac: z.string().optional(),
  codigo_canac: z.string().optional(),
  codigo_sispat: z.string().optional(),
  codigo_prestserv: z.string().optional(),
  licenca_aeronautica: z.string().optional(),
  
  // Exames e certificações médicas
  cma_numero: z.string().optional(),
  cma_data_vencimento: z.string().optional(),
  cma_status: z.string().optional(),
  aso_data_vencimento: z.string().optional(),
  
  // ICAO
  nivel_icao: z.string().optional(),
  nivel_icao_data_vencimento: z.string().optional(),
  nivel_icao_status: z.string().optional(),
  
  // Flags
  is_instrutor: z.number().int().min(0).max(1).default(0),
  is_checador: z.number().int().min(0).max(1).default(0),
  
  // Meta
  avatar: z.string().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional()
});

export type FuncionarioCompleto = z.infer<typeof FuncionarioCompleteSchema>;

// ✅ MAPEAMENTO DE HEADERS CSV PARA CAMPOS DO BANCO
export const CSV_FIELD_MAPPING: Record<string, string> = {
  // Nome e identificação
  "nome": "nome",
  "nome_completo": "nome",
  "funcionario": "nome",
  "guerra": "guerra",
  "nome_guerra": "guerra",
  "matricula": "matricula",
  "numero_matricula": "matricula",
  "mat": "matricula",
  "cpf": "cpf",
  "documento": "cpf",
  
  // Contato
  "email": "email",
  "e-mail": "email",
  "endereco_email": "email",
  "telefone": "telefone",
  "fone": "telefone",
  "celular": "telefone",
  
  // Profissional
  "funcao": "funcao",
  "cargo": "funcao",
  "posicao": "funcao",
  "base": "base",
  "local": "base",
  "cidade": "base",
  "contrato": "contrato",
  "tipo_contrato": "contrato",
  "status": "status",
  "situacao": "status",
  "anv": "anv",
  "aeronave": "anv",
  "aeronave_principal": "aeronave_principal",
  
  // Datas
  "data_nascimento": "data_nascimento",
  "nascimento": "data_nascimento",
  "dt_nascimento": "data_nascimento",
  "data_admissao": "data_admissao",
  "admissao": "data_admissao",
  "dt_admissao": "data_admissao",
  
  // Códigos regulamentares
  "codigo_anac": "codigo_anac",
  "anac": "codigo_anac",
  "cod_anac": "codigo_anac",
  "codigo_canac": "codigo_canac",
  "canac": "codigo_canac",
  "cod_canac": "codigo_canac",
  "codigo_sispat": "codigo_sispat",
  "sispat": "codigo_sispat",
  "cod_sispat": "codigo_sispat",
  "codigo_prestserv": "codigo_prestserv",
  "prestserv": "codigo_prestserv",
  "prestador": "codigo_prestserv",
  "cod_prestserv": "codigo_prestserv",
  "licenca_aeronautica": "licenca_aeronautica",
  "licenca": "licenca_aeronautica",
  "lic_aeronautica": "licenca_aeronautica",
  
  // CMA
  "cma_numero": "cma_numero",
  "numero_cma": "cma_numero",
  "num_cma": "cma_numero",
  "cma": "cma_numero",
  "cma_data_vencimento": "cma_data_vencimento",
  "vencimento_cma": "cma_data_vencimento",
  "validade_cma": "cma_data_vencimento",
  
  // ASO
  "aso_data_vencimento": "aso_data_vencimento",
  "vencimento_aso": "aso_data_vencimento",
  "validade_aso": "aso_data_vencimento",
  "aso": "aso_data_vencimento",
  
  // ICAO
  "nivel_icao": "nivel_icao",
  "icao": "nivel_icao",
  "proficiencia": "nivel_icao",
  "nivel_icao_data_vencimento": "nivel_icao_data_vencimento",
  "vencimento_icao": "nivel_icao_data_vencimento",
  "validade_icao": "nivel_icao_data_vencimento",
};

// ✅ CAMPOS OBRIGATÓRIOS PARA VALIDAÇÃO
export const CAMPOS_OBRIGATORIOS = ["nome", "matricula"];

// ✅ CAMPOS DE DATA PARA CONVERSÃO AUTOMÁTICA
export const CAMPOS_DATA = [
  "data_nascimento",
  "data_admissao", 
  "cma_data_vencimento",
  "aso_data_vencimento",
  "nivel_icao_data_vencimento"
];

// ✅ VALORES PADRÃO PARA STATUS
export const STATUS_VALIDOS = ["ATIVO", "INATIVO", "LICENCA"];
export const STATUS_MAPPING: Record<string, string> = {
  "ativo": "ATIVO",
  "ativa": "ATIVO",
  "inativo": "INATIVO",
  "inativa": "INATIVO",
  "licenca": "LICENCA",
  "licença": "LICENCA",
  "afastado": "LICENCA",
  "afastada": "LICENCA"
};
