import { Context } from 'hono';

export const validateReferentialIntegrity = async (c: Context) => {
  const db = c.env.DB;
  const violations = [];

  try {
    // Verificar integridade referencial Funcionário <-> Função
    const result = await db.prepare(`
      SELECT COUNT(f.id) as count 
      FROM funcionarios f 
      WHERE f.funcao NOT IN (SELECT nome FROM funcoes WHERE deleted_at IS NULL) 
      AND f.deleted_at IS NULL
    `).first();
    
    const invalidCount = result ? result.count : 0;
    if (invalidCount > 0) {
      violations.push({
        type: 'referential_integrity',
        table: 'funcionarios',
        field: 'funcao',
        count: invalidCount,
        message: `Found ${invalidCount} funcionarios with invalid 'funcao'`
      });
    }

  } catch (error) {
    violations.push({
      type: 'validation_error',
      message: (error as Error).message
    });
  }

  return violations;
};
