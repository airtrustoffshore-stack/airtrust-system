import { Context } from 'hono';

export class ComplianceService {
  /**
   * Recalcula o status de compliance para todos os funcionários (SIMPLIFICADO: Todos os itens do catálogo)
   */
  static async recalculateAllCompliance(c: Context) {
    const db = c.env.DB;
    let processed = 0;
    let updated = 0;
    
    try {
      // LÓGICA SIMPLIFICADA: Processar TODOS os itens do catálogo (incluindo CMA/ASO/ICAO)
      const combinacoesTreinamentos = await db.prepare(`
        SELECT DISTINCT f.id as funcionario_id, t.id as treinamento_id, t.nome as treinamento_nome, t.categoria
        FROM funcionarios f
        CROSS JOIN catalogo_treinamentos_v2 t
        WHERE f.deleted_at IS NULL 
        AND t.deleted_at IS NULL 
        AND t.ativo = 1
      `).all();
      
      for (const combo of (combinacoesTreinamentos.results as any[])) {
        processed++;
        
        // Buscar a certificação mais recente ativa para esta combinação
        const ultimaCertificacao = await db.prepare(`
          SELECT id, data_conclusao, data_vencimento
          FROM historico_certificacoes_v2
          WHERE funcionario_id = ? AND treinamento_id = ? 
          AND status = 'ATIVO' AND deleted_at IS NULL
          ORDER BY data_conclusao DESC
          LIMIT 1
        `).bind(combo.funcionario_id, combo.treinamento_id).first();
        
        // Calcular status e dias para vencimento
        let status = 'PENDENTE';
        let diasParaVencimento = null;
        let dataUltimaCertificacao = null;
        let dataVencimento = null;
        let historicoCertificacaoId = null;
        
        if (ultimaCertificacao) {
          dataUltimaCertificacao = ultimaCertificacao.data_conclusao;
          dataVencimento = ultimaCertificacao.data_vencimento;
          historicoCertificacaoId = ultimaCertificacao.id;
          
          if (dataVencimento) {
            const hoje = new Date();
            const vencimento = new Date(dataVencimento);
            diasParaVencimento = Math.ceil((vencimento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
            
            if (diasParaVencimento < 0) {
              status = 'VENCIDO';
            } else if (diasParaVencimento <= 30) {
              status = 'VENCENDO';
            } else {
              status = 'EM_DIA';
            }
          } else {
            status = 'EM_DIA'; // Certificação sem vencimento
          }
        }
        
        // Determinar tipo do item baseado na categoria
        let itemType = 'TREINAMENTO';
        if (combo.categoria === 'LICENCA_MEDICA') {
          itemType = combo.treinamento_nome.includes('CMA') ? 'CMA' : 'ASO';
        } else if (combo.categoria === 'PROFICIENCIA') {
          itemType = 'ICAO';
        }
        
        // Atualizar ou inserir o registro de compliance
        await this.upsertComplianceRecord(db, {
          funcionario_id: combo.funcionario_id,
          treinamento_id: combo.treinamento_id,
          item_type: itemType,
          item_name: combo.treinamento_nome,
          status,
          data_ultima_certificacao: dataUltimaCertificacao,
          data_vencimento: dataVencimento,
          dias_para_vencimento: diasParaVencimento,
          historico_certificacao_id: historicoCertificacaoId
        });
        updated++;
      }
      
      console.log(`✅ COMPLIANCE_SIMPLIFICADO_RECALCULATED: Processed ${processed}, Updated ${updated}`);
      
      return {
        success: true,
        processed,
        updated,
        timestamp: new Date().toISOString(),
        message: 'Motor de compliance simplificado - todos os itens processados via catálogo'
      };
    } catch (error) {
      console.error('❌ COMPLIANCE_SIMPLIFICADO_ERROR:', error);
      throw error;
    }
  }
  
  
  
  /**
   * Helper: Insere ou atualiza registro de compliance
   */
  private static async upsertComplianceRecord(db: any, data: any) {
    // Construir WHERE clause baseado no tipo
    let whereClause = '';
    let whereParams = [];
    
    // Use treinamento_id para todos os tipos (CMA=-1, ASO=-2, Treinamentos=ID real)
    whereClause = 'funcionario_id = ? AND treinamento_id = ?';
    whereParams = [data.funcionario_id, data.treinamento_id];
    
    const existingRecord = await db.prepare(`
      SELECT id FROM compliance_status_v2 
      WHERE ${whereClause}
    `).bind(...whereParams).first();
    
    if (existingRecord) {
      // Atualizar registro existente
      await db.prepare(`
        UPDATE compliance_status_v2 
        SET status = ?, data_ultima_certificacao = ?, data_vencimento = ?,
            dias_para_vencimento = ?, historico_certificacao_id = ?,
            item_name = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(
        data.status,
        data.data_ultima_certificacao,
        data.data_vencimento,
        data.dias_para_vencimento,
        data.historico_certificacao_id,
        data.item_name,
        existingRecord.id
      ).run();
    } else {
      // Inserir novo registro
      await db.prepare(`
        INSERT INTO compliance_status_v2 (
          funcionario_id, treinamento_id, item_type, item_name, status, 
          data_ultima_certificacao, data_vencimento, dias_para_vencimento, 
          historico_certificacao_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        data.funcionario_id,
        data.treinamento_id,
        data.item_type,
        data.item_name,
        data.status,
        data.data_ultima_certificacao,
        data.data_vencimento,
        data.dias_para_vencimento,
        data.historico_certificacao_id
      ).run();
    }
  }
  
  /**
   * Calcula compliance para um funcionário específico
   */
  static async calculateFuncionarioCompliance(c: Context, funcionarioId: number) {
    const db = c.env.DB;
    
    // Buscar todos os treinamentos obrigatórios
    const treinamentos = await db.prepare(`
      SELECT id FROM catalogo_treinamentos_v2 
      WHERE deleted_at IS NULL AND ativo = 1
    `).all();
    
    for (const treinamento of (treinamentos.results as any[])) {
      // Buscar última certificação
      await db.prepare(`
        SELECT id, data_conclusao, data_vencimento
        FROM historico_certificacoes_v2
        WHERE funcionario_id = ? AND treinamento_id = ? 
        AND status = 'ATIVO' AND deleted_at IS NULL
        ORDER BY data_conclusao DESC
        LIMIT 1
      `).bind(funcionarioId, treinamento.id).first();
      
      // Lógica similar ao método anterior...
      // (implementar se necessário para casos específicos)
    }
  }
}
