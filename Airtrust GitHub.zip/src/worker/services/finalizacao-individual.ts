/**
 * ⚠️ PADRÃO BRASILEIRO OBRIGATÓRIO - AIRTRUST ⚠️
 * 
 * Serviço para Finalização Individual de Treinamentos por Tripulante
 * 
 * Características obrigatórias:
 * ✅ Datas: SEMPRE dd/mm/aaaa (nunca mm/dd/yyyy ou yyyy-mm-dd)
 * ✅ Controle individual: Cada tripulante tem progresso independente
 * ✅ Certificação automática: Gerada quando completar todas as sessões
 * ✅ Auditoria completa: Rastreamento de todas as ações
 */

interface ProgressoTreinamento {
  id: number;
  colaborador_id: number;
  treinamento_id: number;
  sessoes_concluidas: number;
  total_sessoes_necessarias: number;
  status_treinamento: string;
  data_inicio: string;
  data_conclusao?: string;
  certificacao_gerada_id?: number;
}

interface ParticipanteSessao {
  id: number;
  sessao_id: number;
  colaborador_id: number;
  treinamento_id: number;
  funcao_na_sessao: string;
  sessao_numero: number;
  total_sessoes_treinamento: number;
  status_individual: string;
  conceito_individual?: string;
  data_conclusao_individual?: string;
  colaborador_nome?: string;
  colaborador_matricula?: string;
  sessao_uuid?: string;
}

export class FinalizacaoIndividualService {
  
  /**
   * Processar aprovação individual de um participante
   */
  static async processarAprovacaoIndividual(
    sessaoParticipanteId: number, 
    conceito: 'APROVADO' | 'REPROVADO', 
    instrutorId: number,
    db: any,
    observacoes?: string
  ): Promise<ParticipanteSessao> {
    
    // Buscar participante completo
    const participante = await db.prepare(`
      SELECT 
        sp.*,
        ss.sessao_uuid,
        f.nome as colaborador_nome, 
        f.matricula as colaborador_matricula,
        ct.codigo as treinamento_codigo,
        ct.nome as treinamento_nome
      FROM sessao_participantes sp
      JOIN sessoes_simulador ss ON sp.sessao_id = ss.id
      JOIN funcionarios f ON sp.colaborador_id = f.id
      JOIN catalogo_treinamentos_v2 ct ON sp.treinamento_id = ct.id
      WHERE sp.id = ?
    `).bind(sessaoParticipanteId).first();
    
    if (!participante) {
      throw new Error('Participante não encontrado');
    }
    
    // Verificar se já foi processado
    if (participante.status_individual !== 'PENDENTE') {
      throw new Error(`Participante já foi ${participante.status_individual.toLowerCase()}`);
    }
    
    // 1. Atualizar status individual do participante
    await db.prepare(`
      UPDATE sessao_participantes 
      SET 
        status_individual = ?, 
        conceito_individual = ?, 
        data_conclusao_individual = CURRENT_TIMESTAMP,
        observacoes_individuais = ?
      WHERE id = ?
    `).bind(
      conceito === 'APROVADO' ? 'APROVADO' : 'REPROVADO',
      conceito,
      observacoes || null,
      sessaoParticipanteId
    ).run();
    
    // 2. Se aprovado, atualizar progresso do treinamento
    if (conceito === 'APROVADO') {
      await this.atualizarProgressoTreinamento(
        participante.colaborador_id,
        participante.treinamento_id,
        instrutorId,
        db
      );
    } else {
      // Se reprovado, registrar na auditoria
      await this.registrarReprovacao(participante, instrutorId, db, observacoes);
    }
    
    return {
      ...participante,
      status_individual: conceito === 'APROVADO' ? 'APROVADO' : 'REPROVADO',
      conceito_individual: conceito,
      data_conclusao_individual: new Date().toISOString()
    };
  }
  
  /**
   * Atualizar progresso individual do treinamento
   */
  static async atualizarProgressoTreinamento(
    colaboradorId: number,
    treinamentoId: number,
    instrutorId: number,
    db: any
  ): Promise<void> {
    
    // Buscar ou criar progresso
    let progresso = await db.prepare(`
      SELECT * FROM progresso_treinamento_individual 
      WHERE colaborador_id = ? AND treinamento_id = ?
    `).bind(colaboradorId, treinamentoId).first();
    
    if (!progresso) {
      // Buscar total de sessões necessárias do treinamento
      const totalSessoes = await this.obterTotalSessoesNecessarias(treinamentoId, db);
      
      // Criar progresso inicial
      const resultado = await db.prepare(`
        INSERT INTO progresso_treinamento_individual 
        (colaborador_id, treinamento_id, total_sessoes_necessarias, sessoes_concluidas)
        VALUES (?, ?, ?, 1)
      `).bind(colaboradorId, treinamentoId, totalSessoes).run();
      
      progresso = {
        id: resultado.meta.last_row_id,
        colaborador_id: colaboradorId,
        treinamento_id: treinamentoId,
        sessoes_concluidas: 1,
        total_sessoes_necessarias: totalSessoes,
        status_treinamento: 'EM_ANDAMENTO'
      };
    } else {
      // Incrementar sessões concluídas
      const novasSessoesCompletas = progresso.sessoes_concluidas + 1;
      
      await db.prepare(`
        UPDATE progresso_treinamento_individual 
        SET sessoes_concluidas = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(novasSessoesCompletas, progresso.id).run();
      
      progresso.sessoes_concluidas = novasSessoesCompletas;
    }
    
    // Verificar se completou o treinamento
    if (progresso.sessoes_concluidas >= progresso.total_sessoes_necessarias) {
      await this.finalizarTreinamentoCompleto(
        progresso,
        instrutorId,
        db
      );
    }
  }
  
  /**
   * Finalizar treinamento quando todas as sessões forem completadas
   */
  static async finalizarTreinamentoCompleto(
    progresso: ProgressoTreinamento,
    instrutorId: number,
    db: any
  ): Promise<void> {
    
    // Marcar treinamento como concluído
    await db.prepare(`
      UPDATE progresso_treinamento_individual 
      SET 
        status_treinamento = 'CONCLUIDO', 
        data_conclusao = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(progresso.id).run();
    
    // Gerar certificação individual
    const certificacao = await this.gerarCertificacaoIndividual(
      progresso.colaborador_id,
      progresso.treinamento_id,
      instrutorId,
      db
    );
    
    // Vincular certificação ao progresso
    if (certificacao.id) {
      await db.prepare(`
        UPDATE progresso_treinamento_individual 
        SET certificacao_gerada_id = ?
        WHERE id = ?
      `).bind(certificacao.id, progresso.id).run();
    }
    
    // Notificar conclusão
    await this.notificarConclusaoTreinamento(
      progresso.colaborador_id,
      certificacao,
      db
    );
  }
  
  /**
   * Gerar certificação individual
   */
  static async gerarCertificacaoIndividual(
    colaboradorId: number,
    treinamentoId: number,
    instrutorId: number,
    db: any
  ): Promise<any> {
    
    // Buscar dados completos
    const colaborador = await db.prepare(`
      SELECT nome, matricula FROM funcionarios WHERE id = ?
    `).bind(colaboradorId).first();
    
    const treinamento = await db.prepare(`
      SELECT codigo, nome FROM catalogo_treinamentos_v2 WHERE id = ?
    `).bind(treinamentoId).first();
    
    const instrutor = await db.prepare(`
      SELECT nome, matricula FROM funcionarios WHERE id = ?
    `).bind(instrutorId).first();
    
    if (!colaborador || !treinamento || !instrutor) {
      throw new Error('Dados incompletos para gerar certificação');
    }
    
    // Buscar todas as sessões aprovadas
    const sessoesCompletas = await db.prepare(`
      SELECT 
        sp.*,
        ss.data_inicio,
        ss.sessao_uuid,
        st.nome_sessao as template_nome
      FROM sessao_participantes sp
      JOIN sessoes_simulador ss ON sp.sessao_id = ss.id
      LEFT JOIN sessoes_template st ON sp.template_sessao_id = st.id
      WHERE sp.colaborador_id = ? AND sp.treinamento_id = ? AND sp.status_individual = 'APROVADO'
      ORDER BY sp.sessao_numero
    `).bind(colaboradorId, treinamentoId).all();
    
    // Gerar ID único da certificação
    const certificacaoId = this.gerarIdCertificacao();
    
    // Calcular datas no formato brasileiro
    const agora = new Date();
    const dataConlusaoBrasil = this.formatarDataBrasil(agora);
    const dataValidade = new Date();
    dataValidade.setMonth(dataValidade.getMonth() + 12);
    const dataValidadeBrasil = this.formatarDataBrasil(dataValidade);
    
    // Preparar observações detalhadas
    const observacoes = this.criarObservacoesCertificacao(sessoesCompletas.results || []);
    
    // Inserir certificação na tabela
    const resultCert = await db.prepare(`
      INSERT INTO certificacoes_v3 (
        certificacao_id, funcionario_matricula, treinamento_codigo,
        data_conclusao, data_vencimento, instrutor, local_realizacao,
        observacoes, tipo_operacao, compliance_status, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      certificacaoId,
      colaborador.matricula,
      treinamento.codigo,
      dataConlusaoBrasil,
      dataValidadeBrasil,
      `${instrutor.nome} (${instrutor.matricula})`,
      'Simulador - Controle Individual AirTrust',
      observacoes,
      'NOVA',
      'VALIDO',
      `SISTEMA_INDIVIDUAL_${instrutorId}`
    ).run();
    
    console.log(`✅ Certificação individual gerada: ${certificacaoId} para ${colaborador.nome}`);
    
    return {
      id: resultCert.meta.last_row_id,
      certificacao_id: certificacaoId,
      colaborador_nome: colaborador.nome,
      treinamento_nome: treinamento.nome,
      data_conclusao: dataConlusaoBrasil,
      data_vencimento: dataValidadeBrasil
    };
  }
  
  /**
   * Obter total de sessões necessárias para um treinamento
   */
  static async obterTotalSessoesNecessarias(treinamentoId: number, db: any): Promise<number> {
    try {
      // Buscar pela configuração do treinamento
      const treinamento = await db.prepare(`
        SELECT 
          (SELECT COUNT(*) FROM sessoes_template st 
           WHERE st.treinamento_codigo = ct.codigo) as total_templates,
          3 as default_sessoes -- fallback padrão
        FROM catalogo_treinamentos_v2 ct 
        WHERE ct.id = ?
      `).bind(treinamentoId).first();
      
      return treinamento?.total_templates || treinamento?.default_sessoes || 3;
    } catch (error) {
      console.warn('Erro ao buscar total de sessões, usando padrão de 3:', error);
      return 3;
    }
  }
  
  /**
   * Registrar reprovação na auditoria
   */
  static async registrarReprovacao(
    participante: any,
    instrutorId: number,
    db: any,
    observacoes?: string
  ): Promise<void> {
    
    // Registrar na auditoria do simulador
    await db.prepare(`
      INSERT INTO auditoria_simulador (
        ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem
      ) VALUES (?, ?, ?, ?, ?)
    `).bind(
      participante.sessao_uuid,
      instrutorId,
      'PARTICIPANTE_REPROVADO',
      JSON.stringify({
        participante_id: participante.id,
        colaborador: participante.colaborador_nome,
        treinamento: participante.treinamento_codigo,
        sessao_numero: participante.sessao_numero,
        observacoes: observacoes || 'Sem observações'
      }),
      'SISTEMA_INDIVIDUAL'
    ).run();
  }
  
  /**
   * Notificar conclusão do treinamento
   */
  static async notificarConclusaoTreinamento(
    colaboradorId: number,
    certificacao: any,
    db: any
  ): Promise<void> {
    
    const mensagem = `🎉 Parabéns! Você concluiu o treinamento ${certificacao.treinamento_nome}. 
    Certificação ${certificacao.certificacao_id} gerada com sucesso!`;
    
    // Criar notificação para o colaborador
    await db.prepare(`
      INSERT INTO notificacoes_simulador (
        ficha_uuid, destinatario_id, tipo_notificacao, mensagem
      ) VALUES (?, ?, ?, ?)
    `).bind(
      'TREINAMENTO_COMPLETO',
      colaboradorId,
      'SESSAO_CONCLUIDA_APROVADA',
      mensagem
    ).run();
  }
  
  /**
   * Buscar progresso individual de um colaborador
   */
  static async buscarProgressoIndividual(colaboradorId: number, db: any): Promise<any[]> {
    const stmt = db.prepare(`
      SELECT 
        pti.*,
        ct.codigo as treinamento_codigo,
        ct.nome as treinamento_nome,
        f.nome as colaborador_nome,
        f.matricula as colaborador_matricula,
        ROUND((pti.sessoes_concluidas * 100.0 / pti.total_sessoes_necessarias), 1) as percentual_conclusao
      FROM progresso_treinamento_individual pti
      JOIN catalogo_treinamentos_v2 ct ON pti.treinamento_id = ct.id
      JOIN funcionarios f ON pti.colaborador_id = f.id
      WHERE pti.colaborador_id = ?
      ORDER BY pti.data_inicio DESC
    `);
    
    const result = await stmt.bind(colaboradorId).all();
    return result.results || [];
  }
  
  /**
   * Buscar sessões de um participante específico
   */
  static async buscarSessoesParticipante(
    colaboradorId: number, 
    treinamentoId: number, 
    db: any
  ): Promise<any[]> {
    const stmt = db.prepare(`
      SELECT 
        sp.*,
        ss.data_inicio,
        ss.data_fim,
        ss.sessao_uuid,
        st.nome_sessao as template_nome,
        s.nome as simulador_nome
      FROM sessao_participantes sp
      JOIN sessoes_simulador ss ON sp.sessao_id = ss.id
      LEFT JOIN sessoes_template st ON sp.template_sessao_id = st.id
      LEFT JOIN simuladores s ON ss.simulador_id = s.id
      WHERE sp.colaborador_id = ? AND sp.treinamento_id = ?
      ORDER BY sp.sessao_numero, ss.data_inicio
    `);
    
    const result = await stmt.bind(colaboradorId, treinamentoId).all();
    return result.results || [];
  }
  
  // ===== MÉTODOS AUXILIARES =====
  
  /**
   * Gerar ID único da certificação
   */
  private static gerarIdCertificacao(): string {
    const agora = new Date();
    const ano = agora.getFullYear().toString().slice(-2);
    const mes = (agora.getMonth() + 1).toString().padStart(2, '0');
    const dia = agora.getDate().toString().padStart(2, '0');
    const numero = Math.floor(Math.random() * 99999).toString().padStart(5, '0');
    return `CERT-${ano}${mes}${dia}-${numero}`;
  }
  
  /**
   * Formatar data para padrão brasileiro
   */
  private static formatarDataBrasil(data: Date): string {
    const dia = data.getDate().toString().padStart(2, '0');
    const mes = (data.getMonth() + 1).toString().padStart(2, '0');
    const ano = data.getFullYear().toString();
    return `${dia}/${mes}/${ano}`;
  }
  
  /**
   * Criar observações detalhadas da certificação
   */
  private static criarObservacoesCertificacao(sessoes: any[]): string {
    const totalSessoes = sessoes.length;
    const detalhes = sessoes.map((s, index) => 
      `Sessão ${index + 1}: ${s.template_nome || 'Template padrão'} (${this.formatarDataBrasil(new Date(s.data_inicio))})`
    ).join('; ');
    
    return `Treinamento concluído através de ${totalSessoes} sessões individuais no simulador. ` +
           `Detalhes: ${detalhes}. ` +
           `Sistema: AirTrust Controle Individual v2.0. ` +
           `Gerado automaticamente em ${this.formatarDataBrasil(new Date())}.`;
  }
}

export default FinalizacaoIndividualService;
