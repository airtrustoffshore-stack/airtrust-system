/**
 * SERVIÇO AirTrust: SINCRONIZAÇÃO AUTOMÁTICA CERTIFICADOS → PASTA VIRTUAL
 * Garantia de que certificados anexados às certificações aparecem automaticamente na Pasta Virtual do funcionário
 */

interface CertificadoSyncResult {
  success: boolean;
  action: string;
  pasta_virtual_id?: number;
  certificado_url?: string;
  nome_arquivo_pasta?: string;
  funcionario_id?: number;
  funcionario_nome?: string;
  treinamento_nome?: string;
  metadata?: any;
  error?: string;
  auditoria_id?: number;
}

/**
 * Sincronização automática de certificado para Pasta Virtual
 * Executada automaticamente após upload de certificado
 */
export const sincronizarCertificadoParaPastaVirtual = async (
  anexoId: number,
  db: any,
  _r2: any = null
): Promise<CertificadoSyncResult> => {
  try {
    console.log(`🔄 [CERT-SYNC] Iniciando sincronização automática - Anexo ID: ${anexoId}`);
    
    // PASSO 1: Buscar dados completos do certificado anexado
    const anexo = await db.prepare(`
      SELECT 
        ca.id as anexo_id,
        ca.historico_id,
        ca.nome_arquivo,
        ca.url_arquivo,
        ca.arquivo_github_url,
        ca.tipo_arquivo,
        ca.tamanho_bytes,
        ca.created_at as anexo_created_at,
        -- Dados da certificação
        hc.id as certificacao_id,
        hc.funcionario_id,
        hc.treinamento_id,
        hc.data_conclusao,
        hc.data_vencimento,
        hc.instrutor,
        hc.nota_final,
        hc.status as certificacao_status,
        -- Dados do funcionário
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        f.funcao as funcionario_funcao,
        f.email as funcionario_email,
        -- Dados do treinamento
        ct.nome as treinamento_nome,
        ct.codigo as treinamento_codigo,
        ct.categoria as treinamento_categoria,
        ct.periodicidade_meses
      FROM certificado_anexos_v2 ca
      JOIN historico_certificacoes_v2 hc ON ca.historico_id = hc.id
      JOIN funcionarios f ON hc.funcionario_id = f.id
      JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE ca.id = ? 
        AND hc.deleted_at IS NULL 
        AND f.deleted_at IS NULL 
        AND ct.deleted_at IS NULL
    `).bind(anexoId).first();
    
    if (!anexo) {
      throw new Error(`Anexo não encontrado ou dados relacionados inválidos: ID ${anexoId}`);
    }
    
    console.log(`📋 [CERT-SYNC] Anexo encontrado: ${anexo.nome_arquivo} para ${anexo.funcionario_nome}`);
    
    // PASSO 2: Verificar se já existe na pasta virtual
    const jaExiste = await db.prepare(`
      SELECT id, nome_arquivo, caminho_arquivo, updated_at
      FROM pasta_virtual
      WHERE funcionario_id = ? 
        AND certificacao_id = ?
        AND tipo_documento = 'CERTIFICADO'
        AND deleted_at IS NULL
    `).bind(anexo.funcionario_id, anexo.historico_id).first();
    
    // PASSO 3: Gerar metadata rica para Pasta Virtual
    const dataFormatada = anexo.data_conclusao ? 
      new Date(anexo.data_conclusao).toLocaleDateString('pt-BR') : 'Sem data';
    const dataVencimento = anexo.data_vencimento ? 
      new Date(anexo.data_vencimento).toLocaleDateString('pt-BR') : 'Sem vencimento';
    
    // Nome claro e auditável para pasta virtual
    const nomeArquivoPasta = `Certificado - ${anexo.treinamento_nome} - ${dataFormatada}.pdf`;
    
    // Caminho estruturado
    const caminhoArquivo = `certificados/${anexo.funcionario_matricula}/${anexo.treinamento_codigo}_${anexo.data_conclusao || 'sem_data'}.pdf`;
    
    // Metadata completa
    const metadata = {
      origem: 'CERTIFICACAO_ANEXO',
      anexo_id: anexo.anexo_id,
      certificacao_id: anexo.certificacao_id,
      funcionario_matricula: anexo.funcionario_matricula,
      treinamento_codigo: anexo.treinamento_codigo,
      data_conclusao: anexo.data_conclusao,
      data_vencimento: anexo.data_vencimento,
      instrutor: anexo.instrutor,
      nota_final: anexo.nota_final,
      tamanho_bytes: anexo.tamanho_bytes,
      tipo_arquivo: anexo.tipo_arquivo,
      url_original: anexo.arquivo_github_url,
      sincronizado_em: new Date().toISOString()
    };
    
    const now = new Date().toISOString();
    let pastaVirtualId: number;
    let action: string;
    
    // PASSO 4: Inserir ou atualizar na pasta virtual
    if (jaExiste) {
      console.log(`🔄 [CERT-SYNC] Atualizando entrada existente na pasta virtual`);
      
      await db.prepare(`
        UPDATE pasta_virtual 
        SET 
          nome_arquivo = ?,
          caminho_arquivo = ?,
          descricao = ?,
          updated_at = ?
        WHERE id = ?
      `).bind(
        nomeArquivoPasta,
        caminhoArquivo,
        `Certificado de ${anexo.treinamento_nome} - Concluído em ${dataFormatada} - Vence em ${dataVencimento}`,
        now,
        jaExiste.id
      ).run();
      
      pastaVirtualId = jaExiste.id;
      action = 'UPDATED_IN_PASTA_VIRTUAL';
      
    } else {
      console.log(`➕ [CERT-SYNC] Criando nova entrada na pasta virtual`);
      
      const insertResult = await db.prepare(`
        INSERT INTO pasta_virtual (
          funcionario_id,
          tipo_documento,
          nome_arquivo,
          caminho_arquivo,
          certificacao_id,
          descricao,
          created_at,
          updated_at
        ) VALUES (?, 'CERTIFICADO', ?, ?, ?, ?, ?, ?)
      `).bind(
        anexo.funcionario_id,
        nomeArquivoPasta,
        caminhoArquivo,
        anexo.historico_id,
        `Certificado de ${anexo.treinamento_nome} - Concluído em ${dataFormatada} - Vence em ${dataVencimento}`,
        now,
        now
      ).run();
      
      pastaVirtualId = insertResult.meta?.last_row_id as number;
      action = 'ADDED_TO_PASTA_VIRTUAL';
    }
    
    // PASSO 5: Registrar no log de sincronização da pasta virtual
    const syncLogExiste = await db.prepare(`
      SELECT id FROM pasta_virtual_sync_log
      WHERE historico_cert_id = ? AND deleted_at IS NULL
    `).bind(anexo.historico_id).first();
    
    if (!syncLogExiste) {
      await db.prepare(`
        INSERT INTO pasta_virtual_sync_log (
          funcionario_id, historico_cert_id, arquivo_original_url,
          arquivo_pasta_virtual_url, nome_arquivo_auditavel,
          funcionario_nome, funcionario_matricula,
          treinamento_nome, treinamento_codigo,
          data_conclusao, data_vencimento,
          status_sincronizacao, tamanho_bytes, data_sincronizacao,
          tentativas_sincronizacao, max_tentativas,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SINCRONIZADO', ?, ?, 1, 3, ?, ?)
      `).bind(
        anexo.funcionario_id, anexo.historico_id, anexo.arquivo_github_url,
        anexo.arquivo_github_url, nomeArquivoPasta,
        anexo.funcionario_nome, anexo.funcionario_matricula,
        anexo.treinamento_nome, anexo.treinamento_codigo,
        anexo.data_conclusao, anexo.data_vencimento,
        anexo.tamanho_bytes, now, now, now
      ).run();
    }
    
    // PASSO 6: Registrar auditoria detalhada
    const auditoriaResult = await db.prepare(`
      INSERT INTO auditoria_avancada_v2 (
        usuario_id, acao, recurso, recurso_id,
        dados_antes, dados_depois, timestamp, nivel_criticidade
      ) VALUES (?, 'CERT_SYNC_AUTO', 'pasta_virtual', ?, ?, ?, ?, 'MEDIO')
    `).bind(
      'SISTEMA_SYNC',
      String(pastaVirtualId),
      JSON.stringify({ anexo_id: anexoId, acao_anterior: jaExiste ? 'EXISTIA' : 'NAO_EXISTIA' }),
      JSON.stringify({
        pasta_virtual_id: pastaVirtualId,
        certificado_nome: nomeArquivoPasta,
        funcionario: anexo.funcionario_nome,
        treinamento: anexo.treinamento_nome,
        metadata: metadata
      }),
      now,
    ).run();
    
    console.log(`✅ [CERT-SYNC] Sincronização concluída: ${anexo.nome_arquivo} → Pasta Virtual ID: ${pastaVirtualId}`);
    
    return {
      success: true,
      action: action,
      pasta_virtual_id: pastaVirtualId,
      certificado_url: anexo.arquivo_github_url,
      nome_arquivo_pasta: nomeArquivoPasta,
      funcionario_id: anexo.funcionario_id,
      funcionario_nome: anexo.funcionario_nome,
      treinamento_nome: anexo.treinamento_nome,
      metadata: metadata,
      auditoria_id: auditoriaResult.meta?.last_row_id as number
    };
    
  } catch (error) {
    console.error(`💥 [CERT-SYNC] Erro na sincronização - Anexo ID: ${anexoId}:`, error);
    
    // Registrar erro na auditoria
    try {
      await db.prepare(`
        INSERT INTO auditoria_avancada_v2 (
          usuario_id, acao, recurso, recurso_id,
          dados_depois, timestamp, nivel_criticidade, resultado
        ) VALUES (?, 'CERT_SYNC_AUTO_ERROR', 'pasta_virtual', ?, ?, ?, 'ALTO', 'ERROR')
      `).bind(
        'SISTEMA_SYNC',
        String(anexoId),
        JSON.stringify({
          error: error instanceof Error ? error.message : 'Erro desconhecido',
          anexo_id: anexoId
        }),
        new Date().toISOString()
      ).run();
    } catch (auditError) {
      console.error(`💥 [CERT-SYNC] Erro ao registrar auditoria:`, auditError);
    }
    
    return {
      success: false,
      action: 'SYNC_ERROR',
      error: error instanceof Error ? error.message : 'Erro desconhecido na sincronização'
    };
  }
};

/**
 * Remover certificado da Pasta Virtual quando anexo é deletado
 * Sincronização bidirecional automática
 */
export const removerCertificadoDaPastaVirtual = async (
  anexoId: number,
  historicoId: number,
  funcionarioId: number,
  db: any
): Promise<CertificadoSyncResult> => {
  try {
    console.log(`🗑️ [CERT-SYNC] Removendo certificado da pasta virtual - Anexo: ${anexoId}, Histórico: ${historicoId}`);
    
    // Marcar como deletado na pasta virtual (soft delete)
    const deleteResult = await db.prepare(`
      UPDATE pasta_virtual 
      SET deleted_at = ?, updated_at = ?
      WHERE funcionario_id = ? 
        AND certificacao_id = ?
        AND tipo_documento = 'CERTIFICADO'
        AND deleted_at IS NULL
    `).bind(
      new Date().toISOString(),
      new Date().toISOString(),
      funcionarioId,
      historicoId
    ).run();
    
    // Atualizar log de sincronização
    await db.prepare(`
      UPDATE pasta_virtual_sync_log
      SET deleted_at = ?, updated_at = ?
      WHERE historico_cert_id = ? AND deleted_at IS NULL
    `).bind(
      new Date().toISOString(),
      new Date().toISOString(),
      historicoId
    ).run();
    
    // Registrar auditoria
    await db.prepare(`
      INSERT INTO auditoria_avancada_v2 (
        usuario_id, acao, recurso, recurso_id,
        dados_depois, timestamp, nivel_criticidade
      ) VALUES (?, 'CERT_SYNC_AUTO_DELETE', 'pasta_virtual', ?, ?, ?, 'MEDIO')
    `).bind(
      'SISTEMA_SYNC',
      String(anexoId),
      JSON.stringify({
        anexo_id: anexoId,
        historico_id: historicoId,
        funcionario_id: funcionarioId,
        registros_afetados: deleteResult.changes || 0
      }),
      new Date().toISOString()
    ).run();
    
    console.log(`✅ [CERT-SYNC] Certificado removido da pasta virtual: ${deleteResult.changes || 0} registros afetados`);
    
    return {
      success: true,
      action: 'REMOVED_FROM_PASTA_VIRTUAL',
      funcionario_id: funcionarioId
    };
    
  } catch (error) {
    console.error(`💥 [CERT-SYNC] Erro ao remover certificado da pasta virtual:`, error);
    
    return {
      success: false,
      action: 'REMOVE_ERROR',
      error: error instanceof Error ? error.message : 'Erro desconhecido na remoção'
    };
  }
};

/**
 * Verificar status de sincronização de um funcionário
 */
export const verificarStatusSincronizacaoFuncionario = async (
  funcionarioId: number,
  db: any
): Promise<{
  funcionario: any;
  total_certificacoes: number;
  sincronizados: number;
  pendentes: number;
  com_erro: number;
  taxa_sincronizacao: number;
  certificacoes: any[];
}> => {
  try {
    // Dados do funcionário
    const funcionario = await db.prepare(`
      SELECT id, nome, matricula, funcao, email
      FROM funcionarios 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(funcionarioId).first();
    
    if (!funcionario) {
      throw new Error(`Funcionário ID ${funcionarioId} não encontrado`);
    }
    
    // Status das certificações
    const certificacoes = await db.prepare(`
      SELECT 
        hc.id as historico_id,
        ct.nome as treinamento_nome,
        ct.codigo as treinamento_codigo,
        hc.data_conclusao,
        hc.data_vencimento,
        hc.certificado_url,
        -- Status na pasta virtual
        pv.id as pasta_virtual_id,
        pv.nome_arquivo as nome_pasta_virtual,
        -- Status no log de sincronização
        pvsl.status_sincronizacao,
        pvsl.data_sincronizacao,
        pvsl.erro_ultimo,
        -- Status do anexo
        ca.id as anexo_id,
        ca.nome_arquivo as anexo_nome
      FROM historico_certificacoes_v2 hc
      JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      LEFT JOIN pasta_virtual pv ON hc.funcionario_id = pv.funcionario_id 
        AND hc.id = pv.certificacao_id 
        AND pv.tipo_documento = 'CERTIFICADO' 
        AND pv.deleted_at IS NULL
      LEFT JOIN pasta_virtual_sync_log pvsl ON hc.id = pvsl.historico_cert_id 
        AND pvsl.deleted_at IS NULL
      LEFT JOIN certificado_anexos_v2 ca ON hc.id = ca.historico_id
      WHERE hc.funcionario_id = ? 
        AND hc.deleted_at IS NULL 
        AND ct.deleted_at IS NULL
      ORDER BY hc.data_conclusao DESC
    `).bind(funcionarioId).all();
    
    const certs = certificacoes.results || [];
    const comAnexo = certs.filter((c: any) => c.anexo_id && c.certificado_url && !c.certificado_url.includes('mock://'));
    const sincronizados = certs.filter((c: any) => c.status_sincronizacao === 'SINCRONIZADO');
    const comErro = certs.filter((c: any) => c.status_sincronizacao === 'ERRO');
    const pendentes = comAnexo.length - sincronizados.length - comErro.length;
    
    return {
      funcionario,
      total_certificacoes: comAnexo.length,
      sincronizados: sincronizados.length,
      pendentes: Math.max(0, pendentes),
      com_erro: comErro.length,
      taxa_sincronizacao: comAnexo.length > 0 ? Math.round((sincronizados.length / comAnexo.length) * 100) : 100,
      certificacoes: certs
    };
    
  } catch (error) {
    console.error(`💥 [CERT-SYNC] Erro ao verificar status:`, error);
    throw error;
  }
};
