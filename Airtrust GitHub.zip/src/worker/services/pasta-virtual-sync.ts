/**
 * SERVIÇO PRINCIPAL: PASTA VIRTUAL
 * Implementação completa da lógica de sincronização de certificados
 */

interface SyncResult {
  success: boolean;
  action: string;
  sync_log_id?: number;
  arquivo_destino?: string;
  url_pasta_virtual?: string;
  tamanho_bytes?: number;
  tempo_execucao_ms?: number;
  tentativas?: number;
  error?: string;
}

/**
 * Função central para sincronizar certificado com pasta virtual
 * @param {number} historicoCertId - ID do histórico de certificação
 * @param {Object} db - Instância do banco D1
 * @param {Object} r2 - Instância do R2 Storage
 * @returns {Object} Resultado da sincronização
 */
export const sincronizarCertificadoComPastaVirtual = async (
  historicoCertId: number, 
  db: any, 
  r2: any = null
): Promise<SyncResult> => {
  const startTime = Date.now();
  
  try {
    console.log(`📂 [SYNC] Iniciando sincronização - ID: ${historicoCertId}`);
    
    // PASSO 1: Verificar se já está sincronizado
    const jaExiste = await db.prepare(`
      SELECT id, status_sincronizacao, tentativas_sincronizacao, max_tentativas
      FROM pasta_virtual_sync_log 
      WHERE historico_cert_id = ? AND deleted_at IS NULL
    `).bind(historicoCertId).first();
    
    if (jaExiste) {
      if (jaExiste.status_sincronizacao === 'SINCRONIZADO') {
        console.log(`✅ [SYNC] Já sincronizado - ID: ${historicoCertId}`);
        return { 
          success: true, 
          action: 'ALREADY_SYNCED', 
          sync_log_id: jaExiste.id 
        };
      }
      
      // Verificar se excedeu tentativas máximas
      if (jaExiste.tentativas_sincronizacao >= jaExiste.max_tentativas) {
        console.log(`❌ [SYNC] Tentativas esgotadas - ID: ${historicoCertId}`);
        return { 
          success: false, 
          action: 'MAX_RETRIES_EXCEEDED',
          tentativas: jaExiste.tentativas_sincronizacao
        };
      }
    }
    
    // PASSO 2: Buscar dados completos da certificação
    const certificacao = await db.prepare(`
      SELECT 
        hc.id, hc.funcionario_id, hc.treinamento_id, 
        hc.data_conclusao, hc.data_vencimento, hc.nota_final, hc.instrutor,
        hc.certificado_url, hc.status,
        f.id as funcionario_id, f.nome as funcionario_nome,
        f.matricula as funcionario_matricula, f.funcao as funcionario_funcao,
        ct.id as treinamento_id, ct.nome as treinamento_nome,
        ct.codigo as treinamento_codigo, ct.categoria as treinamento_categoria
      FROM historico_certificacoes_v2 hc
      LEFT JOIN funcionarios f ON hc.funcionario_id = f.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE hc.id = ? AND hc.deleted_at IS NULL
        AND f.deleted_at IS NULL AND ct.deleted_at IS NULL
    `).bind(historicoCertId).first();
    
    if (!certificacao) {
      console.error(`❌ [SYNC] Certificação não encontrada - ID: ${historicoCertId}`);
      return { 
        success: false, 
        action: 'CERT_NOT_FOUND',
        error: 'Certificação não encontrada ou inativa'
      };
    }
    
    if (!certificacao.certificado_url || certificacao.certificado_url.includes('mock://')) {
      console.log(`⚠️ [SYNC] Sem arquivo anexado - ID: ${historicoCertId}`);
      return { 
        success: false, 
        action: 'NO_FILE_ATTACHED',
        error: 'Nenhum arquivo real anexado à certificação'
      };
    }
    
    // PASSO 3: Gerar estrutura de pastas e nomes auditáveis
    const pastaFuncionario = `${certificacao.funcionario_matricula}_${certificacao.funcionario_nome.replace(/[^a-zA-Z0-9]/g, '_')}`;
    const dataFormatada = certificacao.data_conclusao?.replace(/-/g, '');
    const nomeArquivoAuditavel = `CERT_${certificacao.funcionario_matricula}_${certificacao.treinamento_codigo}_${dataFormatada}.pdf`;
    const caminhoCompleto = `pasta-virtual/funcionarios/${pastaFuncionario}/certificacoes/${nomeArquivoAuditavel}`;
    
    console.log(`📁 [SYNC] Caminho destino: ${caminhoCompleto}`);
    
    // PASSO 4: Processar arquivo com tratamento robusto de erros
    const response = await fetch(certificacao.certificado_url, {
      method: 'GET',
      headers: { 'User-Agent': 'AirTrust-PastaVirtual/1.0' }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const fileBuffer = await response.arrayBuffer();
    const tamanhoBytes = fileBuffer.byteLength;
    
    // PASSO 5: Calcular hashes para integridade
    const hashMD5 = await calcularHashMD5(fileBuffer);
    const hashSHA256 = await calcularHashSHA256(fileBuffer);
    
    // PASSO 6: Salvar na pasta virtual
    let urlPastaVirtual;
    if (r2) {
      try {
        await r2.put(caminhoCompleto, fileBuffer, {
          httpMetadata: {
            contentType: 'application/pdf',
            contentDisposition: `attachment; filename="${nomeArquivoAuditavel}"`
          },
          customMetadata: {
            'funcionario-id': certificacao.funcionario_id.toString(),
            'historico-cert-id': historicoCertId.toString(),
            'hash-md5': hashMD5
          }
        });
        urlPastaVirtual = `https://airtrust-storage.r2.dev/${caminhoCompleto}`;
      } catch (r2Error) {
        console.warn(`⚠️ [SYNC] R2 indisponível, usando mock: ${r2Error}`);
        urlPastaVirtual = `mock://pasta-virtual/${caminhoCompleto}`;
      }
    } else {
      urlPastaVirtual = `mock://pasta-virtual/${caminhoCompleto}`;
    }
    
    // PASSO 7: Salvar/atualizar registro
    const now = new Date().toISOString();
    
    if (!jaExiste) {
      await db.prepare(`
        INSERT INTO pasta_virtual_sync_log (
          funcionario_id, historico_cert_id, arquivo_original_url,
          arquivo_pasta_virtual_url, nome_arquivo_auditavel, 
          funcionario_nome, funcionario_matricula,
          treinamento_nome, treinamento_codigo, data_conclusao, data_vencimento,
          status_sincronizacao, tamanho_bytes, hash_md5, hash_sha256,
          data_sincronizacao, tentativas_sincronizacao, max_tentativas,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SINCRONIZADO', ?, ?, ?, ?, 1, 3, ?, ?)
      `).bind(
        certificacao.funcionario_id, historicoCertId, certificacao.certificado_url,
        urlPastaVirtual, nomeArquivoAuditavel,
        certificacao.funcionario_nome, certificacao.funcionario_matricula,
        certificacao.treinamento_nome, certificacao.treinamento_codigo,
        certificacao.data_conclusao, certificacao.data_vencimento,
        tamanhoBytes, hashMD5, hashSHA256, now, now, now
      ).run();
    } else {
      await db.prepare(`
        UPDATE pasta_virtual_sync_log 
        SET status_sincronizacao = 'SINCRONIZADO',
            arquivo_pasta_virtual_url = ?, tamanho_bytes = ?,
            hash_md5 = ?, hash_sha256 = ?, data_sincronizacao = ?,
            tentativas_sincronizacao = tentativas_sincronizacao + 1,
            updated_at = ?
        WHERE id = ?
      `).bind(urlPastaVirtual, tamanhoBytes, hashMD5, hashSHA256, now, now, jaExiste.id).run();
    }
    
    const tempoExecucao = Date.now() - startTime;
    console.log(`✅ [SYNC] Concluído - ID: ${historicoCertId} (${tempoExecucao}ms)`);
    
    return {
      success: true,
      action: 'SYNCHRONIZED',
      arquivo_destino: caminhoCompleto,
      url_pasta_virtual: urlPastaVirtual,
      tamanho_bytes: tamanhoBytes,
      tempo_execucao_ms: tempoExecucao
    };
    
  } catch (error) {
    const tempoExecucao = Date.now() - startTime;
    console.error(`💥 [SYNC] Erro - ID: ${historicoCertId}:`, error);
    
    // Registrar erro no log se já existe entrada
    const existeEntrada = await db.prepare(`
      SELECT id FROM pasta_virtual_sync_log 
      WHERE historico_cert_id = ? AND deleted_at IS NULL
    `).bind(historicoCertId).first();
    
    if (existeEntrada) {
      try {
        await db.prepare(`
          UPDATE pasta_virtual_sync_log 
          SET status_sincronizacao = 'ERRO',
              erro_ultimo = ?,
              tentativas_sincronizacao = tentativas_sincronizacao + 1,
              updated_at = ?
          WHERE id = ?
        `).bind(
          error instanceof Error ? error.message : 'Erro desconhecido',
          new Date().toISOString(),
          existeEntrada.id
        ).run();
      } catch (updateError) {
        console.error(`💥 [SYNC] Erro ao atualizar log:`, updateError);
      }
    }
    
    return {
      success: false,
      action: 'SYNC_ERROR',
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      tempo_execucao_ms: tempoExecucao
    };
  }
};

// Funções auxiliares para cálculo de hash
export const calcularHashMD5 = async (buffer: ArrayBuffer): Promise<string> => {
  // Note: MD5 is not available in Web Crypto API, using SHA-1 as alternative
  const hashBuffer = await crypto.subtle.digest('SHA-1', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

export const calcularHashSHA256 = async (buffer: ArrayBuffer): Promise<string> => {
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

/**
 * Processamento em lote de sincronizações
 */
export const sincronizarLoteCertificados = async (
  certificacoes: any[],
  db: any,
  r2: any = null,
  batchSize: number = 10
): Promise<{
  sincronizados: number;
  erros: number;
  jaExistiam: number;
  resultados: any[];
  resumoFinal: any;
}> => {
  const startTime = Date.now();
  let sincronizados = 0, erros = 0, jaExistiam = 0;
  const resultados: any[] = [];
  
  const totalBatches = Math.ceil(certificacoes.length / batchSize);
  
  for (let i = 0; i < totalBatches; i++) {
    const batch = certificacoes.slice(i * batchSize, (i + 1) * batchSize);
    console.log(`📦 [BULK-SYNC] Lote ${i + 1}/${totalBatches}`);
    
    for (const cert of batch) {
      try {
        const resultado = await sincronizarCertificadoComPastaVirtual(cert.id, db, r2);
        
        resultados.push({
          historico_cert_id: cert.id,
          funcionario_nome: cert.funcionario_nome || 'N/A',
          treinamento_codigo: cert.treinamento_codigo || 'N/A',
          status: resultado.success ? 'SUCESSO' : 'ERRO',
          action: resultado.action,
          erro: resultado.success ? null : resultado.error
        });
        
        if (resultado.action === 'SYNCHRONIZED') sincronizados++;
        else if (resultado.action === 'ALREADY_SYNCED') jaExistiam++;
        else if (!resultado.success) erros++;
        
      } catch (error) {
        console.error(`💥 [BULK-SYNC] Erro no item ${cert.id}:`, error);
        resultados.push({
          historico_cert_id: cert.id,
          status: 'ERRO',
          erro: error instanceof Error ? error.message : 'Erro desconhecido'
        });
        erros++;
      }
      
      // Pausa pequena entre processamentos
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // Pausa entre lotes
    if (i < totalBatches - 1) {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }
  
  const resumoFinal = {
    total_processados: certificacoes.length,
    sincronizados, 
    ja_existiam: jaExistiam, 
    erros,
    tempo_total_segundos: Math.round((Date.now() - startTime) / 1000),
    taxa_sucesso: certificacoes.length > 0 ? 
      Math.round((sincronizados + jaExistiam) / certificacoes.length * 100) : 0
  };
  
  return {
    sincronizados,
    erros,
    jaExistiam,
    resultados,
    resumoFinal
  };
};
