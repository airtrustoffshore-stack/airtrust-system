export interface User {
  id: string;
  name: string;
  perfil: 'ADMIN' | 'COMPLIANCE' | 'GESTOR' | 'FUNCIONARIO';
  funcionario_id?: number;
  equipe?: string;
}

export interface Funcionario {
  id: number;
  nome: string;
  matricula?: string;
  cpf?: string;
  codigo_anac?: string;
  funcao: string;
  base?: string;
  contrato?: string;
  telefone?: string;
  email?: string;
  status: string;
  cma_numero?: string;
  cma_data_vencimento?: string;
  cma_status?: string;
  aso_data_vencimento?: string;
  nivel_icao?: string;
  nivel_icao_data_vencimento?: string;
  nivel_icao_status?: string;
  is_instrutor: number;
  is_checador: number;
  aeronave_principal?: string;
  avatar?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface Funcao {
  id: number;
  nome: string;
  descricao?: string;
  categoria?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface AuditLog {
  id?: number;
  sessao_id?: string;
  usuario_id: string;
  usuario_nome: string;
  ip_address?: string;
  user_agent?: string;
  acao: string;
  recurso: string;
  recurso_id?: string;
  dados_antes?: string;
  dados_depois?: string;
  resultado: string;
  duracao_ms?: number;
  timestamp?: string;
  nivel_criticidade: string;
}

export interface Env {
  DB: any;
  BUCKET?: any;
  ENVIRONMENT?: string;
  _schema_synced?: boolean;
  R2_ACCESS_KEY_ID?: string;
  R2_SECRET_ACCESS_KEY?: string;
  R2_BUCKET_NAME?: string;
  R2_ENDPOINT?: string;
  CLOUDFLARE_API_TOKEN?: string;
  MOCHA_USERS_SERVICE_API_KEY?: string;
  MOCHA_USERS_SERVICE_API_URL?: string;
  [key: string]: any; // Para propriedades dinâmicas
}
