/**
 * MIGRAÇÃO AUTOMÁTICA DE SINCRONIZAÇÃO DE SCHEMA
 * Executa automaticamente no startup para garantir que produção 
 * tenha o mesmo schema que desenvolvimento
 */

export async function ensureSchemaSyncMigration(db: any): Promise<void> {
  try {
    console.log('🔧 Verificando sincronização de schema...');
    
    // Verificar se tabela funcionarios tem campo deleted_at
    const schemaResult = await db.prepare(`
      PRAGMA table_info(funcionarios)
    `).all();
    
    const schemaInfo = schemaResult.results || [];
    const hasDeletedAt = schemaInfo.some((col: any) => col.name === 'deleted_at');
    
    if (!hasDeletedAt) {
      console.log('❌ Campo deleted_at não encontrado. Aplicando correção...');
      
      // Aplicar correção de schema - adicionar deleted_at
      await db.prepare(`
        ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP
      `).run();
      
      console.log('✅ Campo deleted_at adicionado com sucesso');
    } else {
      console.log('✅ Schema funcionarios já tem deleted_at');
    }
    
    // Verificar outras tabelas críticas
    await ensureDeletedAtInTable(db, 'funcoes');
    await ensureDeletedAtInTable(db, 'catalogo_treinamentos_v2');
    await ensureDeletedAtInTable(db, 'historico_certificacoes_v2');
    
    // Criar índices de performance se não existirem
    await createIndexesSafely(db);
    
    // Limpar dados inconsistentes
    await cleanInconsistentData(db);
    
    console.log('🎯 Migração de sincronização concluída com sucesso');
    
  } catch (error) {
    console.error('❌ Erro na migração de sincronização:', error);
    // Não falhar o startup, apenas logar o erro
    // A aplicação deve continuar funcionando mesmo se a migração falhar
  }
}

async function ensureDeletedAtInTable(db: any, tableName: string): Promise<void> {
  try {
    const schemaResult = await db.prepare(`
      PRAGMA table_info(${tableName})
    `).all();
    
    const schemaInfo = schemaResult.results || [];
    const hasDeletedAt = schemaInfo.some((col: any) => col.name === 'deleted_at');
    
    if (!hasDeletedAt) {
      console.log(`❌ Tabela ${tableName} sem deleted_at. Adicionando...`);
      
      await db.prepare(`
        ALTER TABLE ${tableName} ADD COLUMN deleted_at TIMESTAMP
      `).run();
      
      console.log(`✅ Campo deleted_at adicionado em ${tableName}`);
    } else {
      console.log(`✅ Tabela ${tableName} já tem deleted_at`);
    }
  } catch (error) {
    console.warn(`⚠️ Erro ao verificar tabela ${tableName}:`, error);
  }
}

async function createIndexesSafely(db: any): Promise<void> {
  const indexes = [
    'CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at)',
    'CREATE INDEX IF NOT EXISTS idx_funcionarios_matricula ON funcionarios(matricula) WHERE deleted_at IS NULL',
    'CREATE INDEX IF NOT EXISTS idx_funcoes_deleted_at ON funcoes(deleted_at)',
    'CREATE INDEX IF NOT EXISTS idx_catalogo_treinamentos_deleted_at ON catalogo_treinamentos_v2(deleted_at)',
    'CREATE INDEX IF NOT EXISTS idx_historico_certificacoes_deleted_at ON historico_certificacoes_v2(deleted_at)'
  ];
  
  for (const indexSQL of indexes) {
    try {
      await db.prepare(indexSQL).run();
    } catch (error) {
      console.warn('⚠️ Erro ao criar índice:', error);
    }
  }
  
  console.log('✅ Índices de performance verificados');
}

async function cleanInconsistentData(db: any): Promise<void> {
  try {
    // Limpar valores vazios de deleted_at (devem ser NULL)
    const cleanupQueries = [
      "UPDATE funcionarios SET deleted_at = NULL WHERE deleted_at = ''",
      "UPDATE funcoes SET deleted_at = NULL WHERE deleted_at = ''",
      "UPDATE catalogo_treinamentos_v2 SET deleted_at = NULL WHERE deleted_at = ''",
      "UPDATE historico_certificacoes_v2 SET deleted_at = NULL WHERE deleted_at = ''"
    ];
    
    for (const query of cleanupQueries) {
      try {
        await db.prepare(query).run();
      } catch (error) {
        console.warn('⚠️ Erro na limpeza de dados:', error);
      }
    }
    
    console.log('✅ Dados inconsistentes limpos');
  } catch (error) {
    console.warn('⚠️ Erro na limpeza geral:', error);
  }
}

/**
 * Verificação de saúde do schema após migração
 */
export async function validateSchemaHealth(db: any): Promise<boolean> {
  try {
    // Testar funcionamento básico do soft delete
    await db.prepare(`
      SELECT COUNT(*) as total, 
             COUNT(CASE WHEN deleted_at IS NULL THEN 1 END) as ativos,
             COUNT(CASE WHEN deleted_at IS NOT NULL THEN 1 END) as deletados
      FROM funcionarios
    `).first();
    
    console.log('✅ Schema health check passou');
    return true;
  } catch (error) {
    console.error('❌ Schema health check falhou:', error);
    return false;
  }
}
