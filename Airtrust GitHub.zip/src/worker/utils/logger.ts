// ✅ GAP 5 - Sistema de logs estruturado

export const log = {
  info: (message: string, data?: any) => {
    const timestamp = new Date().toISOString();
    const logData = data ? ` | Data: ${JSON.stringify(data)}` : '';
    console.log(`[INFO] ${timestamp} - ${message}${logData}`);
  },
  
  error: (message: string, error?: any) => {
    const timestamp = new Date().toISOString();
    const errorData = error ? ` | Error: ${error instanceof Error ? error.message : JSON.stringify(error)}` : '';
    console.error(`[ERROR] ${timestamp} - ${message}${errorData}`);
    
    // Se for um erro completo, também loggar stack trace
    if (error instanceof Error && error.stack) {
      console.error(`[ERROR] ${timestamp} - Stack: ${error.stack}`);
    }
  },
  
  audit: (action: string, user: string, data?: any) => {
    const timestamp = new Date().toISOString();
    const auditData = data ? ` | Data: ${JSON.stringify(data)}` : '';
    console.log(`[AUDIT] ${timestamp} - ${user} ${action}${auditData}`);
  },
  
  warn: (message: string, data?: any) => {
    const timestamp = new Date().toISOString();
    const warnData = data ? ` | Data: ${JSON.stringify(data)}` : '';
    console.warn(`[WARN] ${timestamp} - ${message}${warnData}`);
  },
  
  debug: (message: string, data?: any) => {
    const timestamp = new Date().toISOString();
    const debugData = data ? ` | Data: ${JSON.stringify(data)}` : '';
    console.debug(`[DEBUG] ${timestamp} - ${message}${debugData}`);
  },
  
  // Log específico para endpoints de API
  endpoint: (method: string, path: string, status: number, duration?: number) => {
    const timestamp = new Date().toISOString();
    const durationStr = duration ? ` | Duration: ${duration}ms` : '';
    console.log(`[ENDPOINT] ${timestamp} - ${method} ${path} - Status: ${status}${durationStr}`);
  },
  
  // Log específico para operações de banco de dados
  database: (operation: string, table: string, affected: number = 0, duration?: number) => {
    const timestamp = new Date().toISOString();
    const durationStr = duration ? ` | Duration: ${duration}ms` : '';
    console.log(`[DATABASE] ${timestamp} - ${operation} ${table} - Affected: ${affected} rows${durationStr}`);
  },
  
  // Log específico para validações
  validation: (field: string, value: any, isValid: boolean, errors?: string[]) => {
    const timestamp = new Date().toISOString();
    const status = isValid ? 'VALID' : 'INVALID';
    const errorStr = errors && errors.length > 0 ? ` | Errors: ${errors.join(', ')}` : '';
    console.log(`[VALIDATION] ${timestamp} - Field: ${field} | Value: ${JSON.stringify(value)} | Status: ${status}${errorStr}`);
  },
  
  // Log específico para performance
  performance: (operation: string, startTime: number, data?: any) => {
    const timestamp = new Date().toISOString();
    const duration = Date.now() - startTime;
    const perfData = data ? ` | Data: ${JSON.stringify(data)}` : '';
    console.log(`[PERFORMANCE] ${timestamp} - ${operation} completed in ${duration}ms${perfData}`);
  }
};

// Middleware para logging automático de requests
export const requestLogger = (req: any, startTime: number) => {
  return (status: number) => {
    const duration = Date.now() - startTime;
    log.endpoint(req.method, req.url, status, duration);
  };
};

// Helper para criar contexto de auditoria
export const createAuditContext = (userId: string, ip?: string, userAgent?: string) => {
  return {
    userId,
    ip: ip || 'unknown',
    userAgent: userAgent || 'unknown',
    timestamp: new Date().toISOString(),
    
    logAction: (action: string, resource: string, data?: any) => {
      log.audit(`${action} ${resource}`, userId, {
        ip,
        userAgent,
        ...data
      });
    }
  };
};
