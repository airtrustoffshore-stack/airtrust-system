/**
 * ⚠️ PADRÃO BRASILEIRO OBRIGATÓRIO - AIRTRUST ⚠️
 * 
 * Utilitários para manipulação de datas no padrão brasileiro
 * 
 * Características obrigatórias:
 * ✅ Datas: SEMPRE dd/mm/aaaa (nunca mm/dd/yyyy ou yyyy-mm-dd)
 * ✅ Validação: SEMPRE formato brasileiro
 * ✅ Conversão: SEMPRE para Date usando padrão brasileiro
 * ✅ Cultura: SEMPRE pt-BR
 */

/**
 * Validar formato brasileiro de data dd/mm/aaaa
 */
export function validarDataBrasileira(dataBrasil: string): boolean {
  if (!dataBrasil) return false;
  
  const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = dataBrasil.match(regex);
  
  if (!match) return false;
  
  const [, dia, mes, ano] = match;
  const diaNum = parseInt(dia, 10);
  const mesNum = parseInt(mes, 10);
  const anoNum = parseInt(ano, 10);
  
  // Verificar limites básicos
  if (diaNum < 1 || diaNum > 31) return false;
  if (mesNum < 1 || mesNum > 12) return false;
  if (anoNum < 1900 || anoNum > 2100) return false;
  
  // Verificar se é uma data válida
  const dataVerificacao = new Date(anoNum, mesNum - 1, diaNum);
  
  return (
    dataVerificacao.getFullYear() === anoNum &&
    dataVerificacao.getMonth() === mesNum - 1 &&
    dataVerificacao.getDate() === diaNum
  );
}

/**
 * Converter data brasileira dd/mm/aaaa para objeto Date
 */
export function converterDataBrasileira(dataBrasil: string): Date | null {
  if (!validarDataBrasileira(dataBrasil)) return null;
  
  const [dia, mes, ano] = dataBrasil.split('/').map(Number);
  return new Date(ano, mes - 1, dia);
}

/**
 * Converter data brasileira + hora para Date
 */
export function converterDataHoraBrasileira(dataBrasil: string, hora: string): Date | null {
  const dataObj = converterDataBrasileira(dataBrasil);
  if (!dataObj) return null;
  
  const [h, m] = hora.split(':').map(Number);
  if (isNaN(h) || isNaN(m) || h < 0 || h > 23 || m < 0 || m > 59) return null;
  
  dataObj.setHours(h, m, 0, 0);
  return dataObj;
}

/**
 * Formatar data para o padrão brasileiro dd/mm/aaaa
 */
export function formatarDataBrasil(data: Date | string): string {
  if (!data) return '';
  
  const dateObj = typeof data === 'string' ? new Date(data) : data;
  
  if (isNaN(dateObj.getTime())) return '';
  
  const dia = dateObj.getDate().toString().padStart(2, '0');
  const mes = (dateObj.getMonth() + 1).toString().padStart(2, '0');
  const ano = dateObj.getFullYear().toString();
  
  return `${dia}/${mes}/${ano}`;
}

/**
 * Gerar UUID único da sessão individual
 */
export function gerarUuidSessao(): string {
  const agora = new Date();
  const dataBrasil = formatarDataBrasil(agora).replace(/\//g, '');
  const numero = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `SESSAO-IND-${dataBrasil}-${numero}`;
}

/**
 * Validar formato de hora HH:mm
 */
export function validarHora(hora: string): boolean {
  if (!hora || hora.length !== 5) return false;
  
  const [h, m] = hora.split(':').map(Number);
  
  return !isNaN(h) && !isNaN(m) && h >= 0 && h <= 23 && m >= 0 && m <= 59;
}
