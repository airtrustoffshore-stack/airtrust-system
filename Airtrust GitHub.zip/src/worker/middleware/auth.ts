import { MiddlewareHandler } from 'hono';
import { User } from '../types/index';

export const authMiddleware: MiddlewareHandler = async (c, next) => {
  // 🚨 CORREÇÃO TEMPORÁRIA PARA TESTE EM PRODUÇÃO
  // Injetar usuário mock admin em todos os ambientes até implementar auth real
  
  const mockAdminUser: User = {
    id: 'SYSTEM_ADMIN',
    name: 'Usuário Admin (Sistema)',
    perfil: 'ADMIN',
    funcionario_id: 1
  };
  
  console.log('🔐 [AUTH] Mock admin user injetado para testes');
  c.set('user', mockAdminUser);
  await next();
};
