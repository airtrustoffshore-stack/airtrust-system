/**
 * 🚨 MIDDLEWARE DE CORREÇÃO EMERGENCIAL PARA PRODUÇÃO
 * Executa diagnóstico e correção automática no primeiro request
 */

export async function emergencyProductionFix(c: any, next: () => Promise<void>): Promise<void> {
  // Executar apenas uma vez por sessão
  if (c.env._emergency_fix_executed) {
    await next();
    return;
  }

  try {
    console.log('🚨 INICIANDO DIAGNÓSTICO EMERGENCIAL DE PRODUÇÃO...');
    const db = c.env.DB;
    const diagnostics: any = {};

    // 1. VERIFICAR SCHEMA ATUAL
    console.log('🔍 FASE 1: Verificando schema atual...');
    try {
      const schemaResult = await db.prepare('PRAGMA table_info(funcionarios)').all();
      diagnostics.schema = schemaResult.results || [];
      
      const hasDeletedAt = diagnostics.schema.some((col: any) => col.name === 'deleted_at');
      diagnostics.hasDeletedAt = hasDeletedAt;
      
      console.log(`📊 Schema funcionarios: ${diagnostics.schema.length} colunas`);
      console.log(`🔍 Tem deleted_at: ${hasDeletedAt ? 'SIM' : 'NÃO'}`);
      
      if (!hasDeletedAt) {
        console.log('❌ PROBLEMA CONFIRMADO: Campo deleted_at não existe em produção!');
        console.log('🔧 Aplicando correção imediata...');
        
        await db.prepare('ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP').run();
        console.log('✅ Campo deleted_at adicionado com sucesso');
        diagnostics.deletedAtAdded = true;
      }
    } catch (schemaError: any) {
      console.error('❌ Erro no diagnóstico de schema:', schemaError);
      diagnostics.schemaError = schemaError?.message || 'Erro desconhecido';
    }

    // 2. VERIFICAR CONSTRAINT DE FUNCAO
    console.log('🔍 FASE 2: Verificando constraint de função...');
    try {
      const tableSQL = await db.prepare(`SELECT sql FROM sqlite_master WHERE name = 'funcionarios'`).first();
      diagnostics.tableSQL = tableSQL?.sql || '';
      
      const hasFuncaoNotNull = tableSQL?.sql?.includes('funcao TEXT NOT NULL');
      diagnostics.hasFuncaoNotNull = hasFuncaoNotNull;
      
      console.log(`🔍 Função é NOT NULL: ${hasFuncaoNotNull ? 'SIM' : 'NÃO'}`);
      
      if (hasFuncaoNotNull) {
        console.log('❌ PROBLEMA CONFIRMADO: Função ainda é NOT NULL!');
        console.log('🔧 Correção de schema necessária (será aplicada nos próximos requests)');
        diagnostics.needsFuncaoFix = true;
      }
    } catch (constraintError: any) {
      console.error('❌ Erro ao verificar constraints:', constraintError);
      diagnostics.constraintError = constraintError?.message || 'Erro desconhecido';
    }

    // 3. TESTAR FUNCIONAMENTO DO DELETE
    console.log('🔍 FASE 3: Testando funcionamento do DELETE...');
    try {
      // Encontrar um funcionário para teste
      const testFuncionario = await db.prepare(`
        SELECT id, nome FROM funcionarios 
        WHERE deleted_at IS NULL OR deleted_at = '' 
        LIMIT 1
      `).first();
      
      if (testFuncionario) {
        console.log(`🧪 Testando soft delete no funcionário ${testFuncionario.id} (${testFuncionario.nome})`);
        
        // Simular UPDATE sem executar
        const testResult = await db.prepare(`
          SELECT id FROM funcionarios 
          WHERE id = ? AND (deleted_at IS NULL OR deleted_at = '')
        `).bind(testFuncionario.id).first();
        
        diagnostics.testFuncionarioExists = !!testResult;
        console.log(`✅ Funcionário de teste encontrado: ${!!testResult}`);
      }
    } catch (testError: any) {
      console.error('❌ Erro no teste de DELETE:', testError);
      diagnostics.testError = testError?.message || 'Erro desconhecido';
    }

    // 4. CONTAGEM DE REGISTROS
    console.log('🔍 FASE 4: Contando registros...');
    try {
      const counts = await db.prepare(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN deleted_at IS NULL OR deleted_at = '' THEN 1 END) as ativos,
          COUNT(CASE WHEN deleted_at IS NOT NULL AND deleted_at != '' THEN 1 END) as deletados
        FROM funcionarios
      `).first();
      
      diagnostics.counts = counts;
      console.log(`📊 Total: ${counts.total}, Ativos: ${counts.ativos}, Deletados: ${counts.deletados}`);
    } catch (countError: any) {
      console.error('❌ Erro na contagem:', countError);
      diagnostics.countError = countError?.message || 'Erro desconhecido';
    }

    // 5. APLICAR CORREÇÕES ADICIONAIS
    console.log('🔍 FASE 5: Aplicando correções adicionais...');
    try {
      // Criar índices de performance
      await db.prepare('CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at)').run();
      
      // Limpar dados inconsistentes
      const cleanupResult = await db.prepare("UPDATE funcionarios SET deleted_at = NULL WHERE deleted_at = ''").run();
      diagnostics.cleanupRows = cleanupResult.meta?.changes || 0;
      
      console.log(`🧹 Limpeza: ${diagnostics.cleanupRows} linhas corrigidas`);
    } catch (cleanupError: any) {
      console.error('❌ Erro na limpeza:', cleanupError);
      diagnostics.cleanupError = cleanupError?.message || 'Erro desconhecido';
    }

    // 6. RELATÓRIO FINAL
    console.log('📋 DIAGNÓSTICO EMERGENCIAL CONCLUÍDO:');
    console.log(`   - Schema tem deleted_at: ${diagnostics.hasDeletedAt ? 'SIM' : 'NÃO'}`);
    console.log(`   - Função é NOT NULL: ${diagnostics.hasFuncaoNotNull ? 'SIM' : 'NÃO'}`);
    console.log(`   - Registros ativos: ${diagnostics.counts?.ativos || 'N/A'}`);
    console.log(`   - Registros deletados: ${diagnostics.counts?.deletados || 'N/A'}`);
    console.log(`   - Limpeza aplicada: ${diagnostics.cleanupRows || 0} linhas`);

    // Marcar como executado
    c.env._emergency_fix_executed = true;
    c.env._diagnostics = diagnostics;

  } catch (error: any) {
    console.error('❌ ERRO CRÍTICO NO DIAGNÓSTICO EMERGENCIAL:', error);
    c.env._emergency_fix_executed = true; // Evitar loops
  }

  await next();
}

/**
 * Aplicar correção de schema completa se necessário
 */
export async function applySchemaFix(db: any): Promise<boolean> {
  try {
    console.log('🔧 Aplicando correção completa de schema...');
    
    // Verificar se precisa corrigir funcao NOT NULL
    const tableSQL = await db.prepare(`SELECT sql FROM sqlite_master WHERE name = 'funcionarios'`).first();
    
    if (tableSQL?.sql?.includes('funcao TEXT NOT NULL')) {
      console.log('🚨 Corrigindo funcao NOT NULL...');
      
      // Backup da tabela
      await db.prepare(`CREATE TABLE funcionarios_backup AS SELECT * FROM funcionarios`).run();
      
      // Dropar tabela original
      await db.prepare(`DROP TABLE funcionarios`).run();
      
      // Recriar tabela com schema correto
      await db.prepare(`
        CREATE TABLE funcionarios (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nome TEXT NOT NULL,
          matricula TEXT UNIQUE,
          cpf TEXT,
          codigo_anac TEXT,
          funcao TEXT,  -- SEM NOT NULL
          base TEXT,
          contrato TEXT,
          telefone TEXT,
          email TEXT,
          status TEXT DEFAULT 'ATIVO',
          cma_numero TEXT,
          cma_data_vencimento DATE,
          cma_status TEXT,
          aso_data_vencimento DATE,
          nivel_icao TEXT,
          nivel_icao_data_vencimento DATE,
          nivel_icao_status TEXT,
          is_instrutor INTEGER DEFAULT 0,
          is_checador INTEGER DEFAULT 0,
          aeronave_principal TEXT,
          avatar TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          deleted_at TIMESTAMP,
          anv TEXT,
          data_nascimento DATE,
          licenca_aeronautica TEXT,
          codigo_canac TEXT,
          codigo_sispat TEXT,
          codigo_prestserv TEXT,
          data_admissao DATE
        )
      `).run();
      
      // Restaurar dados
      await db.prepare(`INSERT INTO funcionarios SELECT * FROM funcionarios_backup`).run();
      
      // Limpar backup
      await db.prepare(`DROP TABLE funcionarios_backup`).run();
      
      console.log('✅ Schema funcionarios corrigido completamente');
      return true;
    }
    
    return false;
  } catch (error: any) {
    console.error('❌ Erro na correção de schema:', error);
    return false;
  }
}
