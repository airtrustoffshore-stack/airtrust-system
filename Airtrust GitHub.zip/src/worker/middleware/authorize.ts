import { MiddlewareHandler } from 'hono';
import { User } from '../types/index';

// Matriz de permissões por perfil
const PERMISSIONS_MATRIX = {
  ADMIN: {
    funcionarios: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    funcoes: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    system: ['READ', 'HEALTH_CHECK'],
    auditoria: ['READ'],
    treinamentos: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    compliance: ['READ', 'UPDATE'],
    dashboard: ['READ'],
    aeronaves: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    pasta_virtual: ['READ'],
    simuladores: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    simulador: ['CREATE', 'READ', 'UPDATE', 'DELETE']
  },
  COMPLIANCE: {
    funcionarios: ['READ', 'UPDATE'],
    funcoes: ['READ'],
    system: ['READ'],
    auditoria: ['READ'],
    treinamentos: ['READ', 'UPDATE'],
    compliance: ['READ', 'UPDATE'],
    dashboard: ['READ'],
    aeronaves: ['READ'],
    pasta_virtual: ['READ'],
    simuladores: ['READ'],
    simulador: ['READ']
  },
  GESTOR: {
    funcionarios: ['READ', 'UPDATE'],
    funcoes: ['READ'],
    system: ['READ'],
    treinamentos: ['READ'],
    compliance: ['READ'],
    dashboard: ['READ'],
    aeronaves: ['READ'],
    pasta_virtual: ['READ'],
    simuladores: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    simulador: ['CREATE', 'READ', 'UPDATE', 'DELETE']
  },
  FUNCIONARIO: {
    funcionarios: ['READ'],
    funcoes: ['READ'],
    treinamentos: ['READ'],
    compliance: ['READ'],
    dashboard: ['READ'],
    aeronaves: ['READ'],
    pasta_virtual: ['read'],
    simuladores: ['READ'],
    simulador: ['READ', 'UPDATE']
  }
};

export const requirePermission = (modulo: string, acao: string): MiddlewareHandler => {
  return async (c, next) => {
    const user = c.get('user') as User;
    
    if (!user) {
      return c.json({ error: 'User not authenticated' }, 401);
    }

    const userPermissions = PERMISSIONS_MATRIX[user.perfil];
    if (!userPermissions) {
      return c.json({ error: 'Invalid user profile' }, 403);
    }

    const modulePermissions = userPermissions[modulo as keyof typeof userPermissions];
    if (!modulePermissions || !modulePermissions.includes(acao)) {
      return c.json({ 
        error: 'Insufficient permissions',
        required: `${modulo}:${acao}`,
        user_profile: user.perfil 
      }, 403);
    }

    await next();
  };
};
