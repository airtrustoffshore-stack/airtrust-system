import { MiddlewareHandler } from 'hono';
import { validateReferentialIntegrity } from '../services/validation';

/**
 * Monitor de Integridade em Tempo Real
 * Executa verificações críticas APÓS operações de escrita
 */
export const integrityMonitor: MiddlewareHandler = async (c, next) => {
  await next();
  
  // Só executar para operações de escrita
  const method = c.req.method;
  if (!['POST', 'PUT', 'DELETE'].includes(method)) {
    return;
  }

  try {
    const violations = await validateReferentialIntegrity(c);
    
    if (violations.length > 0) {
      console.error('🚨 INTEGRITY VIOLATION DETECTED:', {
        violations,
        timestamp: new Date().toISOString(),
        endpoint: c.req.url,
        method: c.req.method
      });
      
      // Em desenvolvimento, apenas log. Em produção, poderia bloquear
      const environment = c.env?.ENVIRONMENT || 'development';
      if (environment === 'production') {
        // Em produção, implementar ações mais rigorosas
        console.error('⛔ CRITICAL: Integrity violations in production!');
      }
    } else {
      console.log('✅ INTEGRITY CHECK PASSED - All referential constraints valid');
    }
  } catch (error) {
    console.error('❌ INTEGRITY MONITOR ERROR:', error);
  }
};
