/**
 * AIRTRUST DEMO DATA BLOCKER MIDDLEWARE
 * Bloqueia permanentemente inserção de dados de teste/demo
 */

const FORBIDDEN_DEMO_NAMES = [
  'maria oliveira costa',
  'ricardo silva santos', 
  'joão pedro lima',
  'ana paula ferreira',
  'carlos eduardo souza',
  'funcionario_test',
  'teste_funcionario',
  'demo_user',
  'mock_user',
  'example_user'
];

const FORBIDDEN_DEMO_MATRICULAS = [
  'C001', 'C002', 'C003', 'C004', 'C005',
  'SGV-001', 'TEST-001', 'DEMO-001', 'MOCK-001'
];

/**
 * Verifica se dados contêm informações de teste/demo PROIBIDAS
 */
function isDemoData(data: any): boolean {
  if (!data) return false;
  
  const dataStr = JSON.stringify(data).toLowerCase();
  
  // Verificar nomes proibidos
  for (const name of FORBIDDEN_DEMO_NAMES) {
    if (dataStr.includes(name)) {
      console.error(`🚨 DEMO DATA BLOCKED: Nome proibido detectado: ${name}`);
      return true;
    }
  }
  
  // Verificar matrículas proibidas  
  for (const matricula of FORBIDDEN_DEMO_MATRICULAS) {
    if (dataStr.includes(matricula.toLowerCase())) {
      console.error(`🚨 DEMO DATA BLOCKED: Matrícula proibida detectada: ${matricula}`);
      return true;
    }
  }
  
  // Verificar padrões suspeitos
  const suspiciousPatterns = [
    /teste.*funcionario/i,
    /funcionario.*teste/i,
    /exemplo.*funcionario/i,
    /mock.*funcionario/i,
    /demo.*funcionario/i,
    /seeddata/i,
    /devdata/i
  ];
  
  for (const pattern of suspiciousPatterns) {
    if (pattern.test(dataStr)) {
      console.error(`🚨 DEMO DATA BLOCKED: Padrão suspeito detectado: ${pattern}`);
      return true;
    }
  }
  
  return false;
}

/**
 * Middleware que bloqueia dados de demo em todas as requisições
 */
export function createDemoDataBlockerMiddleware() {
  return async (c: any, next: () => Promise<void>) => {
    
    // Verificar POST/PUT requests que podem inserir dados
    if (c.req.method === 'POST' || c.req.method === 'PUT') {
      
      const contentType = c.req.header('content-type') || '';
      
      if (contentType.includes('application/json')) {
        try {
          const body = await c.req.json();
          
          if (isDemoData(body)) {
            console.error('🚨 AIRTRUST PRODUCTION POLICY VIOLATION: Demo data insertion blocked');
            
            return c.json({
              error: 'DEMO_DATA_BLOCKED',
              message: 'AirTrust Production Policy: Inserção de dados de teste/demo é terminantemente proibida',
              details: 'Este sistema só aceita dados reais inseridos/importados pelo usuário',
              policy: 'ZERO_DEMO_DATA_TOLERANCE',
              action: 'REQUEST_BLOCKED'
            }, 403);
          }
          
          // Restaurar body para próximo middleware
          c.req._body = body;
          
        } catch (error) {
          // Se não conseguir parsear JSON, continua
        }
      }
      
      // Verificar form data
      if (contentType.includes('multipart/form-data') || contentType.includes('application/x-www-form-urlencoded')) {
        try {
          const formData = await c.req.formData();
          const formObj: any = {};
          
          for (const [key, value] of formData) {
            formObj[key] = value;
          }
          
          if (isDemoData(formObj)) {
            console.error('🚨 AIRTRUST PRODUCTION POLICY VIOLATION: Demo data in form blocked');
            
            return c.json({
              error: 'DEMO_DATA_BLOCKED',
              message: 'AirTrust Production Policy: Dados de teste em formulários são proibidos',
              policy: 'ZERO_DEMO_DATA_TOLERANCE',
              action: 'FORM_REQUEST_BLOCKED'
            }, 403);
          }
          
        } catch (error) {
          // Se não conseguir parsear form data, continua
        }
      }
    }
    
    await next();
  };
}

/**
 * Verifica se banco contém dados de demo e alerta
 */
export async function auditDemoDataInDatabase(db: any): Promise<{ hasDemoData: boolean, violations: string[] }> {
  const violations: string[] = [];
  
  try {
    // Verificar funcionários com nomes de demo
    for (const name of FORBIDDEN_DEMO_NAMES) {
      const result = await db.prepare(
        `SELECT COUNT(*) as count FROM funcionarios WHERE LOWER(nome) LIKE ? AND (deleted_at IS NULL OR deleted_at = '')`
      ).bind(`%${name}%`).first();
      
      if (result.count > 0) {
        violations.push(`Funcionário com nome demo: ${name} (${result.count} registros)`);
      }
    }
    
    // Verificar matrículas de demo
    for (const matricula of FORBIDDEN_DEMO_MATRICULAS) {
      const result = await db.prepare(
        `SELECT COUNT(*) as count FROM funcionarios WHERE UPPER(matricula) = ? AND (deleted_at IS NULL OR deleted_at = '')`
      ).bind(matricula.toUpperCase()).first();
      
      if (result.count > 0) {
        violations.push(`Funcionário com matrícula demo: ${matricula} (${result.count} registros)`);
      }
    }
    
    // Log resultado
    if (violations.length > 0) {
      console.error('🚨 DEMO DATA AUDIT FAILED:', violations);
      return { hasDemoData: true, violations };
    } else {
      console.log('✅ DEMO DATA AUDIT PASSED: Banco limpo de dados de teste');
      return { hasDemoData: false, violations: [] };
    }
    
  } catch (error) {
    console.error('❌ Erro na auditoria de demo data:', error);
    return { hasDemoData: false, violations: ['Erro na auditoria'] };
  }
}
