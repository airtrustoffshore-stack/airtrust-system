import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';
import { 
  gerarProximoCertificacaoId, 
  normalizarMatricula, 
  calcularDataVencimento, 
  calcularDiasParaVencimento, 
  determinarComplianceStatus 
} from '../../../shared/utils/certificacao-utils';

const app = new Hono<{ Bindings: Env }>();

// Schema de validação para certificação V3
const CertificacaoV3Schema = z.object({
  funcionario_matricula: z.string().min(1),
  treinamento_codigo: z.string().min(1),
  data_conclusao: z.string().min(1),
  data_vencimento: z.string().optional(),
  instrutor: z.string().min(1),
  local_realizacao: z.string().optional(),
  nota_final: z.number().min(0).max(10).optional(),
  observacoes: z.string().optional(),
  tipo_operacao: z.enum(['NOVA', 'RENOVACAO', 'REVALIDACAO']).default('NOVA'),
  created_by: z.string().optional()
});

// Schema para batch import
const BatchImportSchema = z.object({
  csv_data: z.string().min(1)
});

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// POST /api/v2/certificacoes-v3 - Criar certificação com ID automático
app.post('/', requirePermission('treinamentos', 'CREATE'), zValidator('json', CertificacaoV3Schema), async (c) => {
  try {
    const dados = c.req.valid('json');
    const db = c.env.DB;
    
    // 1. Criar snapshot antes da operação
    const { BackupService } = await import('../../services/backup');
    const snapshotId = await BackupService.createSnapshot(c, 'CREATE', 'certificacoes_v3');
    
    // 2. Normalizar matrícula para 5 dígitos
    let matriculaNormalizada: string;
    try {
      matriculaNormalizada = normalizarMatricula(dados.funcionario_matricula);
    } catch (error) {
      return c.json({ 
        success: false, 
        error: 'Matrícula inválida',
        details: error instanceof Error ? error.message : 'Formato de matrícula incorreto'
      }, 400);
    }

    // 3. Gerar ID formatado único (MATRICULA-CODIGO-ANO-SEQUENCIAL)
    const certificacaoId = await gerarProximoCertificacaoId(db, matriculaNormalizada, dados.treinamento_codigo, dados.data_conclusao);
    
    
    
    // 4. Validar se funcionário existe
    const funcionario = await db.prepare(
      'SELECT id, nome FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL'
    ).bind(matriculaNormalizada).first();
    
    if (!funcionario) {
      return c.json({ 
        success: false,
        error: 'Funcionário não encontrado',
        details: `Funcionário com matrícula '${matriculaNormalizada}' não existe no sistema`
      }, 404);
    }
    
    // 5. Validar se treinamento existe
    const treinamento = await db.prepare(
      'SELECT id, nome FROM catalogo_treinamentos_v2 WHERE codigo = ? AND deleted_at IS NULL'
    ).bind(dados.treinamento_codigo).first();
    
    if (!treinamento) {
      return c.json({ 
        success: false,
        error: 'Treinamento não encontrado',
        details: `Treinamento '${dados.treinamento_codigo}' não existe no catálogo`
      }, 404);
    }
    
    // 6. Calcular data de vencimento automaticamente se não fornecida
    const dataVencimento = dados.data_vencimento || calcularDataVencimento(
      dados.data_conclusao, 
      dados.treinamento_codigo
    );
    
    // 7. Calcular compliance automaticamente
    const diasParaVencimento = calcularDiasParaVencimento(dataVencimento);
    const complianceStatus = determinarComplianceStatus(diasParaVencimento);
    
    // 8. Atualizar certificação anterior para "SUBSTITUIDO" se for renovação
    if (dados.tipo_operacao === 'RENOVACAO') {
      await db.prepare(`
        UPDATE certificacoes_v3 
        SET status = 'SUBSTITUIDO', updated_at = CURRENT_TIMESTAMP
        WHERE funcionario_matricula = ? AND treinamento_codigo = ? AND status = 'ATIVO'
      `).bind(matriculaNormalizada, dados.treinamento_codigo).run();
    }
    
    // 9. Inserir nova certificação
    const result = await db.prepare(`
      INSERT INTO certificacoes_v3 (
        certificacao_id, funcionario_matricula, treinamento_codigo,
        data_conclusao, data_vencimento, instrutor, local_realizacao, nota_final,
        observacoes, tipo_operacao, compliance_status, dias_para_vencimento, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      certificacaoId,
      matriculaNormalizada,
      dados.treinamento_codigo,
      dados.data_conclusao,
      dataVencimento,
      dados.instrutor,
      dados.local_realizacao || null,
      dados.nota_final || null,
      dados.observacoes || null,
      dados.tipo_operacao,
      complianceStatus,
      diasParaVencimento,
      dados.created_by || 'SISTEMA'
    ).run();
    
    if (!result.success) {
      return c.json({ 
        success: false,
        error: 'Erro ao criar certificação' 
      }, 400);
    }

    // 10. Registrar auditoria e validar pós-operação
    await logAudit(c, 'CREATE', 'certificacoes_v3', certificacaoId, undefined, {
      ...dados,
      certificacao_id: certificacaoId,
      funcionario_nome: funcionario.nome,
      treinamento_nome: treinamento.nome
    });
    await BackupService.validatePostOperation(c, snapshotId, 'certificacoes_v3');
    
    return c.json({
      success: true,
      certificacao_id: certificacaoId,
      message: `Certificação criada: ${certificacaoId}`,
      data: {
        id: result.meta.last_row_id,
        certificacao_id: certificacaoId,
        funcionario_matricula: matriculaNormalizada,
        funcionario_nome: funcionario.nome,
        treinamento_codigo: dados.treinamento_codigo,
        treinamento_nome: treinamento.nome,
        data_conclusao: dados.data_conclusao,
        data_vencimento: dataVencimento,
        dias_para_vencimento: diasParaVencimento,
        compliance_status: complianceStatus
      }
    }, 201);
    
  } catch (error) {
    console.error('Error creating certificacao v3:', error);
    await logAudit(c, 'CREATE', 'certificacoes_v3', undefined, undefined, undefined, 'ERROR');
    return c.json({ 
      success: false,
      error: 'Internal server error',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/certificacoes-v3/:certificacao_id - Buscar por ID específico
app.get('/:certificacao_id', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const certificacaoId = c.req.param('certificacao_id');
    const db = c.env.DB;
    
    const certificacao = await db.prepare(`
      SELECT 
        c.*,
        f.nome as funcionario_nome,
        t.nome as treinamento_nome,
        t.categoria as treinamento_categoria
      FROM certificacoes_v3 c
      LEFT JOIN funcionarios f ON c.funcionario_matricula = f.matricula
      LEFT JOIN catalogo_treinamentos_v2 t ON c.treinamento_codigo = t.codigo
      WHERE c.certificacao_id = ?
    `).bind(certificacaoId).first();
    
    if (!certificacao) {
      return c.json({ 
        success: false, 
        error: 'Certificação não encontrada',
        details: `Certificação '${certificacaoId}' não existe no sistema`
      }, 404);
    }
    
    await logAudit(c, 'READ', 'certificacoes_v3', certificacaoId);
    
    return c.json({ 
      success: true, 
      data: certificacao 
    });
    
  } catch (error) {
    console.error('Error reading certificacao v3:', error);
    return c.json({ 
      success: false,
      error: 'Internal server error' 
    }, 500);
  }
});

// GET /api/v2/certificacoes-v3 - Listar certificações com filtros
app.get('/', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    const funcionario_matricula = c.req.query('funcionario_matricula');
    const treinamento_codigo = c.req.query('treinamento_codigo');
    const status = c.req.query('status') || 'ATIVO';
    const compliance_status = c.req.query('compliance_status');
    const include_sync_data = c.req.query('include_sync_data') === 'true';
    const limit = parseInt(c.req.query('limit') || '50');
    const offset = parseInt(c.req.query('offset') || '0');
    
    let whereClause = 'WHERE 1=1';
    const params = [];
    
    if (funcionario_matricula) {
      whereClause += ' AND c.funcionario_matricula = ?';
      params.push(funcionario_matricula);
    }
    
    if (treinamento_codigo) {
      whereClause += ' AND c.treinamento_codigo = ?';
      params.push(treinamento_codigo);
    }
    
    if (status) {
      whereClause += ' AND c.status = ?';
      params.push(status);
    }
    
    if (compliance_status) {
      whereClause += ' AND c.compliance_status = ?';
      params.push(compliance_status);
    }
    
    params.push(limit, offset);
    
    // ✅ INCLUIR DADOS DA PASTA VIRTUAL QUANDO SOLICITADO
    let selectClause = `
      SELECT 
        c.*,
        f.nome as funcionario_nome,
        t.nome as treinamento_nome,
        t.categoria as treinamento_categoria`;
        
    let joinClause = `
      FROM certificacoes_v3 c
      LEFT JOIN funcionarios f ON c.funcionario_matricula = f.matricula
      LEFT JOIN catalogo_treinamentos_v2 t ON c.treinamento_codigo = t.codigo`;
    
    if (include_sync_data) {
      selectClause += `,
        pvs.id as sync_id,
        pvs.arquivo_pasta_virtual_url,
        pvs.nome_arquivo_auditavel,
        pvs.status_sincronizacao`;
        
      joinClause += `
        LEFT JOIN pasta_virtual_sync_log pvs ON pvs.historico_cert_id = c.id 
          AND pvs.deleted_at IS NULL`;
    }
    
    const stmt = db.prepare(`
      ${selectClause}
      ${joinClause}
      ${whereClause}
      ORDER BY c.created_at DESC
      LIMIT ? OFFSET ?
    `);
    
    const result = await stmt.bind(...params).all();
    const certificacoes = result.results;

    await logAudit(c, 'LIST', 'certificacoes_v3');
    
    return c.json({
      success: true,
      data: certificacoes,
      total: certificacoes?.length || 0,
      include_sync_data: include_sync_data,
      pagination: {
        limit,
        offset,
        has_more: (certificacoes?.length || 0) === limit
      }
    });
    
  } catch (error) {
    console.error('Error listing certificacoes v3:', error);
    return c.json({ 
      success: false,
      error: 'Internal server error' 
    }, 500);
  }
});

// GET /api/v2/certificacoes-v3/dashboard/metrics - Métricas de compliance
app.get('/dashboard/metrics', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const metrics = await db.prepare(`
      SELECT 
        COUNT(*) as total_certificacoes,
        COUNT(CASE WHEN compliance_status = 'VALIDO' THEN 1 END) as validas,
        COUNT(CASE WHEN compliance_status = 'VENCIDO' THEN 1 END) as vencidas,
        COUNT(CASE WHEN compliance_status = 'VENCENDO' THEN 1 END) as vencendo_30_dias,
        AVG(CASE WHEN dias_para_vencimento > 0 THEN dias_para_vencimento END) as media_dias_vencimento,
        COUNT(CASE WHEN status = 'ATIVO' THEN 1 END) as ativas,
        COUNT(CASE WHEN status = 'SUBSTITUIDO' THEN 1 END) as substituidas,
        COUNT(CASE WHEN tipo_operacao = 'NOVA' THEN 1 END) as novas,
        COUNT(CASE WHEN tipo_operacao = 'RENOVACAO' THEN 1 END) as renovacoes
      FROM certificacoes_v3 
      WHERE status = 'ATIVO'
    `).first();
    
    // Certificações por treinamento
    const porTreinamento = await db.prepare(`
      SELECT 
        c.treinamento_codigo,
        t.nome as treinamento_nome,
        COUNT(*) as total,
        COUNT(CASE WHEN c.compliance_status = 'VALIDO' THEN 1 END) as validas,
        COUNT(CASE WHEN c.compliance_status = 'VENCIDO' THEN 1 END) as vencidas
      FROM certificacoes_v3 c
      LEFT JOIN catalogo_treinamentos_v2 t ON c.treinamento_codigo = t.codigo
      WHERE c.status = 'ATIVO'
      GROUP BY c.treinamento_codigo, t.nome
      ORDER BY total DESC
      LIMIT 10
    `).all();
    
    // Certificações por funcionário com mais vencimentos
    const funcionariosCriticos = await db.prepare(`
      SELECT 
        c.funcionario_matricula,
        f.nome as funcionario_nome,
        COUNT(*) as total_certificacoes,
        COUNT(CASE WHEN c.compliance_status = 'VENCIDO' THEN 1 END) as vencidas,
        COUNT(CASE WHEN c.compliance_status = 'VENCENDO' THEN 1 END) as vencendo,
        MIN(c.dias_para_vencimento) as menor_prazo
      FROM certificacoes_v3 c
      LEFT JOIN funcionarios f ON c.funcionario_matricula = f.matricula
      WHERE c.status = 'ATIVO' AND c.compliance_status IN ('VENCIDO', 'VENCENDO')
      GROUP BY c.funcionario_matricula, f.nome
      HAVING (vencidas + vencendo) > 0
      ORDER BY vencidas DESC, menor_prazo ASC
      LIMIT 10
    `).all();
    
    await logAudit(c, 'READ', 'certificacoes_v3', 'dashboard_metrics');
    
    return c.json({
      success: true,
      data: {
        resumo: metrics,
        por_treinamento: porTreinamento.results,
        funcionarios_criticos: funcionariosCriticos.results
      }
    });
    
  } catch (error) {
    console.error('Error getting dashboard metrics:', error);
    return c.json({ 
      success: false,
      error: 'Internal server error' 
    }, 500);
  }
});

// PUT /api/v2/certificacoes-v3/:certificacao_id - Atualizar certificação
app.put('/:certificacao_id', requirePermission('treinamentos', 'UPDATE'), zValidator('json', CertificacaoV3Schema.partial()), async (c) => {
  try {
    const certificacaoId = c.req.param('certificacao_id');
    const dados = c.req.valid('json');
    const db = c.env.DB;
    
    // 1. Verificar se existe
    const existing = await db.prepare(
      'SELECT * FROM certificacoes_v3 WHERE certificacao_id = ?'
    ).bind(certificacaoId).first();
    
    if (!existing) {
      return c.json({ 
        success: false, 
        error: 'Certificação não encontrada',
        details: `Certificação '${certificacaoId}' não existe no sistema`
      }, 404);
    }
    
    // 2. Criar snapshot antes da operação
    const { BackupService } = await import('../../services/backup');
    const snapshotId = await BackupService.createSnapshot(c, 'UPDATE', 'certificacoes_v3');
    
    // 3. Construir query de update dinamicamente
    const updateFields = [];
    const params = [];
    
    if (dados.data_conclusao !== undefined) {
      updateFields.push('data_conclusao = ?');
      params.push(dados.data_conclusao);
    }
    if (dados.data_vencimento !== undefined) {
      updateFields.push('data_vencimento = ?');
      params.push(dados.data_vencimento);
      
      // Recalcular compliance se data vencimento mudou
      const diasParaVencimento = calcularDiasParaVencimento(dados.data_vencimento);
      const complianceStatus = determinarComplianceStatus(diasParaVencimento);
      updateFields.push('dias_para_vencimento = ?', 'compliance_status = ?');
      params.push(diasParaVencimento, complianceStatus);
    }
    if (dados.instrutor !== undefined) {
      updateFields.push('instrutor = ?');
      params.push(dados.instrutor);
    }
    if (dados.local_realizacao !== undefined) {
      updateFields.push('local_realizacao = ?');
      params.push(dados.local_realizacao || null);
    }
    if (dados.nota_final !== undefined) {
      updateFields.push('nota_final = ?');
      params.push(dados.nota_final || null);
    }
    if (dados.observacoes !== undefined) {
      updateFields.push('observacoes = ?');
      params.push(dados.observacoes || null);
    }
    
    updateFields.push('updated_at = CURRENT_TIMESTAMP');
    params.push(certificacaoId);
    
    const stmt = db.prepare(`
      UPDATE certificacoes_v3 
      SET ${updateFields.join(', ')}
      WHERE certificacao_id = ?
    `);
    
    const result = await stmt.bind(...params).run();
    
    if (!result.success) {
      return c.json({ 
        success: false,
        error: 'Erro ao atualizar certificação' 
      }, 400);
    }

    // 4. Registrar auditoria e validar pós-operação
    await logAudit(c, 'UPDATE', 'certificacoes_v3', certificacaoId, existing, dados);
    await BackupService.validatePostOperation(c, snapshotId, 'certificacoes_v3');
    
    return c.json({
      success: true,
      message: 'Certificação atualizada com sucesso',
      certificacao_id: certificacaoId
    });
  } catch (error) {
    console.error('Error updating certificacao v3:', error);
    await logAudit(c, 'UPDATE', 'certificacoes_v3', c.req.param('certificacao_id'), undefined, undefined, 'ERROR');
    return c.json({ 
      success: false,
      error: 'Internal server error' 
    }, 500);
  }
});

// DELETE /api/v2/certificacoes-v3/:certificacao_id - Deletar certificação (status = CANCELADO) - VERSÃO CORRIGIDA
app.delete('/:certificacao_id', requirePermission('treinamentos', 'DELETE'), async (c) => {
  const certificacaoId = c.req.param('certificacao_id');
  const db = c.env.DB;
  
  console.log(`🚨 [CERTIFICACOES-V3 DELETE] Iniciando exclusão certificação ID: ${certificacaoId}`);
  
  try {
    // 1. VERIFICAR SE CERTIFICAÇÃO EXISTE
    console.log(`🔍 [CERTIFICACOES-V3 DELETE] Buscando certificação ${certificacaoId}...`);
    
    let certificacao;
    try {
      certificacao = await db.prepare(`
        SELECT certificacao_id, funcionario_matricula, treinamento_codigo, status 
        FROM certificacoes_v3 
        WHERE certificacao_id = ?
      `).bind(certificacaoId).first();
      
      console.log(`📋 [CERTIFICACOES-V3 DELETE] Certificação encontrada:`, certificacao ? 
        `${certificacao.certificacao_id} (${certificacao.funcionario_matricula}) - Status: ${certificacao.status}` : 
        'NÃO ENCONTRADA');
      
    } catch (selectError: any) {
      console.error(`❌ [CERTIFICACOES-V3 DELETE] Erro ao buscar certificação:`, selectError);
      return c.json({
        success: false,
        error: 'Erro ao buscar certificação no banco de dados',
        technical_details: selectError?.message || 'Erro desconhecido'
      }, 500);
    }

    if (!certificacao) {
      console.log(`❌ [CERTIFICACOES-V3 DELETE] Certificação ${certificacaoId} não encontrada`);
      return c.json({
        success: false,
        error: 'Certificação não encontrada',
        details: `Certificação '${certificacaoId}' não existe no sistema`
      }, 404);
    }

    // 2. VERIFICAR SE JÁ ESTÁ CANCELADA
    if (certificacao.status === 'CANCELADO') {
      console.log(`⚠️ [CERTIFICACOES-V3 DELETE] Certificação ${certificacaoId} já estava cancelada`);
      return c.json({
        success: false,
        error: 'Certificação já foi cancelada anteriormente',
        current_status: certificacao.status
      }, 400);
    }

    // 3. APLICAR CANCELAMENTO
    const now = new Date().toISOString();
    console.log(`🔧 [CERTIFICACOES-V3 DELETE] Aplicando cancelamento com timestamp: ${now}`);

    const updateResult = await db.prepare(`
      UPDATE certificacoes_v3 
      SET status = 'CANCELADO', updated_at = ? 
      WHERE certificacao_id = ? AND status != 'CANCELADO'
    `).bind(now, certificacaoId).run();
    
    const changes = updateResult.meta?.changes || 0;
    console.log(`📊 [CERTIFICACOES-V3 DELETE] Resultado UPDATE: success=${updateResult.success}, changes=${changes}`);
    
    if (!updateResult.success || changes === 0) {
      console.error(`❌ [CERTIFICACOES-V3 DELETE] Falha na atualização. Success: ${updateResult.success}, Changes: ${changes}`);
      return c.json({
        success: false,
        error: 'Erro interno ao aplicar cancelamento',
        debug: { success: updateResult.success, changes }
      }, 500);
    }

    // 4. VALIDAR QUE O CANCELAMENTO FUNCIONOU
    console.log(`🔍 [CERTIFICACOES-V3 DELETE] Validando cancelamento...`);
    
    const verificacao = await db.prepare(`
      SELECT status FROM certificacoes_v3 WHERE certificacao_id = ?
    `).bind(certificacaoId).first();
    
    console.log(`📋 [CERTIFICACOES-V3 DELETE] Verificação pós-cancelamento: status = ${verificacao?.status}`);
    
    if (verificacao?.status !== 'CANCELADO') {
      console.error(`❌ [CERTIFICACOES-V3 DELETE] VALIDAÇÃO FALHOU: certificação ${certificacaoId} não foi marcada como CANCELADO`);
      return c.json({
        success: false,
        error: 'Falha na validação do cancelamento - operação não foi concluída',
        verification_result: verificacao
      }, 500);
    }

    // 5. SUCESSO!
    console.log(`🎯 [CERTIFICACOES-V3 DELETE] SUCESSO: Certificação ${certificacaoId} cancelada com sucesso`);
    
    // 6. Registrar auditoria
    try {
      await logAudit(c, 'DELETE', 'certificacoes_v3', certificacaoId, certificacao, { status: 'CANCELADO', updated_at: now });
    } catch (auditError) {
      console.warn('⚠️ [CERTIFICACOES-V3 DELETE] Erro ao registrar auditoria (operação continuou):', auditError);
    }
    
    return c.json({
      success: true,
      message: 'Certificação cancelada com sucesso',
      data: {
        certificacao_id: certificacao.certificacao_id,
        funcionario_matricula: certificacao.funcionario_matricula,
        treinamento_codigo: certificacao.treinamento_codigo,
        status_anterior: certificacao.status,
        status_atual: 'CANCELADO',
        cancelled_at: now,
        verified_status: verificacao.status
      }
    });

  } catch (error: any) {
    console.error(`❌ [CERTIFICACOES-V3 DELETE] ERRO CRÍTICO:`, error);
    
    try {
      await logAudit(c, 'DELETE', 'certificacoes_v3', certificacaoId, undefined, undefined, 'ERROR');
    } catch (auditError) {
      console.warn('⚠️ [CERTIFICACOES-V3 DELETE] Erro também na auditoria:', auditError);
    }
    
    return c.json({
      success: false,
      error: 'Erro crítico do sistema',
      technical_details: error?.message || 'Erro desconhecido'
    }, 500);
  }
});

// POST /api/v2/certificacoes-v3/batch-import - Importação em lote com IDs automáticos
app.post('/batch-import', requirePermission('treinamentos', 'CREATE'), zValidator('json', BatchImportSchema), async (c) => {
  const startTime = Date.now();
  const batchId = `cert_v3_batch_${Date.now()}`;
  
  try {
    const { csv_data } = c.req.valid('json');
    const db = c.env.DB;
    
    // 1. Criar snapshot antes da operação
    const { BackupService } = await import('../../services/backup');
    const snapshotId = await BackupService.createSnapshot(c, 'BATCH_CREATE', 'certificacoes_v3');
    
    // 2. Parse do CSV
    const linhas = csv_data.trim().split('\n');
    if (linhas.length < 2) {
      return c.json({
        success: false,
        batch_id: batchId,
        error: 'CSV deve conter cabeçalho e pelo menos uma linha de dados'
      }, 400);
    }
    
    const headers = linhas[0].split(',').map(h => h.trim());
    const rows = linhas.slice(1);
    
    let rowsProcessed = 0;
    let rowsFailed = 0;
    const errors: string[] = [];
    const successIds: string[] = [];
    
    // 3. Processar cada linha
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i].trim();
      if (!row) continue;
      
      const campos = row.split(',').map(c => c.trim());
      const actualRowNumber = i + 2;
      
      try {
        // Mapear campos
        const rowData: any = {};
        headers.forEach((header, index) => {
          rowData[header] = campos[index] || '';
        });
        
        // Normalizar matrícula
        let matriculaNormalizada: string;
        try {
          matriculaNormalizada = normalizarMatricula(rowData.funcionario_matricula);
        } catch (error) {
          errors.push(`Linha ${actualRowNumber}: ${error instanceof Error ? error.message : 'Matrícula inválida'}`);
          rowsFailed++;
          continue;
        }
        
        // Verificar funcionário
        const funcionario = await db.prepare(
          'SELECT id FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL'
        ).bind(matriculaNormalizada).first();
        
        if (!funcionario) {
          errors.push(`Linha ${actualRowNumber}: Funcionário ${matriculaNormalizada} não encontrado`);
          rowsFailed++;
          continue;
        }
        
        // Gerar ID formatado da certificação
        const certificacaoId = await gerarProximoCertificacaoId(db, matriculaNormalizada, rowData.treinamento_codigo);
        
        // Calcular vencimento e compliance
        const dataVencimento = rowData.data_vencimento || calcularDataVencimento(
          rowData.data_conclusao, 
          rowData.treinamento_codigo
        );
        const diasParaVencimento = calcularDiasParaVencimento(dataVencimento);
        const complianceStatus = determinarComplianceStatus(diasParaVencimento);
        
        // Inserir certificação
        const result = await db.prepare(`
          INSERT INTO certificacoes_v3 (
            certificacao_id, funcionario_matricula, treinamento_codigo,
            data_conclusao, data_vencimento, instrutor, nota_final, observacoes,
            compliance_status, dias_para_vencimento, created_by
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          certificacaoId,
          matriculaNormalizada,
          rowData.treinamento_codigo,
          rowData.data_conclusao,
          dataVencimento,
          rowData.instrutor,
          rowData.nota_final ? parseFloat(rowData.nota_final) : null,
          rowData.observacoes || null,
          complianceStatus,
          diasParaVencimento,
          'BATCH_IMPORT'
        ).run();
        
        if (result.success) {
          successIds.push(certificacaoId);
          rowsProcessed++;
        } else {
          errors.push(`Linha ${actualRowNumber}: Erro ao inserir no banco`);
          rowsFailed++;
        }
        
      } catch (error) {
        errors.push(`Linha ${actualRowNumber}: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
        rowsFailed++;
      }
    }
    
    const processingTime = Date.now() - startTime;
    
    // 4. Registrar auditoria
    await logAudit(c, 'BATCH_CREATE', 'certificacoes_v3', batchId, undefined, {
      rows_total: rows.length,
      rows_processed: rowsProcessed,
      rows_failed: rowsFailed,
      processing_time_ms: processingTime,
      success_ids: successIds.slice(0, 10) // Primeiros 10 IDs para auditoria
    });
    
    // 5. Validar pós-operação
    await BackupService.validatePostOperation(c, snapshotId, 'certificacoes_v3');
    
    return c.json({
      success: rowsProcessed > 0,
      batch_id: batchId,
      processing_time_ms: processingTime,
      rows_total: rows.length,
      rows_processed: rowsProcessed,
      rows_failed: rowsFailed,
      errors: errors.slice(0, 20), // Máximo 20 erros na resposta
      success_ids: successIds,
      summary: `${rowsProcessed} certificações criadas com IDs únicos. ${rowsFailed} falhas.`
    }, rowsProcessed > 0 ? 201 : 400);
    
  } catch (error) {
    console.error('Error in batch import certificacoes v3:', error);
    return c.json({
      success: false,
      batch_id: batchId,
      processing_time_ms: Date.now() - startTime,
      error: error instanceof Error ? error.message : 'Erro interno do servidor'
    }, 500);
  }
});

// CORREÇÃO 1: ENDPOINT PARA ATUALIZAR IDs EXISTENTES
app.post('/atualizar-ids', requirePermission('treinamentos', 'UPDATE'), async (c) => {
  try {
    console.log('🔄 Atualizando IDs de certificações...');
    const db = c.env.DB;
    
    const certificacoes = await db.prepare(`
      SELECT 
        c.id,
        c.certificacao_id,
        c.data_conclusao,
        c.treinamento_codigo
      FROM certificacoes_v3 c
      WHERE c.certificacao_id IS NULL OR c.certificacao_id = ''
    `).all();
    
    let atualizados = 0;
    
    for (const cert of certificacoes.results) {
      // Gerar novo ID mais limpo: OPC-2025-01, FAP-2025-02, etc.
      const ano = new Date(cert.data_conclusao as string).getFullYear();
      const contador = String(Math.floor(Math.random() * 99) + 1).padStart(2, '0');
      const novoId = `${(cert.treinamento_codigo as string) || 'CERT'}-${ano}-${contador}`;
      
      // Verificar se não existe
      const existe = await db.prepare(`
        SELECT id FROM certificacoes_v3 
        WHERE certificacao_id = ? AND id != ?
      `).bind(novoId, cert.id as number).first();
      
      if (!existe) {
        await db.prepare(`
          UPDATE certificacoes_v3 
          SET certificacao_id = ?, updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `).bind(novoId, cert.id as number).run();
        
        atualizados++;
      }
    }
    
    return c.json({
      success: true,
      message: `${atualizados} IDs atualizados com sucesso`,
      atualizados: atualizados
    });
    
  } catch (error) {
    console.error('💥 Erro ao atualizar IDs:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// CORREÇÃO 2: ENDPOINT PARA BAIXAR CERTIFICADO ANEXADO ORIGINAL
app.get('/:id/certificado', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const certificacaoId = c.req.param('id');
    console.log(`📎 Buscando certificado anexado para ID: ${certificacaoId}`);
    const db = c.env.DB;
    
    // Buscar certificação com URL do arquivo anexado
    const certificacao = await db.prepare(`
      SELECT 
        hc.*,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        ct.nome as treinamento_nome,
        ct.codigo as treinamento_codigo
      FROM historico_certificacoes_v2 hc
      LEFT JOIN funcionarios f ON hc.funcionario_id = f.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE hc.id = ? AND hc.deleted_at IS NULL
    `).bind(certificacaoId).first();
    
    if (!certificacao) {
      return c.json({
        success: false,
        error: 'Certificação não encontrada'
      }, 404);
    }
    
    // Verificar se existe certificado anexado
    if (!certificacao.certificado_url) {
      return c.json({
        success: false,
        error: 'Nenhum certificado anexado para esta certificação'
      }, 404);
    }
    
    const certificadoUrl = certificacao.certificado_url as string;
    
    try {
      // Se o arquivo estiver no R2 Storage do Cloudflare
      if (certificadoUrl.includes('cloudflare')) {
        return c.redirect(certificadoUrl);
      }
      
      // Se for armazenamento local/pasta virtual
      if (certificadoUrl.startsWith('uploads/') || 
          certificadoUrl.startsWith('pasta-virtual/')) {
        
        const response = await fetch(certificadoUrl);
        
        if (!response.ok) {
          return c.json({
            success: false,
            error: 'Arquivo do certificado não encontrado no storage'
          }, 404);
        }
        
        const fileBuffer = await response.arrayBuffer();
        
        return c.body(fileBuffer, 200, {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="Certificado_${certificacao.certificacao_id}_${(certificacao.funcionario_nome as string).replace(/\s+/g, '_')}.pdf"`,
          'Cache-Control': 'no-cache'
        });
      }
      
      // Fallback: retornar URL direta
      return c.json({
        success: true,
        download_url: certificadoUrl,
        filename: `Certificado_${certificacao.certificacao_id}_${(certificacao.funcionario_nome as string).replace(/\s+/g, '_')}.pdf`
      });
      
    } catch (fileError) {
      console.error('💥 Erro ao acessar arquivo:', fileError);
      return c.json({
        success: false,
        error: 'Erro ao acessar arquivo do certificado',
        details: fileError instanceof Error ? fileError.message : 'Erro desconhecido'
      }, 500);
    }
    
  } catch (error) {
    console.error('💥 Erro ao buscar certificado:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// CORREÇÃO 3: ENDPOINT TEMPORÁRIO PARA INVESTIGAR ESTRUTURA
app.get('/debug/storage', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    console.log('🔍 Investigando storage de certificados...');
    const db = c.env.DB;
    
    // Buscar todas as certificações com URLs
    const certificacoes = await db.prepare(`
      SELECT 
        id, 
        certificacao_id, 
        certificado_url,
        created_at,
        updated_at
      FROM historico_certificacoes_v2 
      WHERE certificado_url IS NOT NULL 
        AND certificado_url != ''
        AND deleted_at IS NULL
      ORDER BY created_at DESC
      LIMIT 50
    `).all();
    
    const debug_info = [];
    
    for (const cert of certificacoes.results) {
      let status_arquivo = 'NAO_TESTADO';
      let detalhes = {};
      
      try {
        if (cert.certificado_url) {
          const response = await fetch(cert.certificado_url as string, { 
            method: 'HEAD'
          });
          
          status_arquivo = response.ok ? 'ACESSIVEL' : `HTTP_${response.status}`;
          detalhes = {
            content_type: response.headers.get('content-type'),
            content_length: response.headers.get('content-length'),
            last_modified: response.headers.get('last-modified')
          };
        }
      } catch (error) {
        status_arquivo = 'ERRO';
        detalhes = { erro: error instanceof Error ? error.message : 'Erro desconhecido' };
      }
      
      debug_info.push({
        id: cert.id,
        certificacao_id: cert.certificacao_id,
        url: cert.certificado_url,
        status: status_arquivo,
        detalhes: detalhes,
        created_at: cert.created_at
      });
    }
    
    return c.json({
      success: true,
      total_certificados: certificacoes.results.length,
      debug_info: debug_info,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('💥 Erro no debug:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
