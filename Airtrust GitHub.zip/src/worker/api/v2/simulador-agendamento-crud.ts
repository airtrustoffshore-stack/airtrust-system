import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

// PUT - Editar agendamento
app.put('/:uuid', async (c) => {
  try {
    const db = c.env.DB;
    const { uuid } = c.req.param();
    const dados = await c.req.json();
    
    console.log(`📝 Editando agendamento: ${uuid}`);
    console.log('Dados recebidos:', dados);
    
    // Buscar ficha pelo UUID
    const ficha = await db.prepare(`
      SELECT fs.id, fs.agendamento_slot_id, fs.status_workflow
      FROM fichas_sessao fs 
      WHERE fs.ficha_uuid = ? AND fs.deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Agendamento não encontrado' }, 404);
    }
    
    // Verificar se pode ser editado
    const statusEditaveis = ['RASCUNHO', 'PENDENTE_ALUNO'];
    if (!statusEditaveis.includes(ficha.status_workflow)) {
      return c.json({
        error: 'Este agendamento não pode ser editado no status atual',
        status_atual: ficha.status_workflow
      }, 400);
    }
    
    // Atualizar slot de agendamento se dados gerais fornecidos
    if (dados.dados_gerais) {
      const dg = dados.dados_gerais;
      
      // Construir data/hora de início e fim
      const dataInicio = dg.data_inicio && dg.hora_inicio 
        ? `${dg.data_inicio} ${dg.hora_inicio}:00`
        : null;
      const dataFim = dg.data_fim && dg.hora_fim
        ? `${dg.data_fim} ${dg.hora_fim}:00`
        : null;
      
      await db.prepare(`
        UPDATE agendamento_slots 
        SET simulador_id = COALESCE(?, simulador_id),
            colaborador_id_instrutor = COALESCE(?, colaborador_id_instrutor),
            colaborador_id_checador = COALESCE(?, colaborador_id_checador),
            data_inicio = COALESCE(?, data_inicio),
            data_fim = COALESCE(?, data_fim),
            updated_at = datetime('now'),
            updated_by = 'SISTEMA'
        WHERE id = ?
      `).bind(
        dg.simulador_id || null,
        dg.instrutor_id || null,
        dg.checador_id || null,
        dataInicio,
        dataFim,
        ficha.agendamento_slot_id
      ).run();
    }
    
    // Atualizar dados da ficha
    if (dados.observacoes_gerais !== undefined || dados.sessao_template_id !== undefined) {
      await db.prepare(`
        UPDATE fichas_sessao 
        SET observacoes_instrutor = COALESCE(?, observacoes_instrutor),
            sessao_template_id = COALESCE(?, sessao_template_id),
            updated_at = datetime('now'),
            updated_by = 'SISTEMA'
        WHERE id = ?
      `).bind(
        dados.observacoes_gerais || null,
        dados.sessao_template_id || null,
        ficha.id
      ).run();
    }
    
    // Atualizar manobras se fornecidas
    if (dados.manobras && Array.isArray(dados.manobras)) {
      // Remover manobras existentes
      await db.prepare(`
        DELETE FROM fichas_manobras_executadas WHERE ficha_id = ?
      `).bind(ficha.id).run();
      
      // Inserir novas manobras
      for (const manobraId of dados.manobras) {
        await db.prepare(`
          INSERT INTO fichas_manobras_executadas (
            ficha_id, manobra_catalogo_id, nota, observacoes
          ) VALUES (?, ?, NULL, NULL)
        `).bind(ficha.id, manobraId).run();
      }
    }
    
    // Registrar auditoria
    await db.prepare(`
      INSERT INTO auditoria_simulador (
        ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem, timestamp_acao
      ) VALUES (?, ?, ?, ?, ?, datetime('now'))
    `).bind(
      uuid,
      999, // TODO: pegar usuário do contexto
      'AGENDAMENTO_EDITADO',
      JSON.stringify({
        dados_alterados: Object.keys(dados),
        slot_id: ficha.agendamento_slot_id
      }),
      c.req.header('CF-Connecting-IP') || 'unknown'
    ).run();
    
    console.log(`✅ Agendamento ${uuid} atualizado com sucesso`);
    
    return c.json({
      success: true,
      message: 'Agendamento atualizado com sucesso',
      uuid: uuid,
      agendamento_slot_id: ficha.agendamento_slot_id
    });
    
  } catch (error) {
    console.error(`❌ Erro ao editar agendamento ${c.req.param('uuid')}:`, error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// DELETE - Excluir agendamento
app.delete('/:uuid', async (c) => {
  try {
    const db = c.env.DB;
    const { uuid } = c.req.param();
    
    console.log(`🗑️ Excluindo agendamento: ${uuid}`);
    
    // Buscar ficha
    const ficha = await db.prepare(`
      SELECT id, status_workflow FROM fichas_sessao 
      WHERE ficha_uuid = ? AND deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Agendamento não encontrado' }, 404);
    }
    
    // Verificar se pode ser excluído
    const statusExcluiveis = ['RASCUNHO', 'PENDENTE_ALUNO'];
    if (!statusExcluiveis.includes(ficha.status_workflow)) {
      return c.json({
        error: 'Este agendamento não pode ser excluído no status atual',
        status_atual: ficha.status_workflow
      }, 400);
    }
    
    // Soft delete da ficha
    const resultado = await db.prepare(`
      UPDATE fichas_sessao 
      SET deleted_at = datetime('now'), updated_at = datetime('now'), updated_by = 'SISTEMA'
      WHERE ficha_uuid = ? AND deleted_at IS NULL
    `).bind(uuid).run();
    
    if (resultado.changes === 0) {
      return c.json({ error: 'Falha ao excluir agendamento' }, 500);
    }
    
    // Registrar auditoria
    await db.prepare(`
      INSERT INTO auditoria_simulador (
        ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem, timestamp_acao
      ) VALUES (?, ?, ?, ?, ?, datetime('now'))
    `).bind(
      uuid,
      999, // TODO: pegar usuário do contexto
      'AGENDAMENTO_EXCLUIDO',
      JSON.stringify({
        status_anterior: ficha.status_workflow,
        motivo: 'Exclusão via interface'
      }),
      c.req.header('CF-Connecting-IP') || 'unknown'
    ).run();
    
    console.log(`✅ Agendamento ${uuid} excluído com sucesso`);
    
    return c.json({
      success: true,
      message: 'Agendamento excluído com sucesso',
      uuid: uuid
    });
    
  } catch (error) {
    console.error(`❌ Erro ao excluir agendamento ${c.req.param('uuid')}:`, error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET - Buscar agendamento para edição
app.get('/:uuid', async (c) => {
  try {
    const db = c.env.DB;
    const { uuid } = c.req.param();
    
    console.log(`📋 Carregando agendamento para edição: ${uuid}`);
    
    // Buscar dados completos do agendamento
    const agendamento = await db.prepare(`
      SELECT 
        fs.id, fs.ficha_uuid, fs.status_workflow, fs.observacoes_instrutor,
        fs.sessao_template_id, fs.ciclo_executado, fs.colaborador_id_aluno,
        slot.simulador_id, slot.colaborador_id_instrutor, slot.colaborador_id_checador,
        slot.data_inicio, slot.data_fim,
        sim.nome as simulador_nome,
        inst.nome as instrutor_nome,
        check.nome as checador_nome,
        aluno.nome as aluno_nome, aluno.matricula as aluno_matricula,
        st.nome_sessao as template_nome
      FROM fichas_sessao fs
      LEFT JOIN agendamento_slots slot ON fs.agendamento_slot_id = slot.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      LEFT JOIN funcionarios check ON slot.colaborador_id_checador = check.id
      LEFT JOIN funcionarios aluno ON fs.colaborador_id_aluno = aluno.id
      LEFT JOIN sessoes_template st ON fs.sessao_template_id = st.id
      WHERE fs.ficha_uuid = ? AND fs.deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!agendamento) {
      return c.json({ error: 'Agendamento não encontrado' }, 404);
    }
    
    // Extrair data e hora de início e fim
    const dataInicio = agendamento.data_inicio ? agendamento.data_inicio.split(' ')[0] : null;
    const horaInicio = agendamento.data_inicio ? agendamento.data_inicio.split(' ')[1]?.substring(0, 5) : null;
    const dataFim = agendamento.data_fim ? agendamento.data_fim.split(' ')[0] : null;
    const horaFim = agendamento.data_fim ? agendamento.data_fim.split(' ')[1]?.substring(0, 5) : null;
    
    // Buscar manobras configuradas
    const manobras = await db.prepare(`
      SELECT mc.id, mc.manobra_id_codigo, mc.nome_manobra, mc.categoria
      FROM fichas_manobras_executadas me
      JOIN manobras_catalogo mc ON me.manobra_catalogo_id = mc.id
      WHERE me.ficha_id = ?
      ORDER BY mc.categoria, mc.manobra_id_codigo
    `).bind(agendamento.id).all();
    
    return c.json({
      success: true,
      agendamento: {
        uuid: agendamento.ficha_uuid,
        status_workflow: agendamento.status_workflow,
        dados_gerais: {
          simulador_id: agendamento.simulador_id,
          instrutor_id: agendamento.colaborador_id_instrutor,
          checador_id: agendamento.colaborador_id_checador,
          aluno_id: agendamento.colaborador_id_aluno,
          data_inicio: dataInicio,
          hora_inicio: horaInicio,
          data_fim: dataFim,
          hora_fim: horaFim,
          sessao_template_id: agendamento.sessao_template_id,
          ciclo_executado: agendamento.ciclo_executado
        },
        participantes: {
          aluno: {
            id: agendamento.colaborador_id_aluno,
            nome: agendamento.aluno_nome,
            matricula: agendamento.aluno_matricula
          },
          instrutor: {
            id: agendamento.colaborador_id_instrutor,
            nome: agendamento.instrutor_nome
          },
          checador: agendamento.colaborador_id_checador ? {
            id: agendamento.colaborador_id_checador,
            nome: agendamento.checador_nome
          } : null
        },
        simulador: {
          id: agendamento.simulador_id,
          nome: agendamento.simulador_nome
        },
        template: {
          id: agendamento.sessao_template_id,
          nome: agendamento.template_nome
        },
        manobras_configuradas: manobras.results,
        observacoes_gerais: agendamento.observacoes_instrutor
      }
    });
    
  } catch (error) {
    console.error(`❌ Erro ao carregar agendamento ${c.req.param('uuid')}:`, error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
