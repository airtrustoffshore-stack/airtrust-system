import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

// PUT - Salvar avaliação
app.put('/:uuid/avaliacao', async (c) => {
  try {
    const db = c.env.DB;
    const { uuid } = c.req.param();
    const dadosAvaliacao = await c.req.json();
    
    // Verificar se a ficha existe
    const ficha = await db.prepare(`
      SELECT id FROM fichas_sessao WHERE ficha_uuid = ?
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // Atualizar ficha com avaliação
    const resultado = await db.prepare(`
      UPDATE fichas_sessao 
      SET resultado_final = ?, nota_final = ?, status_workflow = 'CONCLUIDA',
          updated_at = datetime('now')
      WHERE ficha_uuid = ?
    `).bind(dadosAvaliacao.conceito || dadosAvaliacao.resultado_final, 
            dadosAvaliacao.nota || dadosAvaliacao.nota_final, 
            uuid).run();
    
    if (resultado.changes === 0) {
      return c.json({ error: 'Erro ao salvar avaliação' }, 500);
    }
    
    return c.json({
      success: true,
      message: 'Avaliação salva com sucesso',
      ficha_uuid: uuid,
      avaliacao: {
        resultado_final: dadosAvaliacao.conceito || dadosAvaliacao.resultado_final,
        nota_final: dadosAvaliacao.nota || dadosAvaliacao.nota_final
      }
    });
    
  } catch (error) {
    console.error('❌ Erro ao salvar avaliação:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET - Buscar avaliação
app.get('/:uuid/avaliacao', async (c) => {
  try {
    const db = c.env.DB;
    const { uuid } = c.req.param();
    
    const ficha = await db.prepare(`
      SELECT 
        ficha_uuid,
        resultado_final,
        nota_final,
        status_workflow,
        observacoes_instrutor
      FROM fichas_sessao 
      WHERE ficha_uuid = ?
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    return c.json({
      success: true,
      avaliacao: {
        ficha_uuid: ficha.ficha_uuid,
        resultado_final: ficha.resultado_final,
        nota_final: ficha.nota_final,
        status_workflow: ficha.status_workflow,
        observacoes: ficha.observacoes_instrutor
      }
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar avaliação:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
