import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

// ✅ GAP 3 - Sistema de relatórios
app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    const periodo = c.req.query('periodo') || '2025-09';
    
    // Estatísticas gerais
    const totalSessoes = await db.prepare(`
      SELECT COUNT(*) as total 
      FROM fichas_sessao 
      WHERE deleted_at IS NULL 
      AND created_at LIKE ?
    `).bind(`${periodo}%`).first();
    
    const sessoesAprovadas = await db.prepare(`
      SELECT COUNT(*) as total 
      FROM fichas_sessao 
      WHERE deleted_at IS NULL 
      AND resultado_final = 'APROVADO'
      AND created_at LIKE ?
    `).bind(`${periodo}%`).first();
    
    const sessoesReprovadas = await db.prepare(`
      SELECT COUNT(*) as total 
      FROM fichas_sessao 
      WHERE deleted_at IS NULL 
      AND resultado_final = 'REPROVADO'
      AND created_at LIKE ?
    `).bind(`${periodo}%`).first();
    
    const sessoesPendentes = await db.prepare(`
      SELECT COUNT(*) as total 
      FROM fichas_sessao 
      WHERE deleted_at IS NULL 
      AND status_workflow IN ('RASCUNHO', 'PENDENTE_ALUNO', 'PENDENTE_INSTRUTOR_FINAL')
      AND created_at LIKE ?
    `).bind(`${periodo}%`).first();
    
    // Dados por simulador
    const porSimulador = await db.prepare(`
      SELECT 
        s.nome as simulador,
        COUNT(fs.id) as sessoes,
        ROUND(
          (COUNT(CASE WHEN fs.resultado_final = 'APROVADO' THEN 1 END) * 100.0 / 
           NULLIF(COUNT(CASE WHEN fs.resultado_final IS NOT NULL THEN 1 END), 0)), 1
        ) as aprovacao
      FROM fichas_sessao fs
      JOIN agendamento_slots slot ON fs.agendamento_slot_id = slot.id
      JOIN simuladores s ON slot.simulador_id = s.id
      WHERE fs.deleted_at IS NULL 
      AND fs.created_at LIKE ?
      GROUP BY s.id, s.nome
      ORDER BY sessoes DESC
    `).bind(`${periodo}%`).all();
    
    // Dados por instrutor
    const porInstrutor = await db.prepare(`
      SELECT 
        f.nome as instrutor,
        COUNT(fs.id) as sessoes,
        ROUND(AVG(CASE WHEN fs.nota_final IS NOT NULL THEN fs.nota_final END), 1) as media_nota
      FROM fichas_sessao fs
      JOIN agendamento_slots slot ON fs.agendamento_slot_id = slot.id
      JOIN funcionarios f ON slot.colaborador_id_instrutor = f.id
      WHERE fs.deleted_at IS NULL 
      AND fs.created_at LIKE ?
      GROUP BY f.id, f.nome
      HAVING sessoes > 0
      ORDER BY sessoes DESC
      LIMIT 10
    `).bind(`${periodo}%`).all();
    
    const total = totalSessoes?.total || 0;
    const aprovadas = sessoesAprovadas?.total || 0;
    const reprovadas = sessoesReprovadas?.total || 0;
    const pendentes = sessoesPendentes?.total || 0;
    
    const taxaAprovacao = total > 0 ? Math.round((aprovadas / (aprovadas + reprovadas)) * 100 * 10) / 10 : 0;
    
    const relatorio = {
      periodo: periodo,
      estatisticas: {
        total_sessoes: total,
        sessoes_aprovadas: aprovadas,
        sessoes_reprovadas: reprovadas,
        sessoes_pendentes: pendentes,
        taxa_aprovacao: taxaAprovacao,
        simuladores_utilizados: porSimulador.results.length,
        instrutores_ativos: porInstrutor.results.length
      },
      por_simulador: porSimulador.results,
      por_instrutor: porInstrutor.results,
      timestamp: new Date().toISOString()
    };
    
    return c.json({
      success: true, 
      relatorio: relatorio
    });
    
  } catch (error) {
    console.error('Erro ao gerar relatório:', error);
    return c.json({
      success: false,
      error: 'Erro ao gerar relatório',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// Relatório de performance individual
app.get('/performance/:funcionario_id', async (c) => {
  try {
    const db = c.env.DB;
    const funcionarioId = c.req.param('funcionario_id');
    
    // Dados do funcionário
    const funcionario = await db.prepare(`
      SELECT nome, matricula, funcao FROM funcionarios WHERE id = ?
    `).bind(funcionarioId).first();
    
    if (!funcionario) {
      return c.json({success: false, error: 'Funcionário não encontrado'}, 404);
    }
    
    // Estatísticas como aluno
    const comoAluno = await db.prepare(`
      SELECT 
        COUNT(*) as total_sessoes,
        COUNT(CASE WHEN resultado_final = 'APROVADO' THEN 1 END) as aprovadas,
        COUNT(CASE WHEN resultado_final = 'REPROVADO' THEN 1 END) as reprovadas,
        ROUND(AVG(CASE WHEN nota_final IS NOT NULL THEN nota_final END), 1) as media_nota
      FROM fichas_sessao
      WHERE colaborador_id_aluno = ? AND deleted_at IS NULL
    `).bind(funcionarioId).first();
    
    // Estatísticas como instrutor
    const comoInstrutor = await db.prepare(`
      SELECT 
        COUNT(fs.id) as total_sessoes_instrutor,
        ROUND(AVG(CASE WHEN fs.nota_final IS NOT NULL THEN fs.nota_final END), 1) as media_nota_alunos
      FROM fichas_sessao fs
      JOIN agendamento_slots slot ON fs.agendamento_slot_id = slot.id
      WHERE slot.colaborador_id_instrutor = ? AND fs.deleted_at IS NULL
    `).bind(funcionarioId).first();
    
    return c.json({
      success: true,
      funcionario: funcionario,
      performance: {
        como_aluno: comoAluno,
        como_instrutor: comoInstrutor
      },
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: 'Erro ao gerar relatório de performance',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
