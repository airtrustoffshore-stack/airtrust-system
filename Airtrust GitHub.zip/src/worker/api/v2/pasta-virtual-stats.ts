import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação a todas as rotas
app.use('*', authMiddleware);

// Função para calcular estatísticas da pasta virtual
const calculatePastaVirtualStats = async (db: any) => {
  try {
    // Total de funcionários ativos
    const totalFuncionarios = await db.prepare(`
      SELECT COUNT(*) as count 
      FROM funcionarios 
      WHERE deleted_at IS NULL AND status = 'ATIVO'
    `).first();

    // Funcionários com pendências (qualquer status != 'EM_DIA' em compliance)
    const comPendencias = await db.prepare(`
      SELECT COUNT(DISTINCT funcionario_id) as count
      FROM compliance_status_v2 
      WHERE status != 'EM_DIA'
    `).first();

    // Certificações vencidas
    const vencidos = await db.prepare(`
      SELECT COUNT(*) as count
      FROM compliance_status_v2 
      WHERE status = 'VENCIDO'
    `).first();

    // Situações críticas (vencimento em 7 dias ou menos)
    const criticos = await db.prepare(`
      SELECT COUNT(*) as count
      FROM compliance_status_v2 
      WHERE status = 'VENCENDO' AND dias_para_vencimento <= 7
    `).first();

    return {
      total_funcionarios: (totalFuncionarios?.count as number) || 0,
      com_pendencias: (comPendencias?.count as number) || 0,
      vencidos: (vencidos?.count as number) || 0,
      criticos: (criticos?.count as number) || 0
    };
  } catch (error) {
    console.error('Error calculating pasta virtual stats:', error);
    return {
      total_funcionarios: 0,
      com_pendencias: 0,
      vencidos: 0,
      criticos: 0
    };
  }
};

// GET /api/v2/pasta-virtual/stats - Estatísticas da pasta virtual
app.get('/stats', requirePermission('pasta_virtual', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const stats = await calculatePastaVirtualStats(db);

    await logAudit(c, 'READ', 'pasta_virtual_stats');
    
    return c.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Error fetching pasta virtual stats:', error);
    await logAudit(c, 'READ', 'pasta_virtual_stats', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default app;
