import { Hono } from 'hono';

const treinamentosApi = new Hono<{ Bindings: Env }>();

// ✅ CORREÇÃO: FORÇAR DADOS MOCK SEMPRE PARA TREINAMENTOS
treinamentosApi.get('/', async (c) => {
  console.log('📚 API /api/v2/treinamentos - FORÇANDO MOCK DATA');
  
  // ✅ DADOS MOCK FORÇADOS PARA TREINAMENTOS
  const mockTreinamentos = [
    {id: 1, codigo: 'SGV-001', nome: 'Segurança de Voo Básica', categoria: 'SEGURANÇA', total_sessoes: 3, periodicidade_meses: 12},
    {id: 2, codigo: 'CRM-001', nome: 'Crew Resource Management', categoria: 'OPERACIONAL', total_sessoes: 3, periodicidade_meses: 24},
    {id: 3, codigo: 'SMS-001', nome: 'Safety Management System', categoria: 'COMPLIANCE', total_sessoes: 2, periodicidade_meses: 36},
    {id: 4, codigo: 'EMG-001', nome: 'Procedimentos de Emergência', categoria: 'EMERGÊNCIA', total_sessoes: 2, periodicidade_meses: 6},
    {id: 5, codigo: 'MNT-001', nome: 'Manutenção Preventiva', categoria: 'MANUTENÇÃO', total_sessoes: 1, periodicidade_meses: 12},
    {id: 6, codigo: 'CMA', nome: 'Certificado Médico Aeronáutico', categoria: 'LICENCA_MEDICA', total_sessoes: 1, periodicidade_meses: 12},
    {id: 7, codigo: 'ASO', nome: 'Atestado de Saúde Ocupacional', categoria: 'LICENCA_MEDICA', total_sessoes: 1, periodicidade_meses: 12},
    {id: 8, codigo: 'ICAO', nome: 'Nível de Inglês ICAO', categoria: 'PROFICIENCIA', total_sessoes: 1, periodicidade_meses: 36},
    {id: 12, codigo: 'REC-A', nome: 'Recorrente A', categoria: 'SIMULADOR', total_sessoes: 2, periodicidade_meses: 6},
    {id: 13, codigo: 'CHK-B', nome: 'Check B', categoria: 'SIMULADOR', total_sessoes: 2, periodicidade_meses: 12}
  ];
  
  return c.json({ data: mockTreinamentos, success: true, total: mockTreinamentos.length });
});

// GET /api/v2/treinamentos/listar - ENDPOINT OBRIGATÓRIO MOCK
treinamentosApi.get('/listar', async (c) => {
  console.log('📚 API /api/v2/treinamentos/listar - FORÇANDO MOCK DATA');
  
  const treinamentos = [
    {id: 1, codigo: 'SGV-001', nome: 'Segurança de Voo Básica', categoria: 'SEGURANÇA', total_sessoes: 3, periodicidade_meses: 12},
    {id: 2, codigo: 'CRM-001', nome: 'Crew Resource Management', categoria: 'OPERACIONAL', total_sessoes: 3, periodicidade_meses: 24},
    {id: 3, codigo: 'SMS-001', nome: 'Safety Management System', categoria: 'COMPLIANCE', total_sessoes: 2, periodicidade_meses: 36},
    {id: 4, codigo: 'EMG-001', nome: 'Procedimentos de Emergência', categoria: 'EMERGÊNCIA', total_sessoes: 2, periodicidade_meses: 6},
    {id: 5, codigo: 'MNT-001', nome: 'Manutenção Preventiva', categoria: 'MANUTENÇÃO', total_sessoes: 1, periodicidade_meses: 12},
    {id: 6, codigo: 'CMA', nome: 'Certificado Médico Aeronáutico', categoria: 'LICENCA_MEDICA', total_sessoes: 1, periodicidade_meses: 12},
    {id: 7, codigo: 'ASO', nome: 'Atestado de Saúde Ocupacional', categoria: 'LICENCA_MEDICA', total_sessoes: 1, periodicidade_meses: 12},
    {id: 8, codigo: 'ICAO', nome: 'Nível de Inglês ICAO', categoria: 'PROFICIENCIA', total_sessoes: 1, periodicidade_meses: 36},
    {id: 12, codigo: 'REC-A', nome: 'Recorrente A', categoria: 'SIMULADOR', total_sessoes: 2, periodicidade_meses: 6},
    {id: 13, codigo: 'CHK-B', nome: 'Check B', categoria: 'SIMULADOR', total_sessoes: 2, periodicidade_meses: 12}
  ];
  
  return c.json({
    success: true,
    data: treinamentos,
    total: treinamentos.length,
    from_fallback: true,
    forced_mock: true,
    timestamp: new Date().toISOString()
  });
});

export default treinamentosApi;
