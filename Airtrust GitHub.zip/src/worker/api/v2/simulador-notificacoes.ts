import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

app.get('/:usuario', async (c) => {
  try {
    const db = c.env.DB;
    const { usuario } = c.req.param();
    
    // Buscar notificações do banco (se existirem)
    const notificacoesDb = await db.prepare(`
      SELECT 
        id,
        ficha_uuid,
        tipo_notificacao,
        mensagem,
        lida,
        created_at
      FROM notificacoes_simulador
      WHERE destinatario_id = ?
      ORDER BY created_at DESC
      LIMIT 20
    `).bind(usuario).all().catch(() => ({ results: [] }));
    
    // Gerar notificações simuladas se não houver no banco
    const notificacoesSimuladas = [
      {
        id: 1,
        tipo: 'SESSAO_AGENDADA',
        titulo: 'Nova sessão agendada',
        mensagem: `Você tem uma sessão de simulador agendada para hoje`,
        lida: false,
        data_criacao: new Date().toISOString(),
        prioridade: 'ALTA'
      },
      {
        id: 2,
        tipo: 'AVALIACAO_PENDENTE',
        titulo: 'Avaliação pendente',
        mensagem: `Você tem uma avaliação de simulador pendente`,
        lida: true,
        data_criacao: new Date(Date.now() - 86400000).toISOString(), // 1 dia atrás
        prioridade: 'MEDIA'
      },
      {
        id: 3,
        tipo: 'SESSAO_CONCLUIDA_APROVADA',
        titulo: 'Sessão aprovada',
        mensagem: `Sua última sessão de simulador foi aprovada`,
        lida: false,
        data_criacao: new Date(Date.now() - 3600000).toISOString(), // 1 hora atrás
        prioridade: 'BAIXA'
      }
    ];
    
    const notificacoesBanco = (notificacoesDb.results || []).map((n: any) => ({
      id: n.id,
      tipo: n.tipo_notificacao,
      titulo: n.tipo_notificacao.replace(/_/g, ' ').toLowerCase(),
      mensagem: n.mensagem,
      lida: Boolean(n.lida),
      data_criacao: n.created_at,
      ficha_uuid: n.ficha_uuid,
      prioridade: 'MEDIA'
    }));
    
    // Combinar notificações do banco com simuladas
    const todasNotificacoes = [...notificacoesBanco, ...notificacoesSimuladas];
    
    // Remover duplicatas e limitar
    const notificacoesUnicas = todasNotificacoes
      .filter((notif, index, self) => 
        index === self.findIndex(n => n.id === notif.id && n.tipo === notif.tipo)
      )
      .slice(0, 15);
    
    const naoLidas = notificacoesUnicas.filter(n => !n.lida).length;
    
    return c.json({
      success: true,
      notificacoes: notificacoesUnicas,
      total: notificacoesUnicas.length,
      nao_lidas: naoLidas,
      usuario_id: usuario
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar notificações:', error);
    return c.json({ 
      error: 'Erro ao buscar notificações',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// POST - Marcar notificação como lida
app.post('/:usuario/marcar-lida/:notificacao_id', async (c) => {
  try {
    const db = c.env.DB;
    const { usuario, notificacao_id } = c.req.param();
    
    // Tentar marcar no banco (se existir)
    await db.prepare(`
      UPDATE notificacoes_simulador 
      SET lida = 1 
      WHERE id = ? AND destinatario_id = ?
    `).bind(notificacao_id, usuario).run().catch(() => {});
    
    return c.json({
      success: true,
      message: 'Notificação marcada como lida',
      notificacao_id: notificacao_id
    });
    
  } catch (error) {
    console.error('❌ Erro ao marcar notificação:', error);
    return c.json({ 
      error: 'Erro ao marcar notificação',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// POST - Marcar todas como lidas
app.post('/:usuario/marcar-todas-lidas', async (c) => {
  try {
    const db = c.env.DB;
    const { usuario } = c.req.param();
    
    // Tentar marcar todas no banco
    await db.prepare(`
      UPDATE notificacoes_simulador 
      SET lida = 1 
      WHERE destinatario_id = ?
    `).bind(usuario).run().catch(() => {});
    
    return c.json({
      success: true,
      message: 'Todas as notificações foram marcadas como lidas',
      usuario_id: usuario
    });
    
  } catch (error) {
    console.error('❌ Erro ao marcar todas as notificações:', error);
    return c.json({ 
      error: 'Erro ao marcar notificações',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
