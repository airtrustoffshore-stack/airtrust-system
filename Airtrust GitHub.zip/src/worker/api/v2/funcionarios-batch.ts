import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

interface CSVError {
  row: number;
  field: string;
  message: string;
  error_type: string;
  severity: string;
  raw_value?: string;
}

interface CSVImportResult {
  success: boolean;
  batch_id: string;
  processing_time_ms: number;
  rows_total: number;
  rows_processed: number;
  rows_failed: number;
  rows_skipped: number;
  duplicates_detected: number;
  processados: number;
  importados: number;
  criados: number;
  atualizados: number;
  errors: CSVError[];
  erros: number;
  warnings: any[];
  detalhes: string;
  summary: string;
}

const app = new Hono<{ Bindings: Env }>();

// Função para parsear CSV do padrão AirTrust com TODOS os campos
function parseCSVAirTrust(csvText: string): Array<Record<string, string>> {
  const lines = csvText.trim().split('\n');
  if (lines.length < 2) return [];
  
  // Headers esperados do padrão AirTrust
  const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
  const data: Array<Record<string, string>> = [];
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    
    // Parse mais robusto para lidar com vírgulas em valores
    const values: string[] = [];
    let currentValue = '';
    let insideQuotes = false;
    
    for (let j = 0; j < line.length; j++) {
      const char = line[j];
      
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        values.push(currentValue.trim().replace(/"/g, ''));
        currentValue = '';
      } else {
        currentValue += char;
      }
    }
    values.push(currentValue.trim().replace(/"/g, ''));
    
    if (values.length >= 2) { // Pelo menos Nome e Matrícula
      const row: Record<string, string> = {};
      
      // Mapear TODOS os campos possíveis do padrão AirTrust
      headers.forEach((header, idx) => {
        const normalizedHeader = header.toLowerCase().trim();
        let mappedKey = normalizedHeader;
        
        // Mapeamento completo dos campos AirTrust para campos da tabela funcionarios
        // Log para debugging dos headers
        console.log(`🔍 [FUNCIONARIOS-BATCH] Header original: "${header}" -> normalizado: "${normalizedHeader}"`);
        
        switch (normalizedHeader) {
          case 'nome':
          case 'name':
            mappedKey = 'nome';
            break;
          case 'função':
          case 'funcao':
          case 'function':
          case 'role':
            mappedKey = 'funcao';
            break;
          case 'anv':
          case 'anvisa':
            mappedKey = 'anv';
            break;
          case 'cpf':
          case 'document':
            mappedKey = 'cpf';
            break;
          case 'código anac':
          case 'codigo anac':
          case 'codigo_anac':
          case 'anac':
          case 'cod anac':
          case 'cod. anac':
            mappedKey = 'codigo_anac';
            break;
          case 'base':
          case 'location':
          case 'local':
            mappedKey = 'base';
            break;
          case 'contrato':
          case 'contract':
          case 'tipo contrato':
            mappedKey = 'contrato';
            break;
          case 'data de nasc.':
          case 'data de nascimento':
          case 'data_nascimento':
          case 'nascimento':
          case 'birth date':
          case 'dt nasc':
          case 'dt. nasc.':
            mappedKey = 'data_nascimento';
            break;
          case 'licença':
          case 'licenca':
          case 'licenca_aeronautica':
          case 'licença aeronáutica':
          case 'license':
            mappedKey = 'licenca_aeronautica';
            break;
          case 'canac':
          case 'código canac':
          case 'codigo canac':
          case 'codigo_canac':
          case 'cod canac':
          case 'cod. canac':
            mappedKey = 'codigo_canac';
            break;
          case 'sispat':
          case 'código sispat':
          case 'codigo sispat':
          case 'codigo_sispat':
          case 'cod sispat':
          case 'cod. sispat':
            mappedKey = 'codigo_sispat';
            break;
          case 'prestserv':
          case 'código prestserv':
          case 'codigo prestserv':
          case 'codigo_prestserv':
          case 'cod prestserv':
          case 'cod. prestserv':
          case 'prestação de serviços':
          case 'prestacao de servicos':
            mappedKey = 'codigo_prestserv';
            break;
          case 'email':
          case 'e-mail':
          case 'mail':
          case 'electronic mail':
            mappedKey = 'email';
            break;
          case 'telefone':
          case 'fone':
          case 'celular':
          case 'phone':
          case 'tel':
          case 'cel':
            mappedKey = 'telefone';
            break;
          case 'admissão':
          case 'admissao':
          case 'data_admissao':
          case 'data de admissão':
          case 'data admissão':
          case 'dt admissao':
          case 'dt. admissão':
            mappedKey = 'data_admissao';
            break;
          case 'matrícula':
          case 'matricula':
          case 'mat.':
          case 'mat':
          case 'registration':
          case 'id':
            mappedKey = 'matricula';
            break;
          case 'cma':
          case 'cma_numero':
          case 'número cma':
          case 'numero cma':
          case 'cma number':
          case 'nr cma':
          case 'nr. cma':
            mappedKey = 'cma_numero';
            break;
          case 'cma vencimento':
          case 'cma_data_vencimento':
          case 'vencimento cma':
          case 'validade cma':
          case 'cma expiry':
          case 'dt venc cma':
            mappedKey = 'cma_data_vencimento';
            break;
          case 'cma status':
          case 'cma_status':
          case 'status cma':
          case 'situação cma':
          case 'situacao cma':
            mappedKey = 'cma_status';
            break;
          case 'aso':
          case 'aso vencimento':
          case 'aso_data_vencimento':
          case 'vencimento aso':
          case 'validade aso':
          case 'dt venc aso':
            mappedKey = 'aso_data_vencimento';
            break;
          case 'icao':
          case 'nivel_icao':
          case 'nível icao':
          case 'nivel icao':
          case 'icao level':
            mappedKey = 'nivel_icao';
            break;
          case 'icao vencimento':
          case 'nivel_icao_data_vencimento':
          case 'vencimento icao':
          case 'validade icao':
          case 'dt venc icao':
            mappedKey = 'nivel_icao_data_vencimento';
            break;
          case 'icao status':
          case 'nivel_icao_status':
          case 'status icao':
          case 'situação icao':
          case 'situacao icao':
            mappedKey = 'nivel_icao_status';
            break;
          case 'instrutor':
          case 'is_instrutor':
          case 'é instrutor':
          case 'e instrutor':
          case 'instructor':
            mappedKey = 'is_instrutor';
            break;
          case 'checador':
          case 'is_checador':
          case 'é checador':
          case 'e checador':
          case 'checker':
            mappedKey = 'is_checador';
            break;
          case 'aeronave':
          case 'aeronave_principal':
          case 'aeronave principal':
          case 'aircraft':
          case 'acft':
            mappedKey = 'aeronave_principal';
            break;
          case 'avatar':
          case 'foto':
          case 'image':
          case 'picture':
            mappedKey = 'avatar';
            break;
          case 'status':
          case 'situação':
          case 'situacao':
          case 'state':
          case 'condition':
            mappedKey = 'status';
            break;
          default:
            // Se não encontrou mapping específico, manter o header original normalizado
            mappedKey = normalizedHeader.replace(/[^a-z0-9_]/g, '_');
            console.log(`⚠️ [FUNCIONARIOS-BATCH] Header não mapeado: "${header}" -> usando "${mappedKey}"`);
            break;
        }
        
        row[mappedKey] = (values as string[])[idx] || '';
      });
      
      data.push(row);
    }
  }
  
  return data;
}

// Função para validar campos obrigatórios (apenas Nome e Matrícula)
function validateRequiredFields(rowData: Record<string, string>, rowIndex: number): CSVError[] {
  const errors: CSVError[] = [];
  
  // Validar Nome (obrigatório)
  if (!rowData.nome || rowData.nome.trim() === '') {
    errors.push({
      row: rowIndex + 2,
      field: 'nome',
      message: 'Nome é obrigatório e não pode estar vazio',
      error_type: 'VALIDATION',
      severity: 'HIGH',
      raw_value: rowData.nome
    });
  }
  
  // Validar Matrícula (obrigatória)
  if (!rowData.matricula || rowData.matricula.trim() === '') {
    errors.push({
      row: rowIndex + 2,
      field: 'matricula',
      message: 'Matrícula é obrigatória e não pode estar vazia',
      error_type: 'VALIDATION',
      severity: 'HIGH',
      raw_value: rowData.matricula
    });
  }
  
  return errors;
}

// Função para formatar data (se presente)
function formatDate(dateStr: string): string | null {
  if (!dateStr || dateStr.trim() === '') return null;
  
  try {
    // Tentar diferentes formatos de data
    const formats = [
      /^\d{4}-\d{2}-\d{2}$/, // YYYY-MM-DD
      /^\d{2}\/\d{2}\/\d{4}$/, // DD/MM/YYYY
      /^\d{1,2}\/\d{1,2}\/\d{4}$/ // D/M/YYYY
    ];
    
    for (const format of formats) {
      if (format.test(dateStr)) {
        if (dateStr.includes('/')) {
          const parts = dateStr.split('/');
          return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
        }
        return dateStr; // Já está no formato YYYY-MM-DD
      }
    }
    
    return null;
  } catch {
    return null;
  }
}

// Função para converter string para boolean (para instrutor e checador)
function stringToBoolean(str: string): number {
  if (!str || str.trim() === '') return 0;
  const normalized = str.toLowerCase().trim();
  return (normalized === 'sim' || normalized === 'yes' || normalized === 'true' || normalized === '1') ? 1 : 0;
}

// Middleware para sempre retornar JSON mesmo em erros
app.use('*', async (c, next) => {
  try {
    await next();
  } catch (error) {
    console.error('❌ [FUNCIONARIOS-BATCH] Erro não tratado:', error);
    
    const errorResult: CSVImportResult = {
      success: false,
      batch_id: `error_${Date.now()}`,
      processing_time_ms: 0,
      rows_total: 0,
      rows_processed: 0,
      rows_failed: 1,
      rows_skipped: 0,
      duplicates_detected: 0,
      processados: 0,
      importados: 0,
      criados: 0,
      atualizados: 0,
      errors: [{
        row: 0,
        field: 'system',
        message: `Erro do sistema: ${error instanceof Error ? error.message : 'Erro desconhecido'}`,
        error_type: 'SYSTEM',
        severity: 'CRITICAL'
      }],
      erros: 1,
      warnings: [],
      detalhes: 'Falha crítica do sistema',
      summary: 'Erro interno não tratado'
    };
    
    // SEMPRE retornar JSON, nunca HTML
    return c.json(errorResult, 500);
  }
});

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// POST /api/v2/funcionarios-batch - Importação em lote com padrão AirTrust (SEMPRE JSON)
app.post('/', requirePermission('funcionarios', 'CREATE'), async (c) => {
  // Headers para garantir resposta JSON
  c.header('Content-Type', 'application/json');
  c.header('Cache-Control', 'no-cache');
  
  console.log('🚀 [FUNCIONARIOS-BATCH] Iniciando importação...');
  console.log('📡 [FUNCIONARIOS-BATCH] Content-Type:', c.req.header('content-type'));
  console.log('📡 [FUNCIONARIOS-BATCH] Method:', c.req.method);
  
  // Validação manual para evitar zValidator que pode retornar HTML
  let requestBody;
  try {
    requestBody = await c.req.json();
    console.log('✅ [FUNCIONARIOS-BATCH] Body parsed successfully');
  } catch (error) {
    console.error('❌ [FUNCIONARIOS-BATCH] Error parsing JSON body:', error);
    return c.json({
      success: false,
      batch_id: `error_${Date.now()}`,
      processing_time_ms: 0,
      rows_total: 0,
      rows_processed: 0,
      rows_failed: 1,
      rows_skipped: 0,
      duplicates_detected: 0,
      processados: 0,
      importados: 0,
      criados: 0,
      atualizados: 0,
      errors: [{
        row: 0,
        field: 'request',
        message: 'Corpo da requisição deve ser JSON válido com campo csv_data',
        error_type: 'VALIDATION',
        severity: 'HIGH'
      }],
      erros: 1,
      warnings: [],
      detalhes: 'JSON inválido na requisição',
      summary: 'Falha no parse do JSON'
    }, 400);
  }
  
  if (!requestBody || !requestBody.csv_data) {
    return c.json({
      success: false,
      batch_id: `error_${Date.now()}`,
      processing_time_ms: 0,
      rows_total: 0,
      rows_processed: 0,
      rows_failed: 1,
      rows_skipped: 0,
      duplicates_detected: 0,
      processados: 0,
      importados: 0,
      criados: 0,
      atualizados: 0,
      errors: [{
        row: 0,
        field: 'csv_data',
        message: 'Campo csv_data é obrigatório',
        error_type: 'VALIDATION',
        severity: 'HIGH'
      }],
      erros: 1,
      warnings: [],
      detalhes: 'Campo csv_data ausente',
      summary: 'Dados CSV não fornecidos'
    }, 400);
  }
  const startTime = Date.now();
  const batchId = `funcionarios_airtrust_${Date.now()}`;
  
  try {
    const { csv_data } = requestBody;
    const db = c.env.DB;
    
    console.log(`📊 [FUNCIONARIOS-BATCH] CSV data length: ${csv_data.length} chars`);
    
    // 1. Parsear CSV no padrão AirTrust
    const csvData = parseCSVAirTrust(csv_data);
    
    console.log(`📋 [FUNCIONARIOS-BATCH] Headers detectados no CSV:`);
    if (csvData.length > 0) {
      const firstRow = csvData[0];
      Object.keys(firstRow).forEach(key => {
        console.log(`  - ${key}: "${firstRow[key]}"`);
      });
    }
    
    if (csvData.length === 0) {
      const result: CSVImportResult = {
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        rows_total: 0,
        rows_processed: 0,
        rows_failed: 0,
        rows_skipped: 0,
        duplicates_detected: 0,
        processados: 0,
        importados: 0,
        criados: 0,
        atualizados: 0,
        errors: [{
          row: 0,
          field: 'csv',
          message: 'Nenhum dado válido encontrado no CSV ou formato inválido',
          error_type: 'VALIDATION',
          severity: 'HIGH'
        }],
        erros: 1,
        warnings: [],
        detalhes: 'CSV vazio ou formato incorreto',
        summary: 'Falha na validação do arquivo CSV'
      };
      
      await logAudit(c, 'BATCH_CREATE_FUNCIONARIOS', 'funcionarios', batchId, undefined, result, 'ERROR');
      return c.json(result, 400);
    }

    // 2. Validar dados e processar
    let processedCount = 0;
    let createdCount = 0;
    let updatedCount = 0;
    const allErrors: CSVError[] = [];
    const existingMatriculas = new Set<string>();
    
    // Verificar matrículas existentes
    const existingQuery = await db.prepare(
      'SELECT matricula FROM funcionarios WHERE deleted_at IS NULL'
    ).all();
    
    existingQuery.results.forEach((row: any) => {
      if (row.matricula) existingMatriculas.add(row.matricula);
    });
    
    // Processar cada linha
    for (let i = 0; i < csvData.length; i++) {
      const rowData = csvData[i];
      
      // Validar campos obrigatórios
      const validationErrors = validateRequiredFields(rowData, i);
      if (validationErrors.length > 0) {
        allErrors.push(...validationErrors);
        continue;
      }
      
      try {
        const nome = rowData.nome.trim();
        const matricula = rowData.matricula.trim();
        
        // Verificar se já existe funcionário com essa matrícula
        const isUpdate = existingMatriculas.has(matricula);
        
        if (isUpdate) {
          // Atualizar funcionário existente com TODOS os campos possíveis
          const updateQuery = `
            UPDATE funcionarios SET
              nome = ?,
              funcao = COALESCE(NULLIF(?, ''), funcao),
              anv = COALESCE(NULLIF(?, ''), anv),
              cpf = COALESCE(NULLIF(?, ''), cpf),
              codigo_anac = COALESCE(NULLIF(?, ''), codigo_anac),
              base = COALESCE(NULLIF(?, ''), base),
              contrato = COALESCE(NULLIF(?, ''), contrato),
              data_nascimento = COALESCE(?, data_nascimento),
              licenca_aeronautica = COALESCE(NULLIF(?, ''), licenca_aeronautica),
              codigo_canac = COALESCE(NULLIF(?, ''), codigo_canac),
              codigo_sispat = COALESCE(NULLIF(?, ''), codigo_sispat),
              codigo_prestserv = COALESCE(NULLIF(?, ''), codigo_prestserv),
              email = COALESCE(NULLIF(?, ''), email),
              telefone = COALESCE(NULLIF(?, ''), telefone),
              data_admissao = COALESCE(?, data_admissao),
              cma_numero = COALESCE(NULLIF(?, ''), cma_numero),
              cma_data_vencimento = COALESCE(?, cma_data_vencimento),
              cma_status = COALESCE(NULLIF(?, ''), cma_status),
              aso_data_vencimento = COALESCE(?, aso_data_vencimento),
              nivel_icao = COALESCE(NULLIF(?, ''), nivel_icao),
              nivel_icao_data_vencimento = COALESCE(?, nivel_icao_data_vencimento),
              nivel_icao_status = COALESCE(NULLIF(?, ''), nivel_icao_status),
              is_instrutor = COALESCE(?, is_instrutor),
              is_checador = COALESCE(?, is_checador),
              aeronave_principal = COALESCE(NULLIF(?, ''), aeronave_principal),
              avatar = COALESCE(NULLIF(?, ''), avatar),
              status = COALESCE(NULLIF(?, ''), status),
              updated_at = CURRENT_TIMESTAMP
            WHERE matricula = ? AND deleted_at IS NULL
          `;
          
          await db.prepare(updateQuery).bind(
            nome,
            rowData.funcao || null,
            rowData.anv || null,
            rowData.cpf || null,
            rowData.codigo_anac || null,
            rowData.base || null,
            rowData.contrato || null,
            formatDate(rowData.data_nascimento),
            rowData.licenca_aeronautica || null,
            rowData.codigo_canac || null,
            rowData.codigo_sispat || null,
            rowData.codigo_prestserv || null,
            rowData.email || null,
            rowData.telefone || null,
            formatDate(rowData.data_admissao),
            rowData.cma_numero || null,
            formatDate(rowData.cma_data_vencimento),
            rowData.cma_status || null,
            formatDate(rowData.aso_data_vencimento),
            rowData.nivel_icao || null,
            formatDate(rowData.nivel_icao_data_vencimento),
            rowData.nivel_icao_status || null,
            rowData.is_instrutor ? stringToBoolean(rowData.is_instrutor) : null,
            rowData.is_checador ? stringToBoolean(rowData.is_checador) : null,
            rowData.aeronave_principal || null,
            rowData.avatar || null,
            rowData.status || null,
            matricula
          ).run();
          
          updatedCount++;
        } else {
          // Criar novo funcionário com TODOS os campos possíveis
          const insertQuery = `
            INSERT INTO funcionarios (
              nome, matricula, funcao, anv, cpf, codigo_anac, base, contrato,
              data_nascimento, licenca_aeronautica, codigo_canac, codigo_sispat,
              codigo_prestserv, email, telefone, data_admissao, cma_numero,
              cma_data_vencimento, cma_status, aso_data_vencimento, nivel_icao,
              nivel_icao_data_vencimento, nivel_icao_status, is_instrutor,
              is_checador, aeronave_principal, avatar, status,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `;
          
          await db.prepare(insertQuery).bind(
            nome,
            matricula,
            rowData.funcao || 'FUNCIONARIO',
            rowData.anv || null,
            rowData.cpf || null,
            rowData.codigo_anac || null,
            rowData.base || null,
            rowData.contrato || null,
            formatDate(rowData.data_nascimento),
            rowData.licenca_aeronautica || null,
            rowData.codigo_canac || null,
            rowData.codigo_sispat || null,
            rowData.codigo_prestserv || null,
            rowData.email || null,
            rowData.telefone || null,
            formatDate(rowData.data_admissao),
            rowData.cma_numero || null,
            formatDate(rowData.cma_data_vencimento),
            rowData.cma_status || null,
            formatDate(rowData.aso_data_vencimento),
            rowData.nivel_icao || null,
            formatDate(rowData.nivel_icao_data_vencimento),
            rowData.nivel_icao_status || null,
            stringToBoolean(rowData.is_instrutor || ''),
            stringToBoolean(rowData.is_checador || ''),
            rowData.aeronave_principal || null,
            rowData.avatar || null,
            rowData.status || 'ATIVO'
          ).run();
          
          existingMatriculas.add(matricula);
          createdCount++;
        }
        
        processedCount++;
        
      } catch (error) {
        allErrors.push({
          row: i + 2,
          field: 'system',
          message: `Erro ao processar: ${error instanceof Error ? error.message : 'Erro desconhecido'}`,
          error_type: 'SYSTEM',
          severity: 'CRITICAL',
          raw_value: JSON.stringify(rowData)
        });
      }
    }

    // 3. Resultado final
    const isSuccess = processedCount > 0 && allErrors.length === 0;
    const isPartialSuccess = processedCount > 0 && allErrors.length > 0;
    
    const result: CSVImportResult = {
      success: isSuccess,
      batch_id: batchId,
      processing_time_ms: Date.now() - startTime,
      rows_total: csvData.length,
      rows_processed: processedCount,
      rows_failed: allErrors.length,
      rows_skipped: 0,
      duplicates_detected: 0,
      processados: processedCount,
      importados: processedCount,
      criados: createdCount,
      atualizados: updatedCount,
      errors: allErrors,
      erros: allErrors.length,
      warnings: [],
      detalhes: `${createdCount} criados, ${updatedCount} atualizados, ${allErrors.length} erros`,
      summary: isSuccess 
        ? `Importação concluída: ${createdCount} criados, ${updatedCount} atualizados`
        : isPartialSuccess
          ? `Importação parcial: ${processedCount} processados com ${allErrors.length} erros`
          : `Falha na importação: ${allErrors.length} erros encontrados`
    };

    // 4. Registrar auditoria
    await logAudit(
      c, 
      'BATCH_CREATE_FUNCIONARIOS_AIRTRUST', 
      'funcionarios', 
      batchId, 
      undefined, 
      result,
      isSuccess ? 'SUCCESS' : isPartialSuccess ? 'PARTIAL_SUCCESS' : 'ERROR'
    );
    
    console.log(`✅ [FUNCIONARIOS-BATCH] Importação finalizada:`, result);
    return c.json(result, isSuccess ? 200 : isPartialSuccess ? 206 : 400);
    
  } catch (error) {
    console.error('Erro na importação AirTrust:', error);
    
    const result: CSVImportResult = {
      success: false,
      batch_id: batchId,
      processing_time_ms: Date.now() - startTime,
      rows_total: 0,
      rows_processed: 0,
      rows_failed: 1,
      rows_skipped: 0,
      duplicates_detected: 0,
      processados: 0,
      importados: 0,
      criados: 0,
      atualizados: 0,
      errors: [{
        row: 0,
        field: 'system',
        message: `Erro interno na importação: ${error instanceof Error ? error.message : 'Erro desconhecido'}`,
        error_type: 'SYSTEM',
        severity: 'CRITICAL'
      }],
      erros: 1,
      warnings: [],
      detalhes: 'Falha interna do sistema durante importação',
      summary: 'Erro interno na importação'
    };
    
    await logAudit(c, 'BATCH_CREATE_FUNCIONARIOS_AIRTRUST', 'funcionarios', batchId, undefined, result, 'ERROR');
    return c.json(result, 500);
  }
});

export default app;
