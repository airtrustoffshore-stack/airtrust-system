import { Context } from 'hono';

interface Database {
  prepare(query: string): {
    bind(...params: any[]): {
      all(): Promise<any[]>;
      first(): Promise<any>;
      run(): Promise<any>;
    };
  };
}

function formatarDataBrasil(dateStr: string | Date): string {
  if (!dateStr) return 'N/A';
  
  try {
    const date = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
    if (isNaN(date.getTime())) return 'N/A';
    
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit', 
      year: 'numeric'
    });
  } catch {
    return 'N/A';
  }
}

// CORREÇÃO CRÍTICA 1: Erro SQL 500 no endpoint principal
export const listarFichasCorrigido = async (c: Context) => {
  try {
    const db = c.env.DB as Database;
    
    // Query SQL corrigida sem sintaxe CHECK que causava erro
    const fichas = await db.prepare(`
      SELECT 
        f.id,
        f.ficha_uuid,
        f.status_workflow,
        f.funcao_na_sessao,
        f.resultado_final,
        f.nota_final,
        f.created_at,
        func.nome as funcionario_nome,
        func.matricula as funcionario_matricula,
        s.nome as simulador_nome,
        s.codigo_identificacao as simulador_codigo,
        inst.nome as instrutor_nome,
        st.nome_sessao as template_nome,
        st.numero_sessao
      FROM fichas_sessao f
      LEFT JOIN funcionarios func ON f.colaborador_id_aluno = func.id
      LEFT JOIN agendamento_slots a ON f.agendamento_slot_id = a.id
      LEFT JOIN simuladores s ON a.simulador_id = s.id
      LEFT JOIN funcionarios inst ON a.colaborador_id_instrutor = inst.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.deleted_at IS NULL
      ORDER BY f.created_at DESC
    `).bind().all();
    
    const fichasFormatadas = fichas.map((ficha: any) => ({
      id: ficha.id,
      uuid: ficha.ficha_uuid,
      status_workflow: ficha.status_workflow,
      funcao_na_sessao: ficha.funcao_na_sessao,
      conceito_final: ficha.resultado_final,
      nota_final: ficha.nota_final,
      created_at: formatarDataBrasil(ficha.created_at),
      colaborador: {
        nome: ficha.funcionario_nome || 'N/A',
        matricula: ficha.funcionario_matricula || 'N/A'
      },
      simulador: {
        nome: ficha.simulador_nome || 'N/A',
        codigo: ficha.simulador_codigo || 'N/A'
      },
      instrutor: {
        nome: ficha.instrutor_nome || 'N/A'
      },
      sessao_template: {
        nome: ficha.template_nome || 'N/A',
        numero: ficha.numero_sessao || 'N/A'
      }
    }));
    
    return c.json({ 
      success: true,
      fichas: fichasFormatadas,
      total: fichasFormatadas.length
    });
    
  } catch (error: any) {
    console.error('Erro ao listar fichas:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error.message
    }, 500);
  }
};

// CORREÇÃO CRÍTICA 2: Implementar endpoint de simuladores
export const listarSimuladores = async (c: Context) => {
  try {
    const db = c.env.DB as Database;
    
    const simuladores = await db.prepare(`
      SELECT 
        id,
        nome,
        codigo_identificacao,
        tipo_simulador,
        aeronave_base,
        empresa_local,
        certificacao_anac,
        status
      FROM simuladores 
      WHERE status = 'ATIVO' AND deleted_at IS NULL
      ORDER BY nome ASC
    `).bind().all();
    
    return c.json({
      success: true,
      simuladores,
      total: simuladores.length
    });
  } catch (error: any) {
    console.error('Erro ao listar simuladores:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
};

// CORREÇÃO CRÍTICA 3: Implementar endpoint de templates
export const listarTemplates = async (c: Context) => {
  try {
    const db = c.env.DB as Database;
    
    const templates = await db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo as codigo,
        st.nome_sessao as nome,
        st.descricao,
        st.numero_sessao,
        COUNT(stm.manobra_catalogo_id) as total_manobras
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      GROUP BY st.id, st.treinamento_codigo, st.nome_sessao, st.descricao, st.numero_sessao
      ORDER BY st.numero_sessao ASC
    `).bind().all();
    
    const templatesFormatados = templates.map((template: any) => ({
      id: template.id,
      codigo: template.codigo,
      nome: template.nome,
      descricao: template.descricao || '',
      numero_sessao: template.numero_sessao,
      total_manobras: template.total_manobras || 0
    }));
    
    return c.json({
      success: true,
      templates: templatesFormatados,
      total: templatesFormatados.length
    });
  } catch (error: any) {
    console.error('Erro ao listar templates:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
};

// CORREÇÃO CRÍTICA 4: Implementar criação de agendamento
export const criarAgendamento = async (c: Context) => {
  try {
    const {
      data_inicio,
      hora_inicio,
      data_fim,
      hora_fim,
      simulador_id,
      instrutor_id,
      colaborador_aluno_id,
      template_sessao_id,
      funcao_na_sessao
    } = await c.req.json();
    
    const db = c.env.DB as Database;
    
    // Validar dados obrigatórios
    if (!data_inicio || !hora_inicio || !simulador_id || !instrutor_id || !colaborador_aluno_id) {
      return c.json({ 
        error: 'Campos obrigatórios: data_inicio, hora_inicio, simulador_id, instrutor_id, colaborador_aluno_id' 
      }, 400);
    }
    
    // Converter para timestamp (formato dd/mm/aaaa)
    const [dia, mes, ano] = data_inicio.split('/');
    const [hora, minuto] = hora_inicio.split(':');
    const dataHoraInicio = new Date(parseInt(ano), parseInt(mes) - 1, parseInt(dia), parseInt(hora), parseInt(minuto));
    
    let dataHoraFim = new Date(dataHoraInicio);
    if (data_fim && hora_fim) {
      const [diaF, mesF, anoF] = data_fim.split('/');
      const [horaF, minutoF] = hora_fim.split(':');
      dataHoraFim = new Date(parseInt(anoF), parseInt(mesF) - 1, parseInt(diaF), parseInt(horaF), parseInt(minutoF));
    } else {
      // Auto-calcular 2 horas depois
      dataHoraFim.setHours(dataHoraFim.getHours() + 2);
    }
    
    // Criar agendamento
    const agendamentoResult = await db.prepare(`
      INSERT INTO agendamento_slots (
        data_inicio, data_fim, simulador_id, colaborador_id_instrutor, 
        status_slot, created_at, created_by
      ) VALUES (?, ?, ?, ?, 'AGENDADO', ?, ?)
    `).bind(
      dataHoraInicio.toISOString(),
      dataHoraFim.toISOString(),
      parseInt(simulador_id),
      parseInt(instrutor_id),
      new Date().toISOString(),
      'sistema'
    ).run();
    
    // Criar ficha automaticamente
    const fichaUuid = `FICHA-${new Date().toLocaleDateString('pt-BR').replace(/\//g, '')}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
    
    await db.prepare(`
      INSERT INTO fichas_sessao (
        ficha_uuid, agendamento_slot_id, colaborador_id_aluno, 
        funcao_na_sessao, sessao_template_id, status_workflow, 
        created_at, created_by
      ) VALUES (?, ?, ?, ?, ?, 'RASCUNHO', ?, ?)
    `).bind(
      fichaUuid,
      agendamentoResult.meta.last_row_id,
      parseInt(colaborador_aluno_id),
      funcao_na_sessao || 'PIC',
      template_sessao_id ? parseInt(template_sessao_id) : null,
      new Date().toISOString(),
      'sistema'
    ).run();
    
    return c.json({
      success: true,
      agendamento: {
        id: agendamentoResult.meta.last_row_id,
        ficha_uuid: fichaUuid,
        data_inicio: dataHoraInicio.toLocaleDateString('pt-BR'),
        hora_inicio: dataHoraInicio.toTimeString().substring(0, 5),
        data_fim: dataHoraFim.toLocaleDateString('pt-BR'),
        hora_fim: dataHoraFim.toTimeString().substring(0, 5)
      }
    });
    
  } catch (error: any) {
    console.error('Erro ao criar agendamento:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
};

// CORREÇÃO CRÍTICA 5: Corrigir relacionamentos órfãos
export const corrigirRelacionamentos = async (c: Context) => {
  try {
    const db = c.env.DB as Database;
    
    // Verificar fichas órfãs (sem agendamento)
    const fichasOrfas = await db.prepare(`
      SELECT id, ficha_uuid 
      FROM fichas_sessao 
      WHERE agendamento_slot_id IS NULL AND deleted_at IS NULL
    `).bind().all();
    
    let fichasCorrigidas = 0;
    
    // Criar agendamentos para fichas órfãs
    for (const ficha of fichasOrfas) {
      const agendamentoResult = await db.prepare(`
        INSERT INTO agendamento_slots (
          data_inicio, data_fim, simulador_id, colaborador_id_instrutor,
          status_slot, created_at, created_by
        ) VALUES (?, ?, 1, 1, 'AGENDADO', ?, 'sistema_correcao')
      `).bind(
        new Date().toISOString(),
        new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // +2 horas
        new Date().toISOString()
      ).run();
      
      await db.prepare(`
        UPDATE fichas_sessao 
        SET agendamento_slot_id = ? 
        WHERE id = ?
      `).bind(agendamentoResult.meta.last_row_id, ficha.id).run();
      
      fichasCorrigidas++;
    }
    
    return c.json({
      success: true,
      fichas_corrigidas: fichasCorrigidas,
      message: `${fichasCorrigidas} relacionamentos corrigidos`
    });
    
  } catch (error: any) {
    console.error('Erro ao corrigir relacionamentos:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
};

// CORREÇÃO CRÍTICA 6: Implementar geração de PDF
export const gerarPDFFicha = async (c: Context) => {
  const { uuid } = c.req.param();
  
  try {
    const db = c.env.DB as Database;
    
    // Buscar dados completos da ficha
    const ficha = await db.prepare(`
      SELECT 
        f.*,
        func.nome as funcionario_nome,
        func.matricula as funcionario_matricula,
        s.nome as simulador_nome,
        s.codigo_identificacao as simulador_codigo,
        inst.nome as instrutor_nome,
        st.nome_sessao as template_nome
      FROM fichas_sessao f
      LEFT JOIN funcionarios func ON f.colaborador_id_aluno = func.id
      LEFT JOIN agendamento_slots a ON f.agendamento_slot_id = a.id
      LEFT JOIN simuladores s ON a.simulador_id = s.id
      LEFT JOIN funcionarios inst ON a.colaborador_id_instrutor = inst.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.ficha_uuid = ?
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // Buscar manobras executadas
    const manobras = await db.prepare(`
      SELECT 
        fme.nota,
        fme.observacoes,
        mc.manobra_id_codigo as codigo,
        mc.nome_manobra as nome
      FROM fichas_manobras_executadas fme
      LEFT JOIN manobras_catalogo mc ON fme.manobra_catalogo_id = mc.id
      WHERE fme.ficha_id = ?
    `).bind(ficha.id).all();
    
    // Gerar HTML para PDF
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Ficha de Simulador - ${uuid}</title>
          <style>
            body { 
              font-family: Arial, sans-serif; 
              margin: 20px; 
              font-size: 12px;
            }
            .header { 
              text-align: center; 
              border-bottom: 2px solid #000; 
              padding-bottom: 10px; 
              margin-bottom: 20px;
            }
            .info { margin: 10px 0; }
            .info h3 { margin-bottom: 5px; color: #333; }
            table { 
              width: 100%; 
              border-collapse: collapse; 
              margin: 10px 0; 
            }
            th, td { 
              border: 1px solid #000; 
              padding: 8px; 
              text-align: left; 
            }
            th { background-color: #f0f0f0; }
            .status { 
              font-weight: bold; 
              padding: 5px; 
              border-radius: 3px;
            }
            .status.aprovado { background-color: #d4edda; color: #155724; }
            .status.reprovado { background-color: #f8d7da; color: #721c24; }
            .status.pendente { background-color: #fff3cd; color: #856404; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>FICHA DE AVALIAÇÃO DE SIMULADOR</h1>
            <p><strong>UUID:</strong> ${uuid}</p>
            <p><strong>Data de Criação:</strong> ${formatarDataBrasil(ficha.created_at)}</p>
          </div>
          
          <div class="info">
            <h3>Dados da Sessão</h3>
            <table>
              <tr><td><strong>Tripulante:</strong></td><td>${ficha.funcionario_nome || 'N/A'}</td></tr>
              <tr><td><strong>Matrícula:</strong></td><td>${ficha.funcionario_matricula || 'N/A'}</td></tr>
              <tr><td><strong>Simulador:</strong></td><td>${ficha.simulador_nome || 'N/A'}</td></tr>
              <tr><td><strong>Código Simulador:</strong></td><td>${ficha.simulador_codigo || 'N/A'}</td></tr>
              <tr><td><strong>Instrutor:</strong></td><td>${ficha.instrutor_nome || 'N/A'}</td></tr>
              <tr><td><strong>Função na Sessão:</strong></td><td>${ficha.funcao_na_sessao}</td></tr>
              <tr><td><strong>Template:</strong></td><td>${ficha.template_nome || 'N/A'}</td></tr>
            </table>
          </div>
          
          <div class="info">
            <h3>Status do Workflow</h3>
            <p class="status ${ficha.status_workflow.toLowerCase()}">
              ${ficha.status_workflow}
            </p>
          </div>
          
          <div class="info">
            <h3>Avaliação das Manobras</h3>
            <table>
              <tr>
                <th>Código</th>
                <th>Manobra</th>
                <th>Nota</th>
                <th>Observações</th>
              </tr>
              ${manobras.map((manobra: any) => `
                <tr>
                  <td>${manobra.codigo || 'N/A'}</td>
                  <td>${manobra.nome || 'N/A'}</td>
                  <td style="text-align: center; font-weight: bold;">${manobra.nota}</td>
                  <td>${manobra.observacoes || '-'}</td>
                </tr>
              `).join('')}
            </table>
            ${manobras.length === 0 ? '<p><em>Nenhuma manobra executada ainda.</em></p>' : ''}
          </div>
          
          <div class="info">
            <h3>Resultado Final</h3>
            <table>
              <tr><td><strong>Conceito:</strong></td><td class="status ${(ficha.resultado_final || 'pendente').toLowerCase()}">${ficha.resultado_final || 'Pendente'}</td></tr>
              <tr><td><strong>Nota Final:</strong></td><td>${ficha.nota_final || 'N/A'}</td></tr>
            </table>
          </div>
          
          <div class="info">
            <h3>Observações do Instrutor</h3>
            <p>${ficha.observacoes_instrutor || 'Nenhuma observação registrada.'}</p>
          </div>
          
          <div class="info">
            <h3>Observações do Aluno</h3>
            <p>${ficha.observacoes_aluno || 'Nenhuma observação registrada.'}</p>
          </div>
          
          <div style="margin-top: 30px; font-size: 10px; color: #666; text-align: center;">
            <p>Documento gerado automaticamente pelo Sistema AirTrust em ${formatarDataBrasil(new Date())}</p>
          </div>
        </body>
      </html>
    `;
    
    return new Response(htmlContent, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': `attachment; filename="ficha_${uuid}.html"`
      }
    });
    
  } catch (error: any) {
    console.error('Erro ao gerar PDF:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
};
