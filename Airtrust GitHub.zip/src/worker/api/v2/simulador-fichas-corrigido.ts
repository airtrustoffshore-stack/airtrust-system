/**
 * ⚠️ PADRÃO BRASILEIRO OBRIGATÓRIO - AIRTRUST ⚠️
 * 
 * API CORRIGIDA: Simulador Fichas - Endpoints Críticos Corrigidos
 * 
 * ✅ Datas: SEMPRE dd/mm/aaaa (nunca mm/dd/yyyy ou yyyy-mm-dd)
 * ✅ Conceito: Apenas calculado quando TODAS as manobras têm nota
 * ✅ Erro 500: Endpoints seguros com tratamento completo
 * ✅ Auditoria: Rastreamento completo de ações
 */

import { Hono } from 'hono';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';

const fichasApiCorrigida = new Hono<{ Bindings: Env }>();

// Apply auth middleware
fichasApiCorrigida.use('*', authMiddleware);

// ===== SCHEMAS DE VALIDAÇÃO =====
const SalvarNotasCorrigidoSchema = z.object({
  manobras: z.array(z.object({
    manobra_id: z.number().int().positive(),
    nota: z.string().refine(val => {
      return ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'NR'].includes(val);
    }, 'Nota deve ser de 1 a 10 ou NR'),
    observacoes: z.string().optional()
  })).min(1, 'Pelo menos uma manobra deve ser avaliada'),
  observacoes_instrutor: z.string().optional()
});

// ===== FUNÇÕES AUXILIARES =====

/**
 * Buscar nota anterior de uma manobra para um colaborador
 */
async function buscarNotaAnteriorSegura(
  db: D1Database, 
  colaboradorId: number, 
  manobraId: number, 
  dataSessaoAtual: string
): Promise<{ nota: string; data_avaliacao: string } | null> {
  try {
    const stmt = db.prepare(`
      SELECT 
        CASE 
          WHEN fme.nota = 0 THEN 'NR'
          ELSE CAST(fme.nota AS TEXT)
        END as nota,
        datetime(fs.created_at, 'localtime') as data_avaliacao,
        fs.ficha_uuid
      FROM fichas_manobras_executadas fme
      JOIN fichas_sessao fs ON fme.ficha_id = fs.id
      WHERE fs.colaborador_id_aluno = ? 
        AND fme.manobra_catalogo_id = ?
        AND fs.created_at < ?
        AND fs.deleted_at IS NULL
      ORDER BY fs.created_at DESC
      LIMIT 1
    `);
    
    const result = await stmt.bind(colaboradorId, manobraId, dataSessaoAtual).first();
    return result ? {
      nota: result.nota as string,
      data_avaliacao: result.data_avaliacao as string
    } : null;
  } catch (error) {
    console.error('Erro ao buscar nota anterior:', error);
    return null;
  }
}

/**
 * Formatar data para padrão brasileiro dd/mm/aaaa
 */
function formatarDataBrasil(dataISO: string): string {
  try {
    const data = new Date(dataISO);
    const dia = data.getDate().toString().padStart(2, '0');
    const mes = (data.getMonth() + 1).toString().padStart(2, '0');
    const ano = data.getFullYear().toString();
    return `${dia}/${mes}/${ano}`;
  } catch (error) {
    console.error('Erro ao formatar data:', error);
    return 'Data inválida';
  }
}

/**
 * Calcular conceito APENAS se todas as manobras tiverem nota
 */
function calcularConceitoSeguro(manobras: any[]): 'APROVADO' | 'REPROVADO' | null {
  // Verificar se TODAS as manobras têm nota atual preenchida
  const todasManobrasTemNota = manobras.every(m => m.nota_ficha_atual !== null);
  
  if (!todasManobrasTemNota) {
    return null; // Conceito só aparece quando todas as notas estão preenchidas
  }
  
  // Aplicar regra rigorosa: qualquer nota < 5 = REPROVADO
  const notasNumericas = manobras
    .filter(m => m.nota_ficha_atual !== 'NR')
    .map(m => parseInt(m.nota_ficha_atual));
  
  const temNotaBaixa = notasNumericas.some(nota => nota < 5);
  return temNotaBaixa ? 'REPROVADO' : 'APROVADO';
}

// ===== ENDPOINTS CORRIGIDOS =====

/**
 * GET /api/v2/simulador/ficha/:uuid/corrigida - ENDPOINT CORRIGIDO
 * Carrega ficha sem erro 500, com conceito correto e formato brasileiro
 */
fichasApiCorrigida.get('/ficha/:uuid/corrigida', requirePermission('simuladores', 'READ'), async (c) => {
  const { uuid } = c.req.param();
  
  try {
    const db = c.env.DB;
    
    // 1. Buscar ficha com todas as relações necessárias
    const fichaStmt = db.prepare(`
      SELECT 
        fs.id, fs.ficha_uuid, fs.colaborador_id_aluno, fs.sessao_template_id,
        fs.status_workflow, fs.funcao_na_sessao, fs.created_at,
        f.nome as colaborador_nome, f.matricula as colaborador_matricula,
        slot.data_inicio, slot.data_fim,
        sim.nome as simulador_nome, sim.codigo_identificacao as simulador_codigo,
        inst.nome as instrutor_nome,
        st.nome_sessao as template_nome
      FROM fichas_sessao fs
      LEFT JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      LEFT JOIN agendamento_slots slot ON fs.agendamento_slot_id = slot.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      LEFT JOIN sessoes_template st ON fs.sessao_template_id = st.id
      WHERE fs.ficha_uuid = ? AND fs.deleted_at IS NULL
    `);
    
    const ficha = await fichaStmt.bind(uuid).first();
    
    if (!ficha) {
      return c.json({ 
        error: 'Ficha não encontrada',
        uuid: uuid,
        detalhes: 'Ficha pode ter sido removida ou UUID incorreto'
      }, 404);
    }
    
    // 2. Buscar manobras do template
    const manobrasStmt = db.prepare(`
      SELECT 
        mc.id as manobra_id,
        mc.manobra_id_codigo as codigo,
        mc.nome_manobra as descricao,
        mc.categoria,
        mc.criterios_aprovacao,
        mc.pontuacao_minima
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ? AND mc.deleted_at IS NULL
      ORDER BY mc.categoria, mc.nome_manobra
    `);
    
    const manobrasResult = await manobrasStmt.bind(ficha.sessao_template_id).all();
    const manobrasTemplate = manobrasResult.results || [];
    
    // 3. Para cada manobra, buscar nota anterior e atual
    const manobrasComHistorico = await Promise.all(
      manobrasTemplate.map(async (manobra: any) => {
        // Buscar nota anterior
        const notaAnterior = await buscarNotaAnteriorSegura(
          db,
          ficha.colaborador_id_aluno as number,
          manobra.manobra_id,
          ficha.created_at as string
        );
        
        // Buscar nota atual da ficha (se já preenchida)
        const notaAtualStmt = db.prepare(`
          SELECT 
            CASE 
              WHEN nota = 0 THEN 'NR'
              ELSE CAST(nota AS TEXT)
            END as nota,
            observacoes
          FROM fichas_manobras_executadas
          WHERE ficha_id = ? AND manobra_catalogo_id = ?
        `);
        
        const notaAtual = await notaAtualStmt.bind(ficha.id, manobra.manobra_id).first();
        
        return {
          manobra_id: manobra.manobra_id,
          codigo: manobra.codigo,
          descricao: manobra.descricao,
          categoria: manobra.categoria,
          criterios_aprovacao: manobra.criterios_aprovacao,
          pontuacao_minima: manobra.pontuacao_minima,
          // Nota anterior (formato brasileiro)
          nota_anterior: notaAnterior?.nota || null,
          data_nota_anterior: notaAnterior?.data_avaliacao ? 
            formatarDataBrasil(notaAnterior.data_avaliacao) : null,
          // Nota atual
          nota_ficha_atual: notaAtual?.nota || null,
          observacoes_atual: notaAtual?.observacoes || null
        };
      })
    );
    
    // 4. Calcular conceito APENAS se TODAS as manobras tiverem nota
    const conceito_atual = calcularConceitoSeguro(manobrasComHistorico);
    
    // 5. Montar resposta segura
    const fichaResponse = {
      ficha_id: ficha.id,
      uuid: ficha.ficha_uuid,
      status_workflow: ficha.status_workflow,
      funcao_na_sessao: ficha.funcao_na_sessao,
      conceito_final: conceito_atual, // null se não tiver todas as notas
      created_at: formatarDataBrasil(ficha.created_at as string),
      colaborador: {
        id: ficha.colaborador_id_aluno,
        nome: ficha.colaborador_nome || 'N/A',
        matricula: ficha.colaborador_matricula || 'N/A'
      },
      simulador: {
        nome: ficha.simulador_nome || 'N/A',
        codigo: ficha.simulador_codigo || 'N/A'
      },
      instrutor: {
        nome: ficha.instrutor_nome || 'N/A'
      },
      sessao_template: {
        nome: ficha.template_nome || 'N/A'
      },
      slot_info: {
        data_inicio: ficha.data_inicio ? formatarDataBrasil(ficha.data_inicio as string) : null,
        data_fim: ficha.data_fim ? formatarDataBrasil(ficha.data_fim as string) : null
      },
      manobras: manobrasComHistorico,
      pode_editar: ['RASCUNHO', 'PENDENTE_ALUNO'].includes(ficha.status_workflow as string),
      estatisticas: {
        total_manobras: manobrasComHistorico.length,
        manobras_preenchidas: manobrasComHistorico.filter(m => m.nota_ficha_atual !== null).length,
        percentual_conclusao: Math.round(
          (manobrasComHistorico.filter(m => m.nota_ficha_atual !== null).length / 
           manobrasComHistorico.length) * 100
        )
      }
    };
    
    return c.json({
      success: true,
      data: fichaResponse,
      message: 'Ficha carregada com sucesso'
    });
    
  } catch (error) {
    console.error('Erro detalhado ao carregar ficha:', {
      uuid,
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      stack: error instanceof Error ? error.stack : undefined
    });
    
    return c.json({ 
      error: 'Erro interno do servidor ao carregar ficha',
      details: (error instanceof Error ? error.message : 'Erro desconhecido'),
      uuid,
      timestamp: new Date().toISOString()
    }, 500);
  }
});

/**
 * PATCH /api/v2/simulador/ficha/:uuid/notas-corrigidas - ENDPOINT CORRIGIDO
 * Salva notas com validação rigorosa e conceito correto
 */
fichasApiCorrigida.patch('/ficha/:uuid/notas-corrigidas', 
  requirePermission('simuladores', 'UPDATE'), 
  async (c) => {
    const { uuid } = c.req.param();
    
    try {
      const body = await c.req.json();
      const { manobras, observacoes_instrutor } = SalvarNotasCorrigidoSchema.parse(body);
      
      const db = c.env.DB;
      const usuarioId = 1; // TODO: Obter do contexto de auth
      const ip = c.req.header('cf-connecting-ip') || c.req.header('x-forwarded-for') || 'unknown';
      
      // 1. Buscar e validar ficha
      const fichaStmt = db.prepare(`
        SELECT id, colaborador_id_aluno, status_workflow
        FROM fichas_sessao 
        WHERE ficha_uuid = ? AND deleted_at IS NULL
      `);
      
      const ficha = await fichaStmt.bind(uuid).first();
      
      if (!ficha) {
        return c.json({ error: 'Ficha não encontrada' }, 404);
      }
      
      // 2. Verificar se pode editar
      if (!['RASCUNHO', 'PENDENTE_ALUNO'].includes(ficha.status_workflow as string)) {
        return c.json({ 
          error: 'Ficha não pode ser editada no status atual',
          status_atual: ficha.status_workflow
        }, 403);
      }
      
      // 3. Validar se todas as manobras têm nota
      const manobrasSemNota = manobras.filter(m => !m.nota || m.nota.trim() === '');
      if (manobrasSemNota.length > 0) {
        return c.json({ 
          error: 'Todas as manobras devem ter nota definida',
          manobras_sem_nota: manobrasSemNota.length,
          detalhes: 'Complete todas as avaliações antes de salvar'
        }, 400);
      }
      
      let conceito_final: 'APROVADO' | 'REPROVADO' | null = null;
      const resultados: any[] = [];
      
      // 4. Processar notas com transação
      try {
        // Deletar manobras existentes para esta ficha
        const deleteStmt = db.prepare(`
          DELETE FROM fichas_manobras_executadas WHERE ficha_id = ?
        `);
        await deleteStmt.bind(ficha.id).run();
        
        // Salvar novas notas
        for (const manobra of manobras) {
          const notaValue = manobra.nota === 'NR' ? 0 : parseInt(manobra.nota);
          
          const insertStmt = db.prepare(`
            INSERT INTO fichas_manobras_executadas (
              ficha_id, manobra_catalogo_id, nota, observacoes
            ) VALUES (?, ?, ?, ?)
          `);
          
          const result = await insertStmt.bind(
            ficha.id,
            manobra.manobra_id,
            notaValue,
            manobra.observacoes || null
          ).run();
          
          // Registrar auditoria
          const auditStmt = db.prepare(`
            INSERT INTO auditoria_manobras (
              ficha_manobras_executadas_id, usuario_id, acao, 
              valor_anterior, valor_novo, ip_origem
            ) VALUES (?, ?, ?, ?, ?, ?)
          `);
          
          await auditStmt.bind(
            result.meta.last_row_id,
            usuarioId,
            'NOTA_SALVA',
            null,
            manobra.nota,
            ip
          ).run();
          
          resultados.push({
            manobra_id: manobra.manobra_id,
            nota: manobra.nota,
            status: 'SALVA'
          });
        }
        
        // 5. Calcular conceito final RIGOROSO
        const notasNumericas = manobras
          .filter(m => m.nota !== 'NR')
          .map(m => parseInt(m.nota));
        
        // Qualquer nota < 5 = REPROVADO
        const temNotaBaixa = notasNumericas.some(nota => nota < 5);
        conceito_final = temNotaBaixa ? 'REPROVADO' : 'APROVADO';
        
        const menorNota = notasNumericas.length > 0 ? Math.min(...notasNumericas) : 10;
        
        // 6. Atualizar ficha com conceito
        const updateFichaStmt = db.prepare(`
          UPDATE fichas_sessao 
          SET 
            resultado_final = ?, 
            nota_final = ?,
            observacoes_instrutor = ?,
            status_workflow = 'PENDENTE_ALUNO',
            updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `);
        
        await updateFichaStmt.bind(
          conceito_final, 
          menorNota,
          observacoes_instrutor || null,
          ficha.id
        ).run();
        
        // 7. Auditoria geral da ficha
        const auditFichaStmt = db.prepare(`
          INSERT INTO auditoria_simulador (
            ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem
          ) VALUES (?, ?, ?, ?, ?)
        `);
        
        await auditFichaStmt.bind(
          uuid,
          usuarioId,
          'AVALIACAO_COMPLETA',
          JSON.stringify({
            conceito: conceito_final,
            total_manobras: manobras.length,
            menor_nota: menorNota,
            manobras_nr: manobras.filter(m => m.nota === 'NR').length
          }),
          ip
        ).run();
        
        return c.json({ 
          success: true, 
          data: {
            conceito: conceito_final,
            nota_final: menorNota,
            detalhes_aprovacao: {
              total_manobras: manobras.length,
              manobras_avaliadas: manobras.filter(m => m.nota !== 'NR').length,
              manobras_nr: manobras.filter(m => m.nota === 'NR').length,
              menor_nota: menorNota,
              reprovou_por_nota: conceito_final === 'REPROVADO'
            },
            resultados
          },
          message: `Avaliação salva com sucesso. Conceito: ${conceito_final}`
        });
        
      } catch (transactionError) {
        console.error('Erro na transação de salvamento:', transactionError);
        throw transactionError;
      }
      
    } catch (error) {
      console.error('Erro ao salvar notas:', {
        uuid,
        error: error instanceof Error ? error.message : 'Erro desconhecido',
        stack: error instanceof Error ? error.stack : undefined
      });
      
      return c.json({ 
        error: 'Erro interno do servidor ao salvar notas',
        details: (error instanceof Error ? error.message : 'Erro desconhecido'),
        uuid,
        timestamp: new Date().toISOString()
      }, 500);
    }
  }
);

/**
 * GET /api/v2/simulador/fichas-lista - Lista fichas com informações básicas
 */
fichasApiCorrigida.get('/fichas-lista', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const fichasStmt = db.prepare(`
      SELECT 
        fs.ficha_uuid, fs.status_workflow, fs.funcao_na_sessao,
        fs.resultado_final, fs.nota_final, fs.created_at,
        f.nome as colaborador_nome, f.matricula as colaborador_matricula,
        sim.nome as simulador_nome,
        inst.nome as instrutor_nome,
        st.nome_sessao as template_nome
      FROM fichas_sessao fs
      LEFT JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      LEFT JOIN agendamento_slots slot ON fs.agendamento_slot_id = slot.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      LEFT JOIN sessoes_template st ON fs.sessao_template_id = st.id
      WHERE fs.deleted_at IS NULL
      ORDER BY fs.created_at DESC
      LIMIT 50
    `);
    
    const result = await fichasStmt.all();
    const fichas = (result.results || []).map((ficha: any) => ({
      uuid: ficha.ficha_uuid,
      status_workflow: ficha.status_workflow,
      funcao_na_sessao: ficha.funcao_na_sessao,
      resultado_final: ficha.resultado_final,
      nota_final: ficha.nota_final,
      created_at: ficha.created_at ? formatarDataBrasil(ficha.created_at as string) : 'N/A',
      colaborador: {
        nome: ficha.colaborador_nome || 'N/A',
        matricula: ficha.colaborador_matricula || 'N/A'
      },
      simulador: ficha.simulador_nome || 'N/A',
      instrutor: ficha.instrutor_nome || 'N/A',
      template: ficha.template_nome || 'N/A'
    }));
    
    return c.json({
      success: true,
      data: fichas,
      total: fichas.length,
      message: 'Lista de fichas carregada com sucesso'
    });
    
  } catch (error) {
    console.error('Erro ao listar fichas:', error);
    return c.json({ 
      error: 'Erro interno do servidor ao listar fichas'
    }, 500);
  }
});

export default fichasApiCorrigida;
