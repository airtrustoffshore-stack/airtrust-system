import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';
import { Funcao } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

// Schema de validação para Função
const FuncaoSchema = z.object({
  nome: z.string().min(1),
  descricao: z.string().optional(),
  categoria: z.string().optional()
});

const FuncaoUpdateSchema = FuncaoSchema.partial();

// Aplicar middleware de autenticação a todas as rotas
app.use('*', authMiddleware);

// GET /api/v2/funcoes - Listar todas as funções
app.get('/', requirePermission('funcoes', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT id, nome, descricao, categoria, created_at, updated_at
      FROM funcoes 
      WHERE deleted_at IS NULL 
      ORDER BY nome
    `);
    
    const result = await stmt.all();
    const funcoes = result.results as unknown as Funcao[];

    await logAudit(c, 'LIST', 'funcoes');
    
    return c.json({
      success: true,
      data: funcoes,
      total: funcoes.length
    });
  } catch (error) {
    console.error('Error listing funcoes:', error);
    await logAudit(c, 'LIST', 'funcoes', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/funcoes/:id - Obter função por ID
app.get('/:id', requirePermission('funcoes', 'READ'), async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT id, nome, descricao, categoria, created_at, updated_at
      FROM funcoes 
      WHERE id = ? AND deleted_at IS NULL
    `);
    
    const funcao = await stmt.bind(id).first() as Funcao;
    
    if (!funcao) {
      return c.json({ error: 'Função não encontrada' }, 404);
    }

    await logAudit(c, 'READ', 'funcoes', id);
    
    return c.json({
      success: true,
      data: funcao
    });
  } catch (error) {
    console.error('Error getting funcao:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/v2/funcoes - Criar nova função
app.post('/', requirePermission('funcoes', 'CREATE'), zValidator('json', FuncaoSchema), async (c) => {
  try {
    const data = c.req.valid('json');
    const db = c.env.DB;
    
    // 1. Criar snapshot antes da operação
    const { BackupService } = await import('../../services/backup');
    const snapshotId = await BackupService.createSnapshot(c, 'CREATE', 'funcoes');
    
    const stmt = db.prepare(`
      INSERT INTO funcoes (nome, descricao, categoria)
      VALUES (?, ?, ?)
    `);
    
    const result = await stmt.bind(data.nome, data.descricao, data.categoria).run();
    
    if (!result.success) {
      return c.json({ error: 'Erro ao criar função' }, 400);
    }

    // 2. Registrar auditoria e validar pós-operação
    await logAudit(c, 'CREATE', 'funcoes', result.meta.last_row_id?.toString(), undefined, data);
    await BackupService.validatePostOperation(c, snapshotId, 'funcoes');
    
    return c.json({
      success: true,
      data: { id: result.meta.last_row_id, ...data },
      message: 'Função criada com sucesso'
    }, 201);
  } catch (error) {
    console.error('Error creating funcao:', error);
    await logAudit(c, 'CREATE', 'funcoes', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// PUT /api/v2/funcoes/:id - Atualizar função
app.put('/:id', requirePermission('funcoes', 'UPDATE'), zValidator('json', FuncaoUpdateSchema), async (c) => {
  try {
    const id = c.req.param('id');
    const data = c.req.valid('json');
    const db = c.env.DB;
    
    // Buscar dados anteriores para auditoria
    const oldData = await db.prepare(`
      SELECT * FROM funcoes WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!oldData) {
      return c.json({ error: 'Função não encontrada' }, 404);
    }

    const updates = [];
    const values = [];
    
    if (data.nome !== undefined) {
      updates.push('nome = ?');
      values.push(data.nome);
    }
    if (data.descricao !== undefined) {
      updates.push('descricao = ?');
      values.push(data.descricao);
    }
    if (data.categoria !== undefined) {
      updates.push('categoria = ?');
      values.push(data.categoria);
    }
    
    updates.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);
    
    const stmt = db.prepare(`
      UPDATE funcoes 
      SET ${updates.join(', ')}
      WHERE id = ? AND deleted_at IS NULL
    `);
    
    const result = await stmt.bind(...values).run();
    
    if (!result.success) {
      return c.json({ error: 'Função não encontrada' }, 404);
    }

    await logAudit(c, 'UPDATE', 'funcoes', id, oldData, data);
    
    return c.json({
      success: true,
      message: 'Função atualizada com sucesso'
    });
  } catch (error) {
    console.error('Error updating funcao:', error);
    await logAudit(c, 'UPDATE', 'funcoes', c.req.param('id'), undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// DELETE /api/v2/funcoes/:id - Soft delete de função
app.delete('/:id', requirePermission('funcoes', 'DELETE'), async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    // Buscar dados anteriores para auditoria
    const oldData = await db.prepare(`
      SELECT * FROM funcoes WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!oldData) {
      return c.json({ error: 'Função não encontrada' }, 404);
    }

    const stmt = db.prepare(`
      UPDATE funcoes 
      SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND deleted_at IS NULL
    `);
    
    const result = await stmt.bind(id).run();
    
    if (!result.success) {
      return c.json({ error: 'Função não encontrada' }, 404);
    }

    await logAudit(c, 'DELETE', 'funcoes', id, oldData, undefined);
    
    return c.json({
      success: true,
      message: 'Função removida com sucesso'
    });
  } catch (error) {
    console.error('Error deleting funcao:', error);
    await logAudit(c, 'DELETE', 'funcoes', c.req.param('id'), undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default app;
