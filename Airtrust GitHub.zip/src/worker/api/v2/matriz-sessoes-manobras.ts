import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Schema para configuração da matriz
const MatrizSessaoManobraSchema = z.object({
  sessao_template_id: z.number().int().positive(),
  manobra_catalogo_id: z.number().int().positive()
});

const SessaoManobrasBulkSchema = z.object({
  sessao_template_id: z.number().int().positive(),
  manobras_ids: z.array(z.number().int().positive())
});



// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// GET /api/v2/matriz-sessoes-manobras/sessao/:id - Obter manobras de uma sessão
app.get('/sessao/:id', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const sessaoId = c.req.param('id');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT mc.id, mc.manobra_id_codigo, mc.nome_manobra, mc.categoria,
             mc.criterios_aprovacao, mc.pontuacao_minima, mc.ativo,
             stm.sessao_template_id
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ? AND mc.deleted_at IS NULL
      ORDER BY mc.categoria, mc.nome_manobra
    `);
    
    const result = await stmt.bind(sessaoId).all();
    const manobras = result.results || [];

    await logAudit(c, 'READ', 'matriz_sessao_manobras', sessaoId);
    
    return c.json({
      success: true,
      data: manobras,
      total: manobras.length
    });
  } catch (error) {
    console.error('Error getting manobras da sessao:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/matriz-sessoes-manobras/manobra/:id - Obter sessões que usam uma manobra
app.get('/manobra/:id', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const manobraId = c.req.param('id');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT st.id, st.treinamento_codigo, st.numero_sessao, st.nome_sessao,
             st.descricao, stm.manobra_catalogo_id
      FROM sessoes_template_manobras stm
      JOIN sessoes_template st ON stm.sessao_template_id = st.id
      WHERE stm.manobra_catalogo_id = ?
      ORDER BY st.treinamento_codigo, st.numero_sessao
    `);
    
    const result = await stmt.bind(manobraId).all();
    const sessoes = result.results || [];

    await logAudit(c, 'READ', 'matriz_sessao_manobras', manobraId);
    
    return c.json({
      success: true,
      data: sessoes,
      total: sessoes.length
    });
  } catch (error) {
    console.error('Error getting sessoes da manobra:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/matriz-sessoes-manobras/matriz-completa - Obter matriz completa
app.get('/matriz-completa', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT st.id as sessao_id, st.treinamento_codigo, st.numero_sessao, st.nome_sessao,
             mc.id as manobra_id, mc.manobra_id_codigo, mc.nome_manobra, mc.categoria,
             mc.pontuacao_minima
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      LEFT JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id AND mc.deleted_at IS NULL
      ORDER BY st.treinamento_codigo, st.numero_sessao, mc.categoria, mc.nome_manobra
    `);
    
    const result = await stmt.all();
    const matriz = result.results || [];

    await logAudit(c, 'READ', 'matriz_completa');
    
    return c.json({
      success: true,
      data: matriz,
      total: matriz.length
    });
  } catch (error) {
    console.error('Error getting matriz completa:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/v2/matriz-sessoes-manobras/adicionar - Adicionar relação sessão-manobra
app.post('/adicionar', requirePermission('simuladores', 'CREATE'), zValidator('json', MatrizSessaoManobraSchema), async (c) => {
  try {
    const data = c.req.valid('json');
    const db = c.env.DB;
    
    // Verificar se sessão existe
    const sessaoExists = await db.prepare(
      'SELECT 1 FROM sessoes_template WHERE id = ?'
    ).bind(data.sessao_template_id).first();
    
    if (!sessaoExists) {
      return c.json({ error: 'Sessão template não encontrada' }, 404);
    }
    
    // Verificar se manobra existe
    const manobraExists = await db.prepare(
      'SELECT 1 FROM manobras_catalogo WHERE id = ? AND deleted_at IS NULL'
    ).bind(data.manobra_catalogo_id).first();
    
    if (!manobraExists) {
      return c.json({ error: 'Manobra não encontrada' }, 404);
    }
    
    // Verificar se relação já existe
    const relationExists = await db.prepare(
      'SELECT 1 FROM sessoes_template_manobras WHERE sessao_template_id = ? AND manobra_catalogo_id = ?'
    ).bind(data.sessao_template_id, data.manobra_catalogo_id).first();
    
    if (relationExists) {
      return c.json({ error: 'Relação já existe' }, 400);
    }

    const { BackupService } = await import('../../services/backup');
    const snapshotId = await BackupService.createSnapshot(c, 'CREATE', 'sessoes_template_manobras');
    
    const stmt = db.prepare(`
      INSERT INTO sessoes_template_manobras (sessao_template_id, manobra_catalogo_id)
      VALUES (?, ?)
    `);
    
    const result = await stmt.bind(
      data.sessao_template_id,
      data.manobra_catalogo_id
    ).run();
    
    if (!result.success) {
      return c.json({ error: 'Erro ao criar relação' }, 400);
    }

    await logAudit(c, 'CREATE', 'sessoes_template_manobras', undefined, undefined, data);
    await BackupService.validatePostOperation(c, snapshotId, 'sessoes_template_manobras');
    
    return c.json({
      success: true,
      data: data,
      message: 'Relação criada com sucesso'
    }, 201);
  } catch (error) {
    console.error('Error creating sessao-manobra relation:', error);
    await logAudit(c, 'CREATE', 'sessoes_template_manobras', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// DELETE /api/v2/matriz-sessoes-manobras/remover - Remover relação sessão-manobra
app.delete('/remover', requirePermission('simuladores', 'DELETE'), zValidator('json', MatrizSessaoManobraSchema), async (c) => {
  try {
    const data = c.req.valid('json');
    const db = c.env.DB;
    
    const relation = await db.prepare(
      'SELECT * FROM sessoes_template_manobras WHERE sessao_template_id = ? AND manobra_catalogo_id = ?'
    ).bind(data.sessao_template_id, data.manobra_catalogo_id).first();
    
    if (!relation) {
      return c.json({ error: 'Relação não encontrada' }, 404);
    }

    const { BackupService } = await import('../../services/backup');
    const snapshotId = await BackupService.createSnapshot(c, 'DELETE', 'sessoes_template_manobras');
    
    const stmt = db.prepare(`
      DELETE FROM sessoes_template_manobras 
      WHERE sessao_template_id = ? AND manobra_catalogo_id = ?
    `);
    
    const result = await stmt.bind(
      data.sessao_template_id,
      data.manobra_catalogo_id
    ).run();
    
    if (!result.success) {
      return c.json({ error: 'Erro ao remover relação' }, 400);
    }

    await logAudit(c, 'DELETE', 'sessoes_template_manobras', undefined, relation, data);
    await BackupService.validatePostOperation(c, snapshotId, 'sessoes_template_manobras');
    
    return c.json({
      success: true,
      message: 'Relação removida com sucesso'
    });
  } catch (error) {
    console.error('Error deleting sessao-manobra relation:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// PUT /api/v2/matriz-sessoes-manobras/bulk-update - Atualizar todas as manobras de uma sessão
app.put('/bulk-update', requirePermission('simuladores', 'UPDATE'), zValidator('json', SessaoManobrasBulkSchema), async (c) => {
  try {
    const data = c.req.valid('json');
    const db = c.env.DB;
    
    // Verificar se sessão existe
    const sessaoExists = await db.prepare(
      'SELECT 1 FROM sessoes_template WHERE id = ?'
    ).bind(data.sessao_template_id).first();
    
    if (!sessaoExists) {
      return c.json({ error: 'Sessão template não encontrada' }, 404);
    }
    
    // Capturar estado atual para auditoria
    const currentRelations = await db.prepare(
      'SELECT manobra_catalogo_id FROM sessoes_template_manobras WHERE sessao_template_id = ?'
    ).bind(data.sessao_template_id).all();

    const { BackupService } = await import('../../services/backup');
    const snapshotId = await BackupService.createSnapshot(c, 'UPDATE', 'sessoes_template_manobras');
    
    // Usar transação para operação atomic
    // 1. Remover todas as relações existentes
    await db.prepare(`
      DELETE FROM sessoes_template_manobras WHERE sessao_template_id = ?
    `).bind(data.sessao_template_id).run();
    
    // 2. Inserir novas relações
    if (data.manobras_ids.length > 0) {
      const insertStmt = db.prepare(`
        INSERT INTO sessoes_template_manobras (sessao_template_id, manobra_catalogo_id)
        VALUES (?, ?)
      `);
      
      for (const manobraId of data.manobras_ids) {
        // Verificar se manobra existe
        const manobraExists = await db.prepare(
          'SELECT 1 FROM manobras_catalogo WHERE id = ? AND deleted_at IS NULL'
        ).bind(manobraId).first();
        
        if (manobraExists) {
          await insertStmt.bind(data.sessao_template_id, manobraId).run();
        }
      }
    }

    await logAudit(c, 'BULK_UPDATE', 'sessoes_template_manobras', data.sessao_template_id.toString(), 
                   currentRelations, data);
    await BackupService.validatePostOperation(c, snapshotId, 'sessoes_template_manobras');
    
    return c.json({
      success: true,
      message: 'Manobras da sessão atualizadas com sucesso'
    });
  } catch (error) {
    console.error('Error bulk updating sessao manobras:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/v2/matriz-sessoes-manobras/import-csv - Importar matriz via CSV
app.post('/import-csv', requirePermission('simuladores', 'CREATE'), async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ error: 'Arquivo CSV obrigatório' }, 400);
    }
    
    const csvContent = await file.text();
    const lines = csvContent.split('\n').filter(line => line.trim());
    
    if (lines.length < 2) {
      return c.json({ error: 'Arquivo CSV deve ter pelo menos um cabeçalho e uma linha de dados' }, 400);
    }
    
    const header = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const expectedHeaders = ['sessao_codigo', 'nome_sessao', 'manobra_codigos'];
    
    // Validar cabeçalho
    const missingHeaders = expectedHeaders.filter(h => !header.includes(h));
    if (missingHeaders.length > 0) {
      return c.json({ 
        error: 'Cabeçalho CSV inválido',
        details: `Colunas obrigatórias: ${expectedHeaders.join(', ')}. Faltando: ${missingHeaders.join(', ')}`
      }, 400);
    }
    
    const db = c.env.DB;
    const { BackupService } = await import('../../services/backup');
    const snapshotId = await BackupService.createSnapshot(c, 'IMPORT_CSV', 'matriz_sessoes_manobras');
    
    const results = {
      total_linhas: lines.length - 1,
      processadas: 0,
      erros: [] as any[],
      sessoes_criadas: 0,
      relacoes_criadas: 0,
      codigos_nao_encontrados: [] as string[]
    };
    
    for (let i = 1; i < lines.length; i++) {
      try {
        const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
        const rowData: any = {};
        
        header.forEach((h, idx) => {
          rowData[h] = values[idx] || '';
        });
        
        if (!rowData.sessao_codigo || !rowData.nome_sessao) {
          results.erros.push({
            linha: i,
            erro: 'Sessão código e nome são obrigatórios',
            dados: rowData
          });
          continue;
        }
        
        // Encontrar ou criar sessão template
        let sessao = await db.prepare(
          'SELECT id FROM sessoes_template WHERE nome_sessao = ?'
        ).bind(rowData.nome_sessao).first();
        
        if (!sessao) {
          // Criar nova sessão template
          const createSessaoStmt = db.prepare(`
            INSERT INTO sessoes_template (treinamento_codigo, numero_sessao, nome_sessao)
            VALUES (?, ?, ?)
          `);
          
          // Extrair número da sessão do código
          const numeroSessao = parseInt(rowData.sessao_codigo.replace(/\D/g, '')) || 1;
          
          const result = await createSessaoStmt.bind(
            rowData.sessao_codigo,
            numeroSessao,
            rowData.nome_sessao
          ).run();
          
          if (result.success) {
            sessao = { id: result.meta.last_row_id };
            results.sessoes_criadas++;
          } else {
            results.erros.push({
              linha: i,
              erro: 'Erro ao criar sessão template',
              dados: rowData
            });
            continue;
          }
        }
        
        // Processar códigos de manobras
        if (rowData.manobra_codigos) {
          const manobrasCodigosArray = rowData.manobra_codigos.split(',').map((c: string) => c.trim());
          
          for (const manobraCodigo of manobrasCodigosArray) {
            if (!manobraCodigo) continue;
            
            // Encontrar manobra pelo código
            const manobra = await db.prepare(
              'SELECT id FROM manobras_catalogo WHERE manobra_id_codigo = ? AND deleted_at IS NULL'
            ).bind(manobraCodigo).first();
            
            if (manobra) {
              // Verificar se relação já existe
              const relationExists = await db.prepare(
                'SELECT 1 FROM sessoes_template_manobras WHERE sessao_template_id = ? AND manobra_catalogo_id = ?'
              ).bind(sessao.id, manobra.id).first();
              
              if (!relationExists) {
                // Criar relação
                await db.prepare(`
                  INSERT INTO sessoes_template_manobras (sessao_template_id, manobra_catalogo_id)
                  VALUES (?, ?)
                `).bind(sessao.id, manobra.id).run();
                
                results.relacoes_criadas++;
              }
            } else {
              if (!results.codigos_nao_encontrados.includes(manobraCodigo)) {
                results.codigos_nao_encontrados.push(manobraCodigo);
              }
            }
          }
        }
        
        results.processadas++;
      } catch (error) {
        results.erros.push({
          linha: i,
          erro: error instanceof Error ? error.message : 'Erro desconhecido',
          dados: lines[i]
        });
      }
    }

    await logAudit(c, 'IMPORT_CSV', 'matriz_sessoes_manobras', undefined, undefined, {
      arquivo: file.name,
      resultados: results
    });
    await BackupService.validatePostOperation(c, snapshotId, 'matriz_sessoes_manobras');
    
    return c.json({
      success: true,
      data: results,
      message: `Importação concluída. ${results.processadas} linhas processadas, ${results.sessoes_criadas} sessões criadas, ${results.relacoes_criadas} relações criadas.`
    });
  } catch (error) {
    console.error('Error importing CSV:', error);
    await logAudit(c, 'IMPORT_CSV', 'matriz_sessoes_manobras', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/matriz-sessoes-manobras/export-csv - Exportar matriz como CSV
app.get('/export-csv', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT st.treinamento_codigo as sessao_codigo, st.nome_sessao,
             GROUP_CONCAT(mc.manobra_id_codigo) as manobra_codigos
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      LEFT JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id AND mc.deleted_at IS NULL
      GROUP BY st.id, st.treinamento_codigo, st.nome_sessao
      ORDER BY st.treinamento_codigo
    `);
    
    const result = await stmt.all();
    const dados = result.results || [];
    
    // Gerar CSV
    const csvLines = ['sessao_codigo,nome_sessao,manobra_codigos'];
    
    dados.forEach((row: any) => {
      const manobrasString = row.manobra_codigos || '';
      csvLines.push(`"${row.sessao_codigo}","${row.nome_sessao}","${manobrasString}"`);
    });
    
    const csvContent = csvLines.join('\n');

    await logAudit(c, 'EXPORT_CSV', 'matriz_sessoes_manobras');
    
    return new Response(csvContent, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': 'attachment; filename="matriz_sessoes_manobras.csv"'
      }
    });
  } catch (error) {
    console.error('Error exporting CSV:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default app;
