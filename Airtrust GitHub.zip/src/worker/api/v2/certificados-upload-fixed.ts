import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

interface Env {
  DB: any;
  R2_BUCKET: any;
}

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ ENDPOINT DE UPLOAD DE CERTIFICADO CORRIGIDO
app.post('/:id/upload-certificado', requirePermission('treinamentos', 'CREATE'), async (c) => {
  try {
    const certificacaoId = c.req.param('id');
    console.log(`📂 Upload certificado para certificação: ${certificacaoId}`);
    
    const formData = await c.req.formData();
    const file = formData.get('certificado') as File;
    
    if (!file) {
      return c.json({ 
        success: false, 
        error: 'Arquivo de certificado é obrigatório' 
      }, 400);
    }
    
    console.log(`📄 Arquivo recebido: ${file.name}, tamanho: ${file.size} bytes`);
    
    // Verificar se certificação existe (suporta tanto V2 quanto V3)
    let certificacao = await c.env.DB.prepare(`
      SELECT 
        c.id,
        c.certificacao_id,
        c.funcionario_matricula,
        f.nome as funcionario_nome,
        f.matricula,
        t.nome as treinamento_nome,
        c.treinamento_codigo
      FROM certificacoes_v3 c
      JOIN funcionarios f ON c.funcionario_matricula = f.matricula
      JOIN catalogo_treinamentos_v2 t ON c.treinamento_codigo = t.codigo
      WHERE c.id = ?
    `).bind(certificacaoId).first();
    
    // Se não encontrou em V3, buscar em V2 (histórico)
    if (!certificacao) {
      certificacao = await c.env.DB.prepare(`
        SELECT 
          c.id,
          c.id as certificacao_id,
          c.funcionario_id as colaboradorid,
          f.nome as funcionario_nome,
          f.matricula,
          t.nome as treinamento_nome,
          t.codigo as treinamento_codigo
        FROM historico_certificacoes_v2 c
        JOIN funcionarios f ON c.funcionario_id = f.id
        JOIN catalogo_treinamentos_v2 t ON c.treinamento_id = t.id
        WHERE c.id = ? AND c.deleted_at IS NULL
      `).bind(certificacaoId).first();
    }
    
    if (!certificacao) {
      return c.json({ 
        success: false, 
        error: 'Certificação não encontrada' 
      }, 404);
    }
    
    console.log(`✅ Certificação encontrada: ${certificacao.certificacao_id}`);
    
    // ✅ GERAR NOME ÚNICO PARA ARQUIVO
    const extensao = file.name.split('.').pop() || 'pdf';
    const nomeArquivo = `cert_${certificacao.certificacao_id || certificacao.id}_${Date.now()}.${extensao}`;
    
    console.log(`📝 Nome do arquivo: ${nomeArquivo}`);
    
    // ✅ UPLOAD PARA CLOUDFLARE R2
    const arrayBuffer = await file.arrayBuffer();
    const caminhoArquivo = `certificados/${certificacao.matricula}/${nomeArquivo}`;
    
    const uploadResponse = await c.env.R2_BUCKET.put(
      caminhoArquivo,
      arrayBuffer,
      {
        httpMetadata: {
          contentType: file.type || 'application/pdf',
          contentDisposition: `attachment; filename="${file.name}"`
        },
        customMetadata: {
          certificacao_id: String(certificacao.certificacao_id || certificacao.id),
          funcionario_id: String(certificacao.colaboradorid || certificacao.funcionario_id),
          matricula: certificacao.matricula,
          treinamento: certificacao.treinamento_nome,
          uploaded_at: new Date().toISOString()
        }
      }
    );
    
    if (!uploadResponse) {
      throw new Error('Falha no upload para R2');
    }
    
    console.log(`✅ Upload R2 concluído: ${caminhoArquivo}`);
    
    // ✅ GERAR URL DE ACESSO PÚBLICO
    const publicUrl = `https://pub-your-r2-domain.r2.dev/${caminhoArquivo}`;
    
    // ✅ SALVAR INFORMAÇÕES NO BANCO (V2 - histórico)
    const now = new Date().toISOString();
    
    if (certificacao.colaboradorid) {
      // Para registros V2 (histórico_certificacoes_v2)
      await c.env.DB.prepare(`
        UPDATE historico_certificacoes_v2 
        SET 
          certificado_url = ?,
          updated_at = ?
        WHERE id = ?
      `).bind(
        publicUrl,
        now,
        certificacaoId
      ).run();
    }
    
    // ✅ SALVAR NA TABELA DE ANEXOS
    const anexoResult = await c.env.DB.prepare(`
      INSERT INTO certificado_anexos_v2 (historico_id, nome_arquivo, url_arquivo, arquivo_github_url, tipo_arquivo, tamanho_bytes, created_at) 
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      certificacaoId,
      file.name,
      publicUrl,
      publicUrl, // arquivo_github_url (mesmo valor para compatibilidade)
      file.type || 'application/pdf',
      file.size,
      now
    ).run();
    
    console.log(`✅ Anexo registrado no banco de dados`);
    
    // ✅ SINCRONIZAÇÃO AUTOMÁTICA COM PASTA VIRTUAL
    console.log(`🔄 Iniciando sincronização automática com pasta virtual...`);
    
    try {
      // Importar e executar sincronização automática
      const { sincronizarCertificadoParaPastaVirtual } = await import('../../services/certificado-pasta-virtual-sync');
      
      const syncResult = await sincronizarCertificadoParaPastaVirtual(
        anexoResult.meta?.last_row_id as number,
        c.env.DB,
        c.env.R2_BUCKET
      );
      
      if (syncResult.success) {
        console.log(`✅ Sincronização automática concluída: ${syncResult.action}`);
      } else {
        console.warn(`⚠️ Erro na sincronização automática: ${syncResult.error}`);
      }
      
    } catch (syncError) {
      console.error(`💥 Erro na sincronização automática:`, syncError);
      // Não falhar o upload por erro na sincronização, apenas logar
    }
    
    await logAudit(c, 'UPLOAD', 'certificado_anexos_v2', String(anexoResult.meta?.last_row_id), undefined, {
      certificacao_id: certificacao.certificacao_id || certificacao.id,
      filename: nomeArquivo,
      r2_path: caminhoArquivo,
      file_size: file.size,
      funcionario: certificacao.funcionario_nome
    });
    
    return c.json({
      success: true,
      message: 'Certificado enviado e sincronizado com a pasta virtual',
      data: {
        certificacao_id: certificacao.certificacao_id || certificacao.id,
        anexo_id: anexoResult.meta?.last_row_id,
        arquivo_nome: file.name,
        arquivo_url: publicUrl,
        r2_path: caminhoArquivo,
        funcionario: certificacao.funcionario_nome,
        pasta_virtual_sincronizado: true
      }
    });
    
  } catch (error) {
    console.error('💥 Erro no upload do certificado:', error);
    return c.json({
      success: false,
      error: `Erro no upload: ${error instanceof Error ? error.message : 'Erro desconhecido'}`
    }, 500);
  }
});

// ✅ ENDPOINT DE DOWNLOAD DE CERTIFICADO CORRIGIDO  
app.get('/:id/download-certificado', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const certificacaoId = c.req.param('id');
    console.log(`⬇️ Download certificado para: ${certificacaoId}`);
    
    // Buscar certificação com arquivo
    const certificacao = await c.env.DB.prepare(`
      SELECT 
        c.id,
        c.certificacao_id,
        c.certificado_url,
        a.url_arquivo,
        a.nome_arquivo,
        a.tipo_arquivo,
        f.nome as funcionario_nome,
        f.matricula
      FROM historico_certificacoes_v2 c
      JOIN funcionarios f ON c.funcionario_id = f.id
      LEFT JOIN certificado_anexos_v2 a ON c.id = a.historico_id
      WHERE c.id = ? AND c.deleted_at IS NULL
      ORDER BY a.created_at DESC
      LIMIT 1
    `).bind(certificacaoId).first();
    
    if (!certificacao) {
      return c.json({ 
        success: false, 
        error: 'Certificação não encontrada' 
      }, 404);
    }
    
    const arquivoUrl = certificacao.url_arquivo || certificacao.certificado_url;
    
    if (!arquivoUrl) {
      return c.json({ 
        success: false, 
        error: 'Nenhum certificado foi enviado para esta certificação' 
      }, 404);
    }
    
    console.log(`📄 Buscando arquivo: ${arquivoUrl}`);
    
    // ✅ SE FOR URL R2, BUSCAR DIRETAMENTE DO BUCKET
    if (arquivoUrl.includes('certificados/')) {
      const r2Path = arquivoUrl.split('/').slice(-3).join('/'); // certificados/matricula/arquivo.pdf
      console.log(`📦 Buscando no R2: ${r2Path}`);
      
      const objeto = await c.env.R2_BUCKET.get(r2Path);
      
      if (!objeto) {
        console.error(`❌ Arquivo não encontrado no R2: ${r2Path}`);
        return c.json({ 
          success: false, 
          error: 'Arquivo de certificado não encontrado no armazenamento' 
        }, 404);
      }
      
      console.log(`✅ Arquivo encontrado no R2, preparando download...`);
      
      // ✅ RETORNAR ARQUIVO REAL
      const headers = new Headers();
      headers.set('Content-Type', certificacao.tipo_arquivo || 'application/pdf');
      headers.set('Content-Disposition', `attachment; filename="${certificacao.nome_arquivo || 'certificado.pdf'}"`);
      headers.set('Cache-Control', 'public, max-age=3600');
      
      await logAudit(c, 'DOWNLOAD', 'certificado_anexos_v2', certificacaoId);
      
      return new Response(objeto.body, {
        status: 200,
        headers: headers
      });
    }
    
    // ✅ SE FOR URL PÚBLICA, REDIRECIONAR
    console.log(`🔗 Redirecionando para URL: ${arquivoUrl}`);
    await logAudit(c, 'DOWNLOAD', 'certificado_anexos_v2', certificacaoId);
    return c.redirect(arquivoUrl);
    
  } catch (error) {
    console.error('💥 Erro no download do certificado:', error);
    return c.json({
      success: false,
      error: `Erro no download: ${error instanceof Error ? error.message : 'Erro desconhecido'}`
    }, 500);
  }
});

export default app;
