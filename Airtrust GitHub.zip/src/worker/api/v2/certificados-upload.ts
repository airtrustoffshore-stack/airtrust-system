import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

interface Env {
  DB: any;
}

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// Função para testar autenticação GitHub
const testGitHubAuth = async (): Promise<boolean> => {
  try {
    console.log('🔐 Testando autenticação GitHub...');
    const response = await fetch('https://api.github.com/user', {
      headers: {
        'Authorization': 'Bearer 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',
        'User-Agent': 'AirTrust/1.0'
      }
    });
    
    console.log('🔐 Auth test:', response.status, response.ok);
    
    if (response.ok) {
      const userData = await response.json() as { login?: string };
      console.log('👤 User:', userData.login || 'NO_LOGIN');
      return true;
    } else {
      const errorText = await response.text();
      console.error('❌ Auth error response:', errorText);
      return false;
    }
  } catch (error) {
    console.error('❌ Auth error:', error);
    return false;
  }
};

// Função para testar acesso ao repositório
const testRepoAccess = async (): Promise<boolean> => {
  try {
    console.log('📁 Testando acesso ao repositório...');
    const response = await fetch('https://api.github.com/repos/airtrustoffshore-stack/airtrust-storage', {
      headers: {
        'Authorization': 'Bearer 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',
        'User-Agent': 'AirTrust/1.0'
      }
    });
    
    console.log('📁 Repo test:', response.status, response.ok);
    
    if (response.ok) {
      const repoData = await response.json() as { 
        full_name?: string; 
        permissions?: { push?: boolean; admin?: boolean } 
      };
      console.log('📊 Repo:', repoData.full_name || 'NO_FULLNAME');
      console.log('🔓 Permissions:', {
        push: repoData.permissions?.push || false,
        admin: repoData.permissions?.admin || false
      });
      return true;
    } else {
      const errorText = await response.text();
      console.error('❌ Repo error response:', errorText);
      return false;
    }
  } catch (error) {
    console.error('❌ Repo error:', error);
    return false;
  }
};

// Função DIAGNOSTICADA para upload GitHub
const uploadToGitHub = async (file: File, filename: string): Promise<string> => {
  try {
    console.log('🔄 Iniciando upload GitHub DIAGNÓSTICO para:', filename);
    console.log('📁 File size:', file.size, 'bytes');
    console.log('📁 File type:', file.type);
    
    // CONVERSÃO BASE64 COM LOGS DETALHADOS
    console.log('📦 Convertendo para ArrayBuffer...');
    const arrayBuffer = await file.arrayBuffer();
    console.log('📦 ArrayBuffer length:', arrayBuffer.byteLength);
    
    console.log('🔢 Criando Uint8Array...');
    const uint8Array = new Uint8Array(arrayBuffer);
    console.log('🔢 Uint8Array length:', uint8Array.length);
    
    console.log('🔤 Convertendo para binary string...');
    let binaryString = '';
    for (let i = 0; i < uint8Array.length; i++) {
      binaryString += String.fromCharCode(uint8Array[i]);
    }
    console.log('🔤 Binary string length:', binaryString.length);
    
    console.log('📋 Convertendo para base64...');
    const base64Content = btoa(binaryString);
    console.log('📋 Base64 length:', base64Content.length);
    
    // GitHub API config com logs
    const githubUrl = `https://api.github.com/repos/airtrustoffshore-stack/airtrust-storage/contents/certificados/${filename}`;
    const githubToken = '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';
    
    console.log('🌐 Request URL:', githubUrl);
    console.log('🔑 Token length:', githubToken.length);
    
    // Payload com logs
    const payload = {
      message: `Upload ${filename}`,
      content: base64Content,
      branch: 'main'
    };
    
    console.log('📤 Payload size:', JSON.stringify(payload).length, 'chars');
    console.log('📤 Sending payload...');
    
    // Request com logs detalhados
    const response = await fetch(githubUrl, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${githubToken}`,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json',
        'User-Agent': 'AirTrust/1.0',
        'X-GitHub-Api-Version': '2022-11-28'
      },
      body: JSON.stringify(payload)
    });
    
    console.log('📡 Response status:', response.status, response.statusText);
    console.log('📡 Response ok:', response.ok);
    console.log('📡 Response headers:', 'Headers available');
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ GitHub error response:', errorText);
      console.error('❌ Full error details:', {
        status: response.status,
        statusText: response.statusText,
        url: githubUrl,
        fileSize: file.size,
        base64Size: base64Content.length
      });
      throw new Error(`GitHub API: ${response.status} - ${errorText}`);
    }
    
    const result = await response.json() as { 
      content?: { download_url?: string }; 
      download_url?: string;
      [key: string]: any;
    };
    console.log('✅ GitHub result keys:', Object.keys(result));
    console.log('✅ GitHub result.content keys:', result.content ? Object.keys(result.content) : 'NO_CONTENT');
    console.log('✅ Download URL from content:', result.content?.download_url || 'NO_CONTENT_DOWNLOAD_URL');
    console.log('✅ Direct download URL:', result.download_url || 'NO_DIRECT_DOWNLOAD_URL');
    
    const finalUrl = result.content?.download_url || result.download_url;
    console.log('✅ Final URL returned:', finalUrl);
    
    if (!finalUrl) {
      console.error('❌ NO DOWNLOAD URL FOUND in result:', JSON.stringify(result, null, 2));
      throw new Error('GitHub API returned success but no download URL found');
    }
    
    return finalUrl;
    
  } catch (error) {
    console.error('💥 Upload GitHub error details:', {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined,
      filename,
      fileSize: file.size
    });
    throw error;
  }
};

// Função para deletar do GitHub
const deleteFromGitHub = async (githubUrl: string): Promise<void> => {
  try {
    console.log('🗑️ Deletando do GitHub:', githubUrl);
    
    const githubToken = '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';
    
    // Extrair filename da URL
    const urlParts = githubUrl.split('/');
    const filename = urlParts[urlParts.length - 1];
    const apiUrl = `https://api.github.com/repos/airtrustoffshore-stack/airtrust-storage/contents/certificados/${filename}`;
    
    console.log('🔍 Buscando SHA do arquivo:', filename);
    
    // Obter SHA do arquivo
    const getResponse = await fetch(apiUrl, {
      headers: {
        'Authorization': `Bearer ${githubToken}`,
        'Accept': 'application/vnd.github+json',
        'User-Agent': 'AirTrust/1.0',
        'X-GitHub-Api-Version': '2022-11-28'
      }
    });
    
    if (!getResponse.ok) {
      console.warn('⚠️ Arquivo não encontrado para deleção:', filename);
      return;
    }
    
    const fileInfo = await getResponse.json() as { sha: string };
    console.log('📋 SHA obtido:', fileInfo.sha);
    
    // Deletar arquivo
    const deleteResponse = await fetch(apiUrl, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${githubToken}`,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json',
        'User-Agent': 'AirTrust/1.0',
        'X-GitHub-Api-Version': '2022-11-28'
      },
      body: JSON.stringify({
        message: `Delete certificado ${filename}`,
        sha: fileInfo.sha,
        branch: 'main'
      })
    });
    
    if (!deleteResponse.ok) {
      const error = await deleteResponse.text();
      console.error('❌ Erro ao deletar:', error);
    } else {
      console.log('✅ Arquivo removido do GitHub');
    }
    
  } catch (error) {
    console.error('💥 Erro na exclusão GitHub:', error);
  }
};

// Função de validação robusta para evitar undefined
const validateFieldsForDB = (historico_id: string, file: File, githubUrl: string) => {
  console.log('🔍 VALIDANDO CAMPOS PARA DB:');
  console.log('historico_id:', historico_id, typeof historico_id);
  console.log('file.name:', file.name, typeof file.name);
  console.log('file.type:', file.type, typeof file.type);
  console.log('file.size:', file.size, typeof file.size);
  console.log('githubUrl:', githubUrl, typeof githubUrl);
  
  // Validar histórico ID
  if (!historico_id || historico_id === 'undefined') {
    throw new Error('historico_id é obrigatório e não pode ser undefined');
  }
  
  // Validar nome do arquivo
  const nome_arquivo = file.name || 'documento_sem_nome.pdf';
  if (!nome_arquivo || nome_arquivo === 'undefined') {
    throw new Error('nome_arquivo é obrigatório');
  }
  
  // Validar URL GitHub
  if (!githubUrl || githubUrl === 'undefined') {
    throw new Error('arquivo_github_url é obrigatório');
  }
  
  // Validar tipo de arquivo
  const tipo_arquivo = file.type || 'application/octet-stream';
  
  // Validar tamanho
  const tamanho_bytes = file.size || 0;
  
  console.log('✅ CAMPOS VALIDADOS:', {
    historico_id: String(historico_id),
    nome_arquivo: String(nome_arquivo),
    arquivo_github_url: String(githubUrl),
    tipo_arquivo: String(tipo_arquivo),
    tamanho_bytes: Number(tamanho_bytes)
  });
  
  return {
    historico_id: String(historico_id),
    nome_arquivo: String(nome_arquivo),
    arquivo_github_url: String(githubUrl),
    tipo_arquivo: String(tipo_arquivo),
    tamanho_bytes: Number(tamanho_bytes)
  };
};

// POST /api/v2/certificados-upload - Upload de certificados
app.post('/', requirePermission('treinamentos', 'CREATE'), async (c) => {
  try {
    console.log('📥 Upload request recebido');
    
    // 🧪 TESTES DE DIAGNÓSTICO GITHUB
    console.log('🧪 Testando GitHub...');
    const authOk = await testGitHubAuth();
    const repoOk = await testRepoAccess();
    
    console.log('✅ Auth:', authOk, 'Repo:', repoOk);
    
    if (!authOk || !repoOk) {
      console.error('❌ GitHub access failed - Auth:', authOk, 'Repo:', repoOk);
      return c.json({
        success: false,
        error: 'GitHub access failed',
        details: {
          auth_test: authOk,
          repo_test: repoOk
        }
      }, 500);
    }
    
    const formData = await c.req.formData();
    const file = formData.get('arquivo') as File;
    const historico_id = formData.get('historico_id') as string;

    console.log('🔍 DADOS BRUTOS RECEBIDOS:', {
      file: !!file,
      file_name: file?.name,
      file_size: file?.size,
      file_type: file?.type,
      historico_id: historico_id,
      historico_id_type: typeof historico_id
    });

    if (!file || !historico_id) {
      console.error('❌ Dados obrigatórios faltando');
      return c.json({ error: 'Dados obrigatórios (arquivo e historico_id)' }, 400);
    }

    console.log('📋 Upload details:', {
      filename: file.name,
      size: file.size,
      type: file.type,
      historico_id
    });

    // Sanitizar filename
    const timestamp = Date.now();
    const sanitizedName = (file.name || 'documento').replace(/[^a-zA-Z0-9.-]/g, '_');
    const filename = `cert_${historico_id}_${timestamp}_${sanitizedName}`;
    
    console.log('🔄 Nome sanitizado:', filename);
    
    // Upload GitHub - FUNÇÃO CORRIGIDA
    const githubUrl = await uploadToGitHub(file, filename);
    
    console.log('💾 URL GitHub obtida:', githubUrl);
    
    // VALIDAÇÃO ROBUSTA - EVITAR UNDEFINED
    const validatedFields = validateFieldsForDB(historico_id, file, githubUrl);
    
    console.log('💾 Salvando no banco de dados com campos validados...');
    
    // Salvar no banco com TODAS as colunas obrigatórias (incluindo url_arquivo)
    const dbResult = await c.env.DB.prepare(`
      INSERT INTO certificado_anexos_v2 (historico_id, nome_arquivo, url_arquivo, arquivo_github_url, tipo_arquivo, tamanho_bytes, created_at) 
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      validatedFields.historico_id,
      validatedFields.nome_arquivo,
      validatedFields.arquivo_github_url, // url_arquivo
      validatedFields.arquivo_github_url, // arquivo_github_url
      validatedFields.tipo_arquivo,
      validatedFields.tamanho_bytes,
      new Date().toISOString()
    ).run();
    
    console.log('✅ RESULTADO DB:', dbResult);

    console.log('📝 Log auditoria...');
    
    await logAudit(c, 'UPLOAD', 'certificado_anexos_v2', dbResult.meta?.last_row_id?.toString(), undefined, {
      historico_id: validatedFields.historico_id,
      filename,
      github_url: validatedFields.arquivo_github_url,
      file_size: validatedFields.tamanho_bytes,
      db_insert_id: dbResult.meta?.last_row_id
    });

    // ✅ SINCRONIZAÇÃO AUTOMÁTICA COM PASTA VIRTUAL
    console.log('🔄 Iniciando sincronização automática com pasta virtual...');
    
    try {
      const { sincronizarCertificadoParaPastaVirtual } = await import('../../services/certificado-pasta-virtual-sync');
      
      const syncResult = await sincronizarCertificadoParaPastaVirtual(
        dbResult.meta?.last_row_id as number,
        c.env.DB,
        null // GitHub-based, no R2
      );
      
      if (syncResult.success) {
        console.log(`✅ Sincronização automática concluída: ${syncResult.action}`);
      } else {
        console.warn(`⚠️ Erro na sincronização automática: ${syncResult.error}`);
      }
      
    } catch (syncError) {
      console.error(`💥 Erro na sincronização automática:`, syncError);
      // Não falhar o upload por erro na sincronização
    }
    
    console.log('✅ Upload completo com sucesso!');
    
    return c.json({
      success: true,
      data: {
        id: dbResult.meta?.last_row_id,
        url_arquivo: validatedFields.arquivo_github_url,
        nome_arquivo: validatedFields.nome_arquivo,
        historico_id: parseInt(validatedFields.historico_id),
        tamanho_bytes: validatedFields.tamanho_bytes
      },
      message: 'Certificado salvo no GitHub, banco e sincronizado com pasta virtual'
    });

  } catch (error) {
    console.error('🔥 ERRO DETALHADO no endpoint upload:', {
      message: error instanceof Error ? error.message : 'Erro desconhecido',
      stack: error instanceof Error ? error.stack : undefined,
      error_type: typeof error,
      error_constructor: error?.constructor?.name
    });
    
    await logAudit(c, 'UPLOAD', 'certificado_anexos_v2', undefined, undefined, {
      error_message: error instanceof Error ? error.message : 'Erro desconhecido',
      error_type: typeof error
    }, 'ERROR');
    
    return c.json({ 
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido no upload',
      details: error instanceof Error ? error.stack : undefined
    }, 500);
  }
});

// GET /api/v2/certificados-upload/:historicoId - Listar arquivos de uma certificação
app.get('/:historicoId', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const historicoId = c.req.param('historicoId');
    const db = c.env.DB;

    const arquivos = await db.prepare(`
      SELECT id, nome_arquivo, url_arquivo, arquivo_github_url, tipo_arquivo, tamanho_bytes, created_at
      FROM certificado_anexos_v2
      WHERE historico_id = ?
      ORDER BY created_at DESC
    `).bind(historicoId).all();

    await logAudit(c, 'LIST', 'certificado_anexos_v2', historicoId);

    return c.json({
      success: true,
      data: arquivos.results,
      total: arquivos.results?.length || 0,
      storage_method: 'GITHUB_STORAGE_SAFE'
    });

  } catch (error) {
    console.error('Error listing certificate files:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// DELETE /api/v2/certificados-upload/:id - Deletar arquivo
app.delete('/:id', requirePermission('treinamentos', 'DELETE'), async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;

    console.log('🗑️ Deletando certificado ID:', id);

    const arquivo = await db.prepare(
      'SELECT * FROM certificado_anexos_v2 WHERE id = ?'
    ).bind(id).first();

    if (!arquivo) {
      return c.json({ error: 'Arquivo não encontrado' }, 404);
    }

    console.log('📋 Arquivo encontrado:', arquivo.nome_arquivo);

    // Deletar do GitHub se tiver URL
    if (arquivo.arquivo_github_url) {
      await deleteFromGitHub(arquivo.arquivo_github_url);
    }

    // ✅ REMOVER DA PASTA VIRTUAL AUTOMATICAMENTE
    console.log('🗑️ Removendo certificado da pasta virtual...');
    
    try {
      const { removerCertificadoDaPastaVirtual } = await import('../../services/certificado-pasta-virtual-sync');
      
      const removeResult = await removerCertificadoDaPastaVirtual(
        parseInt(id),
        arquivo.historico_id,
        0, // Será buscado automaticamente
        c.env.DB
      );
      
      if (removeResult.success) {
        console.log(`✅ Removido da pasta virtual: ${removeResult.action}`);
      } else {
        console.warn(`⚠️ Erro ao remover da pasta virtual: ${removeResult.error}`);
      }
      
    } catch (removeError) {
      console.error(`💥 Erro ao remover da pasta virtual:`, removeError);
    }
    
    // Deletar do banco
    await db.prepare(
      'DELETE FROM certificado_anexos_v2 WHERE id = ?'
    ).bind(id).run();

    await logAudit(c, 'DELETE', 'certificado_anexos_v2', id, arquivo, {
      github_url: arquivo.arquivo_github_url,
      deleted_from_github: !!arquivo.arquivo_github_url,
      pasta_virtual_sync: true
    });

    console.log('✅ Certificado deletado com sucesso');

    return c.json({
      success: true,
      message: 'Certificado removido do GitHub, banco de dados e pasta virtual'
    });

  } catch (error) {
    console.error('❌ Erro ao deletar certificado:', error);
    await logAudit(c, 'DELETE', 'certificado_anexos_v2', undefined, undefined, undefined, 'ERROR');
    
    return c.json({ 
      success: false,
      error: 'Erro interno do servidor' 
    }, 500);
  }
});

export default app;
