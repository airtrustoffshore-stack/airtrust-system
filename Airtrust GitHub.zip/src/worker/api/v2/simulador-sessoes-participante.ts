import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';


const app = new Hono<{ Bindings: Env }>();

/**
 * ⚠️ PADRÃO BRASILEIRO OBRIGATÓRIO - AIRTRUST ⚠️
 * 
 * API para buscar sessões de participantes individuais
 */

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// GET /api/v2/simulador/sessoes-participante/:colaborador_id/:treinamento_id
app.get('/sessoes-participante/:colaborador_id/:treinamento_id', 
  requirePermission('simuladores', 'READ'), 
  async (c) => {
    try {
      const colaboradorId = parseInt(c.req.param('colaborador_id'));
      const treinamentoId = parseInt(c.req.param('treinamento_id'));
      const db = c.env.DB;
      
      const stmt = db.prepare(`
        SELECT 
          sp.*,
          ss.data_inicio,
          ss.data_fim,
          ss.sessao_uuid,
          st.nome_sessao as template_nome,
          s.nome as simulador_nome
        FROM sessao_participantes sp
        JOIN sessoes_simulador ss ON sp.sessao_id = ss.id
        LEFT JOIN sessoes_template st ON sp.template_sessao_id = st.id
        LEFT JOIN simuladores s ON ss.simulador_id = s.id
        WHERE sp.colaborador_id = ? AND sp.treinamento_id = ?
        ORDER BY sp.sessao_numero, ss.data_inicio
      `);
      
      const result = await stmt.bind(colaboradorId, treinamentoId).all();
      const sessoes = result.results || [];
      
      return c.json({
        success: true,
        data: sessoes,
        total: sessoes.length
      });
    } catch (error) {
      console.error('Erro ao buscar sessões do participante:', error);
      return c.json({ error: 'Erro interno do servidor' }, 500);
    }
  }
);

export default app;
