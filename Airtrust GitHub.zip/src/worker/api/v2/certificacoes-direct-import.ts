import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';
import { gerarProximoIdCertificacao, normalizarMatricula } from '../../../shared/utils/certificacao-utils';
import { sincronizarLoteCertificados } from '../../services/pasta-virtual-sync';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ MAPEAMENTO FLEXÍVEL DE CAMPOS CSV
const mapearCamposCSV = (obj: Record<string, string>) => {
  const normalizar = (str: string) => {
    return str.toLowerCase()
      .replace(/[áàâãäå]/g, 'a')
      .replace(/[éèêë]/g, 'e')
      .replace(/[íìîï]/g, 'i')
      .replace(/[óòôõö]/g, 'o')
      .replace(/[úùûü]/g, 'u')
      .replace(/[ç]/g, 'c')
      .replace(/[^a-z0-9]/g, '');
  };

  const keys = Object.keys(obj).map(k => normalizar(k));
  const valores = Object.values(obj);
  
  // Mapear campos flexivelmente
  const result: any = {};
  
  keys.forEach((key, index) => {
    const valor = valores[index];
    
    // Matrícula
    if (['matricula', 'funcionariomatricula', 'mat'].includes(key)) {
      result.funcionario_matricula = valor;
    }
    // Treinamento
    if (['treinamento', 'treinamentocodigo', 'codigo', 'codigotreinamento'].includes(key)) {
      result.treinamento_codigo = valor;
    }
    // Data conclusão
    if (['dataconclusao', 'conclusao', 'data', 'datarealizacao'].includes(key)) {
      result.data_conclusao = valor;
    }
    // Data vencimento
    if (['datavencimento', 'vencimento', 'validade', 'expiracao'].includes(key)) {
      result.data_vencimento = valor;
    }
    // Instrutor
    if (['instrutor', 'professor', 'responsavel'].includes(key)) {
      result.instrutor = valor;
    }
    // Nota
    if (['nota', 'notafinal', 'pontuacao', 'resultado'].includes(key)) {
      result.nota_final = valor;
    }
    // Observações
    if (['observacoes', 'obs', 'comentarios', 'notas'].includes(key)) {
      result.observacoes = valor;
    }
  });
  
  return result;
};

// ✅ BUSCAR FUNCIONÁRIO SEM AUTO-CRIAÇÃO
const buscarFuncionario = async (matricula: string, db: any) => {
  const matriculaNormalizada = normalizarMatricula(matricula);
  
  const funcionario = await db.prepare(
    'SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL'
  ).bind(matriculaNormalizada).first();
  
  if (!funcionario) {
    throw new Error(`Funcionário com matrícula '${matriculaNormalizada}' não encontrado no sistema.`);
  }
  
  return funcionario;
};

// ✅ BUSCAR OU CRIAR TREINAMENTO
const buscarOuCriarTreinamento = async (codigo: string, db: any) => {
  let treinamento = await db.prepare(
    'SELECT id, codigo, nome FROM catalogo_treinamentos_v2 WHERE codigo = ? AND deleted_at IS NULL'
  ).bind(codigo).first();
  
  if (!treinamento) {
    const nomeTrainamento = `Treinamento ${codigo}`;
    const result = await db.prepare(`
      INSERT INTO catalogo_treinamentos_v2 (
        codigo, nome, categoria, ativo, created_at, updated_at
      ) VALUES (?, ?, 'IMPORTADO_CSV', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(codigo, nomeTrainamento).run();
    
    if (result.success && result.meta?.last_row_id) {
      treinamento = {
        id: result.meta.last_row_id,
        codigo: codigo,
        nome: nomeTrainamento,
        novo: true
      };
    } else {
      throw new Error(`Erro ao criar treinamento ${codigo}`);
    }
  } else {
    treinamento.novo = false;
  }
  
  return treinamento;
};

// ✅ ENDPOINT PRINCIPAL PARA IMPORTAÇÃO DIRETA
app.post('/certificacoes-direct', requirePermission('treinamentos', 'CREATE'), async (c) => {
  const startTime = Date.now();
  let batchId = `batch_${Date.now()}`;
  
  try {
    console.log('🚀 [DIRECT-IMPORT] Iniciando importação direta de certificações');
    
    const body = await c.req.json();
    const csvData = body.data;
    
    if (!Array.isArray(csvData) || csvData.length === 0) {
      return c.json({
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        rows_total: 0,
        rows_processed: 0,
        rows_failed: 1,
        rows_skipped: 0,
        duplicates_detected: 0,
        errors: [{
          row: 0,
          field: 'data',
          message: 'Array de dados CSV é obrigatório',
          error_type: 'VALIDATION',
          severity: 'CRITICAL'
        }],
        warnings: [],
        summary: 'Dados não fornecidos'
      }, 400);
    }

    console.log(`📊 [DIRECT-IMPORT] Processando ${csvData.length} linhas de dados`);

    const db = c.env.DB;
    const r2 = (c.env as any).BUCKET || null;
    
    let linhasProcessadas = 0;
    let certificacoesCriadas = 0;
    let treinamentosCriados = 0;
    let duplicatasDetectadas = 0;
    const errors: any[] = [];
    const warnings: any[] = [];
    const sucessos: string[] = [];
    const novosTreinamentos: string[] = [];
    const certificacoesParaSincronizar: any[] = [];

    // ✅ PROCESSAR TODAS AS LINHAS (NÃO APENAS PREVIEW)
    for (let i = 0; i < csvData.length; i++) {
      try {
        const rowData = mapearCamposCSV(csvData[i]);
        
        // Validação obrigatória
        if (!rowData.funcionario_matricula || !rowData.treinamento_codigo || !rowData.data_conclusao) {
          errors.push({
            row: i + 1,
            field: 'campos_obrigatorios',
            message: 'Campos obrigatórios: funcionario_matricula, treinamento_codigo, data_conclusao',
            error_type: 'VALIDATION',
            severity: 'HIGH'
          });
          continue;
        }

        // Buscar funcionário
        const funcionario = await buscarFuncionario(rowData.funcionario_matricula, db);
        
        // Buscar ou criar treinamento  
        const treinamento = await buscarOuCriarTreinamento(rowData.treinamento_codigo, db);
        if (treinamento.novo) {
          treinamentosCriados++;
          novosTreinamentos.push(`${treinamento.nome} (${treinamento.codigo})`);
        }

        // Verificar duplicata
        const existente = await db.prepare(`
          SELECT id FROM historico_certificacoes_v2 
          WHERE funcionario_id = ? AND treinamento_id = ? 
          AND data_conclusao = ? AND status = 'ATIVO' AND deleted_at IS NULL
        `).bind(funcionario.id, treinamento.id, rowData.data_conclusao).first();

        if (existente) {
          duplicatasDetectadas++;
          warnings.push({
            row: i + 1,
            field: 'duplicata',
            message: `Certificação já existe para ${funcionario.nome} em ${treinamento.nome}`,
            warning_type: 'DUPLICATE'
          });
          continue;
        }

        // Gerar ID único
        const certificacaoId = await gerarProximoIdCertificacao(
          funcionario.id,
          treinamento.id,
          rowData.data_conclusao,
          db
        );

        // Criar certificação
        const now = new Date().toISOString();
        const insertResult = await db.prepare(`
          INSERT INTO historico_certificacoes_v2 
          (funcionario_id, treinamento_id, data_conclusao, 
           data_vencimento, instrutor, nota_final, observacoes, status, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, 'ATIVO', ?, ?)
        `).bind(
          funcionario.id,
          treinamento.id,
          rowData.data_conclusao,
          rowData.data_vencimento || null,
          rowData.instrutor || null,
          rowData.nota_final ? parseFloat(rowData.nota_final) : null,
          rowData.observacoes || null,
          now,
          now
        ).run();

        if (insertResult.success && insertResult.meta?.last_row_id) {
          const novoHistoricoId = insertResult.meta.last_row_id;
          
          certificacoesCriadas++;
          linhasProcessadas++;
          sucessos.push(`${certificacaoId}: ${funcionario.nome} certificado em ${treinamento.nome}`);
          
          // ✅ PREPARAR PARA SINCRONIZAÇÃO COM PASTA VIRTUAL
          certificacoesParaSincronizar.push({
            id: novoHistoricoId,
            funcionario_id: funcionario.id,
            funcionario_nome: funcionario.nome,
            funcionario_matricula: funcionario.matricula,
            treinamento_id: treinamento.id,
            treinamento_codigo: treinamento.codigo,
            treinamento_nome: treinamento.nome,
            data_conclusao: rowData.data_conclusao,
            data_vencimento: rowData.data_vencimento
          });
        }

      } catch (error) {
        console.error(`❌ [DIRECT-IMPORT] Erro na linha ${i + 1}:`, error);
        errors.push({
          row: i + 1,
          field: 'processamento',
          message: error instanceof Error ? error.message : 'Erro desconhecido',
          error_type: 'PROCESSING',
          severity: 'MEDIUM'
        });
      }
    }

    // ✅ SINCRONIZAÇÃO EM LOTE COM PASTA VIRTUAL
    let resultadoSincronizacao = null;
    if (certificacoesParaSincronizar.length > 0) {
      console.log(`📁 [DIRECT-IMPORT] Sincronizando ${certificacoesParaSincronizar.length} certificações com Pasta Virtual`);
      
      try {
        resultadoSincronizacao = await sincronizarLoteCertificados(
          certificacoesParaSincronizar,
          db,
          r2,
          5 // batch size
        );
        console.log('✅ [DIRECT-IMPORT] Sincronização completa:', resultadoSincronizacao.resumoFinal);
      } catch (syncError) {
        console.error('⚠️ [DIRECT-IMPORT] Erro na sincronização:', syncError);
        warnings.push({
          row: 0,
          field: 'sincronizacao',
          message: `Erro na sincronização com Pasta Virtual: ${syncError instanceof Error ? syncError.message : 'Erro desconhecido'}`,
          warning_type: 'SYNC_FAILED'
        });
      }
    }

    // Auditoria detalhada
    await logAudit(c, 'IMPORT_CERTIFICACOES_DIRECT', 'historico_certificacoes_v2', batchId, undefined, {
      linhas_total: csvData.length,
      linhas_processadas: linhasProcessadas,
      certificacoes_criadas: certificacoesCriadas,
      treinamentos_criados: treinamentosCriados,
      duplicatas_detectadas: duplicatasDetectadas,
      erros_count: errors.length,
      sincronizacao_pasta_virtual: resultadoSincronizacao?.resumoFinal || null
    });

    const processingTime = Date.now() - startTime;
    console.log(`🎯 [DIRECT-IMPORT] Finalizado - ${certificacoesCriadas} certificações criadas, ${treinamentosCriados} treinamentos criados, ${errors.length} erros (${processingTime}ms)`);

    // ✅ RESPOSTA DETALHADA
    return c.json({
      success: true,
      batch_id: batchId,
      processing_time_ms: processingTime,
      rows_total: csvData.length,
      rows_processed: linhasProcessadas,
      rows_failed: errors.length,
      rows_skipped: duplicatasDetectadas,
      duplicates_detected: duplicatasDetectadas,
      new_catalogs_created: treinamentosCriados,
      errors: errors,
      warnings: warnings,
      summary: `${certificacoesCriadas} certificações importadas com sucesso! ${treinamentosCriados} treinamentos criados automaticamente.`,
      
      // Detalhes específicos para compatibilidade com frontend
      importadas_com_sucesso: certificacoesCriadas,
      treinamentos_criados: treinamentosCriados,
      erros: errors.length,
      detalhes_erros: errors.map(e => ({ linha: e.row, erro: e.message })),
      duracao_ms: processingTime,
      resumo: `${certificacoesCriadas} certificações importadas com sucesso! ${treinamentosCriados} treinamentos criados automaticamente.`,
      
      // Informações de sincronização
      pasta_virtual_sync: resultadoSincronizacao ? {
        sincronizados: resultadoSincronizacao.sincronizados,
        erros_sync: resultadoSincronizacao.erros,
        ja_existiam: resultadoSincronizacao.jaExistiam,
        tempo_total_segundos: resultadoSincronizacao.resumoFinal?.tempo_total_segundos || 0
      } : null,
      
      // Entidades criadas
      novas_entidades: {
        treinamentos: novosTreinamentos
      }
    });

  } catch (error) {
    console.error('💥 [DIRECT-IMPORT] Erro crítico:', error);
    return c.json({
      success: false,
      batch_id: batchId,
      processing_time_ms: Date.now() - startTime,
      rows_total: 0,
      rows_processed: 0,
      rows_failed: 1,
      rows_skipped: 0,
      duplicates_detected: 0,
      errors: [{
        row: 0,
        field: 'system',
        message: error instanceof Error ? error.message : 'Erro interno do servidor',
        error_type: 'SYSTEM',
        severity: 'CRITICAL'
      }],
      warnings: [],
      summary: 'Falha crítica no sistema',
      
      // Compatibilidade com frontend
      importadas_com_sucesso: 0,
      erros: 1,
      detalhes_erros: [{ linha: 0, erro: error instanceof Error ? error.message : 'Erro interno' }],
      duracao_ms: Date.now() - startTime,
      resumo: 'Falha crítica no sistema'
    }, 500);
  }
});

export default app;
