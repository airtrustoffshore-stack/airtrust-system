import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Schema de validação para Aeronave
const AeronaveSchema = z.object({
  codigo: z.string().min(1).max(10),
  nome: z.string().min(1).max(100),
  fabricante: z.string().optional(),
  categoria: z.string().optional(),
  ativo: z.boolean().default(true)
});

const AeronaveUpdateSchema = AeronaveSchema.partial();

// Aplicar middleware de autenticação a todas as rotas
app.use('*', authMiddleware);

// GET /api/v2/aeronaves - Listar todas as aeronaves
app.get('/', requirePermission('aeronaves', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT id, codigo, nome, fabricante, categoria, ativo, created_at, updated_at
      FROM aeronaves 
      ORDER BY codigo
    `);
    
    const result = await stmt.all();
    const aeronaves = result.results;

    await logAudit(c, 'LIST', 'aeronaves');
    
    return c.json({
      success: true,
      data: aeronaves,
      total: aeronaves?.length || 0
    });
  } catch (error) {
    console.error('Error listing aeronaves:', error);
    await logAudit(c, 'LIST', 'aeronaves', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/aeronaves/:id - Obter aeronave por ID
app.get('/:id', requirePermission('aeronaves', 'READ'), async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT id, codigo, nome, fabricante, categoria, ativo, created_at, updated_at
      FROM aeronaves 
      WHERE id = ?
    `);
    
    const aeronave = await stmt.bind(id).first();
    
    if (!aeronave) {
      return c.json({ error: 'Aeronave não encontrada' }, 404);
    }

    await logAudit(c, 'read', 'aeronaves', id);
    
    return c.json({
      success: true,
      data: aeronave
    });
  } catch (error) {
    console.error('Error getting aeronave:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/v2/aeronaves - Criar nova aeronave
app.post('/', requirePermission('aeronaves', 'CREATE'), zValidator('json', AeronaveSchema), async (c) => {
  try {
    const data = c.req.valid('json');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      INSERT INTO aeronaves (codigo, nome, fabricante, categoria, ativo) 
      VALUES (?, ?, ?, ?, ?)
    `);
    
    const result = await stmt.bind(
      data.codigo,
      data.nome,
      data.fabricante || null,
      data.categoria || null,
      data.ativo ? 1 : 0
    ).run();
    
    if (!result.success) {
      return c.json({ error: 'Erro ao criar aeronave' }, 400);
    }

    await logAudit(c, 'CREATE', 'aeronaves', result.meta.last_row_id?.toString(), undefined, data);
    
    return c.json({
      success: true,
      data: { id: result.meta.last_row_id, ...data },
      message: 'Aeronave criada com sucesso'
    }, 201);
  } catch (error) {
    console.error('Error creating aeronave:', error);
    await logAudit(c, 'CREATE', 'aeronaves', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// PUT /api/v2/aeronaves/:id - Atualizar aeronave
app.put('/:id', requirePermission('aeronaves', 'UPDATE'), zValidator('json', AeronaveUpdateSchema), async (c) => {
  try {
    const id = c.req.param('id');
    const data = c.req.valid('json');
    const db = c.env.DB;
    
    // Buscar dados anteriores para auditoria
    const oldData = await db.prepare(`
      SELECT * FROM aeronaves WHERE id = ?
    `).bind(id).first();
    
    if (!oldData) {
      return c.json({ error: 'Aeronave não encontrada' }, 404);
    }

    const updates = [];
    const values = [];
    
    Object.entries(data).forEach(([key, value]) => {
      if (value !== undefined) {
        updates.push(`${key} = ?`);
        values.push(key === 'ativo' ? (value ? 1 : 0) : value);
      }
    });
    
    updates.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);
    
    const stmt = db.prepare(`
      UPDATE aeronaves 
      SET ${updates.join(', ')}
      WHERE id = ?
    `);
    
    const result = await stmt.bind(...values).run();
    
    if (!result.success) {
      return c.json({ error: 'Aeronave não encontrada' }, 404);
    }

    await logAudit(c, 'UPDATE', 'aeronaves', id, oldData, data);
    
    return c.json({
      success: true,
      message: 'Aeronave atualizada com sucesso'
    });
  } catch (error) {
    console.error('Error updating aeronave:', error);
    await logAudit(c, 'UPDATE', 'aeronaves', c.req.param('id'), undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// DELETE /api/v2/aeronaves/:id - Deletar aeronave
app.delete('/:id', requirePermission('aeronaves', 'DELETE'), async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    // Buscar dados anteriores para auditoria
    const oldData = await db.prepare(`
      SELECT * FROM aeronaves WHERE id = ?
    `).bind(id).first();
    
    if (!oldData) {
      return c.json({ error: 'Aeronave não encontrada' }, 404);
    }

    const stmt = db.prepare(`
      DELETE FROM aeronaves WHERE id = ?
    `);
    
    const result = await stmt.bind(id).run();
    
    if (!result.success) {
      return c.json({ error: 'Aeronave não encontrada' }, 404);
    }

    await logAudit(c, 'DELETE', 'aeronaves', id, oldData, undefined);
    
    return c.json({
      success: true,
      message: 'Aeronave removida com sucesso'
    });
  } catch (error) {
    console.error('Error deleting aeronave:', error);
    await logAudit(c, 'DELETE', 'aeronaves', c.req.param('id'), undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default app;
