import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação a todas as rotas
app.use('*', authMiddleware);

// GET /api/v2/compliance - Relatório de compliance por funcionário
app.get('/', requirePermission('compliance', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const funcionario_id = c.req.query('funcionario_id');
    const status = c.req.query('status');
    
    let whereClause = '';
    const params = [];
    
    if (funcionario_id) {
      whereClause += ' AND cs.funcionario_id = ?';
      params.push(funcionario_id);
    }
    
    if (status) {
      whereClause += ' AND cs.status = ?';
      params.push(status);
    }
    
    const stmt = db.prepare(`
      SELECT cs.id, cs.funcionario_id, cs.treinamento_id, cs.status,
             cs.data_ultima_certificacao, cs.data_vencimento, cs.dias_para_vencimento,
             cs.historico_certificacao_id, cs.created_at, cs.updated_at,
             f.nome as funcionario_nome, f.funcao, f.base,
             t.codigo as treinamento_codigo, t.nome as treinamento_nome,
             t.categoria as treinamento_categoria
      FROM compliance_status_v2 cs
      JOIN funcionarios f ON cs.funcionario_id = f.id
      JOIN catalogo_treinamentos_v2 t ON cs.treinamento_id = t.id
      WHERE f.deleted_at IS NULL AND t.deleted_at IS NULL ${whereClause}
      ORDER BY cs.dias_para_vencimento ASC, f.nome
    `);
    
    const result = await stmt.bind(...params).all();
    const compliance = result.results;

    // Calcular estatísticas resumidas
    const stats = {
      total_registros: compliance?.length || 0,
      em_dia: compliance?.filter((c: any) => c.status === 'EM_DIA').length || 0,
      vencendo: compliance?.filter((c: any) => c.status === 'VENCENDO').length || 0,
      vencido: compliance?.filter((c: any) => c.status === 'VENCIDO').length || 0,
      pendente: compliance?.filter((c: any) => c.status === 'PENDENTE').length || 0
    };

    await logAudit(c, 'LIST', 'compliance_status_v2');
    
    return c.json({
      success: true,
      data: compliance,
      stats,
      total: compliance?.length || 0
    });
  } catch (error) {
    console.error('Error listing compliance:', error);
    await logAudit(c, 'LIST', 'compliance_status_v2', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// POST /api/v2/compliance/recalculate - Recalcular status de compliance
app.post('/recalculate', requirePermission('compliance', 'UPDATE'), async (c) => {
  try {
    // Importar o serviço de compliance
    const { ComplianceService } = await import('../../services/compliance');
    
    // Executar recálculo
    const result = await ComplianceService.recalculateAllCompliance(c);
    
    await logAudit(c, 'RECALCULATE', 'compliance_status_v2', undefined, undefined, { 
      processed: result.processed,
      updated: result.updated 
    });
    
    return c.json({
      success: true,
      message: 'Compliance recalculado com sucesso',
      data: result
    });
  } catch (error) {
    console.error('Error recalculating compliance:', error);
    await logAudit(c, 'RECALCULATE', 'compliance_status_v2', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/compliance/dashboard - Dashboard de compliance
app.get('/dashboard', requirePermission('compliance', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    // Estatísticas gerais
    const statsQuery = await db.prepare(`
      SELECT 
        COUNT(*) as total_funcionarios,
        SUM(CASE WHEN cs.status = 'EM_DIA' THEN 1 ELSE 0 END) as em_dia,
        SUM(CASE WHEN cs.status = 'VENCENDO' THEN 1 ELSE 0 END) as vencendo,
        SUM(CASE WHEN cs.status = 'VENCIDO' THEN 1 ELSE 0 END) as vencido,
        SUM(CASE WHEN cs.status = 'PENDENTE' THEN 1 ELSE 0 END) as pendente
      FROM (
        SELECT DISTINCT funcionario_id, 
               CASE 
                 WHEN MIN(CASE WHEN status = 'VENCIDO' THEN 1 ELSE 0 END) = 1 THEN 'VENCIDO'
                 WHEN MIN(CASE WHEN status = 'VENCENDO' THEN 1 ELSE 0 END) = 1 THEN 'VENCENDO'
                 WHEN MIN(CASE WHEN status = 'PENDENTE' THEN 1 ELSE 0 END) = 1 THEN 'PENDENTE'
                 ELSE 'EM_DIA'
               END as status
        FROM compliance_status_v2 
        GROUP BY funcionario_id
      ) cs
    `).first();
    
    // Top 10 vencimentos próximos
    const proximosVencimentos = await db.prepare(`
      SELECT f.nome as funcionario_nome, t.nome as treinamento_nome,
             cs.data_vencimento, cs.dias_para_vencimento
      FROM compliance_status_v2 cs
      JOIN funcionarios f ON cs.funcionario_id = f.id
      JOIN catalogo_treinamentos_v2 t ON cs.treinamento_id = t.id
      WHERE cs.status IN ('VENCENDO', 'VENCIDO') AND f.deleted_at IS NULL
      ORDER BY cs.dias_para_vencimento ASC
      LIMIT 10
    `).all();

    await logAudit(c, 'DASHBOARD', 'compliance_status_v2');
    
    return c.json({
      success: true,
      data: {
        stats: statsQuery,
        proximos_vencimentos: proximosVencimentos.results
      }
    });
  } catch (error) {
    console.error('Error getting compliance dashboard:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default app;
