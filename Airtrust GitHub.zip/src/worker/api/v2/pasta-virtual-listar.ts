import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

interface Env {
  DB: any;
}

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// API: LISTAR ESTRUTURA COMPLETA DE UM FUNCIONÁRIO
app.get('/listar/:funcionario_id', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const funcionarioId = parseInt(c.req.param('funcionario_id'));
    console.log(`📁 [LISTAR] Montando estrutura da pasta virtual para funcionário ID: ${funcionarioId}`);
    
    if (isNaN(funcionarioId)) {
      return c.json({ success: false, error: 'ID de funcionário inválido' }, 400);
    }
    
    // Verificar se funcionário existe
    const funcionario = await c.env.DB.prepare(`
      SELECT id, nome, matricula, funcao FROM funcionarios 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(funcionarioId).first();
    
    if (!funcionario) {
      return c.json({ success: false, error: 'Funcionário não encontrado' }, 404);
    }
    
    // Buscar certificações sincronizadas
    const certificacoes = await c.env.DB.prepare(`
      SELECT 
        pvsl.*,
        ct.nome as treinamento_nome,
        ct.categoria as treinamento_categoria,
        CASE 
          WHEN pvsl.data_vencimento < DATE('now') THEN 'VENCIDO'
          WHEN pvsl.data_vencimento <= DATE('now', '+30 days') THEN 'VENCENDO'
          ELSE 'VALIDO'
        END as status_validade
      FROM pasta_virtual_sync_log pvsl
      LEFT JOIN historico_certificacoes_v2 hc ON pvsl.historico_cert_id = hc.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE pvsl.funcionario_id = ? 
        AND pvsl.deleted_at IS NULL
        AND pvsl.status_sincronizacao = 'SINCRONIZADO'
      ORDER BY pvsl.data_conclusao DESC, pvsl.created_at DESC
    `).bind(funcionarioId).all();
    
    // Organizar em estrutura de árvore conforme solicitado
    const estruturaArvore = {
      id: `funcionario_${funcionarioId}`,
      name: `Pasta de ${funcionario.nome}`,
      type: 'folder' as const,
      children: [
        {
          id: `cert_folder_${funcionarioId}`,
          name: '📁 Certificações',
          type: 'folder' as const,
          children: [] as any[]
        },
        {
          id: `med_folder_${funcionarioId}`,
          name: '📁 Médicos',
          type: 'folder' as const,
          children: [] as any[]
        },
        {
          id: `doc_folder_${funcionarioId}`,
          name: '📁 Documentos Gerais',
          type: 'folder' as const,
          children: [] as any[]
        }
      ]
    };
    
    // Separar certificações por categoria
    let certificacoesTecnicas = 0;
    let documentosMedicos = 0;
    
    (certificacoes.results || []).forEach((cert: any) => {
      const categoria = cert.treinamento_categoria?.toLowerCase() || 'geral';
      
      let parentFolder;
      if (categoria.includes('medic') || categoria.includes('cma') || categoria.includes('aso')) {
        parentFolder = estruturaArvore.children[1]; // Médicos
        documentosMedicos++;
      } else if (categoria.includes('tecnic') || categoria.includes('operacional') || categoria.includes('treinamento')) {
        parentFolder = estruturaArvore.children[0]; // Certificações
        certificacoesTecnicas++;
      } else {
        parentFolder = estruturaArvore.children[2]; // Documentos Gerais
      }
      
      // Criar nó do arquivo
      const fileNode = {
        id: `cert_${cert.id}`,
        name: cert.nome_arquivo_auditavel || `${cert.treinamento_nome || cert.treinamento_codigo}.pdf`,
        type: 'file' as const,
        metadata: {
          size_bytes: cert.tamanho_bytes,
          created_at: cert.data_conclusao,
          modified_at: cert.data_sincronizacao,
          download_url: `/api/v2/pasta-virtual-download-enhanced/download/${cert.id}`,
          file_type: 'application/pdf',
          status: cert.status_sincronizacao,
          extra_info: {
            treinamento: cert.treinamento_codigo,
            conclusao: cert.data_conclusao ? new Date(cert.data_conclusao).toLocaleDateString('pt-BR') : null,
            vencimento: cert.data_vencimento ? new Date(cert.data_vencimento).toLocaleDateString('pt-BR') : null,
            status_validade: cert.status_validade,
            instrutor: cert.instrutor
          }
        }
      };
      
      parentFolder.children.push(fileNode);
    });
    
    // Estatísticas
    const estatisticas = {
      total_certificacoes: certificacoes.results?.length || 0,
      certificacoes_tecnicas: certificacoesTecnicas,
      documentos_medicos: documentosMedicos,
      total_pastas: 3, // Sempre 3 pastas raiz
      espaco_utilizado_bytes: (certificacoes.results || []).reduce((total: number, cert: any) => 
        total + (cert.tamanho_bytes || 0), 0
      )
    };
    
    await logAudit(c, 'READ', 'pasta_virtual_estrutura', String(funcionarioId));
    
    return c.json({
      success: true,
      funcionario: {
        id: funcionario.id,
        nome: funcionario.nome,
        matricula: funcionario.matricula,
        funcao: funcionario.funcao
      },
      estrutura: estruturaArvore,
      estatisticas: estatisticas,
      metadata: {
        total_arquivos: estatisticas.total_certificacoes,
        espaco_total_mb: Math.round(estatisticas.espaco_utilizado_bytes / (1024 * 1024) * 100) / 100,
        ultima_sincronizacao: new Date().toISOString()
      }
    });
    
  } catch (error) {
    console.error('💥 [LISTAR] Erro ao montar estrutura:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Erro interno' 
    }, 500);
  }
});

export default app;
