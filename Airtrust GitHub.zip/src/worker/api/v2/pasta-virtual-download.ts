import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

interface Env {
  DB: any;
  R2_BUCKET: any;
}

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ NOVO ENDPOINT SEGURO E ROBUSTO PARA DOWNLOAD DA PASTA VIRTUAL
app.get('/download/:sync_id', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const { sync_id } = c.req.param();
    const db = c.env.DB;
    const r2Bucket = c.env.R2_BUCKET; // Binding para R2

    if (!sync_id) {
      return c.json({ success: false, error: 'ID de sincronização inválido' }, 400);
    }

    console.log(`📁 [PASTA-DOWNLOAD] Buscando arquivo - Sync ID: ${sync_id}`);

    // Buscar registro na pasta_virtual_sync_log
    const logEntry = await db.prepare(`
      SELECT 
        arquivo_pasta_virtual_url, 
        nome_arquivo_auditavel,
        status_sincronizacao,
        funcionario_nome,
        treinamento_nome,
        data_conclusao,
        tamanho_bytes
      FROM pasta_virtual_sync_log 
      WHERE id = ? AND status_sincronizacao = 'SINCRONIZADO' AND deleted_at IS NULL
    `).bind(sync_id).first();

    if (!logEntry) {
      console.error(`❌ [PASTA-DOWNLOAD] Arquivo não encontrado ou não sincronizado - ID: ${sync_id}`);
      
      await logAudit(c, 'DOWNLOAD_FAILED', 'pasta_virtual_sync_log', sync_id, undefined, { 
        erro: 'Arquivo não encontrado ou não sincronizado',
        sync_id: sync_id
      });

      return c.json({ 
        success: false, 
        error: 'Arquivo não encontrado, não sincronizado, ou acesso negado.' 
      }, 404);
    }

    const { arquivo_pasta_virtual_url, nome_arquivo_auditavel } = logEntry;

    if (!arquivo_pasta_virtual_url) {
      console.error(`❌ [PASTA-DOWNLOAD] Registro sem URL de arquivo - ID: ${sync_id}`);
      return c.json({ success: false, error: 'Registro não contém URL de arquivo.' }, 404);
    }

    console.log(`📁 [PASTA-DOWNLOAD] Arquivo encontrado: ${nome_arquivo_auditavel}`);
    console.log(`🔗 [PASTA-DOWNLOAD] URL: ${arquivo_pasta_virtual_url}`);

    // Se for URL mock (para desenvolvimento), redirecionar
    if (arquivo_pasta_virtual_url.startsWith('mock://')) {
      console.log(`🔄 [PASTA-DOWNLOAD] Mock URL detectada, simulando download`);
      
      await logAudit(c, 'DOWNLOAD_MOCK', 'pasta_virtual_sync_log', sync_id, undefined, {
        arquivo: nome_arquivo_auditavel,
        funcionario: logEntry.funcionario_nome,
        treinamento: logEntry.treinamento_nome
      });

      // Retornar um PDF mock para desenvolvimento
      const mockPdfContent = `%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj
2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj
3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
>>
endobj
4 0 obj
<<
/Length 44
>>
stream
BT
/F1 12 Tf
100 700 Td
(Certificado Mock - ${nome_arquivo_auditavel}) Tj
ET
endstream
endobj
xref
0 5
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000206 00000 n 
trailer
<<
/Size 5
/Root 1 0 R
>>
startxref
299
%%EOF`;

      const headers = new Headers();
      headers.set('Content-Type', 'application/pdf');
      headers.set('Content-Disposition', `attachment; filename="${nome_arquivo_auditavel}"`);

      return new Response(mockPdfContent, { headers });
    }

    // Extrair chave do R2 do URL
    let key: string;
    try {
      const url = new URL(arquivo_pasta_virtual_url);
      key = url.pathname.substring(1); // Remove a barra inicial
    } catch (urlError) {
      console.error(`❌ [PASTA-DOWNLOAD] URL inválida: ${arquivo_pasta_virtual_url}`);
      return c.json({ 
        success: false, 
        error: 'URL de arquivo inválida no registro.' 
      }, 500);
    }

    console.log(`🔍 [PASTA-DOWNLOAD] Buscando no R2 - Chave: ${key}`);

    if (!r2Bucket) {
      console.warn(`⚠️ [PASTA-DOWNLOAD] R2 não configurado, retornando erro`);
      return c.json({ 
        success: false, 
        error: 'Armazenamento R2 não disponível.' 
      }, 503);
    }

    // Buscar arquivo específico no R2
    const object = await r2Bucket.get(key);

    if (object === null) {
      console.error(`❌ [PASTA-DOWNLOAD] Arquivo não encontrado no R2 - Chave: ${key}`);
      
      await logAudit(c, 'DOWNLOAD_INTEGRITY_FAIL', 'pasta_virtual_sync_log', sync_id, undefined, {
        erro: 'Arquivo não encontrado no armazenamento R2',
        key_procurada: key,
        arquivo: nome_arquivo_auditavel
      });

      return c.json({ 
        success: false, 
        error: 'Integridade Falhou: Arquivo não encontrado no armazenamento R2.',
        key_procurada: key,
        debug_info: {
          sync_id: sync_id,
          arquivo_esperado: nome_arquivo_auditavel,
          url_original: arquivo_pasta_virtual_url
        }
      }, 404);
    }

    console.log(`✅ [PASTA-DOWNLOAD] Arquivo encontrado no R2, iniciando download`);

    // Auditoria de sucesso
    await logAudit(c, 'DOWNLOAD_SUCCESS', 'pasta_virtual_sync_log', sync_id, undefined, {
      arquivo: nome_arquivo_auditavel,
      funcionario: logEntry.funcionario_nome,
      treinamento: logEntry.treinamento_nome,
      tamanho_bytes: logEntry.tamanho_bytes,
      key: key
    });

    // Headers corretos para download do PDF
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('Content-Disposition', `attachment; filename="${nome_arquivo_auditavel}"`);
    headers.set('Content-Type', 'application/pdf');
    headers.set('Cache-Control', 'no-cache');

    console.log(`📤 [PASTA-DOWNLOAD] Servindo arquivo: ${nome_arquivo_auditavel}`);

    // Retornar o arquivo verdadeiro para download
    return new Response(object.body, {
      headers,
    });

  } catch (error) {
    console.error("💥 [PASTA-DOWNLOAD] Falha no download de arquivo:", error);
    
    await logAudit(c, 'DOWNLOAD_ERROR', 'pasta_virtual_sync_log', c.req.param('sync_id'), undefined, {
      erro: error instanceof Error ? error.message : 'Erro desconhecido',
      stack: error instanceof Error ? error.stack : undefined
    });

    return c.json({ 
      success: false, 
      error: 'Erro interno no download: ' + (error instanceof Error ? error.message : 'Erro desconhecido')
    }, 500);
  }
});

// ✅ ENDPOINT PARA DOWNLOAD POR ID DE HISTÓRICO (compatibilidade)
app.get('/by-historico/:historicoId', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const historicoId = c.req.param('historicoId');
    const db = c.env.DB;

    console.log(`🔄 [PASTA-DOWNLOAD] Buscando por histórico ID: ${historicoId}`);

    // Buscar sync_id correspondente ao histórico
    const syncRecord = await db.prepare(`
      SELECT id as sync_id, nome_arquivo_auditavel, status_sincronizacao
      FROM pasta_virtual_sync_log 
      WHERE historico_cert_id = ? AND deleted_at IS NULL
      ORDER BY created_at DESC 
      LIMIT 1
    `).bind(historicoId).first();

    if (!syncRecord) {
      console.error(`❌ [PASTA-DOWNLOAD] Nenhum arquivo sincronizado encontrado para histórico: ${historicoId}`);
      return c.json({ 
        success: false,
        error: 'Nenhum arquivo sincronizado encontrado para este histórico' 
      }, 404);
    }

    if (syncRecord.status_sincronizacao !== 'SINCRONIZADO') {
      console.warn(`⚠️ [PASTA-DOWNLOAD] Arquivo não sincronizado - Status: ${syncRecord.status_sincronizacao}`);
      return c.json({ 
        success: false,
        error: `Arquivo não está sincronizado. Status: ${syncRecord.status_sincronizacao}` 
      }, 400);
    }

    console.log(`✅ [PASTA-DOWNLOAD] Redirecionando para sync_id: ${syncRecord.sync_id}`);

    // Redirecionar para o download usando sync_id
    return c.redirect(`/api/v2/pasta-virtual-download/download/${syncRecord.sync_id}`);

  } catch (error) {
    console.error('💥 [PASTA-DOWNLOAD] Erro ao buscar por histórico:', error);
    return c.json({ 
      success: false, 
      error: 'Erro interno ao buscar arquivo por histórico' 
    }, 500);
  }
});

// ✅ ENDPOINT PARA LISTAR DOWNLOADS DISPONÍVEIS PARA UM FUNCIONÁRIO
app.get('/funcionario/:funcionarioId/downloads', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const funcionarioId = c.req.param('funcionarioId');
    const db = c.env.DB;

    console.log(`📋 [PASTA-DOWNLOAD] Listando downloads para funcionário: ${funcionarioId}`);

    const downloads = await db.prepare(`
      SELECT 
        id as sync_id,
        nome_arquivo_auditavel,
        treinamento_nome,
        treinamento_codigo,
        data_conclusao,
        data_vencimento,
        status_sincronizacao,
        tamanho_bytes,
        data_sincronizacao,
        CASE 
          WHEN data_vencimento < DATE('now') THEN 'VENCIDO'
          WHEN data_vencimento <= DATE('now', '+30 days') THEN 'VENCENDO'
          ELSE 'VALIDO'
        END as status_validade
      FROM pasta_virtual_sync_log
      WHERE funcionario_id = ? AND deleted_at IS NULL
      ORDER BY data_conclusao DESC, created_at DESC
    `).bind(funcionarioId).all();

    const resumo = {
      total: downloads.results?.length || 0,
      sincronizados: (downloads.results || []).filter((d: any) => d.status_sincronizacao === 'SINCRONIZADO').length,
      com_erro: (downloads.results || []).filter((d: any) => d.status_sincronizacao === 'ERRO').length,
      vencidos: (downloads.results || []).filter((d: any) => d.status_validade === 'VENCIDO').length
    };

    return c.json({
      success: true,
      funcionario_id: funcionarioId,
      downloads: downloads.results || [],
      resumo: resumo,
      endpoint_download: '/api/v2/pasta-virtual-download/download/{sync_id}'
    });

  } catch (error) {
    console.error('💥 [PASTA-DOWNLOAD] Erro ao listar downloads:', error);
    return c.json({ 
      success: false, 
      error: 'Erro interno ao listar downloads' 
    }, 500);
  }
});

export default app;
