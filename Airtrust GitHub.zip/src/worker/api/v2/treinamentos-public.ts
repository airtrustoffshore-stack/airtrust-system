import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// GET /api/v2/treinamentos-public/listar - Listar treinamentos (sem autenticação para dropdown)
app.get('/listar', async (c) => {
  try {
    const db = c.env.DB;
    
    console.log('📚 Carregando treinamentos para dropdown...');
    
    const stmt = db.prepare(`
      SELECT 
        id,
        codigo,
        nome,
        descricao,
        categoria,
        periodicidade_meses,
        instrutor_obrigatorio,
        nota_minima,
        carga_horaria,
        ativo,
        obrigatorio_funcoes,
        tipo_vencimento,
        created_at,
        updated_at
      FROM catalogo_treinamentos_v2
      WHERE deleted_at IS NULL AND ativo = 1
      ORDER BY categoria ASC, nome ASC
    `);
    
    const result = await stmt.all();
    const treinamentos = result.results;

    // Formatar dados para o frontend
    const treinamentosFormatados = treinamentos.map((t: any) => ({
      id: t.id,
      codigo: t.codigo,
      nome: t.nome,
      descricao: t.descricao,
      categoria: t.categoria,
      tipo_treinamento: t.categoria,
      periodicidade_meses: t.periodicidade_meses,
      total_sessoes_necessarias: Math.ceil((Number(t.carga_horaria) || 8) / 2),
      validade_meses: t.periodicidade_meses,
      instrutor_obrigatorio: Boolean(t.instrutor_obrigatorio),
      nota_minima: t.nota_minima,
      carga_horaria: t.carga_horaria,
      status: t.ativo ? 'ATIVO' : 'INATIVO',
      obrigatorio_funcoes: t.obrigatorio_funcoes ? String(t.obrigatorio_funcoes).split(',') : [],
      tipo_vencimento: t.tipo_vencimento,
      created_at: t.created_at,
      updated_at: t.updated_at
    }));

    console.log(`✅ ${treinamentosFormatados.length} treinamentos carregados`);
    
    return c.json({
      success: true,
      treinamentos: treinamentosFormatados,
      data: treinamentosFormatados,
      total: treinamentosFormatados.length
    });
  } catch (error) {
    console.error('❌ Erro ao carregar treinamentos:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

export default app;
