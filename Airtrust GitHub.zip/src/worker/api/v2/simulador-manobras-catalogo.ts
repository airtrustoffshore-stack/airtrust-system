import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    let manobrasFormatadas: any[] = [];
    
    try {
      // Buscar catálogo de manobras
      const manobras = await db.prepare(`
        SELECT 
          id,
          manobra_id_codigo as codigo,
          nome_manobra as nome,
          descricao_detalhada as descricao,
          categoria,
          criterios_aprovacao,
          pontuacao_minima,
          ativo,
          created_at,
          created_by
        FROM manobras_catalogo
        WHERE ativo = 1
        ORDER BY categoria, nome_manobra
      `).all();
      
      manobrasFormatadas = (manobras.results || []).map((manobra: any) => ({
        id: manobra.id,
        codigo: manobra.codigo,
        nome: manobra.nome,
        descricao: manobra.descricao,
        categoria: manobra.categoria,
        criterios_aprovacao: manobra.criterios_aprovacao,
        pontuacao_minima: manobra.pontuacao_minima,
        ativo: Boolean(manobra.ativo),
        created_at: manobra.created_at,
        created_by: manobra.created_by
      }));
    } catch (dbError) {
      console.log('DB erro, usando fallback de manobras');
    }
    
    // ✅ FALLBACK SE VAZIO
    if (manobrasFormatadas.length === 0) {
      manobrasFormatadas = [
        {id: 1, codigo: 'MAN-001', nome: 'Decolagem Normal', categoria: 'DECOLAGEM', descricao: 'Decolagem em condições normais', pontuacao_minima: 5, ativo: true},
        {id: 2, codigo: 'MAN-002', nome: 'Aproximação ILS', categoria: 'APROXIMACAO', descricao: 'Aproximação por instrumentos ILS', pontuacao_minima: 5, ativo: true},
        {id: 3, codigo: 'MAN-003', nome: 'Pouso Manual', categoria: 'POUSO', descricao: 'Pouso manual sem piloto automático', pontuacao_minima: 5, ativo: true},
        {id: 4, codigo: 'MAN-004', nome: 'Emergência - Falha Motor', categoria: 'EMERGENCIA', descricao: 'Procedimento de falha de motor', pontuacao_minima: 5, ativo: true},
        {id: 5, codigo: 'MAN-005', nome: 'Go Around', categoria: 'PROCEDIMENTO', descricao: 'Procedimento de arremetida', pontuacao_minima: 5, ativo: true}
      ];
    }
    
    // Agrupar por categoria
    const categorias = [...new Set(manobrasFormatadas.map((m: any) => m.categoria))];
    const manobrasPorCategoria = categorias.map(categoria => ({
      categoria,
      manobras: manobrasFormatadas.filter((m: any) => m.categoria === categoria)
    }));
    
    return c.json({
      success: true,
      manobras: manobrasFormatadas,
      manobras_por_categoria: manobrasPorCategoria,
      total: manobrasFormatadas.length,
      categorias: categorias,
      from_fallback: manobrasFormatadas.length <= 5,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar catálogo de manobras:', error);
    return c.json({ 
      success: false,
      data: [],
      error: 'Erro ao buscar catálogo',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      from_fallback: true
    }, 500);
  }
});

// GET - Buscar manobras por categoria
app.get('/categoria/:categoria', async (c) => {
  try {
    const db = c.env.DB;
    const { categoria } = c.req.param();
    
    const manobras = await db.prepare(`
      SELECT 
        id,
        manobra_id_codigo as codigo,
        nome_manobra as nome,
        descricao_detalhada as descricao,
        categoria,
        criterios_aprovacao,
        pontuacao_minima
      FROM manobras_catalogo
      WHERE categoria = ? AND ativo = 1
      ORDER BY nome_manobra
    `).bind(categoria).all();
    
    return c.json({
      success: true,
      categoria: categoria,
      manobras: manobras.results || [],
      total: manobras.results?.length || 0
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar manobras por categoria:', error);
    return c.json({ 
      error: 'Erro ao buscar manobras da categoria',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET - Buscar detalhes de uma manobra
app.get('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const { id } = c.req.param();
    
    const manobra = await db.prepare(`
      SELECT 
        id,
        manobra_id_codigo as codigo,
        nome_manobra as nome,
        descricao_detalhada as descricao,
        categoria,
        criterios_aprovacao,
        pontuacao_minima,
        ativo,
        created_at,
        created_by,
        updated_at,
        updated_by
      FROM manobras_catalogo
      WHERE id = ?
    `).bind(id).first();
    
    if (!manobra) {
      return c.json({ error: 'Manobra não encontrada' }, 404);
    }
    
    // Buscar ciclos relacionados
    const ciclos = await db.prepare(`
      SELECT c.numero_ciclo, c.nome, c.descricao
      FROM ciclos c
      JOIN manobras_catalogo_ciclos mcc ON c.id = mcc.ciclo_id
      WHERE mcc.manobra_catalogo_id = ?
    `).bind(id).all();
    
    return c.json({
      success: true,
      manobra: {
        id: manobra.id,
        codigo: manobra.codigo,
        nome: manobra.nome,
        descricao: manobra.descricao,
        categoria: manobra.categoria,
        criterios_aprovacao: manobra.criterios_aprovacao,
        pontuacao_minima: manobra.pontuacao_minima,
        ativo: Boolean(manobra.ativo),
        ciclos: ciclos.results || [],
        created_at: manobra.created_at,
        created_by: manobra.created_by,
        updated_at: manobra.updated_at,
        updated_by: manobra.updated_by
      }
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar detalhes da manobra:', error);
    return c.json({ 
      error: 'Erro ao buscar manobra',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
