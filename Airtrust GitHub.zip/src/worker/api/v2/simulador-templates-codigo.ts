import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.use('*', authMiddleware);

// GET /api/v2/simulador-templates/treinamento/:codigo - Buscar templates por código de treinamento
app.get('/treinamento/:codigo', async (c) => {
  try {
    const db = c.env.DB;
    const codigoTreinamento = c.req.param('codigo');

    console.log(`🔍 Buscando templates para treinamento: ${codigoTreinamento}`);

    // Buscar treinamento pelo código
    const treinamento = await db.prepare(`
      SELECT id, codigo, nome 
      FROM catalogo_treinamentos_v2 
      WHERE codigo = ? AND deleted_at IS NULL
    `).bind(codigoTreinamento).first();

    if (!treinamento) {
      console.log(`❌ Treinamento ${codigoTreinamento} não encontrado`);
      return c.json({ 
        error: 'Treinamento não encontrado',
        codigo: codigoTreinamento,
        success: false
      }, 404);
    }

    // Buscar templates do treinamento
    const templates = await db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo,
        st.numero_sessao,
        st.nome_sessao,
        st.descricao,
        st.created_at,
        COUNT(stm.manobra_catalogo_id) as total_manobras
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      WHERE st.treinamento_codigo = ?
      GROUP BY st.id
      ORDER BY st.numero_sessao ASC
    `).bind(codigoTreinamento).all();

    const templatesFormatados = templates.results.map((t: any) => ({
      id: t.id,
      codigo: t.treinamento_codigo,
      nome: t.nome_sessao,
      descricao: t.descricao,
      numero_sessao: t.numero_sessao,
      total_manobras: t.total_manobras || 0,
      created_at: t.created_at
    }));

    console.log(`✅ Encontrados ${templatesFormatados.length} templates para ${codigoTreinamento}`);

    return c.json({
      success: true,
      treinamento: {
        id: treinamento.id,
        codigo: treinamento.codigo,
        nome: treinamento.nome
      },
      templates: templatesFormatados,
      total: templatesFormatados.length
    });

  } catch (error) {
    console.error('❌ Erro ao buscar templates por código de treinamento:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message,
      success: false
    }, 500);
  }
});

export default app;
