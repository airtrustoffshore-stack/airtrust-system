import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ ESTRUTURA HIERÁRQUICA DA PASTA VIRTUAL
interface PastaVirtualNode {
  id: string;
  nome: string;
  tipo: 'pasta' | 'arquivo';
  caminho: string;
  filhos?: PastaVirtualNode[];
  metadata?: {
    tamanho_bytes?: number;
    data_criacao?: string;
    data_modificacao?: string;
    hash_md5?: string;
    url_download?: string;
    funcionario_id?: number;
    historico_cert_id?: number;
    treinamento_codigo?: string;
    data_conclusao?: string;
    data_vencimento?: string;
    status_sincronizacao?: string;
  };
}

// ✅ GERAR ESTRUTURA HIERÁRQUICA DA PASTA VIRTUAL
app.get('/estrutura/:funcionario_id', requirePermission('pasta_virtual', 'READ'), async (c) => {
  try {
    const funcionarioId = parseInt(c.req.param('funcionario_id'));
    
    if (!funcionarioId) {
      return c.json({ error: 'ID do funcionário é obrigatório' }, 400);
    }

    const db = c.env.DB;
    
    // Buscar dados do funcionário
    const funcionario = await db.prepare(`
      SELECT id, nome, matricula, funcao 
      FROM funcionarios 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(funcionarioId).first();
    
    if (!funcionario) {
      return c.json({ error: 'Funcionário não encontrado' }, 404);
    }

    // Buscar certificações sincronizadas
    const certificacoesSincronizadas = await db.prepare(`
      SELECT 
        pvsl.id as sync_id,
        pvsl.nome_arquivo_auditavel,
        pvsl.arquivo_pasta_virtual_url,
        pvsl.funcionario_nome,
        pvsl.funcionario_matricula,
        pvsl.treinamento_nome,
        pvsl.treinamento_codigo,
        pvsl.data_conclusao,
        pvsl.data_vencimento,
        pvsl.status_sincronizacao,
        pvsl.tamanho_bytes,
        pvsl.hash_md5,
        pvsl.data_sincronizacao,
        hc.nota_final,
        hc.instrutor,
        ct.categoria as treinamento_categoria
      FROM pasta_virtual_sync_log pvsl
      LEFT JOIN historico_certificacoes_v2 hc ON pvsl.historico_cert_id = hc.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE pvsl.funcionario_id = ? 
        AND pvsl.status_sincronizacao = 'SINCRONIZADO'
        AND pvsl.deleted_at IS NULL
      ORDER BY pvsl.data_conclusao DESC, pvsl.treinamento_codigo
    `).bind(funcionarioId).all();

    // Construir estrutura hierárquica
    const nomePastaFuncionario = `${funcionario.matricula}_${String(funcionario.nome).replace(/[^a-zA-Z0-9]/g, '_')}`;
    
    const estrutura: PastaVirtualNode = {
      id: `funcionario_${funcionario.id}`,
      nome: nomePastaFuncionario,
      tipo: 'pasta',
      caminho: `pasta-virtual/funcionarios/${nomePastaFuncionario}`,
      filhos: [
        {
          id: `certificacoes_${funcionario.id}`,
          nome: 'Certificações',
          tipo: 'pasta',
          caminho: `pasta-virtual/funcionarios/${nomePastaFuncionario}/certificacoes`,
          filhos: []
        },
        {
          id: `treinamentos_${funcionario.id}`,
          nome: 'Treinamentos',
          tipo: 'pasta',
          caminho: `pasta-virtual/funcionarios/${nomePastaFuncionario}/treinamentos`,
          filhos: []
        },
        {
          id: `documentos_medicos_${funcionario.id}`,
          nome: 'Documentos Médicos',
          tipo: 'pasta',
          caminho: `pasta-virtual/funcionarios/${nomePastaFuncionario}/documentos_medicos`,
          filhos: []
        }
      ]
    };

    // Organizar certificações por categoria
    const pastaCertificacoes = estrutura.filhos!.find(f => f.nome === 'Certificações')!;
    const pastaDocumentosMedicos = estrutura.filhos!.find(f => f.nome === 'Documentos Médicos')!;
    
    certificacoesSincronizadas.results?.forEach((cert: any) => {
      const arquivo: PastaVirtualNode = {
        id: `cert_${cert.sync_id}`,
        nome: cert.nome_arquivo_auditavel,
        tipo: 'arquivo',
        caminho: cert.arquivo_pasta_virtual_url,
        metadata: {
          tamanho_bytes: cert.tamanho_bytes,
          data_criacao: cert.data_sincronizacao,
          data_modificacao: cert.data_sincronizacao,
          hash_md5: cert.hash_md5,
          url_download: `/api/v2/pasta-virtual-download-enhanced/download/${cert.sync_id}`,
          funcionario_id: funcionarioId,
          historico_cert_id: cert.historico_cert_id,
          treinamento_codigo: cert.treinamento_codigo,
          data_conclusao: cert.data_conclusao,
          data_vencimento: cert.data_vencimento,
          status_sincronizacao: cert.status_sincronizacao
        }
      };

      // Categorizar certificações
      if (cert.treinamento_categoria === 'MEDICO' || 
          cert.treinamento_codigo.includes('CMA') || 
          cert.treinamento_codigo.includes('ASO')) {
        pastaDocumentosMedicos.filhos!.push(arquivo);
      } else {
        pastaCertificacoes.filhos!.push(arquivo);
      }
    });

    // Auditoria
    await logAudit(c, 'PASTA_VIRTUAL_ESTRUTURA', 'pasta_virtual', funcionarioId.toString(), undefined, {
      funcionario_id: funcionarioId,
      certificacoes_encontradas: certificacoesSincronizadas.results?.length || 0
    });

    return c.json({
      success: true,
      funcionario: {
        id: funcionario.id,
        nome: funcionario.nome,
        matricula: funcionario.matricula,
        funcao: funcionario.funcao
      },
      estrutura: estrutura,
      estatisticas: {
        total_certificacoes: certificacoesSincronizadas.results?.length || 0,
        certificacoes_tecnicas: pastaCertificacoes.filhos!.length,
        documentos_medicos: pastaDocumentosMedicos.filhos!.length,
        total_pastas: 4, // funcionario + 3 subpastas
        espaco_utilizado_bytes: certificacoesSincronizadas.results?.reduce((acc: number, cert: any) => 
          acc + (cert.tamanho_bytes || 0), 0) || 0
      }
    });

  } catch (error) {
    console.error('💥 [PASTA-VIRTUAL] Erro ao gerar estrutura:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno do servidor'
    }, 500);
  }
});

// ✅ DOWNLOAD SEGURO E AUDITÁVEL DE CERTIFICADOS
app.get('/download/:sync_id', requirePermission('pasta_virtual', 'READ'), async (c) => {
  try {
    const syncId = parseInt(c.req.param('sync_id'));
    
    if (!syncId) {
      return c.json({ error: 'ID de sincronização é obrigatório' }, 400);
    }

    const db = c.env.DB;
    const r2 = (c.env as any).BUCKET || null;
    
    // Buscar registro de sincronização
    const syncRecord = await db.prepare(`
      SELECT 
        pvsl.*,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        ct.nome as treinamento_nome,
        ct.codigo as treinamento_codigo
      FROM pasta_virtual_sync_log pvsl
      LEFT JOIN funcionarios f ON pvsl.funcionario_id = f.id
      LEFT JOIN historico_certificacoes_v2 hc ON pvsl.historico_cert_id = hc.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE pvsl.id = ? 
        AND pvsl.status_sincronizacao = 'SINCRONIZADO'
        AND pvsl.deleted_at IS NULL
    `).bind(syncId).first();
    
    if (!syncRecord) {
      return c.json({ error: 'Arquivo não encontrado ou não sincronizado' }, 404);
    }

    // Verificar integridade do arquivo no R2
    let arquivoDisponivel = true;
    let urlDownload = String(syncRecord.arquivo_pasta_virtual_url || '');
    
    if (r2 && !urlDownload.includes('mock://')) {
      try {
        const caminhoR2 = String(urlDownload).replace(/^https?:\/\/[^\/]+\//, '');
        const objeto = await r2.get(caminhoR2);
        
        if (!objeto) {
          arquivoDisponivel = false;
          console.warn(`⚠️ [DOWNLOAD] Arquivo não encontrado no R2: ${caminhoR2}`);
        }
      } catch (r2Error) {
        console.error(`❌ [DOWNLOAD] Erro ao verificar R2:`, r2Error);
        arquivoDisponivel = false;
      }
    }

    if (!arquivoDisponivel) {
      return c.json({ 
        error: 'Arquivo temporariamente indisponível',
        detalhes: 'O arquivo foi sincronizado mas não está acessível no momento'
      }, 503);
    }

    // Log de auditoria para download
    await logAudit(c, 'PASTA_VIRTUAL_DOWNLOAD', 'pasta_virtual_sync_log', syncId.toString(), undefined, {
      sync_id: syncId,
      funcionario_id: syncRecord.funcionario_id,
      funcionario_nome: syncRecord.funcionario_nome,
      arquivo: syncRecord.nome_arquivo_auditavel,
      tamanho_bytes: syncRecord.tamanho_bytes,
      hash_md5: syncRecord.hash_md5,
      url_original: syncRecord.arquivo_original_url,
      ip_address: c.req.header('CF-Connecting-IP') || 'unknown'
    });

    // Redirecionar para download
    if (String(urlDownload).includes('mock://')) {
      // Mock para desenvolvimento
      return c.json({
        success: true,
        download_type: 'mock',
        arquivo: {
          nome: syncRecord.nome_arquivo_auditavel,
          tamanho_bytes: syncRecord.tamanho_bytes,
          hash_md5: syncRecord.hash_md5,
          funcionario: syncRecord.funcionario_nome,
          treinamento: syncRecord.treinamento_nome,
          data_conclusao: syncRecord.data_conclusao
        },
        message: 'Download simulado - arquivo mock gerado'
      });
    } else {
      // Redirect para URL real do R2
      return c.redirect(String(urlDownload));
    }

  } catch (error) {
    console.error('💥 [DOWNLOAD] Erro:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno do servidor'
    }, 500);
  }
});

// ✅ LISTAR TODOS OS ARQUIVOS DE UM FUNCIONÁRIO (FLAT)
app.get('/arquivos/:funcionario_id', requirePermission('pasta_virtual', 'READ'), async (c) => {
  try {
    const funcionarioId = parseInt(c.req.param('funcionario_id'));
    
    if (!funcionarioId) {
      return c.json({ error: 'ID do funcionário é obrigatório' }, 400);
    }

    const db = c.env.DB;
    
    // Buscar todos os arquivos sincronizados
    const arquivos = await db.prepare(`
      SELECT 
        pvsl.id as sync_id,
        pvsl.nome_arquivo_auditavel,
        pvsl.arquivo_pasta_virtual_url,
        pvsl.tamanho_bytes,
        pvsl.hash_md5,
        pvsl.data_sincronizacao,
        pvsl.funcionario_nome,
        pvsl.funcionario_matricula,
        pvsl.treinamento_nome,
        pvsl.treinamento_codigo,
        pvsl.data_conclusao,
        pvsl.data_vencimento,
        hc.nota_final,
        hc.instrutor,
        ct.categoria as treinamento_categoria,
        CASE 
          WHEN ct.categoria = 'MEDICO' OR pvsl.treinamento_codigo LIKE '%CMA%' OR pvsl.treinamento_codigo LIKE '%ASO%' 
          THEN 'Documentos Médicos'
          ELSE 'Certificações'
        END as pasta_categoria
      FROM pasta_virtual_sync_log pvsl
      LEFT JOIN historico_certificacoes_v2 hc ON pvsl.historico_cert_id = hc.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE pvsl.funcionario_id = ? 
        AND pvsl.status_sincronizacao = 'SINCRONIZADO'
        AND pvsl.deleted_at IS NULL
      ORDER BY pvsl.data_conclusao DESC, pvsl.treinamento_codigo
    `).bind(funcionarioId).all();

    const resultado = arquivos.results?.map((arquivo: any) => ({
      sync_id: arquivo.sync_id,
      nome_arquivo: arquivo.nome_arquivo_auditavel,
      categoria: arquivo.pasta_categoria,
      treinamento: {
        codigo: arquivo.treinamento_codigo,
        nome: arquivo.treinamento_nome,
        categoria: arquivo.treinamento_categoria
      },
      certificacao: {
        data_conclusao: arquivo.data_conclusao,
        data_vencimento: arquivo.data_vencimento,
        nota_final: arquivo.nota_final,
        instrutor: arquivo.instrutor
      },
      arquivo: {
        tamanho_bytes: arquivo.tamanho_bytes,
        hash_md5: arquivo.hash_md5,
        data_sincronizacao: arquivo.data_sincronizacao,
        url_download: `/api/v2/pasta-virtual-download-enhanced/download/${arquivo.sync_id}`
      },
      funcionario: {
        nome: arquivo.funcionario_nome,
        matricula: arquivo.funcionario_matricula
      }
    })) || [];

    return c.json({
      success: true,
      funcionario_id: funcionarioId,
      total_arquivos: resultado.length,
      arquivos: resultado,
      estatisticas: {
        por_categoria: {
          certificacoes: resultado.filter(a => a.categoria === 'Certificações').length,
          documentos_medicos: resultado.filter(a => a.categoria === 'Documentos Médicos').length
        },
        espaco_total_bytes: resultado.reduce((acc, arquivo) => acc + (arquivo.arquivo.tamanho_bytes || 0), 0),
        ultimo_sync: resultado.length > 0 ? resultado[0].arquivo.data_sincronizacao : null
      }
    });

  } catch (error) {
    console.error('💥 [ARQUIVOS] Erro:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno do servidor'
    }, 500);
  }
});

export default app;
