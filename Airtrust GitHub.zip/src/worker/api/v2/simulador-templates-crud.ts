import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

// POST - Criar novo template
app.post('/', async (c) => {
  try {
    const db = c.env.DB;
    const dados = await c.req.json();
    
    console.log('📝 Criando novo template:', dados);
    
    // Validações obrigatórias
    if (!dados.treinamento_codigo && !dados.treinamento_id) {
      return c.json({
        error: 'treinamento_codigo ou treinamento_id é obrigatório'
      }, 400);
    }
    
    if (!dados.nome_sessao) {
      return c.json({
        error: 'nome_sessao é obrigatório'
      }, 400);
    }
    
    // Inserir template
    const resultado = await db.prepare(`
      INSERT INTO sessoes_template (
        treinamento_codigo,
        numero_sessao, 
        nome_sessao,
        descricao,
        created_at,
        created_by,
        updated_at,
        updated_by
      ) VALUES (?, ?, ?, ?, datetime('now'), ?, datetime('now'), ?)
    `).bind(
      dados.treinamento_codigo || `TREINO-${dados.treinamento_id}`,
      dados.numero_sessao || 1,
      dados.nome_sessao,
      dados.descricao || '',
      'SISTEMA',
      'SISTEMA'
    ).run();
    
    if (resultado.changes === 0) {
      return c.json({ error: 'Falha ao criar template' }, 500);
    }
    
    const templateId = resultado.meta.last_row_id;
    
    // Configurar manobras se fornecidas
    if (dados.manobras && Array.isArray(dados.manobras)) {
      for (const manobraId of dados.manobras) {
        await db.prepare(`
          INSERT INTO sessoes_template_manobras (
            sessao_template_id,
            manobra_catalogo_id
          ) VALUES (?, ?)
        `).bind(templateId, manobraId).run();
      }
    }
    
    console.log(`✅ Template criado com ID: ${templateId}`);
    
    return c.json({
      success: true,
      template: {
        id: templateId,
        treinamento_codigo: dados.treinamento_codigo || `TREINO-${dados.treinamento_id}`,
        numero_sessao: dados.numero_sessao || 1,
        nome_sessao: dados.nome_sessao,
        descricao: dados.descricao || '',
        manobras_configuradas: dados.manobras ? dados.manobras.length : 0
      },
      message: 'Template criado com sucesso'
    });
    
  } catch (error) {
    console.error('❌ Erro ao criar template:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// PUT - Atualizar template existente
app.put('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const templateId = c.req.param('id');
    const dados = await c.req.json();
    
    console.log(`📝 Atualizando template ${templateId}:`, dados);
    
    // Verificar se template existe
    const templateExistente = await db.prepare(`
      SELECT id FROM sessoes_template WHERE id = ?
    `).bind(templateId).first();
    
    if (!templateExistente) {
      return c.json({ error: 'Template não encontrado' }, 404);
    }
    
    // Atualizar template
    await db.prepare(`
      UPDATE sessoes_template 
      SET nome_sessao = ?, descricao = ?, updated_at = datetime('now'), updated_by = ?
      WHERE id = ?
    `).bind(
      dados.nome_sessao || 'Nome não definido',
      dados.descricao || '',
      'SISTEMA',
      templateId
    ).run();
    
    // Atualizar manobras se fornecidas
    if (dados.manobras && Array.isArray(dados.manobras)) {
      // Remover manobras existentes
      await db.prepare(`
        DELETE FROM sessoes_template_manobras WHERE sessao_template_id = ?
      `).bind(templateId).run();
      
      // Inserir novas manobras
      for (const manobraId of dados.manobras) {
        await db.prepare(`
          INSERT INTO sessoes_template_manobras (
            sessao_template_id,
            manobra_catalogo_id
          ) VALUES (?, ?)
        `).bind(templateId, manobraId).run();
      }
    }
    
    console.log(`✅ Template ${templateId} atualizado com sucesso`);
    
    return c.json({
      success: true,
      template: {
        id: templateId,
        nome_sessao: dados.nome_sessao,
        descricao: dados.descricao,
        manobras_configuradas: dados.manobras ? dados.manobras.length : 0
      },
      message: 'Template atualizado com sucesso'
    });
    
  } catch (error) {
    console.error(`❌ Erro ao atualizar template ${c.req.param('id')}:`, error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// DELETE - Excluir template
app.delete('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const templateId = c.req.param('id');
    
    console.log(`🗑️ Excluindo template ${templateId}`);
    
    // Verificar se template existe
    const templateExistente = await db.prepare(`
      SELECT id FROM sessoes_template WHERE id = ?
    `).bind(templateId).first();
    
    if (!templateExistente) {
      return c.json({ error: 'Template não encontrado' }, 404);
    }
    
    // Remover manobras associadas
    await db.prepare(`
      DELETE FROM sessoes_template_manobras WHERE sessao_template_id = ?
    `).bind(templateId).run();
    
    // Remover template
    await db.prepare(`
      DELETE FROM sessoes_template WHERE id = ?
    `).bind(templateId).run();
    
    console.log(`✅ Template ${templateId} excluído com sucesso`);
    
    return c.json({
      success: true,
      message: 'Template excluído com sucesso',
      template_id: templateId
    });
    
  } catch (error) {
    console.error(`❌ Erro ao excluir template ${c.req.param('id')}:`, error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
