import { Hono } from 'hono';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

// Middleware simples - sem auth por enquanto para debug
app.use('*', async (c, next) => {
  console.log(`📡 [NOTIFICACOES] Request: ${c.req.method} ${c.req.path}`);
  await next();
  console.log(`📡 [NOTIFICACOES] Response enviada`);
});

app.get('/:usuario', async (c) => {
  try {
    console.log('🔍 [NOTIFICACOES] Início do endpoint notificações');
    
    const { usuario } = c.req.param();
    console.log('🔍 [NOTIFICACOES] Usuário:', usuario);
    
    // Verificar se DB está disponível
    const db = c.env.DB;
    console.log('🔍 [NOTIFICACOES] DB disponível?', !!db);
    
    if (!db) {
      console.log('❌ [NOTIFICACOES] Database não disponível');
      return c.json({ error: 'Database não disponível' }, 500);
    }
    
    // Tentar query simples primeiro
    try {
      const teste = await db.prepare('SELECT 1 as teste').first();
      console.log('🔍 [NOTIFICACOES] Query teste:', teste);
    } catch (dbError) {
      console.log('❌ [NOTIFICACOES] Erro na query teste:', dbError);
      return c.json({ 
        error: 'Erro de conectividade com banco',
        details: dbError instanceof Error ? dbError.message : 'Erro desconhecido'
      }, 500);
    }
    
    // Dados mock simples - sem DB por enquanto
    const notificacoes = [
      {
        id: 1,
        tipo: 'SESSAO_AGENDADA',
        titulo: 'Nova sessão agendada',
        mensagem: `Você tem uma sessão de simulador agendada para hoje`,
        lida: false,
        data_criacao: new Date().toISOString(),
        prioridade: 'ALTA'
      },
      {
        id: 2,
        tipo: 'AVALIACAO_PENDENTE',
        titulo: 'Avaliação pendente',
        mensagem: `Você tem uma avaliação de simulador pendente`,
        lida: false,
        data_criacao: new Date(Date.now() - 3600000).toISOString(),
        prioridade: 'MEDIA'
      },
      {
        id: 3,
        tipo: 'SESSAO_CONCLUIDA_APROVADA',
        titulo: 'Sessão aprovada',
        mensagem: `Sua última sessão de simulador foi aprovada`,
        lida: true,
        data_criacao: new Date(Date.now() - 86400000).toISOString(),
        prioridade: 'BAIXA'
      }
    ];
    
    console.log('🔍 [NOTIFICACOES] Dados preparados:', notificacoes.length);
    
    const resposta = {
      success: true,
      notificacoes: notificacoes,
      total: notificacoes.length,
      nao_lidas: notificacoes.filter(n => !n.lida).length,
      usuario_id: usuario,
      timestamp: new Date().toISOString(),
      debug: {
        endpoint: 'notificacoes-fixed',
        version: '2.0-debug',
        db_available: !!db
      }
    };
    
    console.log('✅ [NOTIFICACOES] Retornando resposta com', resposta.notificacoes.length, 'notificações');
    return c.json(resposta);
    
  } catch (error) {
    console.error('❌ [NOTIFICACOES] ERRO CAPTURADO:', {
      message: error instanceof Error ? error.message : 'Erro desconhecido',
      stack: error instanceof Error ? error.stack?.substring(0, 200) : 'N/A',
      name: error instanceof Error ? error.name : 'Unknown'
    });
    
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'notificacoes-fixed',
      timestamp: new Date().toISOString(),
      debug: {
        error_type: error instanceof Error ? error.constructor.name : 'Unknown',
        path: c.req.path,
        method: c.req.method
      }
    }, 500);
  }
});

// POST - Marcar notificação como lida (versão simplificada)
app.post('/:usuario/marcar-lida/:notificacao_id', async (c) => {
  try {
    console.log('🔍 [NOTIFICACOES] Marcar como lida');
    
    const { usuario, notificacao_id } = c.req.param();
    
    // Mock response sem interação com DB
    return c.json({
      success: true,
      message: 'Notificação marcada como lida (simulado)',
      notificacao_id: notificacao_id,
      usuario_id: usuario,
      timestamp: new Date().toISOString(),
      debug: {
        endpoint: 'marcar-lida-fixed',
        mock: true
      }
    });
    
  } catch (error) {
    console.error('❌ [NOTIFICACOES] Erro ao marcar notificação:', error);
    return c.json({ 
      error: 'Erro ao marcar notificação',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'marcar-lida-fixed'
    }, 500);
  }
});

// GET - Status do endpoint para debug
app.get('/status', async (c) => {
  return c.json({
    success: true,
    endpoint: 'simulador-notificacoes-fixed',
    version: '2.0-debug',
    status: 'OPERACIONAL',
    timestamp: new Date().toISOString(),
    features: [
      'GET /:usuario - Listar notificações',
      'POST /:usuario/marcar-lida/:id - Marcar como lida', 
      'GET /status - Status do endpoint'
    ]
  });
});

export default app;
