import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

interface Env {
  DB: any;
  R2?: any;
}

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

/**
 * API DEDICADA: CERTIFICADOS NA PASTA VIRTUAL
 * Endpoints específicos para gerenciar certificados sincronizados automaticamente
 */

// GET /api/v2/pasta-virtual-certificados/funcionario/:id - Certificados do funcionário
app.get('/funcionario/:id', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const funcionarioId = parseInt(c.req.param('id'));
    const incluirHistorico = c.req.query('historico') === 'true';
    
    if (isNaN(funcionarioId)) {
      return c.json({ success: false, error: 'ID de funcionário inválido' }, 400);
    }
    
    // Buscar informações do funcionário
    const funcionario = await c.env.DB.prepare(`
      SELECT id, nome, matricula, funcao, email, status
      FROM funcionarios 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(funcionarioId).first();
    
    if (!funcionario) {
      return c.json({ success: false, error: 'Funcionário não encontrado' }, 404);
    }
    
    // Buscar certificados na pasta virtual (sincronizados automaticamente)
    let whereClause = incluirHistorico ? '' : 'AND pvsl.deleted_at IS NULL';
    
    const certificados = await c.env.DB.prepare(`
      SELECT 
        pvsl.*,
        hc.nota_final,
        hc.instrutor,
        hc.status as certificacao_status,
        ct.categoria as treinamento_categoria,
        ct.periodicidade_meses,
        ct.obrigatorio_funcoes,
        -- Status de validade
        CASE 
          WHEN pvsl.data_vencimento IS NULL THEN 'SEM_VENCIMENTO'
          WHEN pvsl.data_vencimento < DATE('now') THEN 'VENCIDO'
          WHEN pvsl.data_vencimento <= DATE('now', '+30 days') THEN 'VENCENDO'
          WHEN pvsl.data_vencimento <= DATE('now', '+90 days') THEN 'ATENCAO'
          ELSE 'VALIDO'
        END as status_validade,
        -- Dias para vencimento
        CASE 
          WHEN pvsl.data_vencimento IS NOT NULL THEN 
            CAST((julianday(pvsl.data_vencimento) - julianday('now')) AS INTEGER)
          ELSE NULL
        END as dias_para_vencimento,
        -- Metadata de download
        CASE 
          WHEN pvsl.arquivo_pasta_virtual_url LIKE 'https://%' THEN 'DISPONIVEL'
          WHEN pvsl.arquivo_pasta_virtual_url LIKE 'mock://%' THEN 'MOCK'
          ELSE 'INDISPONIVEL'
        END as status_download
      FROM pasta_virtual_sync_log pvsl
      JOIN historico_certificacoes_v2 hc ON pvsl.historico_cert_id = hc.id
      JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE pvsl.funcionario_id = ? ${whereClause}
      ORDER BY 
        CASE pvsl.status_sincronizacao
          WHEN 'ERRO' THEN 1
          WHEN 'PENDENTE' THEN 2
          WHEN 'SINCRONIZADO' THEN 3
        END,
        pvsl.data_vencimento ASC NULLS LAST,
        pvsl.data_conclusao DESC
    `).bind(funcionarioId).all();
    
    const certs = certificados.results || [];
    
    // Estatísticas
    const estatisticas = {
      total_certificados: certs.length,
      sincronizados: certs.filter((c: any) => c.status_sincronizacao === 'SINCRONIZADO').length,
      com_erro: certs.filter((c: any) => c.status_sincronizacao === 'ERRO').length,
      pendentes: certs.filter((c: any) => c.status_sincronizacao === 'PENDENTE').length,
      vencidos: certs.filter((c: any) => c.status_validade === 'VENCIDO').length,
      vencendo: certs.filter((c: any) => c.status_validade === 'VENCENDO').length,
      em_atencao: certs.filter((c: any) => c.status_validade === 'ATENCAO').length,
      validos: certs.filter((c: any) => c.status_validade === 'VALIDO').length,
      sem_vencimento: certs.filter((c: any) => c.status_validade === 'SEM_VENCIMENTO').length,
      tamanho_total_mb: Math.round(certs.reduce((acc: number, c: any) => acc + (c.tamanho_bytes || 0), 0) / (1024 * 1024) * 100) / 100
    };
    
    await logAudit(c, 'READ', 'pasta_virtual_certificados', String(funcionarioId));
    
    return c.json({
      success: true,
      funcionario: funcionario,
      certificados: certs,
      estatisticas: estatisticas,
      configuracao: {
        incluir_historico: incluirHistorico,
        ordenacao: 'prioridade_status_vencimento'
      },
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Error listing certificados:', error);
    return c.json({ 
      success: false,
      error: error instanceof Error ? error.message : 'Internal server error' 
    }, 500);
  }
});

// GET /api/v2/pasta-virtual-certificados/:id/download - Download de certificado específico
app.get('/:id/download', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const certificadoId = parseInt(c.req.param('id'));
    
    if (isNaN(certificadoId)) {
      return c.json({ success: false, error: 'ID de certificado inválido' }, 400);
    }
    
    // Buscar certificado
    const certificado = await c.env.DB.prepare(`
      SELECT 
        pvsl.*,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula
      FROM pasta_virtual_sync_log pvsl
      JOIN funcionarios f ON pvsl.funcionario_id = f.id
      WHERE pvsl.id = ? AND pvsl.deleted_at IS NULL
    `).bind(certificadoId).first();
    
    if (!certificado) {
      return c.json({ success: false, error: 'Certificado não encontrado' }, 404);
    }
    
    if (certificado.status_sincronizacao !== 'SINCRONIZADO') {
      return c.json({ 
        success: false, 
        error: `Certificado não está sincronizado (status: ${certificado.status_sincronizacao})` 
      }, 400);
    }
    
    const urlDownload = certificado.arquivo_pasta_virtual_url || certificado.arquivo_original_url;
    
    if (!urlDownload || urlDownload.includes('mock://')) {
      return c.json({ 
        success: false, 
        error: 'Arquivo não disponível para download' 
      }, 404);
    }
    
    // Registrar download na auditoria
    await logAudit(c, 'DOWNLOAD', 'pasta_virtual_certificado', String(certificadoId), undefined, {
      funcionario_nome: certificado.funcionario_nome,
      funcionario_matricula: certificado.funcionario_matricula,
      treinamento_nome: certificado.treinamento_nome,
      arquivo_nome: certificado.nome_arquivo_auditavel,
      url_original: urlDownload
    });
    
    // Headers para download
    const headers = new Headers();
    headers.set('Content-Type', 'application/pdf');
    headers.set('Content-Disposition', `attachment; filename="${certificado.nome_arquivo_auditavel || 'certificado.pdf'}"`);
    headers.set('Cache-Control', 'public, max-age=3600');
    headers.set('X-Certificado-ID', String(certificadoId));
    headers.set('X-Funcionario-Matricula', certificado.funcionario_matricula);
    
    // Se for URL R2, buscar do bucket
    if (urlDownload.includes('r2.dev') && c.env.R2) {
      try {
        const r2Path = urlDownload.split('.dev/')[1];
        const objeto = await c.env.R2.get(r2Path);
        
        if (objeto) {
          return new Response(objeto.body, { 
            status: 200, 
            headers: headers 
          });
        }
      } catch (r2Error) {
        console.warn('R2 download failed, fallback to URL:', r2Error);
      }
    }
    
    // Fallback: redirecionar para URL direta
    return c.redirect(urlDownload);
    
  } catch (error) {
    console.error('Error downloading certificado:', error);
    return c.json({ 
      success: false,
      error: error instanceof Error ? error.message : 'Internal server error' 
    }, 500);
  }
});

// GET /api/v2/pasta-virtual-certificados/dashboard-compliance - Dashboard de compliance
app.get('/dashboard-compliance', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    console.log('📊 [COMPLIANCE] Carregando dashboard de compliance...');
    
    // Estatísticas gerais de compliance
    const stats = await c.env.DB.prepare(`
      SELECT 
        COUNT(DISTINCT pvsl.funcionario_id) as funcionarios_com_certificados,
        COUNT(*) as total_certificados_sincronizados,
        COUNT(CASE WHEN pvsl.status_sincronizacao = 'ERRO' THEN 1 END) as certificados_com_erro,
        COUNT(CASE WHEN pvsl.data_vencimento < DATE('now') THEN 1 END) as certificados_vencidos,
        COUNT(CASE WHEN pvsl.data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days') THEN 1 END) as vencendo_30_dias,
        COUNT(CASE WHEN pvsl.data_vencimento BETWEEN DATE('now') AND DATE('now', '+90 days') THEN 1 END) as vencendo_90_dias,
        SUM(pvsl.tamanho_bytes) as tamanho_total_bytes
      FROM pasta_virtual_sync_log pvsl
      WHERE pvsl.deleted_at IS NULL
    `).first();
    
    // Top 10 funcionários com mais certificados vencidos
    const funcionariosRisco = await c.env.DB.prepare(`
      SELECT 
        f.id, f.nome, f.matricula, f.funcao,
        COUNT(*) as total_certificados,
        COUNT(CASE WHEN pvsl.data_vencimento < DATE('now') THEN 1 END) as vencidos,
        COUNT(CASE WHEN pvsl.data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days') THEN 1 END) as vencendo_30_dias
      FROM pasta_virtual_sync_log pvsl
      JOIN funcionarios f ON pvsl.funcionario_id = f.id
      WHERE pvsl.deleted_at IS NULL AND f.deleted_at IS NULL
      GROUP BY f.id, f.nome, f.matricula, f.funcao
      HAVING vencidos > 0 OR vencendo_30_dias > 0
      ORDER BY vencidos DESC, vencendo_30_dias DESC
      LIMIT 10
    `).all();
    
    // Certificações por categoria (agrupamento)
    const porCategoria = await c.env.DB.prepare(`
      SELECT 
        ct.categoria,
        COUNT(*) as total,
        COUNT(CASE WHEN pvsl.data_vencimento < DATE('now') THEN 1 END) as vencidos,
        COUNT(CASE WHEN pvsl.data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days') THEN 1 END) as vencendo
      FROM pasta_virtual_sync_log pvsl
      JOIN historico_certificacoes_v2 hc ON pvsl.historico_cert_id = hc.id
      JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE pvsl.deleted_at IS NULL 
        AND hc.deleted_at IS NULL 
        AND ct.deleted_at IS NULL
      GROUP BY ct.categoria
      ORDER BY total DESC
    `).all();
    
    const tamanhoTotalMB = stats?.tamanho_total_bytes ? 
      Math.round(stats.tamanho_total_bytes / (1024 * 1024) * 100) / 100 : 0;
    
    return c.json({
      success: true,
      compliance_dashboard: {
        resumo_geral: {
          funcionarios_com_certificados: stats?.funcionarios_com_certificados || 0,
          total_certificados_sincronizados: stats?.total_certificados_sincronizados || 0,
          certificados_com_erro: stats?.certificados_com_erro || 0,
          certificados_vencidos: stats?.certificados_vencidos || 0,
          vencendo_30_dias: stats?.vencendo_30_dias || 0,
          vencendo_90_dias: stats?.vencendo_90_dias || 0,
          tamanho_total_mb: tamanhoTotalMB,
          taxa_compliance: stats?.total_certificados_sincronizados > 0 ? 
            Math.round(((stats.total_certificados_sincronizados - stats.certificados_vencidos) / stats.total_certificados_sincronizados) * 100) : 100
        },
        funcionarios_em_risco: funcionariosRisco.results || [],
        certificados_por_categoria: porCategoria.results || [],
        alertas: {
          criticos: stats?.certificados_vencidos || 0,
          atencao: stats?.vencendo_30_dias || 0,
          avisos: stats?.vencendo_90_dias || 0
        }
      },
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('💥 [COMPLIANCE] Erro no dashboard:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Erro interno' 
    }, 500);
  }
});

// POST /api/v2/pasta-virtual-certificados/resincronizar-todos - Re-sincronização geral
app.post('/resincronizar-todos', requirePermission('funcionarios', 'UPDATE'), async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const { limite = 100, apenas_com_erro = false } = body;
    
    console.log(`🔄 [RE-SYNC] Iniciando re-sincronização geral (limite: ${limite}, apenas erros: ${apenas_com_erro})`);
    
    let whereClause = 'AND ca.url_arquivo IS NOT NULL AND ca.url_arquivo != ""';
    if (apenas_com_erro) {
      whereClause += ' AND pvsl.status_sincronizacao = "ERRO"';
    }
    
    const anexosParaResinc = await c.env.DB.prepare(`
      SELECT DISTINCT 
        ca.id as anexo_id,
        ca.historico_id,
        f.nome as funcionario_nome,
        ct.nome as treinamento_nome,
        pvsl.tentativas_sincronizacao
      FROM certificado_anexos_v2 ca
      JOIN historico_certificacoes_v2 hc ON ca.historico_id = hc.id
      JOIN funcionarios f ON hc.funcionario_id = f.id
      JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      LEFT JOIN pasta_virtual_sync_log pvsl ON hc.id = pvsl.historico_cert_id
      WHERE hc.deleted_at IS NULL 
        AND f.deleted_at IS NULL 
        AND ct.deleted_at IS NULL
        ${whereClause}
      ORDER BY pvsl.tentativas_sincronizacao ASC NULLS FIRST
      LIMIT ?
    `).bind(limite).all();
    
    const anexos = anexosParaResinc.results || [];
    
    if (anexos.length === 0) {
      return c.json({
        success: true,
        message: 'Nenhum anexo encontrado para re-sincronização',
        data: {
          total_processados: 0,
          sincronizados: 0,
          erros: 0
        }
      });
    }
    
    const { sincronizarCertificadoParaPastaVirtual } = await import('../../services/certificado-pasta-virtual-sync');
    
    let sincronizados = 0, erros = 0;
    const resultados = [];
    
    for (const anexo of anexos) {
      try {
        const resultado = await sincronizarCertificadoParaPastaVirtual(
          anexo.anexo_id,
          c.env.DB,
          c.env.R2
        );
        
        if (resultado.success && resultado.action !== 'ALREADY_SYNCED') {
          sincronizados++;
        } else if (!resultado.success) {
          erros++;
        }
        
        resultados.push({
          anexo_id: anexo.anexo_id,
          funcionario_nome: anexo.funcionario_nome,
          treinamento_nome: anexo.treinamento_nome,
          status: resultado.success ? 'SUCESSO' : 'ERRO',
          action: resultado.action,
          error: resultado.error,
          tentativas_anteriores: anexo.tentativas_sincronizacao || 0
        });
        
      } catch (error) {
        erros++;
        resultados.push({
          anexo_id: anexo.anexo_id,
          status: 'ERRO',
          error: error instanceof Error ? error.message : 'Erro desconhecido'
        });
      }
      
      // Pausa entre sincronizações para não sobrecarregar
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    
    await logAudit(c, 'BULK_RESYNC', 'pasta_virtual_certificados', 'all', undefined, {
      total_processados: anexos.length,
      sincronizados,
      erros,
      apenas_com_erro,
      limite
    });
    
    return c.json({
      success: true,
      message: `Re-sincronização concluída: ${sincronizados} sucessos, ${erros} erros`,
      data: {
        total_processados: anexos.length,
        sincronizados,
        erros,
        taxa_sucesso: anexos.length > 0 ? Math.round((sincronizados / anexos.length) * 100) : 100,
        configuracao: {
          limite,
          apenas_com_erro
        },
        resultados: resultados.slice(0, 50) // Limitar resposta
      }
    });
    
  } catch (error) {
    console.error('💥 [RE-SYNC] Erro na re-sincronização geral:', error);
    return c.json({ 
      success: false,
      error: error instanceof Error ? error.message : 'Internal server error' 
    }, 500);
  }
});

export default app;
