import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

app.post('/', async (c) => {
  try {
    const dados = await c.req.json();
    
    // Validar dados básicos
    if (!dados.usuario_id || !dados.documento_id) {
      return c.json({
        error: 'Dados obrigatórios: usuario_id e documento_id'
      }, 400);
    }
    
    // Simular processo de assinatura digital
    const assinaturaHash = `ASS-${Date.now()}-${Math.random().toString(36).substr(2, 8)}`;
    const protocolo = `PROT-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    
    const assinatura = {
      hash: assinaturaHash,
      protocolo: protocolo,
      timestamp: new Date().toISOString(),
      usuario_id: dados.usuario_id,
      documento_id: dados.documento_id,
      tipo_assinatura: dados.tipo_assinatura || 'INSTRUTOR',
      ip_origem: c.req.header('CF-Connecting-IP') || 'unknown',
      user_agent: c.req.header('User-Agent') || 'unknown'
    };
    
    // Em uma implementação real, aqui seria feita a integração com o sistema de certificado digital
    // Por ora, retornamos uma assinatura simulada válida
    
    return c.json({
      success: true,
      assinatura: assinatura,
      message: 'Assinatura digital realizada com sucesso'
    });
    
  } catch (error) {
    console.error('❌ Erro na assinatura digital:', error);
    return c.json({ 
      error: 'Erro no processo de assinatura',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET - Verificar assinatura
app.get('/verificar/:hash', async (c) => {
  try {
    const { hash } = c.req.param();
    
    // Simular verificação de assinatura
    const isValid = hash.startsWith('ASS-');
    
    return c.json({
      success: true,
      assinatura_valida: isValid,
      hash: hash,
      verificado_em: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('❌ Erro na verificação de assinatura:', error);
    return c.json({ 
      error: 'Erro na verificação',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
