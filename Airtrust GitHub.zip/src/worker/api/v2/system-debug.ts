import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';

interface Env {
  DB: any;
  R2_BUCKET?: any;
}

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ ENDPOINT DE DEBUG OBRIGATÓRIO
app.get('/system-status', requirePermission('admin', 'READ'), async (c) => {
  try {
    console.log('🔍 === VERIFICAÇÃO COMPLETA DO SISTEMA ===');
    
    const verificacoes: any = {
      timestamp: new Date().toISOString(),
      verificacoes: {}
    };
    
    // 1. VERIFICAR FUNÇÃO DE GERAÇÃO DE ID
    try {
      console.log('🔍 Testando função de geração de ID...');
      
      // Importar a função
      const { gerarProximoCertificacaoId } = await import('../../../shared/utils/certificacao-utils');
      
      verificacoes.verificacoes.funcao_id_existe = typeof gerarProximoCertificacaoId === 'function';
      
      if (typeof gerarProximoCertificacaoId === 'function') {
        // Testar geração de ID real
        const testId = await gerarProximoCertificacaoId(c.env.DB, '00074', 'SGV', '2024-04-30');
        verificacoes.verificacoes.id_gerado_teste = testId;
        verificacoes.verificacoes.formato_correto = testId.match(/^\d{5}-[A-Z0-9]+-\d{4}-\d{2}$/);
      }
    } catch (error) {
      verificacoes.verificacoes.funcao_id_erro = error instanceof Error ? error.message : 'Erro desconhecido';
    }
    
    // 2. VERIFICAR ESTRUTURA DO BANCO - CERTIFICAÇÕES V3
    try {
      console.log('🔍 Verificando estrutura certificações v3...');
      const colunasCertV3 = await c.env.DB.prepare("PRAGMA table_info(certificacoes_v3)").all();
      verificacoes.verificacoes.colunas_certificacoes_v3 = colunasCertV3.results?.map((col: any) => col.name) || [];
      
      const temCertificacaoId = colunasCertV3.results?.some((col: any) => col.name === 'certificacao_id');
      verificacoes.verificacoes.coluna_certificacao_id_existe = temCertificacaoId;
    } catch (error) {
      verificacoes.verificacoes.certificacoes_v3_erro = error instanceof Error ? error.message : 'Erro desconhecido';
    }
    
    // 3. VERIFICAR ESTRUTURA DO BANCO - CERTIFICADO ANEXOS V2
    try {
      console.log('🔍 Verificando estrutura anexos v2...');
      const colunasAnexos = await c.env.DB.prepare("PRAGMA table_info(certificado_anexos_v2)").all();
      verificacoes.verificacoes.colunas_anexos_v2 = colunasAnexos.results?.map((col: any) => col.name) || [];
      
      const temArquivoUrl = colunasAnexos.results?.some((col: any) => col.name === 'arquivo_github_url');
      verificacoes.verificacoes.coluna_arquivo_github_existe = temArquivoUrl;
    } catch (error) {
      verificacoes.verificacoes.anexos_v2_erro = error instanceof Error ? error.message : 'Erro desconhecido';
    }
    
    // 4. VERIFICAR ÚLTIMAS CERTIFICAÇÕES V3
    try {
      console.log('🔍 Verificando últimas certificações v3...');
      const ultimasCertV3 = await c.env.DB.prepare(`
        SELECT certificacao_id, funcionario_matricula, created_at, status
        FROM certificacoes_v3 
        ORDER BY created_at DESC 
        LIMIT 5
      `).all();
      
      verificacoes.verificacoes.ultimas_certificacoes_v3 = ultimasCertV3.results || [];
      
      // Verificar formato dos IDs V3
      const formatosIncorretos = (ultimasCertV3.results || []).filter((cert: any) => 
        cert.certificacao_id && cert.certificacao_id.includes('00000-')
      );
      verificacoes.verificacoes.ids_v3_ainda_incorretos = formatosIncorretos.length;
    } catch (error) {
      verificacoes.verificacoes.certificacoes_v3_lista_erro = error instanceof Error ? error.message : 'Erro desconhecido';
    }
    
    // 5. VERIFICAR SISTEMA DE PASTA VIRTUAL
    try {
      console.log('🔍 Verificando pasta virtual...');
      const pastaVirtualExiste = await c.env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='pasta_virtual'").first();
      verificacoes.verificacoes.pasta_virtual_existe = !!pastaVirtualExiste;
      
      if (pastaVirtualExiste) {
        const colunasPastaVirtual = await c.env.DB.prepare("PRAGMA table_info(pasta_virtual)").all();
        verificacoes.verificacoes.colunas_pasta_virtual = colunasPastaVirtual.results?.map((col: any) => col.name) || [];
      }
    } catch (error) {
      verificacoes.verificacoes.pasta_virtual_erro = error instanceof Error ? error.message : 'Erro desconhecido';
    }
    
    // 6. VERIFICAR SISTEMA R2 
    try {
      console.log('🔍 Verificando R2 Bucket...');
      verificacoes.verificacoes.r2_bucket_configurado = !!c.env.R2_BUCKET;
      
      if (c.env.R2_BUCKET) {
        // Tentar listar objetos do bucket (teste básico)
        const listResult = await c.env.R2_BUCKET.list({ limit: 1 });
        verificacoes.verificacoes.r2_acesso_funcionando = !!listResult;
      }
    } catch (error) {
      verificacoes.verificacoes.r2_erro = error instanceof Error ? error.message : 'Erro desconhecido';
    }
    
    // 7. VERIFICAR HISTÓRICO CERTIFICAÇÕES V2 (sistema legado)
    try {
      console.log('🔍 Verificando histórico certificações v2...');
      const ultimasHistorico = await c.env.DB.prepare(`
        SELECT id, funcionario_id, treinamento_id, created_at
        FROM historico_certificacoes_v2 
        ORDER BY created_at DESC 
        LIMIT 3
      `).all();
      
      verificacoes.verificacoes.historico_v2_count = ultimasHistorico.results?.length || 0;
    } catch (error) {
      verificacoes.verificacoes.historico_v2_erro = error instanceof Error ? error.message : 'Erro desconhecido';
    }
    
    // DETERMINAR STATUS GERAL
    const problemas = [];
    
    if (!verificacoes.verificacoes.funcao_id_existe) {
      problemas.push('Função de geração de ID não implementada');
    }
    if (!verificacoes.verificacoes.formato_correto) {
      problemas.push('Formato de ID incorreto');
    }
    if ((verificacoes.verificacoes.ids_v3_ainda_incorretos || 0) > 0) {
      problemas.push(`${verificacoes.verificacoes.ids_v3_ainda_incorretos} IDs V3 ainda no formato incorreto`);
    }
    if (!verificacoes.verificacoes.coluna_certificacao_id_existe) {
      problemas.push('Coluna certificacao_id não existe na tabela certificacoes_v3');
    }
    if (!verificacoes.verificacoes.coluna_arquivo_github_existe) {
      problemas.push('Coluna arquivo_github_url não existe na tabela certificado_anexos_v2');
    }
    if (!verificacoes.verificacoes.pasta_virtual_existe) {
      problemas.push('Tabela pasta_virtual não existe');
    }
    if (!verificacoes.verificacoes.r2_bucket_configurado) {
      problemas.push('R2 Bucket não configurado');
    }
    
    verificacoes.status_geral = problemas.length === 0 ? 'OK' : 'PROBLEMAS_DETECTADOS';
    verificacoes.problemas = problemas;
    verificacoes.total_problemas = problemas.length;
    
    console.log(`📊 Status geral: ${verificacoes.status_geral} (${problemas.length} problemas)`);
    
    return c.json({
      success: true,
      data: verificacoes
    });
    
  } catch (error) {
    console.error('💥 Erro na verificação:', error);
    return c.json({
      success: false,
      error: `Erro na verificação: ${error instanceof Error ? error.message : 'Erro desconhecido'}`,
      timestamp: new Date().toISOString()
    }, 500);
  }
});

// ✅ ENDPOINT DE IMPLEMENTAÇÃO COM VERIFICAÇÃO AUTOMÁTICA
app.post('/implement-with-verification', requirePermission('admin', 'CREATE'), async (c) => {
  try {
    console.log('🔧 === IMPLEMENTAÇÃO COM VERIFICAÇÃO ===');
    
    const verificacoes = [];
    const db = c.env.DB;
    
    // 1. CRIAR TABELA PASTA VIRTUAL SE NÃO EXISTIR
    console.log('📝 Criando tabela pasta_virtual...');
    
    try {
      await db.prepare(`
        CREATE TABLE IF NOT EXISTS pasta_virtual (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          funcionario_id INTEGER NOT NULL,
          tipo_documento TEXT NOT NULL,
          nome_arquivo TEXT NOT NULL,
          caminho_arquivo TEXT NOT NULL,
          certificacao_id INTEGER NULL,
          descricao TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          deleted_at TEXT NULL
        )
      `).run();
      
      verificacoes.push({
        item: 'Tabela pasta_virtual',
        status: 'OK',
        acao: 'Criada ou já existia'
      });
    } catch (error) {
      verificacoes.push({
        item: 'Tabela pasta_virtual',
        status: 'ERRO',
        erro: error instanceof Error ? error.message : 'Erro desconhecido'
      });
    }
    
    // 2. VERIFICAR E ADICIONAR COLUNAS NECESSÁRIAS
    console.log('📝 Verificando colunas necessárias...');
    
    try {
      // Tentar adicionar colunas na tabela historico_certificacoes_v2 se não existirem
      const colunasExistentes = await db.prepare("PRAGMA table_info(historico_certificacoes_v2)").all();
      const nomesColunas = colunasExistentes.results?.map((col: any) => col.name) || [];
      
      if (!nomesColunas.includes('arquivo_url')) {
        await db.prepare('ALTER TABLE historico_certificacoes_v2 ADD COLUMN arquivo_url TEXT').run();
        verificacoes.push({ item: 'Coluna arquivo_url', status: 'ADICIONADA' });
      } else {
        verificacoes.push({ item: 'Coluna arquivo_url', status: 'JA_EXISTE' });
      }
      
      if (!nomesColunas.includes('arquivo_nome')) {
        await db.prepare('ALTER TABLE historico_certificacoes_v2 ADD COLUMN arquivo_nome TEXT').run();
        verificacoes.push({ item: 'Coluna arquivo_nome', status: 'ADICIONADA' });
      } else {
        verificacoes.push({ item: 'Coluna arquivo_nome', status: 'JA_EXISTE' });
      }
      
    } catch (error) {
      verificacoes.push({
        item: 'Colunas adicionais',
        status: 'ERRO',
        erro: error instanceof Error ? error.message : 'Erro desconhecido'
      });
    }
    
    // 3. TESTAR FUNÇÃO DE GERAÇÃO DE ID
    console.log('🧪 Testando função de geração de ID...');
    
    try {
      const { gerarProximoCertificacaoId } = await import('../../../shared/utils/certificacao-utils');
      
      const testeId = await gerarProximoCertificacaoId(db, '00074', 'SGV', '2024-04-30');
      
      verificacoes.push({
        item: 'Função geração ID',
        status: 'OK',
        resultado: testeId,
        formato_correto: testeId.match(/^\d{5}-[A-Z0-9]+-\d{4}-\d{2}$/) ? 'SIM' : 'NÃO'
      });
    } catch (error) {
      verificacoes.push({
        item: 'Função geração ID',
        status: 'ERRO',
        erro: error instanceof Error ? error.message : 'Erro desconhecido'
      });
    }
    
    // 4. TESTAR COM DADOS REAIS
    console.log('🧪 Testando correções com dados reais...');
    
    try {
      const funcionarios = await db.prepare("SELECT id, matricula FROM funcionarios WHERE deleted_at IS NULL LIMIT 3").all();
      const treinamentos = await db.prepare("SELECT id, codigo FROM catalogo_treinamentos_v2 WHERE deleted_at IS NULL LIMIT 3").all();
      
      if ((funcionarios.results?.length || 0) > 0 && (treinamentos.results?.length || 0) > 0) {
        const func = funcionarios.results[0];
        const trein = treinamentos.results[0];
        
        const { gerarProximoCertificacaoId } = await import('../../../shared/utils/certificacao-utils');
        const idTeste = await gerarProximoCertificacaoId(db, String(func.matricula).padStart(5, '0'), trein.codigo, '2024-09-17');
        
        verificacoes.push({
          item: 'Teste ID com dados reais',
          status: 'OK',
          funcionario_matricula: func.matricula,
          id_gerado: idTeste,
          formato_esperado: `${String(func.matricula).padStart(5, '0')}-${trein.codigo}-2024-XX`
        });
      }
    } catch (error) {
      verificacoes.push({
        item: 'Teste ID com dados reais',
        status: 'ERRO',
        erro: error instanceof Error ? error.message : 'Erro desconhecido'
      });
    }
    
    return c.json({
      success: true,
      message: 'Implementação executada com verificação',
      verificacoes: verificacoes,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: `Erro na implementação: ${error instanceof Error ? error.message : 'Erro desconhecido'}`
    }, 500);
  }
});

export default app;
