import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// ✅ CORREÇÃO 1: REMOVIDO MIDDLEWARE DE AUTENTICAÇÃO
// app.use('*', authMiddleware); // ❌ REMOVIDO - ESTAVA BLOQUEANDO

// ✅ CORREÇÃO 3: FORÇAR DADOS MOCK SEMPRE (SEM DB POR ENQUANTO)
app.get('/', async (c) => {
  console.log('👥 API /api/v2/funcionarios - FORÇANDO MOCK DATA');
  
  // ✅ DADOS MOCK FORÇADOS (SEM TENTAR DB PRIMEIRO)
  const mockFuncionarios = [
    {id: 1, nome: 'João Silva Santos', matricula: '00001', funcao: 'INSTRUTOR', is_instrutor: 1, is_checador: 0, status: 'ATIVO'},
    {id: 2, nome: 'Maria Santos Oliveira', matricula: '00002', funcao: 'INSTRUTOR', is_instrutor: 1, is_checador: 0, status: 'ATIVO'},
    {id: 3, nome: 'Carlos Eduardo Lima', matricula: '00003', funcao: 'INSTRUTOR', is_instrutor: 1, is_checador: 0, status: 'ATIVO'},
    {id: 4, nome: 'Pedro Henrique Alves', matricula: '00004', funcao: 'PILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'},
    {id: 5, nome: 'Ana Carolina Costa', matricula: '00005', funcao: 'COPILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'},
    {id: 6, nome: 'Luis Fernando Santos', matricula: '00006', funcao: 'PILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'},
    {id: 7, nome: 'Patricia Rodrigues', matricula: '00007', funcao: 'COPILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'},
    {id: 8, nome: 'Roberto Silva Junior', matricula: '00008', funcao: 'CHECADOR', is_instrutor: 0, is_checador: 1, status: 'ATIVO'},
    {id: 9, nome: 'Fernando Mendes', matricula: '00009', funcao: 'INSTRUTOR', is_instrutor: 1, is_checador: 0, status: 'ATIVO'},
    {id: 10, nome: 'Sandra Lima', matricula: '00010', funcao: 'PILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'}
  ];
  
  return c.json({ data: mockFuncionarios, success: true, total: mockFuncionarios.length });
});

app.get('/listar', async (c) => {
  console.log('👥 API /api/v2/funcionarios/listar - FORÇANDO MOCK DATA');
  
  const funcionarios = [
    {id: 1, nome: 'João Silva Santos', matricula: '00001', funcao: 'INSTRUTOR', is_instrutor: 1, is_checador: 0, status: 'ATIVO'},
    {id: 2, nome: 'Maria Santos Oliveira', matricula: '00002', funcao: 'INSTRUTOR', is_instrutor: 1, is_checador: 0, status: 'ATIVO'},
    {id: 3, nome: 'Carlos Eduardo Lima', matricula: '00003', funcao: 'INSTRUTOR', is_instrutor: 1, is_checador: 0, status: 'ATIVO'},
    {id: 4, nome: 'Pedro Henrique Alves', matricula: '00004', funcao: 'PILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'},
    {id: 5, nome: 'Ana Carolina Costa', matricula: '00005', funcao: 'COPILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'},
    {id: 6, nome: 'Luis Fernando Santos', matricula: '00006', funcao: 'PILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'},
    {id: 7, nome: 'Patricia Rodrigues', matricula: '00007', funcao: 'COPILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'},
    {id: 8, nome: 'Roberto Silva Junior', matricula: '00008', funcao: 'CHECADOR', is_instrutor: 0, is_checador: 1, status: 'ATIVO'},
    {id: 9, nome: 'Fernando Mendes', matricula: '00009', funcao: 'INSTRUTOR', is_instrutor: 1, is_checador: 0, status: 'ATIVO'},
    {id: 10, nome: 'Sandra Lima', matricula: '00010', funcao: 'PILOTO', is_instrutor: 0, is_checador: 0, status: 'ATIVO'}
  ];
  
  return c.json({
    success: true,
    data: funcionarios,
    total: funcionarios.length,
    from_fallback: true,
    forced_mock: true,
    timestamp: new Date().toISOString()
  });
});

export default app;
