import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

// PUT - Salvar avaliação da ficha
app.put('/:uuid/avaliar', async (c) => {
  try {
    const db = c.env.DB;
    const { uuid } = c.req.param();
    const dadosAvaliacao = await c.req.json();
    
    console.log(`💾 Salvando avaliação da ficha: ${uuid}`);
    console.log('Dados recebidos:', dadosAvaliacao);
    
    // Verificar se ficha existe
    const ficha = await db.prepare(`
      SELECT id, status_workflow FROM fichas_sessao WHERE ficha_uuid = ?
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // Verificar se pode ser avaliada
    const statusPermitidos = ['RASCUNHO', 'PENDENTE_ALUNO', 'PENDENTE_INSTRUTOR_FINAL'];
    if (!statusPermitidos.includes(ficha.status_workflow)) {
      return c.json({
        error: 'Esta ficha não pode ser avaliada no status atual',
        status_atual: ficha.status_workflow
      }, 400);
    }
    
    // Atualizar manobras avaliadas
    if (dadosAvaliacao.manobras && Array.isArray(dadosAvaliacao.manobras)) {
      for (const manobra of dadosAvaliacao.manobras) {
        console.log(`Atualizando manobra ${manobra.id || manobra.manobra_id}:`, manobra);
        
        // Verificar se a avaliação já existe
        const avaliacaoExistente = await db.prepare(`
          SELECT id FROM fichas_manobras_executadas 
          WHERE ficha_id = ? AND manobra_catalogo_id = ?
        `).bind(ficha.id, manobra.id || manobra.manobra_id).first();
        
        const notaFinal = manobra.nota === 'NR' ? null : parseFloat(manobra.nota);
        
        if (avaliacaoExistente) {
          // Atualizar avaliação existente
          await db.prepare(`
            UPDATE fichas_manobras_executadas 
            SET nota = ?, observacoes = ?
            WHERE ficha_id = ? AND manobra_catalogo_id = ?
          `).bind(
            notaFinal,
            manobra.observacoes || null,
            ficha.id,
            manobra.id || manobra.manobra_id
          ).run();
        } else {
          // Criar nova avaliação
          await db.prepare(`
            INSERT INTO fichas_manobras_executadas (
              ficha_id, manobra_catalogo_id, nota, observacoes
            ) VALUES (?, ?, ?, ?)
          `).bind(
            ficha.id,
            manobra.id || manobra.manobra_id,
            notaFinal,
            manobra.observacoes || null
          ).run();
        }
      }
    }
    
    // Calcular nota final
    const manobrasAvaliadas = await db.prepare(`
      SELECT nota FROM fichas_manobras_executadas 
      WHERE ficha_id = ? AND nota IS NOT NULL
    `).bind(ficha.id).all();
    
    const notasValidas = manobrasAvaliadas.results
      .filter((m: any) => m.nota !== null)
      .map((m: any) => Number(m.nota));
    
    const notaFinal = notasValidas.length > 0 
      ? notasValidas.reduce((sum: number, nota: number) => sum + nota, 0) / notasValidas.length 
      : null;
    
    // Aplicar regra rigorosa: qualquer nota < 5 = REPROVADO
    const temNotaBaixa = notasValidas.some((nota: number) => nota < 5);
    const conceitoFinal = notaFinal !== null 
      ? (temNotaBaixa ? 'REPROVADO' : 'APROVADO')
      : null;
    
    // Determinar próximo status
    let novoStatus = ficha.status_workflow;
    if (dadosAvaliacao.finalizar === true) {
      if (conceitoFinal === 'REPROVADO') {
        novoStatus = 'REPROVADA';
      } else {
        novoStatus = 'PENDENTE_CHECK';
      }
    }
    
    // Atualizar ficha
    await db.prepare(`
      UPDATE fichas_sessao 
      SET resultado_final = ?, nota_final = ?, 
          status_workflow = ?, observacoes_instrutor = ?, updated_at = datetime('now')
      WHERE id = ?
    `).bind(
      conceitoFinal,
      notaFinal,
      novoStatus,
      dadosAvaliacao.observacoes_gerais || null,
      ficha.id
    ).run();
    
    // Registrar auditoria
    await db.prepare(`
      INSERT INTO auditoria_simulador (
        ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem, timestamp_acao
      ) VALUES (?, ?, ?, ?, ?, datetime('now'))
    `).bind(
      uuid,
      999, // TODO: pegar usuário do contexto
      'AVALIACAO_SALVA',
      JSON.stringify({ 
        manobras_avaliadas: dadosAvaliacao.manobras?.length || 0,
        nota_final: notaFinal,
        conceito: conceitoFinal,
        status_anterior: ficha.status_workflow,
        status_novo: novoStatus
      }),
      c.req.header('CF-Connecting-IP') || 'unknown'
    ).run();
    
    console.log(`✅ Avaliação salva: nota=${notaFinal}, conceito=${conceitoFinal}, status=${novoStatus}`);
    
    return c.json({
      success: true,
      ficha: {
        uuid: uuid,
        resultado_final: conceitoFinal,
        nota_final: notaFinal,
        status_workflow: novoStatus
      },
      message: 'Avaliação salva com sucesso'
    });
    
  } catch (error) {
    console.error(`❌ Erro ao salvar avaliação ${c.req.param('uuid')}:`, error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET - Buscar dados para avaliação
app.get('/:uuid/avaliar', async (c) => {
  try {
    const db = c.env.DB;
    const { uuid } = c.req.param();
    
    console.log(`📋 Carregando dados para avaliação da ficha: ${uuid}`);
    
    // Buscar ficha com informações completas
    const ficha = await db.prepare(`
      SELECT 
        f.id, f.ficha_uuid, f.status_workflow, f.resultado_final, f.nota_final,
        f.observacoes_instrutor, f.ciclo_executado, f.sessao_template_id,
        slot.data_inicio, slot.data_fim,
        sim.nome as simulador_nome,
        inst.nome as instrutor_nome,
        aluno.nome as aluno_nome, aluno.matricula as aluno_matricula,
        st.nome_sessao as template_nome
      FROM fichas_sessao f
      LEFT JOIN agendamento_slots slot ON f.agendamento_slot_id = slot.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      LEFT JOIN funcionarios aluno ON f.colaborador_id_aluno = aluno.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.ficha_uuid = ?
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // Buscar manobras com avaliações existentes
    const manobras = await db.prepare(`
      SELECT DISTINCT
        mc.id,
        mc.manobra_id_codigo,
        mc.nome_manobra,
        mc.categoria,
        mc.criterios_aprovacao,
        mc.pontuacao_minima,
        COALESCE(me.nota, 'NR') as nota,
        me.observacoes
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      LEFT JOIN fichas_manobras_executadas me ON me.ficha_id = ? AND me.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ?
      AND mc.ativo = 1
      ORDER BY mc.categoria, mc.manobra_id_codigo
    `).bind(ficha.id, ficha.sessao_template_id).all();
    
    return c.json({
      success: true,
      ficha: {
        uuid: ficha.ficha_uuid,
        status_workflow: ficha.status_workflow,
        resultado_final: ficha.resultado_final,
        nota_final: ficha.nota_final,
        observacoes_instrutor: ficha.observacoes_instrutor,
        aluno: {
          nome: ficha.aluno_nome,
          matricula: ficha.aluno_matricula
        },
        simulador: ficha.simulador_nome,
        instrutor: ficha.instrutor_nome,
        template: ficha.template_nome,
        data_sessao: ficha.data_inicio
      },
      manobras: manobras.results.map((m: any) => ({
        id: m.id,
        codigo: m.manobra_id_codigo,
        nome: m.nome_manobra,
        categoria: m.categoria,
        criterios: m.criterios_aprovacao,
        pontuacao_minima: m.pontuacao_minima,
        nota: m.nota,
        observacoes: m.observacoes
      }))
    });
    
  } catch (error) {
    console.error(`❌ Erro ao carregar dados para avaliação ${c.req.param('uuid')}:`, error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
