import { Hono } from 'hono';
import type { Env } from '../../types/index';

const agendamentoApi = new Hono<{ Bindings: Env }>();

// ✅ CORREÇÃO 1: LISTA EM MEMÓRIA PARA SINCRONIZAR POST E GET
let sessoesSalvasMemoria: any[] = [];

// Função auxiliar para obter nome de instrutor
const obterNomeInstrutor = (instrutor_id: number) => {
  const instrutores: Record<number, string> = {
    1: 'Ana Paula Santos',
    2: 'Carlos Alberto Silva',
    3: 'Maria Fernanda Costa',
    4: 'João Pedro Oliveira',
    5: 'Patricia Regina Alves'
  };
  return instrutores[instrutor_id] || `Instrutor ${instrutor_id}`;
};

// Função auxiliar para formatação de datas
const formatarDataCompleta = (data: string, hora?: string) => {
  if (!data) return new Date().toISOString().slice(0, 19).replace('T', ' ');
  const dataBase = data.includes('T') ? data : `${data}T${hora || '08:00'}:00`;
  return new Date(dataBase).toISOString().slice(0, 19).replace('T', ' ');
};

// POST - Criar agendamento
agendamentoApi.post('/', async (c) => {
  try {
    const db = c.env.DB;
    const dados = await c.req.json();
    
    console.log('📥 Dados recebidos:', JSON.stringify(dados, null, 2));
    
    // Validação manual simples
    if (!dados.dados_gerais) {
      return c.json({
        success: false, 
        error: 'dados_gerais obrigatório'
      }, 400);
    }
    
    const dg = dados.dados_gerais;
    
    if (!dg.simulador_id) {
      return c.json({success: false, error: 'simulador_id obrigatório'}, 400);
    }
    
    if (!dg.instrutor_id) {
      return c.json({success: false, error: 'instrutor_id obrigatório'}, 400);
    }
    
    if (!dg.data_inicio) {
      return c.json({success: false, error: 'data_inicio obrigatória'}, 400);
    }
    
    // Criar agendamento
    const dataInicio = formatarDataCompleta(dg.data_inicio, dg.hora_inicio);
    const dataFim = formatarDataCompleta(dg.data_fim || dg.data_inicio, dg.hora_fim);
    
    const slotResult = await db.prepare(`
      INSERT INTO agendamento_slots (
        simulador_id, colaborador_id_instrutor, colaborador_id_checador, data_inicio, data_fim, 
        status_slot, created_at, updated_at, created_by
      ) VALUES (?, ?, ?, ?, ?, 'AGENDADO', datetime('now'), datetime('now'), 'SISTEMA')
    `).bind(
      dg.simulador_id,
      dg.instrutor_id,
      dg.checador_id || null,
      dataInicio,
      dataFim
    ).run();
    
    const agendamentoId = slotResult.meta.last_row_id;
    const fichasCriadas = [];
    
    // Criar fichas para participantes se fornecidos
    if (dados.participantes && Array.isArray(dados.participantes)) {
      for (const participante of dados.participantes) {
        // ✅ CORREÇÃO 4: UUID CURTO E REALISTA
        const fichaUuid = `F${Date.now()}P${participante.colaborador_id || participante.id}`;
        
        const fichaResult = await db.prepare(`
          INSERT INTO fichas_sessao (
            ficha_uuid, agendamento_slot_id, colaborador_id_aluno, 
            funcao_na_sessao, sessao_template_id, ciclo_executado,
            status_workflow, created_at, updated_at, created_by
          ) VALUES (?, ?, ?, ?, ?, ?, 'RASCUNHO', datetime('now'), datetime('now'), 'SISTEMA')
        `).bind(
          fichaUuid,
          agendamentoId,
          participante.colaborador_id || participante.id,
          participante.funcao_na_sessao || 'PIC',
          participante.template_id || 1,
          participante.ciclo || 1
        ).run();
        
        fichasCriadas.push({
          id: fichaResult.meta.last_row_id,
          ficha_uuid: fichaUuid,
          colaborador_id_aluno: participante.colaborador_id || participante.id,
          aluno_nome: participante.nome || `Aluno ${participante.colaborador_id || participante.id}`,
          aluno_matricula: participante.matricula || `00${(participante.colaborador_id || participante.id).toString().padStart(3, '0')}`,
          funcao_na_sessao: participante.funcao_na_sessao || 'PIC',
          template_nome: 'Template Padrão',
          template_numero: 1,
          ciclo_executado: participante.ciclo || 1,
          status_workflow: 'RASCUNHO',
          resultado_final: null,
          nota_final: null
        });
      }
    }

    // ✅ CORREÇÃO 1: ADICIONAR À LISTA DE MEMÓRIA
    const novoAgendamento = {
      id: agendamentoId,
      simulador_id: dg.simulador_id,
      simulador_nome: `Simulador A320-${dg.simulador_id.toString().padStart(3, '0')}`,
      simulador_codigo: `SIM-A320-${dg.simulador_id.toString().padStart(3, '0')}`,
      colaborador_id_instrutor: dg.instrutor_id,
      instrutor_nome: obterNomeInstrutor(dg.instrutor_id),
      instrutor_matricula: `I${dg.instrutor_id.toString().padStart(4, '0')}`,
      colaborador_id_checador: dg.checador_id || null,
      checador_nome: dg.checador_id ? obterNomeInstrutor(dg.checador_id) : null,
      checador_matricula: dg.checador_id ? `C${dg.checador_id.toString().padStart(4, '0')}` : null,
      data_inicio: dataInicio,
      data_fim: dataFim,
      status_slot: 'AGENDADO',
      created_at: new Date().toISOString(),
      fichas: fichasCriadas
    };

    // ✅ ADICIONAR À LISTA QUE O GET USA
    sessoesSalvasMemoria.push(novoAgendamento);
    
    console.log('✅ Agendamento adicionado à memória:', {
      id: agendamentoId,
      total_na_memoria: sessoesSalvasMemoria.length,
      fichas_criadas: fichasCriadas.length
    });
    
    return c.json({
      success: true,
      agendamento: novoAgendamento,
      participantes_count: fichasCriadas.length,
      message: 'Agendamento criado com sucesso'
    });
    
  } catch (error) {
    console.error('❌ Erro no agendamento:', error);
    return c.json({
      success: false, 
      error: 'Erro interno do servidor',
      details: (error as Error).message
    }, 500);
  }
});

// ✅ CORREÇÃO 2: ENDPOINT DELETE
agendamentoApi.delete('/:id', async (c) => {
  try {
    const { id } = c.req.param();
    const agendamentoId = parseInt(id);
    
    console.log('🗑️ Excluindo sessão:', agendamentoId);
    
    // Remover da lista em memória
    const indexAntes = sessoesSalvasMemoria.length;
    sessoesSalvasMemoria = sessoesSalvasMemoria.filter(s => s.id !== agendamentoId);
    const indexDepois = sessoesSalvasMemoria.length;
    
    // Soft delete no banco
    const db = c.env.DB;
    await db.prepare(`
      UPDATE fichas_sessao 
      SET deleted_at = datetime('now'), updated_at = datetime('now')
      WHERE agendamento_slot_id = ? AND deleted_at IS NULL
    `).bind(agendamentoId).run();
    
    console.log('✅ Sessão excluída:', {
      id: agendamentoId,
      removido_da_memoria: indexAntes > indexDepois,
      total_restante: indexDepois
    });
    
    return c.json({ 
      success: true, 
      message: `Sessão ${agendamentoId} excluída com sucesso`,
      total_restante: indexDepois
    });
    
  } catch (error) {
    console.error('❌ Erro ao excluir sessão:', error);
    return c.json({
      success: false,
      error: 'Erro ao excluir sessão',
      details: (error as Error).message
    }, 500);
  }
});

// GET /api/v2/simulador/slots - ✅ CORREÇÃO 1: RETORNAR DADOS DA LISTA ATUALIZADA
agendamentoApi.get('/slots', async (c) => {
  try {
    const db = c.env.DB;
    
    console.log('🔍 Buscando slots de simulador...');
    
    // Buscar slots com dados completos do banco
    const slotsQuery = await db.prepare(`
      SELECT 
        s.id,
        s.simulador_id,
        s.colaborador_id_instrutor,
        s.colaborador_id_checador,
        s.data_inicio,
        s.data_fim,
        s.status_slot,
        s.created_at,
        sim.nome as simulador_nome,
        sim.codigo_identificacao as simulador_codigo,
        inst.nome as instrutor_nome,
        inst.matricula as instrutor_matricula,
        check.nome as checador_nome,
        check.matricula as checador_matricula
      FROM agendamento_slots s
      LEFT JOIN simuladores sim ON s.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON s.colaborador_id_instrutor = inst.id  
      LEFT JOIN funcionarios check ON s.colaborador_id_checador = check.id
      WHERE s.id NOT IN (
        SELECT DISTINCT agendamento_slot_id 
        FROM fichas_sessao 
        WHERE deleted_at IS NOT NULL
      )
      ORDER BY s.data_inicio DESC
      LIMIT 50
    `).all();

    console.log(`📊 Slots do banco: ${slotsQuery.results.length}`);
    console.log(`📊 Slots na memória: ${sessoesSalvasMemoria.length}`);

    const slots = [];

    // Processar slots do banco
    for (const slot of slotsQuery.results) {
      const fichasQuery = await db.prepare(`
        SELECT 
          fs.id,
          fs.ficha_uuid,
          fs.colaborador_id_aluno,
          fs.funcao_na_sessao,
          fs.sessao_template_id,
          fs.ciclo_executado,
          fs.status_workflow,
          fs.resultado_final,
          fs.nota_final,
          aluno.nome as aluno_nome,
          aluno.matricula as aluno_matricula,
          st.nome as template_nome,
          st.numero_sessao as template_numero
        FROM fichas_sessao fs
        LEFT JOIN funcionarios aluno ON fs.colaborador_id_aluno = aluno.id
        LEFT JOIN sessoes_template st ON fs.sessao_template_id = st.id
        WHERE fs.agendamento_slot_id = ? AND fs.deleted_at IS NULL
      `).bind(slot.id).all();

      const fichas = fichasQuery.results.map((ficha: any) => ({
        id: ficha.id,
        ficha_uuid: ficha.ficha_uuid,
        colaborador_id_aluno: ficha.colaborador_id_aluno,
        aluno_nome: ficha.aluno_nome || 'Aluno não encontrado',
        aluno_matricula: ficha.aluno_matricula || 'N/A',
        funcao_na_sessao: ficha.funcao_na_sessao || 'PIC',
        template_nome: ficha.template_nome || 'Template Padrão',
        template_numero: ficha.template_numero || 1,
        ciclo_executado: ficha.ciclo_executado || 1,
        status_workflow: ficha.status_workflow || 'RASCUNHO',
        resultado_final: ficha.resultado_final,
        nota_final: ficha.nota_final
      }));

      slots.push({
        id: slot.id,
        simulador_id: slot.simulador_id,
        simulador_nome: slot.simulador_nome || 'Simulador não encontrado',
        simulador_codigo: slot.simulador_codigo || 'N/A',
        colaborador_id_instrutor: slot.colaborador_id_instrutor,
        instrutor_nome: slot.instrutor_nome || 'Instrutor não encontrado',
        instrutor_matricula: slot.instrutor_matricula || 'N/A',
        colaborador_id_checador: slot.colaborador_id_checador,
        checador_nome: slot.checador_nome,
        checador_matricula: slot.checador_matricula,
        data_inicio: slot.data_inicio,
        data_fim: slot.data_fim,
        status_slot: slot.status_slot || 'AGENDADO',
        created_at: slot.created_at,
        fichas: fichas
      });
    }

    // ✅ ADICIONAR SESSÕES DA MEMÓRIA
    for (const sessaoMemoria of sessoesSalvasMemoria) {
      // Verificar se já não está na lista (evitar duplicatas)
      if (!slots.find(s => s.id === sessaoMemoria.id)) {
        slots.push(sessaoMemoria);
      }
    }

    // Se ainda não há dados, fornecer dados mock
    if (slots.length === 0) {
      console.log('🔄 Nenhum slot encontrado, gerando dados mock...');
      
      const hoje = new Date();
      const amanha = new Date(hoje);
      amanha.setDate(hoje.getDate() + 1);
      
      const dataAmanhaStr = `${amanha.getFullYear()}-${String(amanha.getMonth() + 1).padStart(2, '0')}-${String(amanha.getDate()).padStart(2, '0')}`;
      
      return c.json({ 
        success: true,
        slots: [
          {
            id: 999,
            simulador_id: 1,
            simulador_nome: 'Simulador A320-001',
            simulador_codigo: 'SIM-A320-001',
            colaborador_id_instrutor: 1,
            instrutor_nome: 'Ana Paula Santos',
            instrutor_matricula: '12345',
            colaborador_id_checador: null,
            checador_nome: null,
            checador_matricula: null,
            data_inicio: `${dataAmanhaStr} 08:00:00`,
            data_fim: `${dataAmanhaStr} 10:00:00`,
            status_slot: 'AGENDADO',
            created_at: new Date().toISOString(),
            fichas: [
              {
                id: 999,
                ficha_uuid: 'F1758930641045P1',
                colaborador_id_aluno: 2,
                aluno_nome: 'Pedro Henrique Alves',
                aluno_matricula: '00300',
                funcao_na_sessao: 'PIC',
                template_nome: 'Template Padrão',
                template_numero: 1,
                ciclo_executado: 1,
                status_workflow: 'RASCUNHO',
                resultado_final: null,
                nota_final: null
              }
            ]
          }
        ],
        total: 1,
        from_mock: true
      });
    }

    console.log(`✅ Retornando ${slots.length} slots (${slotsQuery.results.length} do banco + ${sessoesSalvasMemoria.length} da memória)`);

    return c.json({ 
      success: true,
      slots: slots,
      total: slots.length 
    });

  } catch (error) {
    console.error('❌ Erro ao buscar slots:', error);
    return c.json({ 
      success: false,
      error: 'Erro interno do servidor',
      details: (error as Error).message,
      slots: []
    }, 500);
  }
});

// PUT - Editar agendamento
agendamentoApi.put('/:uuid', async (c) => {
  const {uuid} = c.req.param();
  const dados = await c.req.json();
  
  try {
    const db = c.env.DB;
    
    // Verificar se existe
    const agendamento = await db.prepare(`
      SELECT fs.id, fs.agendamento_slot_id 
      FROM fichas_sessao fs 
      WHERE fs.ficha_uuid = ? AND fs.deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!agendamento) {
      return c.json({success: false, error: 'Agendamento não encontrado'}, 404);
    }
    
    // Atualizar slot se dados_gerais fornecidos
    if (dados.dados_gerais) {
      const dg = dados.dados_gerais;
      const dataInicio = dg.data_inicio && dg.hora_inicio 
        ? `${dg.data_inicio} ${dg.hora_inicio}:00`
        : null;
      const dataFim = dg.data_fim && dg.hora_fim
        ? `${dg.data_fim} ${dg.hora_fim}:00`
        : null;
        
      await db.prepare(`
        UPDATE agendamento_slots 
        SET simulador_id = COALESCE(?, simulador_id),
            colaborador_id_instrutor = COALESCE(?, colaborador_id_instrutor),
            data_inicio = COALESCE(?, data_inicio),
            data_fim = COALESCE(?, data_fim),
            updated_at = datetime('now')
        WHERE id = ?
      `).bind(
        dg.simulador_id || null,
        dg.instrutor_id || null,
        dataInicio,
        dataFim,
        agendamento.agendamento_slot_id
      ).run();
    }
    
    return c.json({
      success: true,
      message: `Agendamento ${uuid} atualizado`,
      dados: {...dados, updated_at: new Date().toISOString()}
    });
    
  } catch (error) {
    return c.json({success: false, error: (error as Error).message}, 500);
  }
});

// PUT - Alterar status de ficha
agendamentoApi.put('/ficha/:uuid/status', async (c) => {
  const {uuid} = c.req.param();
  const {status} = await c.req.json();
  
  try {
    const db = c.env.DB;
    
    const resultado = await db.prepare(`
      UPDATE fichas_sessao 
      SET status_workflow = ?, updated_at = datetime('now')
      WHERE ficha_uuid = ? AND deleted_at IS NULL
    `).bind(status, uuid).run();
    
    if (resultado.changes === 0) {
      return c.json({success: false, error: 'Ficha não encontrada'}, 404);
    }
    
    return c.json({
      success: true,
      message: `Status da ficha ${uuid} alterado para ${status}`,
      novo_status: status,
      updated_at: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({success: false, error: (error as Error).message}, 500);
  }
});

export default agendamentoApi;
