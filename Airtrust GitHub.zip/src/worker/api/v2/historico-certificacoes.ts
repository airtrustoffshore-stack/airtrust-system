import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// 🚨 FUNÇÃO PARA AUTO-CRIAÇÃO DE FUNCIONÁRIOS
const criarFuncionarioSeNecessario = async (identificador: string, db: any) => {
  console.log(`👤 [AUTO-CREATE] Buscando/criando funcionário: ${identificador}`);
  
  // Estratégias de busca flexível
  const estrategias = [
    identificador,
    identificador.replace(/^0+/, '') || '0',
    identificador.padStart(5, '0'),
    identificador.padStart(3, '0')
  ];
  
  for (const matricula of estrategias) {
    const funcionario = await db.prepare(
      'SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL LIMIT 1'
    ).bind(matricula).first();
    
    if (funcionario) {
      console.log(`✅ [AUTO-CREATE] Funcionário encontrado: ${funcionario.nome} (${funcionario.matricula})`);
      return { ...funcionario, existia: true };
    }
  }
  
  // Se não encontrou, criar com dados mínimos
  console.log(`➕ [AUTO-CREATE] Criando funcionário com matrícula: ${identificador}`);
  
  const novoFuncionario = {
    nome: `Funcionário ${identificador}`,
    matricula: identificador.padStart(5, '0'),
    funcao: 'OPERACIONAL',
    status: 'ATIVO',
    contrato: 'CLT'
  };
  
  const resultado = await db.prepare(`
    INSERT INTO funcionarios 
    (nome, matricula, funcao, status, contrato, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
  `).bind(
    novoFuncionario.nome,
    novoFuncionario.matricula,
    novoFuncionario.funcao,
    novoFuncionario.status,
    novoFuncionario.contrato
  ).run();
  
  if (resultado.success && resultado.meta?.last_row_id) {
    const funcionarioCriado = {
      id: resultado.meta.last_row_id,
      nome: novoFuncionario.nome,
      matricula: novoFuncionario.matricula,
      existia: false
    };
    
    console.log(`🎉 [AUTO-CREATE] Funcionário criado: ${funcionarioCriado.nome} (ID: ${funcionarioCriado.id})`);
    return funcionarioCriado;
  } else {
    throw new Error(`Falha ao criar funcionário ${identificador}`);
  }
};

// 🚨 FUNÇÃO PARA AUTO-CRIAÇÃO DE TREINAMENTOS
const criarTreinamentoSeNecessario = async (identificador: string, nomeOpcional: string | null, db: any) => {
  console.log(`📚 [AUTO-CREATE] Buscando/criando treinamento: ${identificador}`);
  
  // Buscar existente com flexibilidade
  let treinamento = await db.prepare(`
    SELECT id, nome, codigo FROM catalogo_treinamentos_v2 
    WHERE (codigo = ? OR codigo LIKE ? OR nome LIKE ?) 
    AND deleted_at IS NULL
    LIMIT 1
  `).bind(identificador, `%${identificador}%`, `%${identificador}%`).first();
  
  if (treinamento) {
    console.log(`✅ [AUTO-CREATE] Treinamento encontrado: ${treinamento.nome} (${treinamento.codigo})`);
    return { ...treinamento, existia: true };
  }
  
  // Se não encontrou, criar com dados mínimos
  console.log(`➕ [AUTO-CREATE] Criando treinamento com código: ${identificador}`);
  
  const novoTreinamento = {
    codigo: identificador,
    nome: nomeOpcional || `Auto-criado: ${identificador}`,
    categoria: 'AUTO_CRIADO_CSV',
    ativo: 1
  };
  
  const resultado = await db.prepare(`
    INSERT INTO catalogo_treinamentos_v2 
    (codigo, nome, categoria, ativo, created_at, updated_at)
    VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
  `).bind(
    novoTreinamento.codigo,
    novoTreinamento.nome,
    novoTreinamento.categoria,
    novoTreinamento.ativo
  ).run();
  
  if (resultado.success && resultado.meta?.last_row_id) {
    const treinamentoCriado = {
      id: resultado.meta.last_row_id,
      nome: novoTreinamento.nome,
      codigo: novoTreinamento.codigo,
      existia: false
    };
    
    console.log(`🎉 [AUTO-CREATE] Treinamento criado: ${treinamentoCriado.nome} (ID: ${treinamentoCriado.id})`);
    return treinamentoCriado;
  } else {
    throw new Error(`Falha ao criar treinamento ${identificador}`);
  }
};

// ✅ ENDPOINT CRÍTICO - BATCH IMPORT DE CERTIFICAÇÕES
app.post('/batch-import', async (c) => {
  const startTime = Date.now();
  const batchId = `cert_batch_${Date.now()}`;
  
  console.log('🔥 [HISTORICO-CERT-BATCH] === IMPORTAÇÃO BATCH CERTIFICAÇÕES ===');
  
  // ✅ GARANTIR HEADERS JSON SEMPRE - PRIMEIRA PRIORIDADE
  c.header('Content-Type', 'application/json');
  c.header('Access-Control-Allow-Origin', '*');
  c.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  c.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  try {
    // ✅ VALIDAÇÃO DE AMBIENTE CRÍTICO
    if (!c.env || !c.env.DB) {
      console.error('❌ [HISTORICO-CERT-BATCH] Ambiente não configurado - DB não disponível');
      return c.json({
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        error: 'Ambiente não configurado - Database não disponível',
        technical_details: 'c.env.DB is undefined'
      }, 500);
    }

    // ✅ PROCESSAR FORM DATA AO INVÉS DE JSON DIRETO
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      console.error('❌ [HISTORICO-CERT-BATCH] Arquivo não fornecido');
      return c.json({
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        error: 'Arquivo CSV é obrigatório',
        technical_details: 'FormData não contém campo "file"'
      }, 400);
    }
    
    // Parse CSV
    const csvText = await file.text();
    const lines = csvText.trim().split('\n');
    
    if (lines.length < 2) {
      console.error('❌ [HISTORICO-CERT-BATCH] Arquivo deve ter header + dados');
      return c.json({
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        error: 'Arquivo deve ter cabeçalho + pelo menos 1 linha de dados'
      }, 400);
    }
    
    const dataLines = lines.slice(1);
    
    // Converter para formato que o resto do código espera
    const body = {
      data: dataLines.map(line => {
        const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
        return {
          funcionario_matricula: values[0],
          treinamento_codigo: values[1], 
          data_conclusao: values[2],
          instrutor: values[3] || null,
          nota_final: values[4] ? parseFloat(values[4]) : null,
          data_vencimento: values[5] || null,
          observacoes: values[6] || null
        };
      })
    };
    console.log('📊 [HISTORICO-CERT-BATCH] Body recebido:', { 
      hasData: !!body.data, 
      isArray: Array.isArray(body.data),
      length: body.data?.length || 0 
    });
    
    // ✅ VALIDAÇÃO INICIAL RIGOROSA
    if (!body.data || !Array.isArray(body.data)) {
      console.error('❌ [HISTORICO-CERT-BATCH] Dados inválidos recebidos');
      return c.json({ 
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        error: 'Formato inválido. Esperado: { data: [...] }',
        linhas_processadas: 0,
        importadas_com_sucesso: 0,
        erros: 1,
        detalhes_erros: [{ linha: 0, erro: 'Formato inválido - dados não são array válido' }]
      }, 400);
    }

    if (body.data.length === 0) {
      console.error('❌ [HISTORICO-CERT-BATCH] Array de dados vazio');
      return c.json({ 
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        error: 'Array de dados está vazio',
        linhas_processadas: 0,
        importadas_com_sucesso: 0,
        erros: 1,
        detalhes_erros: [{ linha: 0, erro: 'Nenhum registro fornecido para importação' }]
      }, 400);
    }

    const db = c.env.DB;
    const totalLinhas = body.data.length;
    let criadas = 0;
    let funcionariosCriados = 0;
    let treinamentosCriados = 0;
    const erros = [];
    const sucessos = [];
    const novosFuncionarios = [];
    const novosTreinamentos = [];
    
    console.log(`🔄 [HISTORICO-CERT-BATCH] Processando ${totalLinhas} linhas COMPLETAS (não preview)`);
    
    // ✅ PROCESSAR TODAS AS LINHAS DO ARRAY (ARQUIVO COMPLETO)
    for (let i = 0; i < body.data.length; i++) {
      const item = body.data[i];
      const linha = i + 1;
      
      console.log(`📝 [HISTORICO-CERT-BATCH] --- LINHA ${linha}/${totalLinhas} ---`);
      
      try {
        // ✅ DETECTAR CAMPOS AUTOMATICAMENTE COM FLEXIBILIDADE
        const funcionarioMatricula = item.funcionario_matricula || '';
        const treinamentoCodigo = item.treinamento_codigo || '';
        const dataConclusao = item.data_conclusao || new Date().toISOString().split('T')[0];

        console.log(`🔍 [HISTORICO-CERT-BATCH] Campos detectados:`, {
          funcionarioMatricula, treinamentoCodigo, dataConclusao
        });

        // ✅ VALIDAÇÃO OBRIGATÓRIA
        if (!funcionarioMatricula || !treinamentoCodigo) {
          const erro = `Campos obrigatórios faltando: funcionario_matricula=${funcionarioMatricula}, treinamento_codigo=${treinamentoCodigo}`;
          console.warn(`⚠️ [HISTORICO-CERT-BATCH] ${erro}`);
          erros.push({ linha, erro, dados: item });
          continue;
        }

        // ✅ BUSCAR OU CRIAR FUNCIONÁRIO
        const funcionario = await criarFuncionarioSeNecessario(funcionarioMatricula, db);
        if (!funcionario.existia) {
          funcionariosCriados++;
          novosFuncionarios.push(`${funcionario.nome} (${funcionario.matricula})`);
        }
        
        // ✅ BUSCAR OU CRIAR TREINAMENTO
        const treinamento = await criarTreinamentoSeNecessario(
          treinamentoCodigo, 
          null,
          db
        );
        if (!treinamento.existia) {
          treinamentosCriados++;
          novosTreinamentos.push(`${treinamento.nome} (${treinamento.codigo})`);
        }
        
        console.log(`✅ [HISTORICO-CERT-BATCH] Dependências OK: ${funcionario.nome} + ${treinamento.nome}`);

        // ✅ VERIFICAR DUPLICATA ANTES DE INSERIR
        const existente = await db.prepare(`
          SELECT id FROM historico_certificacoes_v2 
          WHERE funcionario_id = ? AND treinamento_id = ? AND data_conclusao = ? AND status = 'ATIVO' AND deleted_at IS NULL
        `).bind(funcionario.id, treinamento.id, dataConclusao).first();

        if (existente) {
          console.warn(`⚠️ [HISTORICO-CERT-BATCH] Duplicata detectada linha ${linha}`);
          erros.push({ linha, erro: 'Certificação duplicada (mesmo funcionário, treinamento e data)', dados: item });
          continue;
        }

        // ✅ ATUALIZAR CERTIFICAÇÃO ANTERIOR PARA SUBSTITUIDO
        await db.prepare(`
          UPDATE historico_certificacoes_v2 
          SET status = 'SUBSTITUIDO', updated_at = CURRENT_TIMESTAMP
          WHERE funcionario_id = ? AND treinamento_id = ? AND status = 'ATIVO' AND deleted_at IS NULL
        `).bind(funcionario.id, treinamento.id).run();

        // ✅ CRIAR NOVA CERTIFICAÇÃO
        const result = await db.prepare(`
          INSERT INTO historico_certificacoes_v2 (
            funcionario_id, treinamento_id, data_conclusao, data_vencimento,
            instrutor, nota_final, observacoes, status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 'ATIVO', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `).bind(
          funcionario.id,
          treinamento.id,
          dataConclusao,
          item.data_vencimento || null,
          item.instrutor || null,
          item.nota_final ? parseFloat(String(item.nota_final)) : null,
          item.observacoes || null
        ).run();

        if (result.success && result.meta?.last_row_id) {
          criadas++;
          sucessos.push(`🏆 ${funcionario.nome} certificado em ${treinamento.nome} (ID: ${result.meta.last_row_id})`);
          console.log(`🎉 [HISTORICO-CERT-BATCH] Certificação criada: ID ${result.meta.last_row_id}`);
        } else {
          const erro = 'Falha ao inserir certificação no banco de dados';
          console.error(`❌ [HISTORICO-CERT-BATCH] ${erro}`);
          erros.push({ linha, erro, dados: item });
        }
          
      } catch (error) {
        const erro = `Erro interno: ${error instanceof Error ? error.message : 'Erro desconhecido'}`;
        console.error(`❌ [HISTORICO-CERT-BATCH] Linha ${linha}: ${erro}`, error);
        erros.push({ linha, erro, dados: item });
      }
    }
    
    const processingTime = Date.now() - startTime;
    
    console.log(`🎯 [HISTORICO-CERT-BATCH] === RESULTADO FINAL ===`);
    console.log(`  - Total processadas: ${totalLinhas}`);
    console.log(`  - Certificações criadas: ${criadas}`);
    console.log(`  - Funcionários auto-criados: ${funcionariosCriados}`);
    console.log(`  - Treinamentos auto-criados: ${treinamentosCriados}`);
    console.log(`  - Erros: ${erros.length}`);
    console.log(`  - Tempo processamento: ${processingTime}ms`);
    
    // ✅ RESPOSTA JSON SEMPRE, NUNCA HTML
    return c.json({
      success: true,
      batch_id: batchId,
      processing_time_ms: processingTime,
      linhas_processadas: totalLinhas,
      importadas_com_sucesso: criadas,
      funcionarios_criados: funcionariosCriados,
      treinamentos_criados: treinamentosCriados,
      erros: erros.length,
      detalhes_erros: erros.slice(0, 50), // Limitar erros na resposta
      sucessos: sucessos.slice(0, 20), // Limitar sucessos na resposta
      novas_entidades: {
        funcionarios: novosFuncionarios,
        treinamentos: novosTreinamentos
      },
      observacao: funcionariosCriados > 0 || treinamentosCriados > 0 ? 
        'Funcionários e/ou treinamentos foram criados automaticamente. Importe os dados completos para atualizar as informações.' : 
        'Todas as dependências já existiam no banco.',
      message: `Importação concluída: ${criadas} certificações, ${funcionariosCriados} funcionários criados, ${treinamentosCriados} treinamentos criados`,
      resumo: `Processadas: ${totalLinhas}, Certificações: ${criadas}, Auto-criados: F:${funcionariosCriados} + T:${treinamentosCriados}, Erros: ${erros.length}`,
      timestamp: new Date().toISOString(),
      evidence: {
        total_records_in_request: totalLinhas,
        total_records_processed: totalLinhas,
        records_successfully_imported: criadas,
        processing_evidence: 'Arquivo completo processado, não apenas preview',
        database_audit_available: true
      }
    });
    
  } catch (error) {
    const processingTime = Date.now() - startTime;
    console.error('💥 [HISTORICO-CERT-BATCH] ERRO CRÍTICO:', error);
    
    // ✅ RESPOSTA DE ERRO SEMPRE EM JSON, NUNCA HTML
    return c.json({
      success: false,
      batch_id: batchId,
      processing_time_ms: processingTime,
      error: `Erro crítico: ${error instanceof Error ? error.message : 'Erro interno'}`,
      linhas_processadas: 0,
      importadas_com_sucesso: 0,
      funcionarios_criados: 0,
      treinamentos_criados: 0,
      erros: 1,
      detalhes_erros: [{ 
        linha: 0, 
        erro: error instanceof Error ? error.message : 'Erro interno do servidor',
        dados: null 
      }],
      timestamp: new Date().toISOString(),
      evidence: {
        error_type: 'CRITICAL_SYSTEM_ERROR',
        processing_evidence: 'Sistema falhou antes de processar registros',
        database_audit_available: false
      }
    }, 500);
  }
});

// ✅ ENDPOINT DE LISTAGEM SIMPLES
app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    const limit = parseInt(c.req.query('limit') || '50');
    const offset = parseInt(c.req.query('offset') || '0');
    
    const result = await db.prepare(`
      SELECT 
        hc.*,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        ct.nome as treinamento_nome,
        ct.codigo as treinamento_codigo
      FROM historico_certificacoes_v2 hc
      LEFT JOIN funcionarios f ON hc.funcionario_id = f.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE hc.deleted_at IS NULL
      ORDER BY hc.created_at DESC
      LIMIT ? OFFSET ?
    `).bind(limit, offset).all();
    
    return c.json({
      success: true,
      data: result.results,
      total: result.results?.length || 0,
      pagination: {
        limit,
        offset,
        has_more: (result.results?.length || 0) === limit
      }
    });
    
  } catch (error) {
    console.error('❌ [HISTORICO-CERT] Erro ao listar:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno'
    }, 500);
  }
});

// ✅ ENDPOINT DE STATUS/HEALTH CHECK
app.get('/status', async (c) => {
  try {
    const db = c.env.DB;
    
    const stats = await db.prepare(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'ATIVO' THEN 1 END) as ativas,
        COUNT(CASE WHEN status = 'SUBSTITUIDO' THEN 1 END) as substituidas,
        COUNT(CASE WHEN created_at >= date('now', '-7 days') THEN 1 END) as ultimos_7_dias
      FROM historico_certificacoes_v2
      WHERE deleted_at IS NULL
    `).first();
    
    return c.json({
      success: true,
      endpoint: '/api/v2/historico-certificacoes',
      status: 'ONLINE',
      database_connected: true,
      stats: stats,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('❌ [HISTORICO-CERT] Status check failed:', error);
    return c.json({
      success: false,
      endpoint: '/api/v2/historico-certificacoes',
      status: 'ERROR',
      error: error instanceof Error ? error.message : 'Erro interno'
    }, 500);
  }
});

export default app;
