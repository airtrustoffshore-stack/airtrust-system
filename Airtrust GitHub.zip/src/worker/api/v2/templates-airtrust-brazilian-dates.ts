import { Hono } from 'hono';
import { DateParser } from '../../utils/date-parser';

const app = new Hono<{ Bindings: Env }>();

// ✅ TEMPLATE CERTIFICAÇÕES CSV - FORMATO BRASILEIRO
app.get('/certificacoes/csv', async (c) => {
  try {
    // Gerar datas exemplo no formato brasileiro
    const dataExemplo1 = DateParser.generateExampleDate(15); // 15 dias no futuro
    const dataVencimento1 = DateParser.generateExampleDate(365); // 1 ano no futuro
    
    const dataExemplo2 = DateParser.generateExampleDate(30); // 30 dias no futuro
    const dataVencimento2 = DateParser.generateExampleDate(395); // ~13 meses no futuro
    
    const dataExemplo3 = DateParser.generateExampleDate(45); // 45 dias no futuro
    const dataVencimento3 = DateParser.generateExampleDate(225); // ~7 meses no futuro

    // Template com formato brasileiro correto
    const csvContent = `funcionario_matricula,treinamento_codigo,data_conclusao,data_vencimento,instrutor,nota_final,observacoes
00300,CMA-001,${dataExemplo1},${dataVencimento1},Dr. João Silva,8.5,Certificação médica aprovada
00301,ICAO-001,${dataExemplo2},${dataVencimento2},Maria Santos,9.0,Proficiência linguística excelente
00302,SGS-001,${dataExemplo3},${dataVencimento3},Pedro Costa,7.5,Treinamento de segurança concluído`;

    return new Response(csvContent, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': 'attachment; filename="template_certificacoes_brasileiro.csv"',
        'Cache-Control': 'no-cache'
      }
    });

  } catch (error) {
    console.error('Erro ao gerar template CSV:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      message: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// ✅ TEMPLATE CERTIFICAÇÕES XLSX - FORMATO BRASILEIRO
app.get('/certificacoes/xlsx', async (c) => {
  try {
    // Por ora, redirecionar para CSV - pode ser implementado Excel mais tarde
    return c.redirect('/api/v2/templates-airtrust-brazilian-dates/certificacoes/csv');
    
  } catch (error) {
    console.error('Erro ao gerar template XLSX:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      message: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// ✅ ENDPOINT DE DOCUMENTAÇÃO DO FORMATO
app.get('/formato-brasileiro', async (c) => {
  const documentacao = {
    formato_datas: "DD/MM/AAAA",
    padrao: "Brasileiro",
    compliance: "Legislação e prática de mercado nacional",
    campos_com_data: [
      {
        campo: "data_conclusao",
        obrigatorio: true,
        formato: "DD/MM/AAAA",
        exemplo: "20/08/2025",
        descricao: "Data de conclusão do treinamento"
      },
      {
        campo: "data_vencimento", 
        obrigatorio: false,
        formato: "DD/MM/AAAA",
        exemplo: "19/09/2026",
        descricao: "Data de vencimento da certificação"
      }
    ],
    exemplos_validos: [
      "01/01/2025",
      "15/12/2024", 
      "31/03/2026"
    ],
    exemplos_invalidos: [
      "2025-01-01 (formato americano/ISO)",
      "01-01-2025 (separadores incorretos)",
      "1/1/2025 (sem zeros à esquerda)",
      "32/13/2025 (data inexistente)"
    ],
    erros_comuns: [
      {
        erro: "Data no formato antigo ISO",
        solucao: "Converter de YYYY-MM-DD para DD/MM/AAAA",
        exemplo: "2025-08-20 → 20/08/2025"
      },
      {
        erro: "Separadores incorretos",
        solucao: "Usar apenas barras (/) como separador",
        exemplo: "20-08-2025 → 20/08/2025"
      }
    ]
  };

  return c.json(documentacao);
});

export default app;
