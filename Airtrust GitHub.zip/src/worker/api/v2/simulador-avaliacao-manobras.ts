import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// ✅ SISTEMA DE AVALIAÇÃO DE MANOBRAS COM HISTÓRICO

// Schemas de validação
const AvaliacaoManobraSchema = z.object({
  manobra_id: z.number().int().positive(),
  nota: z.string().refine(val => {
    return ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'NR'].includes(val);
  }, 'Nota deve ser de 1 a 10 ou NR'),
  observacoes: z.string().optional()
});

const SalvarNotasSchema = z.object({
  manobras: z.array(AvaliacaoManobraSchema).min(1, 'Pelo menos uma manobra deve ser avaliada')
});

// Aplicar middleware de autenticação a todas as rotas
app.use('*', authMiddleware);

// ===== FUNÇÃO AUXILIAR PARA BUSCAR NOTA ANTERIOR =====
async function buscarNotaAnterior(
  db: D1Database, 
  funcionarioId: number, 
  manobraId: number, 
  dataSessaoAtual: string
): Promise<{ nota: string; data_avaliacao: string; ficha_uuid: string } | null> {
  try {
    const stmt = db.prepare(`
      SELECT CAST(fme.nota AS TEXT) as nota, 
             COALESCE(fme.data_avaliacao, fs.created_at) as data_avaliacao, 
             fs.ficha_uuid,
             f.nome as funcionario_nome, mc.nome_manobra
      FROM fichas_manobras_executadas fme
      JOIN fichas_sessao fs ON fme.ficha_id = fs.id
      JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      JOIN manobras_catalogo mc ON fme.manobra_catalogo_id = mc.id
      WHERE fs.colaborador_id_aluno = ? 
        AND fme.manobra_catalogo_id = ?
        AND fs.created_at < ?
        AND fs.deleted_at IS NULL
        AND mc.deleted_at IS NULL
      ORDER BY fs.created_at DESC
      LIMIT 1
    `);
    
    const result = await stmt.bind(funcionarioId, manobraId, dataSessaoAtual).first();
    return result ? {
      nota: result.nota as string,
      data_avaliacao: result.data_avaliacao as string,
      ficha_uuid: result.ficha_uuid as string
    } : null;
  } catch (error) {
    console.error('Erro ao buscar nota anterior:', error);
    return null;
  }
}

// ===== FUNÇÃO PARA CALCULAR CONCEITO FINAL =====
function calcularConceito(notas: string[]): 'APROVADO' | 'REPROVADO' {
  // Regra rigorosa: qualquer nota < 5 = reprovado
  const notasNumericas = notas
    .filter(nota => nota !== 'NR')
    .map(nota => parseInt(nota));
  
  const temNotaBaixa = notasNumericas.some(nota => nota < 5);
  return temNotaBaixa ? 'REPROVADO' : 'APROVADO';
}

// ===== ENDPOINTS =====

// GET /api/v2/simulador/ficha/:uuid/avaliacao - Carregar ficha com histórico
app.get('/ficha/:uuid/avaliacao', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const { uuid } = c.req.param();
    const db = c.env.DB;
    
    // 1. Buscar dados básicos da ficha
    const fichaStmt = db.prepare(`
      SELECT fs.id, fs.ficha_uuid, fs.colaborador_id_aluno, fs.sessao_template_id,
             fs.status_workflow, fs.resultado_final, fs.nota_final, fs.created_at,
             f.nome as colaborador_nome, f.matricula as colaborador_matricula,
             st.nome_sessao, st.treinamento_codigo
      FROM fichas_sessao fs
      JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      JOIN sessoes_template st ON fs.sessao_template_id = st.id
      WHERE fs.ficha_uuid = ? AND fs.deleted_at IS NULL
    `);
    
    const ficha = await fichaStmt.bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // 2. Buscar manobras da sessão template
    const manobrasStmt = db.prepare(`
      SELECT mc.id as manobra_id, mc.manobra_id_codigo as codigo,
             mc.nome_manobra as descricao, mc.categoria,
             mc.criterios_aprovacao, mc.pontuacao_minima
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ? AND mc.deleted_at IS NULL
      ORDER BY mc.categoria, mc.nome_manobra
    `);
    
    const manobras = await manobrasStmt.bind(ficha.sessao_template_id).all();
    
    // 3. Para cada manobra, buscar nota anterior e atual
    const manobrasComHistorico = await Promise.all(
      manobras.results.map(async (manobra: any) => {
        // Buscar nota anterior
        const notaAnterior = await buscarNotaAnterior(
          db,
          ficha.colaborador_id_aluno as number,
          manobra.manobra_id,
          ficha.created_at as string
        );
        
        // Buscar nota atual da ficha (se já existe)
        const notaAtualStmt = db.prepare(`
          SELECT CAST(nota AS TEXT) as nota, observacoes
          FROM fichas_manobras_executadas
          WHERE ficha_id = ? AND manobra_catalogo_id = ?
        `);
        
        const notaAtual = await notaAtualStmt.bind(ficha.id, manobra.manobra_id).first();
        
        return {
          manobra_id: manobra.manobra_id,
          codigo: manobra.codigo,
          descricao: manobra.descricao,
          categoria: manobra.categoria,
          criterios_aprovacao: manobra.criterios_aprovacao,
          pontuacao_minima: manobra.pontuacao_minima,
          nota_anterior: notaAnterior?.nota || null,
          data_nota_anterior: notaAnterior?.data_avaliacao || null,
          ficha_anterior_uuid: notaAnterior?.ficha_uuid || null,
          nota_ficha_atual: notaAtual?.nota || null,
          observacoes_atual: notaAtual?.observacoes || null
        };
      })
    );
    
    // 4. Calcular conceito atual se todas as notas estão preenchidas
    const notasAtuais = manobrasComHistorico
      .map(m => m.nota_ficha_atual)
      .filter(nota => nota !== null);
    
    let conceitoAtual = null;
    if (notasAtuais.length === manobrasComHistorico.length) {
      conceitoAtual = calcularConceito(notasAtuais as string[]);
    }
    
    await logAudit(c, 'READ', 'ficha_avaliacao', uuid);
    
    return c.json({
      success: true,
      data: {
        ficha_id: ficha.id,
        ficha_uuid: ficha.ficha_uuid,
        colaborador: {
          id: ficha.colaborador_id_aluno,
          nome: ficha.colaborador_nome,
          matricula: ficha.colaborador_matricula
        },
        sessao: {
          nome: ficha.nome_sessao,
          treinamento_codigo: ficha.treinamento_codigo
        },
        manobras: manobrasComHistorico,
        conceito_atual: conceitoAtual,
        resultado_final: ficha.resultado_final,
        nota_final: ficha.nota_final,
        pode_editar: ['RASCUNHO', 'PENDENTE_INSTRUTOR_FINAL'].includes(ficha.status_workflow as string),
        status_workflow: ficha.status_workflow
      }
    });
  } catch (error) {
    console.error('Erro ao carregar ficha com histórico:', error);
    await logAudit(c, 'READ', 'ficha_avaliacao', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// PATCH /api/v2/simulador/ficha/:uuid/notas - Salvar notas da avaliação
app.patch('/ficha/:uuid/notas', requirePermission('simuladores', 'UPDATE'), zValidator('json', SalvarNotasSchema), async (c) => {
  try {
    const { uuid } = c.req.param();
    const { manobras } = c.req.valid('json');
    const db = c.env.DB;
    
    // Obter informações do usuário e IP
    const usuarioId = 1; // TODO: Implementar obtenção correta do usuário logado
    const ip = c.req.header('cf-connecting-ip') || c.req.header('x-forwarded-for') || 'unknown';
    
    // 1. Buscar ficha
    const fichaStmt = db.prepare(`
      SELECT id, colaborador_id_aluno, status_workflow
      FROM fichas_sessao 
      WHERE ficha_uuid = ? AND deleted_at IS NULL
    `);
    
    const ficha = await fichaStmt.bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // 2. Verificar se pode editar
    const canEdit = ['RASCUNHO', 'PENDENTE_INSTRUTOR_FINAL'].includes(ficha.status_workflow as string);
    if (!canEdit) {
      return c.json({ error: 'Ficha não pode ser editada no status atual' }, 400);
    }
    
    // 3. Validar se todas as manobras têm nota
    if (manobras.some((m: any) => !m.nota)) {
      return c.json({ error: 'Todas as manobras devem ter nota definida' }, 400);
    }
    
    // 4. Processar cada nota com auditoria
    const resultados: any[] = [];
    
    for (const manobra of manobras) {
      try {
        // Verificar se já existe registro para esta combinação
        const existenteStmt = db.prepare(`
          SELECT id, CAST(nota AS TEXT) as nota, observacoes
          FROM fichas_manobras_executadas
          WHERE ficha_id = ? AND manobra_catalogo_id = ?
        `);
        
        const existente = await existenteStmt.bind(ficha.id, manobra.manobra_id).first();
        
        if (existente) {
          // Atualizar nota existente - aceitar tanto integer quanto string 'NR'
          const notaValue = manobra.nota === 'NR' ? 0 : parseInt(manobra.nota); // 0 como placeholder para 'NR'
          const updateStmt = db.prepare(`
            UPDATE fichas_manobras_executadas 
            SET nota = ?, observacoes = ?
            WHERE id = ?
          `);
          
          await updateStmt.bind(notaValue, manobra.observacoes || null, existente.id).run();
          
          // Registrar auditoria da alteração
          const auditStmt = db.prepare(`
            INSERT INTO auditoria_manobras (
              ficha_manobras_executadas_id, usuario_id, acao, 
              valor_anterior, valor_novo, ip_origem
            ) VALUES (?, ?, ?, ?, ?, ?)
          `);
          
          await auditStmt.bind(
            existente.id,
            usuarioId,
            'NOTA_ALTERADA',
            existente.nota,
            manobra.nota,
            ip
          ).run();
          
          resultados.push({
            manobra_id: manobra.manobra_id,
            acao: 'ATUALIZADA',
            nota_anterior: existente.nota,
            nota_nova: manobra.nota
          });
        } else {
          // Criar nova nota - aceitar tanto integer quanto string 'NR'
          const notaValue = manobra.nota === 'NR' ? 0 : parseInt(manobra.nota); // 0 como placeholder para 'NR'
          const insertStmt = db.prepare(`
            INSERT INTO fichas_manobras_executadas (
              ficha_id, manobra_catalogo_id, nota, observacoes
            ) VALUES (?, ?, ?, ?)
          `);
          
          const result = await insertStmt.bind(
            ficha.id,
            manobra.manobra_id,
            notaValue,
            manobra.observacoes || null
          ).run();
          
          // Registrar auditoria da criação
          const auditStmt = db.prepare(`
            INSERT INTO auditoria_manobras (
              ficha_manobras_executadas_id, usuario_id, acao, 
              valor_anterior, valor_novo, ip_origem
            ) VALUES (?, ?, ?, ?, ?, ?)
          `);
          
          await auditStmt.bind(
            result.meta.last_row_id,
            usuarioId,
            'NOTA_CRIADA',
            null,
            manobra.nota,
            ip
          ).run();
          
          resultados.push({
            manobra_id: manobra.manobra_id,
            acao: 'CRIADA',
            nota_anterior: null,
            nota_nova: manobra.nota
          });
        }
      } catch (error) {
        console.error(`Erro ao processar manobra ${manobra.manobra_id}:`, error);
        resultados.push({
          manobra_id: manobra.manobra_id,
          acao: 'ERRO',
          erro: error instanceof Error ? error.message : 'Erro desconhecido'
        });
      }
    }
    
    // 5. Calcular conceito final - Regra rigorosa: qualquer nota < 5 = REPROVADO
    const notasNumericas = manobras
      .filter((m: any) => m.nota !== 'NR')
      .map((m: any) => parseInt(m.nota));
    
    const menorNota = notasNumericas.length > 0 ? Math.min(...notasNumericas) : 10;
    const conceito = calcularConceito(manobras.map((m: any) => m.nota));
    
    // 6. Atualizar status da ficha
    const updateFichaStmt = db.prepare(`
      UPDATE fichas_sessao 
      SET resultado_final = ?, nota_final = ?, 
          status_workflow = CASE 
            WHEN ? = 'REPROVADO' THEN 'REPROVADA'
            ELSE 'PENDENTE_ALUNO'
          END,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    await updateFichaStmt.bind(conceito, menorNota, conceito, ficha.id).run();
    
    await logAudit(c, 'UPDATE', 'ficha_avaliacao', uuid, undefined, {
      conceito,
      total_manobras: manobras.length,
      menor_nota: menorNota,
      resultados
    });
    
    return c.json({
      success: true,
      data: {
        conceito,
        nota_final: menorNota,
        detalhes_aprovacao: {
          total_manobras: manobras.length,
          manobras_avaliadas: manobras.filter((m: any) => m.nota !== 'NR').length,
          manobras_nr: manobras.filter((m: any) => m.nota === 'NR').length,
          menor_nota: menorNota,
          reprovou_por_nota: conceito === 'REPROVADO'
        },
        resultados
      },
      message: `Avaliação salva com sucesso. Conceito: ${conceito}`
    });
  } catch (error) {
    console.error('Erro ao salvar notas da avaliação:', error);
    await logAudit(c, 'UPDATE', 'ficha_avaliacao', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// GET /api/v2/simulador/funcionario/:id/historico-manobras - Histórico de um funcionário por manobra
app.get('/funcionario/:id/historico-manobras', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const funcionarioId = c.req.param('id');
    const manobraId = c.req.query('manobra_id');
    const db = c.env.DB;
    
    let whereClause = 'WHERE fs.colaborador_id_aluno = ? AND fs.deleted_at IS NULL';
    const params = [funcionarioId];
    
    if (manobraId) {
      whereClause += ' AND fme.manobra_catalogo_id = ?';
      params.push(manobraId);
    }
    
    const stmt = db.prepare(`
      SELECT fme.nota, fme.observacoes, fme.created_at as data_avaliacao,
             fs.ficha_uuid, fs.resultado_final,
             mc.manobra_id_codigo, mc.nome_manobra, mc.categoria,
             st.nome_sessao, st.treinamento_codigo,
             f.nome as funcionario_nome, f.matricula
      FROM fichas_manobras_executadas fme
      JOIN fichas_sessao fs ON fme.ficha_id = fs.id
      JOIN manobras_catalogo mc ON fme.manobra_catalogo_id = mc.id
      JOIN sessoes_template st ON fs.sessao_template_id = st.id
      JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      ${whereClause}
      ORDER BY fme.created_at DESC, mc.categoria, mc.nome_manobra
      LIMIT 100
    `);
    
    const result = await stmt.bind(...params).all();
    const historico = result.results;
    
    return c.json({
      success: true,
      data: historico,
      total: historico?.length || 0
    });
  } catch (error) {
    console.error('Erro ao buscar histórico de manobras:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// GET /api/v2/simulador/auditoria-manobras/:ficha_uuid - Auditoria de uma ficha específica
app.get('/auditoria-manobras/:ficha_uuid', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const fichaUuid = c.req.param('ficha_uuid');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT am.id, am.acao, am.valor_anterior, am.valor_novo, 
             am.ip_origem, am.created_at,
             mc.manobra_id_codigo, mc.nome_manobra,
             f.nome as usuario_nome
      FROM auditoria_manobras am
      JOIN fichas_manobras_executadas fme ON am.ficha_manobras_executadas_id = fme.id
      JOIN fichas_sessao fs ON fme.ficha_id = fs.id
      JOIN manobras_catalogo mc ON fme.manobra_catalogo_id = mc.id
      LEFT JOIN funcionarios f ON am.usuario_id = f.id
      WHERE fs.ficha_uuid = ?
      ORDER BY am.created_at DESC
    `);
    
    const result = await stmt.bind(fichaUuid).all();
    const auditoria = result.results;
    
    return c.json({
      success: true,
      data: auditoria,
      total: auditoria?.length || 0
    });
  } catch (error) {
    console.error('Erro ao buscar auditoria de manobras:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

export default app;
