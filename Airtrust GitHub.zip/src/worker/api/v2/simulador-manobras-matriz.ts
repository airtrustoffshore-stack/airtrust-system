import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.use('*', authMiddleware);

// GET - Buscar matriz de manobras (endpoint correto)
app.get('/matriz', async (c) => {
  try {
    const db = c.env.DB;
    
    console.log('🎯 Carregando matriz de manobras');
    
    // Buscar todas as manobras agrupadas por categoria
    const manobras = await db.prepare(`
      SELECT
        id,
        manobra_id_codigo as codigo,
        nome_manobra as nome,
        descricao_detalhada as descricao,
        categoria,
        criterios_aprovacao,
        pontuacao_minima,
        ativo
      FROM manobras_catalogo
      WHERE ativo = 1
      ORDER BY categoria ASC, nome_manobra ASC
    `).all();
    
    // Agrupar por categoria
    const matrizManobras: { [categoria: string]: any[] } = {};
    
    manobras.results.forEach((manobra: any) => {
      const categoria = manobra.categoria || 'GERAL';
      if (!matrizManobras[categoria]) {
        matrizManobras[categoria] = [];
      }
      matrizManobras[categoria].push(manobra);
    });
    
    // Estatísticas
    const totalManobras = manobras.results.length;
    const totalCategorias = Object.keys(matrizManobras).length;
    
    console.log(`✅ Matriz carregada: ${totalManobras} manobras em ${totalCategorias} categorias`);
    
    return c.json({
      success: true,
      matriz: matrizManobras,
      estatisticas: {
        total_manobras: totalManobras,
        total_categorias: totalCategorias,
        categorias: Object.keys(matrizManobras)
      }
    });
    
  } catch (error) {
    console.error('❌ Erro ao carregar matriz:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET - Manter endpoint original para compatibilidade
app.get('/', async (c) => {
  try {
    const db = c.env.DB;

    // Buscar todas as manobras agrupadas por categoria
    const manobras = await db.prepare(`
      SELECT 
        id,
        manobra_id_codigo as codigo,
        nome_manobra as nome,
        descricao_detalhada as descricao,
        categoria,
        criterios_aprovacao,
        pontuacao_minima,
        ativo
      FROM manobras_catalogo
      WHERE ativo = 1
      ORDER BY categoria ASC, nome_manobra ASC
    `).all();

    // Agrupar por categoria
    const matrizManobras: { [categoria: string]: any[] } = {};
    
    manobras.results.forEach((manobra: any) => {
      const categoria = manobra.categoria || 'GERAL';
      
      if (!matrizManobras[categoria]) {
        matrizManobras[categoria] = [];
      }
      
      matrizManobras[categoria].push({
        id: manobra.id,
        codigo: manobra.codigo,
        nome: manobra.nome,
        descricao: manobra.descricao,
        criterios_aprovacao: manobra.criterios_aprovacao,
        pontuacao_minima: manobra.pontuacao_minima,
        ativo: Boolean(manobra.ativo)
      });
    });

    // Buscar configurações de templates se houver
    const templates = await db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo,
        st.numero_sessao,
        st.nome_sessao,
        GROUP_CONCAT(stm.manobra_catalogo_id) as manobras_ids
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      GROUP BY st.id
      ORDER BY st.treinamento_codigo, st.numero_sessao
    `).all();

    const templatesFormatados = templates.results.map((t: any) => ({
      id: t.id,
      treinamento_codigo: t.treinamento_codigo,
      numero_sessao: t.numero_sessao,
      nome_sessao: t.nome_sessao,
      manobras_ids: t.manobras_ids ? t.manobras_ids.split(',').map(Number) : []
    }));

    return c.json({
      success: true,
      matriz: matrizManobras,
      templates: templatesFormatados,
      estatisticas: {
        total_manobras: manobras.results.length,
        total_categorias: Object.keys(matrizManobras).length,
        total_templates: templatesFormatados.length
      }
    });

  } catch (error) {
    console.error('❌ Erro ao buscar matriz de manobras:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

// POST /api/v2/simulador/manobras/configurar - Configurar manobras para sessão
app.post('/configurar', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();

    const { 
      sessao_template_id, 
      manobras = [],
      treinamento_codigo,
      numero_sessao,
      nome_sessao 
    } = body;

    // Se não tem template ID, criar um novo template
    let templateId = sessao_template_id;
    
    if (!templateId && treinamento_codigo && numero_sessao) {
      const resultTemplate = await db.prepare(`
        INSERT OR REPLACE INTO sessoes_template (
          treinamento_codigo,
          numero_sessao,
          nome_sessao,
          created_at,
          created_by
        ) VALUES (?, ?, ?, datetime('now'), 'SISTEMA')
      `).bind(
        treinamento_codigo,
        numero_sessao,
        nome_sessao || `Sessão ${numero_sessao}`
      ).run();

      templateId = resultTemplate.meta.last_row_id;
    }

    if (!templateId) {
      return c.json({ 
        error: 'Template ID é obrigatório ou não pôde ser criado' 
      }, 400);
    }

    // Limpar manobras existentes do template
    await db.prepare(`
      DELETE FROM sessoes_template_manobras 
      WHERE sessao_template_id = ?
    `).bind(templateId).run();

    // Adicionar novas manobras
    for (const manobraId of manobras) {
      await db.prepare(`
        INSERT INTO sessoes_template_manobras (
          sessao_template_id,
          manobra_catalogo_id
        ) VALUES (?, ?)
      `).bind(templateId, manobraId).run();
    }

    return c.json({
      success: true,
      message: 'Configuração de manobras salva com sucesso',
      template_id: templateId,
      manobras_configuradas: manobras.length
    });

  } catch (error) {
    console.error('❌ Erro ao configurar manobras:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

// PUT /api/v2/simulador/manobras/atualizar - Atualizar configuração existente
app.put('/atualizar', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();

    const { 
      sessao_template_id, 
      manobras = [] 
    } = body;

    if (!sessao_template_id) {
      return c.json({ 
        error: 'Template ID é obrigatório' 
      }, 400);
    }

    // Limpar manobras existentes
    await db.prepare(`
      DELETE FROM sessoes_template_manobras 
      WHERE sessao_template_id = ?
    `).bind(sessao_template_id).run();

    // Adicionar novas manobras
    for (const manobraId of manobras) {
      await db.prepare(`
        INSERT INTO sessoes_template_manobras (
          sessao_template_id,
          manobra_catalogo_id
        ) VALUES (?, ?)
      `).bind(sessao_template_id, manobraId).run();
    }

    // Atualizar timestamp do template
    await db.prepare(`
      UPDATE sessoes_template 
      SET updated_at = datetime('now'),
          updated_by = 'SISTEMA'
      WHERE id = ?
    `).bind(sessao_template_id).run();

    return c.json({
      success: true,
      message: 'Configuração atualizada com sucesso',
      template_id: sessao_template_id,
      manobras_atualizadas: manobras.length
    });

  } catch (error) {
    console.error('❌ Erro ao atualizar configuração:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

// GET /api/v2/simulador/manobras/template/:id - Buscar configuração de um template específico
app.get('/template/:id', async (c) => {
  try {
    const db = c.env.DB;
    const templateId = c.req.param('id');

    const template = await db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo,
        st.numero_sessao,
        st.nome_sessao,
        st.descricao,
        GROUP_CONCAT(stm.manobra_catalogo_id) as manobras_ids
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      WHERE st.id = ?
      GROUP BY st.id
    `).bind(templateId).first();

    if (!template) {
      return c.json({ 
        error: 'Template não encontrado' 
      }, 404);
    }

    const manobrasIds = template.manobras_ids ? 
      template.manobras_ids.split(',').map(Number) : [];

    // Buscar detalhes das manobras configuradas
    const manobrasDetalhes = [];
    if (manobrasIds.length > 0) {
      const placeholders = manobrasIds.map(() => '?').join(',');
      const manobras = await db.prepare(`
        SELECT 
          id,
          manobra_id_codigo as codigo,
          nome_manobra as nome,
          categoria,
          pontuacao_minima
        FROM manobras_catalogo
        WHERE id IN (${placeholders})
        ORDER BY categoria, nome_manobra
      `).bind(...manobrasIds).all();

      manobrasDetalhes.push(...manobras.results);
    }

    return c.json({
      success: true,
      template: {
        id: template.id,
        treinamento_codigo: template.treinamento_codigo,
        numero_sessao: template.numero_sessao,
        nome_sessao: template.nome_sessao,
        descricao: template.descricao,
        manobras_configuradas: manobrasDetalhes,
        total_manobras: manobrasDetalhes.length
      }
    });

  } catch (error) {
    console.error('❌ Erro ao buscar configuração do template:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

export default app;
