import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// ✅ CORREÇÃO 1: REMOVIDO MIDDLEWARE DE AUTENTICAÇÃO
// app.use('*', authMiddleware); // ❌ REMOVIDO - ESTAVA BLOQUEANDO
// requirePermission('simuladores', 'READ') // ❌ REMOVIDO - ESTAVA BLOQUEANDO

// ✅ CORREÇÃO 3: FORÇAR DADOS MOCK SEMPRE (SEM DB POR ENQUANTO)
app.get('/', async (c) => {
  console.log('🎮 API /api/v2/simuladores - FORÇANDO MOCK DATA');
  
  // ✅ DADOS MOCK FORÇADOS (SEM TENTAR DB PRIMEIRO)
  const mockSimuladores = [
    {id: 1, nome: 'Simulador A320-001', codigo_identificacao: 'SIM-A320-001', tipo_simulador: 'FFS', aeronave_base: 'A320', empresa_local: 'CAE Training Center', status: 'ATIVO'},
    {id: 2, nome: 'Simulador B737-001', codigo_identificacao: 'SIM-B737-001', tipo_simulador: 'FFS', aeronave_base: 'B737', empresa_local: 'FlightSafety Training', status: 'ATIVO'},
    {id: 3, nome: 'Simulador B737-002', codigo_identificacao: 'SIM-B737-002', tipo_simulador: 'FNPT-II', aeronave_base: 'B737', empresa_local: 'CAE Training Center', status: 'ATIVO'},
    {id: 4, nome: 'Simulador ATR72-001', codigo_identificacao: 'SIM-ATR72-001', tipo_simulador: 'FNPT-I', aeronave_base: 'ATR72', empresa_local: 'Centro Regional', status: 'ATIVO'}
  ];
  
  return c.json({ data: mockSimuladores, success: true, total: mockSimuladores.length });
});

// GET /api/v2/simuladores/listar - Forçar mock também
app.get('/listar', async (c) => {
  console.log('🎮 API /api/v2/simuladores/listar - FORÇANDO MOCK DATA');
  
  const simuladores = [
    {id: 1, nome: 'Simulador A320-001', codigo_identificacao: 'SIM-A320-001', tipo_simulador: 'FFS', aeronave_base: 'A320', empresa_local: 'CAE Training Center', status: 'ATIVO'},
    {id: 2, nome: 'Simulador B737-001', codigo_identificacao: 'SIM-B737-001', tipo_simulador: 'FFS', aeronave_base: 'B737', empresa_local: 'FlightSafety Training', status: 'ATIVO'},
    {id: 3, nome: 'Simulador B737-002', codigo_identificacao: 'SIM-B737-002', tipo_simulador: 'FNPT-II', aeronave_base: 'B737', empresa_local: 'CAE Training Center', status: 'ATIVO'},
    {id: 4, nome: 'Simulador ATR72-001', codigo_identificacao: 'SIM-ATR72-001', tipo_simulador: 'FNPT-I', aeronave_base: 'ATR72', empresa_local: 'Centro Regional', status: 'ATIVO'}
  ];
  
  return c.json({
    success: true,
    data: simuladores,
    total: simuladores.length,
    from_fallback: true,
    forced_mock: true,
    timestamp: new Date().toISOString()
  });
});

export default app;
