import { Hono } from 'hono';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

// Middleware simples - sem auth por enquanto para debug
app.use('*', async (c, next) => {
  console.log(`📡 [PROGRESSO] Request: ${c.req.method} ${c.req.path}`);
  await next();
  console.log(`📡 [PROGRESSO] Response enviada`);
});

app.get('/:colaborador/:treinamento', async (c) => {
  try {
    console.log('🔍 [PROGRESSO] Início do endpoint progresso específico');
    
    const { colaborador, treinamento } = c.req.param();
    console.log('🔍 [PROGRESSO] Colaborador:', colaborador, 'Treinamento:', treinamento);
    
    // Verificar DB
    const db = c.env.DB;
    console.log('🔍 [PROGRESSO] DB disponível?', !!db);
    
    // Mock data para progresso específico
    const progressoMock = {
      colaborador: {
        id: Number(colaborador),
        nome: `Colaborador ${colaborador}`,
        matricula: `0000${colaborador}`
      },
      treinamento: {
        id: Number(treinamento),
        codigo: `TREIN-${treinamento}`,
        nome: `Treinamento ${treinamento}`
      },
      estatisticas: {
        total_sessoes: 5,
        sessoes_aprovadas: 4,
        sessoes_reprovadas: 1,
        sessoes_concluidas: 5,
        percentual_conclusao: 100,
        percentual_aprovacao: 80
      },
      ultimas_sessoes: [
        {
          ficha_uuid: `FICHA-${colaborador}-${treinamento}-001`,
          resultado_final: 'APROVADO',
          nota_final: 8.5,
          status_workflow: 'CONCLUIDA',
          data_inicio: new Date(Date.now() - 86400000).toISOString(),
          simulador_nome: 'Simulador AW139 - 001'
        },
        {
          ficha_uuid: `FICHA-${colaborador}-${treinamento}-002`,
          resultado_final: 'APROVADO',
          nota_final: 9.0,
          status_workflow: 'CONCLUIDA',
          data_inicio: new Date(Date.now() - 172800000).toISOString(),
          simulador_nome: 'Simulador AW139 - 002'
        }
      ]
    };
    
    console.log('🔍 [PROGRESSO] Dados mock preparados');
    
    return c.json({
      success: true,
      progresso: progressoMock,
      timestamp: new Date().toISOString(),
      debug: {
        endpoint: 'progresso-especifico-fixed',
        version: '2.0-debug',
        db_available: !!db,
        mock: true
      }
    });
    
  } catch (error) {
    console.error('❌ [PROGRESSO] ERRO CAPTURADO:', {
      message: error instanceof Error ? error.message : 'Erro desconhecido',
      stack: error instanceof Error ? error.stack?.substring(0, 200) : 'N/A',
      name: error instanceof Error ? error.name : 'Unknown'
    });
    
    return c.json({
      error: 'Erro ao buscar progresso',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'progresso-especifico-fixed',
      timestamp: new Date().toISOString(),
      debug: {
        error_type: error instanceof Error ? error.constructor.name : 'Unknown',
        path: c.req.path,
        method: c.req.method
      }
    }, 500);
  }
});

// GET - Progresso geral do colaborador (versão simplificada)
app.get('/:colaborador', async (c) => {
  try {
    console.log('🔍 [PROGRESSO] Progresso geral do colaborador');
    
    const { colaborador } = c.req.param();
    
    // Mock data para progresso geral
    const progressoGeral = {
      colaborador_id: colaborador,
      total_fichas: 15,
      fichas_aprovadas: 12,
      fichas_reprovadas: 2,
      fichas_concluidas: 14,
      media_notas: 8.2
    };
    
    return c.json({
      success: true,
      progresso_geral: progressoGeral,
      debug: {
        endpoint: 'progresso-geral-fixed',
        mock: true,
        timestamp: new Date().toISOString()
      }
    });
    
  } catch (error) {
    console.error('❌ [PROGRESSO] Erro ao buscar progresso geral:', error);
    return c.json({ 
      error: 'Erro ao buscar progresso geral',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'progresso-geral-fixed'
    }, 500);
  }
});

// GET - Status do endpoint
app.get('/status', async (c) => {
  return c.json({
    success: true,
    endpoint: 'simulador-progresso-fixed',
    version: '2.0-debug',
    status: 'OPERACIONAL',
    timestamp: new Date().toISOString(),
    features: [
      'GET /:colaborador/:treinamento - Progresso específico',
      'GET /:colaborador - Progresso geral',
      'GET /status - Status do endpoint'
    ]
  });
});

export default app;
