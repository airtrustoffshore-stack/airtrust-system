import { Hono } from 'hono';

const templatesApi = new Hono<{ Bindings: Env }>();

// GET /api/v2/simulador/templates/treinamento/{id} - ENDPOINT OBRIGATÓRIO
templatesApi.get('/treinamento/:id', async (c) => {
  const { id } = c.req.param();
  const treinamentoId = parseInt(id);
  
  if (!treinamentoId) {
    return c.json({ error: 'ID do treinamento inválido' }, 400);
  }
  
  try {
    console.log(`📋 Buscando templates do treinamento ${treinamentoId}...`);
    
    const db = c.env.DB;
    
    // Primeiro, buscar informações do treinamento
    const treinamento = await db.prepare(`
      SELECT codigo, nome 
      FROM catalogo_treinamentos_v2 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(treinamentoId).first();
    
    if (!treinamento) {
      console.log(`❌ Treinamento ${treinamentoId} não encontrado`);
      return c.json({ 
        error: 'Treinamento não encontrado',
        treinamento_id: treinamentoId
      }, 404);
    }
    
    console.log(`✅ Treinamento encontrado: ${treinamento.codigo} - ${treinamento.nome}`);
    
    // Buscar templates associados ao código do treinamento
    const templates = await db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo,
        st.numero_sessao,
        st.nome_sessao as nome,
        st.descricao,
        st.created_at,
        st.updated_at,
        COUNT(stm.manobra_catalogo_id) as total_manobras
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      WHERE st.treinamento_codigo = ?
      GROUP BY st.id
      ORDER BY st.numero_sessao ASC
    `).bind(treinamento.codigo).all();
    
    console.log(`📊 Query executada para código: ${treinamento.codigo}`);
    console.log(`📊 Resultados encontrados: ${templates.results?.length || 0}`);
    
    if (!templates.results || templates.results.length === 0) {
      console.log(`⚠️ Nenhum template encontrado para treinamento ${treinamento.codigo}`);
      
      // Verificar se existem templates em geral
      const totalTemplates = await db.prepare(`
        SELECT COUNT(*) as total FROM sessoes_template
      `).first();
      
      console.log(`📊 Total de templates no sistema: ${totalTemplates?.total || 0}`);
      
      return c.json({
        success: true,
        treinamento_id: treinamentoId,
        treinamento_codigo: treinamento.codigo,
        treinamento_nome: treinamento.nome,
        templates: [],
        total: 0,
        message: 'Este treinamento não possui templates de sessão cadastrados'
      });
    }
    
    // Formatar templates para o frontend
    const templatesFormatados = templates.results.map((template: any) => ({
      id: template.id,
      treinamento_id: treinamentoId,
      treinamento_codigo: template.treinamento_codigo,
      numero_sessao: template.numero_sessao,
      nome: template.nome || `Sessão ${template.numero_sessao}`,
      descricao: template.descricao,
      total_manobras: template.total_manobras || 0,
      created_at: template.created_at,
      updated_at: template.updated_at
    }));
    
    console.log(`✅ Encontrados ${templatesFormatados.length} templates para treinamento ${treinamentoId}`);
    console.log('📋 Templates:', templatesFormatados.map(t => `${t.numero_sessao}: ${t.nome} (${t.total_manobras} manobras)`));
    
    return c.json({
      success: true,
      treinamento_id: treinamentoId,
      treinamento_codigo: treinamento.codigo,
      treinamento_nome: treinamento.nome,
      templates: templatesFormatados,
      total: templatesFormatados.length
    });
    
  } catch (error) {
    console.error(`❌ Erro ao buscar templates do treinamento ${treinamentoId}:`, error);
    return c.json({ 
      error: 'Erro interno do servidor',
      treinamento_id: treinamentoId,
      details: (error as Error).message
    }, 500);
  }
});

// GET /api/v2/simulador/templates/{template_id}/manobras - Buscar manobras de um template específico
templatesApi.get('/:template_id/manobras', async (c) => {
  const { template_id } = c.req.param();
  const templateId = parseInt(template_id);
  
  if (!templateId) {
    return c.json({ error: 'ID do template inválido' }, 400);
  }
  
  try {
    console.log(`🎯 Buscando manobras do template ${templateId}...`);
    
    const db = c.env.DB;
    
    // Verificar se o template existe
    const template = await db.prepare(`
      SELECT st.*, ct.nome as treinamento_nome
      FROM sessoes_template st
      LEFT JOIN catalogo_treinamentos_v2 ct ON st.treinamento_codigo = ct.codigo
      WHERE st.id = ?
    `).bind(templateId).first();
    
    if (!template) {
      return c.json({ 
        error: 'Template não encontrado',
        template_id: templateId
      }, 404);
    }
    
    // Buscar manobras do template
    const manobras = await db.prepare(`
      SELECT 
        mc.id,
        mc.manobra_id_codigo,
        mc.nome_manobra,
        mc.descricao_detalhada,
        mc.categoria,
        mc.criterios_aprovacao,
        mc.pontuacao_minima,
        stm.sessao_template_id
      FROM sessoes_template_manobras stm
      INNER JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ?
      ORDER BY mc.manobra_id_codigo
    `).bind(templateId).all();
    
    const manobrasFormatadas = manobras.results.map((manobra: any) => ({
      id: manobra.id,
      codigo: manobra.manobra_id_codigo,
      nome: manobra.nome_manobra,
      descricao: manobra.descricao_detalhada,
      categoria: manobra.categoria,
      criterios_aprovacao: manobra.criterios_aprovacao,
      pontuacao_minima: manobra.pontuacao_minima
    }));
    
    console.log(`✅ Encontradas ${manobrasFormatadas.length} manobras para template ${templateId}`);
    
    return c.json({
      success: true,
      template: {
        id: template.id,
        nome: template.nome_sessao,
        numero_sessao: template.numero_sessao,
        treinamento_codigo: template.treinamento_codigo,
        treinamento_nome: template.treinamento_nome
      },
      manobras: manobrasFormatadas,
      total_manobras: manobrasFormatadas.length
    });
    
  } catch (error) {
    console.error(`❌ Erro ao buscar manobras do template ${templateId}:`, error);
    return c.json({ 
      error: 'Erro interno do servidor',
      template_id: templateId
    }, 500);
  }
});

export default templatesApi;
