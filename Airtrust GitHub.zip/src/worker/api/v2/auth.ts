import { Hono } from 'hono';
import { authMiddleware as mochaAuthMiddleware } from '../../middleware/auth';

interface Env {
  DB: any;
}

// Extend Hono context to include auth properties
declare module 'hono' {
  interface ContextVariableMap {
    user_id?: string;
    user_name?: string;
  }
}

const app = new Hono<{ Bindings: Env }>();

// API para retornar perfil do usuário atual (RBAC)
app.get('/me', mochaAuthMiddleware, async (c) => {
  try {
    // Pegar informações do usuário do middleware de auth
    const userId = c.get('user_id');
    const userName = c.get('user_name');
    
    if (!userId) {
      return c.json({ success: false, error: 'Usuário não autenticado' }, 401);
    }
    
    // Buscar perfil completo no banco
    const userProfile = await c.env.DB.prepare(`
      SELECT 
        user_id,
        funcionario_id,
        user_name,
        perfil,
        equipe,
        ativo,
        created_at,
        updated_at
      FROM user_profiles_v2 
      WHERE user_id = ? AND ativo = 1
      LIMIT 1
    `).bind(userId).first();
    
    if (!userProfile) {
      // Se não tem perfil, criar um básico como FUNCIONARIO
      const now = new Date().toISOString();
      
      await c.env.DB.prepare(`
        INSERT INTO user_profiles_v2 
        (user_id, user_name, perfil, ativo, created_at, updated_at)
        VALUES (?, ?, 'FUNCIONARIO', 1, ?, ?)
      `).bind(userId, userName || 'Usuário', now, now).run();
      
      return c.json({
        success: true,
        user_id: userId,
        user_name: userName || 'Usuário',
        perfil: 'FUNCIONARIO',
        equipe: null,
        funcionario_id: null,
        ativo: true,
        created_at: now,
        permissions: {
          pasta_virtual: false,
          admin: false,
          compliance: false
        }
      });
    }
    
    // Determinar permissões baseadas no perfil
    const permissions = {
      pasta_virtual: ['ADMIN', 'GESTOR', 'COMPLIANCE'].includes(userProfile.perfil),
      admin: userProfile.perfil === 'ADMIN',
      compliance: ['ADMIN', 'COMPLIANCE'].includes(userProfile.perfil),
      gestao: ['ADMIN', 'GESTOR'].includes(userProfile.perfil)
    };
    
    return c.json({
      success: true,
      user_id: userProfile.user_id,
      user_name: userProfile.user_name,
      perfil: userProfile.perfil,
      equipe: userProfile.equipe,
      funcionario_id: userProfile.funcionario_id,
      ativo: userProfile.ativo,
      created_at: userProfile.created_at,
      updated_at: userProfile.updated_at,
      permissions: permissions
    });
    
  } catch (error) {
    console.error('💥 [AUTH] Erro ao buscar perfil do usuário:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Erro interno' 
    }, 500);
  }
});

export default app;
