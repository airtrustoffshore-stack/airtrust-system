import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

interface Env {
  DB: any;
  R2?: any;
}

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ LISTAR FUNCIONÁRIOS ESPECÍFICO COM ESTRUTURA HIERARCHICA 5 PASTAS
app.get('/listar/:funcionario_id', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const funcionarioId = parseInt(c.req.param('funcionario_id'));
    
    if (!funcionarioId) {
      return c.json({ error: 'ID do funcionário é obrigatório' }, 400);
    }

    const db = c.env.DB;
    
    // Buscar dados do funcionário
    const funcionario = await db.prepare(`
      SELECT id, nome, matricula, funcao, status
      FROM funcionarios 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(funcionarioId).first();
    
    if (!funcionario) {
      return c.json({ error: 'Funcionário não encontrado' }, 404);
    }

    // Buscar certificações sincronizadas com detalhes completos
    const certificacoes = await db.prepare(`
      SELECT 
        pvsl.id as sync_id,
        pvsl.nome_arquivo_auditavel,
        pvsl.arquivo_pasta_virtual_url,
        pvsl.funcionario_nome,
        pvsl.funcionario_matricula,
        pvsl.treinamento_nome,
        pvsl.treinamento_codigo,
        pvsl.data_conclusao,
        pvsl.data_vencimento,
        pvsl.status_sincronizacao,
        pvsl.tamanho_bytes,
        pvsl.hash_md5,
        pvsl.data_sincronizacao,
        hc.nota_final,
        hc.instrutor,
        ct.categoria as treinamento_categoria,
        CASE 
          WHEN pvsl.data_vencimento IS NOT NULL AND pvsl.data_vencimento < DATE('now') THEN 'VENCIDO'
          WHEN pvsl.data_vencimento IS NOT NULL AND pvsl.data_vencimento <= DATE('now', '+30 days') THEN 'VENCENDO'
          ELSE 'VALIDO'
        END as status_validade
      FROM pasta_virtual_sync_log pvsl
      LEFT JOIN historico_certificacoes_v2 hc ON pvsl.historico_cert_id = hc.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE pvsl.funcionario_id = ? 
        AND pvsl.status_sincronizacao = 'SINCRONIZADO'
        AND pvsl.deleted_at IS NULL
      ORDER BY pvsl.data_conclusao DESC, pvsl.treinamento_codigo
    `).bind(funcionarioId).all();

    // Estrutura das 5 subpastas conforme especificação Enterprise
    const estruturaPastas = {
      certificacoes: {
        nome: 'Certificações',
        icone: 'certificate',
        descricao: 'Certificações técnicas e operacionais',
        arquivos: [] as any[]
      },
      treinamentos: {
        nome: 'Treinamentos',
        icone: 'book',
        descricao: 'Histórico completo de treinamentos',
        arquivos: [] as any[]
      },
      medicos: {
        nome: 'Documentos Médicos',
        icone: 'heart',
        descricao: 'CMA, ASO e documentos médicos',
        arquivos: [] as any[]
      },
      documentos_gerais: {
        nome: 'Documentos Gerais',
        icone: 'file',
        descricao: 'Documentos diversos e administrativos',
        arquivos: [] as any[]
      },
      fichas_simulador: {
        nome: 'Fichas de Simulador',
        icone: 'monitor',
        descricao: 'Preparado para Módulo 5 - Sistema de Simuladores',
        arquivos: [] as any[] // Preparado para futuro
      }
    };

    // Categorizar certificações nas subpastas
    certificacoes.results?.forEach((cert: any) => {
      const arquivo = {
        sync_id: cert.sync_id,
        nome_arquivo: cert.nome_arquivo_auditavel,
        treinamento: {
          codigo: cert.treinamento_codigo,
          nome: cert.treinamento_nome,
          categoria: cert.treinamento_categoria
        },
        certificacao: {
          data_conclusao: cert.data_conclusao,
          data_vencimento: cert.data_vencimento,
          nota_final: cert.nota_final,
          instrutor: cert.instrutor,
          status_validade: cert.status_validade
        },
        arquivo: {
          tamanho_bytes: cert.tamanho_bytes,
          hash_md5: cert.hash_md5,
          data_sincronizacao: cert.data_sincronizacao,
          url_download: `/api/v2/pasta-virtual/download/${cert.sync_id}`
        },
        funcionario: {
          nome: cert.funcionario_nome,
          matricula: cert.funcionario_matricula
        }
      };

      // Lógica de categorização
      if (cert.treinamento_categoria === 'MEDICO' || 
          cert.treinamento_codigo?.includes('CMA') || 
          cert.treinamento_codigo?.includes('ASO') ||
          cert.treinamento_codigo?.includes('MEDICO')) {
        (estruturaPastas.medicos.arquivos as any[]).push(arquivo);
      } else if (cert.treinamento_categoria === 'TECNICO' ||
                 cert.treinamento_categoria === 'OPERACIONAL') {
        (estruturaPastas.certificacoes.arquivos as any[]).push(arquivo);
      } else if (cert.treinamento_categoria === 'TREINAMENTO') {
        (estruturaPastas.treinamentos.arquivos as any[]).push(arquivo);
      } else {
        (estruturaPastas.documentos_gerais.arquivos as any[]).push(arquivo);
      }
    });

    // Estatísticas por pasta
    const estatisticas = {
      total_arquivos: certificacoes.results?.length || 0,
      certificacoes: estruturaPastas.certificacoes.arquivos.length,
      treinamentos: estruturaPastas.treinamentos.arquivos.length,
      medicos: estruturaPastas.medicos.arquivos.length,
      documentos_gerais: estruturaPastas.documentos_gerais.arquivos.length,
      fichas_simulador: estruturaPastas.fichas_simulador.arquivos.length,
      espaco_total_bytes: certificacoes.results?.reduce((acc: number, cert: any) => 
        acc + (cert.tamanho_bytes || 0), 0) || 0,
      ultimo_sync: certificacoes.results?.[0]?.data_sincronizacao || null,
      arquivos_vencidos: certificacoes.results?.filter((cert: any) => cert.status_validade === 'VENCIDO').length || 0,
      arquivos_vencendo: certificacoes.results?.filter((cert: any) => cert.status_validade === 'VENCENDO').length || 0
    };

    // Auditoria
    await logAudit(c, 'PASTA_VIRTUAL_LISTAR', 'pasta_virtual', funcionarioId.toString(), undefined, {
      funcionario_id: funcionarioId,
      total_arquivos: estatisticas.total_arquivos,
      pastas_com_conteudo: Object.values(estruturaPastas).filter(p => p.arquivos.length > 0).length
    });

    return c.json({
      success: true,
      funcionario: {
        id: funcionario.id,
        nome: funcionario.nome,
        matricula: funcionario.matricula,
        funcao: funcionario.funcao,
        status: funcionario.status
      },
      estrutura_pastas: estruturaPastas,
      estatisticas: estatisticas,
      rbac_permissions: {
        can_download: true,
        can_sync: true,
        can_manage: true // Baseado no middleware RBAC
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('💥 [PASTA-VIRTUAL] Erro ao listar estrutura:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno do servidor'
    }, 500);
  }
});

// ✅ SINCRONIZAR FUNCIONÁRIO ESPECÍFICO
app.post('/sync/:funcionario_id', requirePermission('funcionarios', 'UPDATE'), async (c) => {
  try {
    const funcionarioId = parseInt(c.req.param('funcionario_id'));
    
    if (!funcionarioId) {
      return c.json({ error: 'ID do funcionário é obrigatório' }, 400);
    }

    const db = c.env.DB;
    
    // Verificar se funcionário existe
    const funcionario = await db.prepare(`
      SELECT id, nome, matricula
      FROM funcionarios 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(funcionarioId).first();
    
    if (!funcionario) {
      return c.json({ error: 'Funcionário não encontrado' }, 404);
    }

    // Buscar certificações do funcionário que precisam ser sincronizadas
    const certificacoesParaSincronizar = await db.prepare(`
      SELECT 
        hc.id,
        hc.funcionario_id,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        ct.codigo as treinamento_codigo,
        ct.nome as treinamento_nome,
        hc.certificado_url,
        hc.data_conclusao,
        hc.data_vencimento,
        hc.instrutor
      FROM historico_certificacoes_v2 hc
      LEFT JOIN funcionarios f ON hc.funcionario_id = f.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      LEFT JOIN pasta_virtual_sync_log pvsl ON hc.id = pvsl.historico_cert_id AND pvsl.deleted_at IS NULL
      WHERE hc.funcionario_id = ?
        AND hc.certificado_url IS NOT NULL 
        AND hc.certificado_url != ''
        AND NOT hc.certificado_url LIKE 'mock://%'
        AND hc.deleted_at IS NULL 
        AND f.deleted_at IS NULL 
        AND ct.deleted_at IS NULL
        AND pvsl.id IS NULL -- Não sincronizado ainda
      ORDER BY hc.created_at DESC
    `).bind(funcionarioId).all();

    const resultados = {
      funcionario: {
        id: funcionario.id,
        nome: funcionario.nome,
        matricula: funcionario.matricula
      },
      certificacoes_encontradas: certificacoesParaSincronizar.results?.length || 0,
      sincronizados: 0,
      erros: 0,
      detalhes: []
    };

    // Sincronizar cada certificação individualmente
    if (certificacoesParaSincronizar.results && certificacoesParaSincronizar.results.length > 0) {
      
      for (const cert of certificacoesParaSincronizar.results) {
        try {
          // Gerar nome do arquivo auditável
          const dataFormatada = new Date(cert.data_conclusao).toISOString().slice(0, 10).replace(/-/g, '');
          const nomeArquivoAuditavel = `CERT_${cert.funcionario_matricula}_${cert.treinamento_codigo}_${dataFormatada}.pdf`;
          
          // Simular URL da Pasta Virtual (em produção seria R2)
          const caminhoR2 = `pasta-virtual/funcionarios/${cert.funcionario_matricula}_${cert.funcionario_nome.replace(/[^a-zA-Z0-9]/g, '_')}/certificacoes/${nomeArquivoAuditavel}`;
          const urlPastaVirtual = cert.certificado_url.includes('mock://') 
            ? `mock://pasta-virtual/${nomeArquivoAuditavel}`
            : `https://airtrust-storage.r2.cloudflarestorage.com/${caminhoR2}`;

          // Inserir no log de sincronização
          const syncResult = await db.prepare(`
            INSERT INTO pasta_virtual_sync_log (
              funcionario_id, historico_cert_id, arquivo_original_url, arquivo_pasta_virtual_url,
              nome_arquivo_auditavel, funcionario_nome, funcionario_matricula,
              treinamento_nome, treinamento_codigo, data_conclusao, data_vencimento,
              status_sincronizacao, tamanho_bytes, hash_md5, data_sincronizacao,
              tentativas_sincronizacao, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `).bind(
            cert.funcionario_id,
            cert.id,
            cert.certificado_url,
            urlPastaVirtual,
            nomeArquivoAuditavel,
            cert.funcionario_nome,
            cert.funcionario_matricula,
            cert.treinamento_nome,
            cert.treinamento_codigo,
            cert.data_conclusao,
            cert.data_vencimento,
            'SINCRONIZADO',
            1024 + Math.floor(Math.random() * 10000), // Mock tamanho
            `md5_${Date.now()}_${cert.id}`, // Mock hash
            new Date().toISOString(),
            1,
            new Date().toISOString(),
            new Date().toISOString()
          ).run();

          resultados.sincronizados++;
          (resultados.detalhes as any[]).push({
            historico_id: cert.id,
            treinamento: cert.treinamento_nome,
            status: 'SUCESSO',
            arquivo: nomeArquivoAuditavel,
            sync_id: syncResult.meta?.last_row_id
          });

        } catch (syncError) {
          console.error(`❌ Erro ao sincronizar certificação ${cert.id}:`, syncError);
          resultados.erros++;
          (resultados.detalhes as any[]).push({
            historico_id: cert.id,
            treinamento: cert.treinamento_nome,
            status: 'ERRO',
            erro: syncError instanceof Error ? syncError.message : 'Erro desconhecido'
          });
        }
      }
    }

    // Auditoria
    await logAudit(c, 'PASTA_VIRTUAL_SYNC', 'funcionario', funcionarioId.toString(), undefined, {
      funcionario_id: funcionarioId,
      certificacoes_encontradas: resultados.certificacoes_encontradas,
      sincronizados: resultados.sincronizados,
      erros: resultados.erros
    });

    return c.json({
      success: true,
      resultados: resultados,
      timestamp: new Date().toISOString(),
      message: `Sincronização concluída: ${resultados.sincronizados} sucessos, ${resultados.erros} erros`
    });

  } catch (error) {
    console.error('💥 [SYNC-FUNCIONARIO] Erro:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno do servidor'
    }, 500);
  }
});

// ✅ DOWNLOAD AUDITÁVEL COM RBAC
app.get('/download/:sync_id', requirePermission('pasta_virtual', 'READ'), async (c) => {
  try {
    const syncId = parseInt(c.req.param('sync_id'));
    
    if (!syncId) {
      return c.json({ error: 'ID de sincronização é obrigatório' }, 400);
    }

    const db = c.env.DB;
    
    // Buscar registro de sincronização
    const syncRecord = await db.prepare(`
      SELECT 
        pvsl.*,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        ct.nome as treinamento_nome,
        ct.codigo as treinamento_codigo
      FROM pasta_virtual_sync_log pvsl
      LEFT JOIN funcionarios f ON pvsl.funcionario_id = f.id
      LEFT JOIN historico_certificacoes_v2 hc ON pvsl.historico_cert_id = hc.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE pvsl.id = ? 
        AND pvsl.status_sincronizacao = 'SINCRONIZADO'
        AND pvsl.deleted_at IS NULL
    `).bind(syncId).first();
    
    if (!syncRecord) {
      return c.json({ error: 'Arquivo não encontrado ou não sincronizado' }, 404);
    }

    // TODO: Validar RBAC - funcionário só pode baixar seus próprios arquivos
    // if (user.perfil === 'FUNCIONARIO' && syncRecord.funcionario_id !== user.funcionario_id) {
    //   return c.json({ error: 'Acesso negado' }, 403);
    // }

    // Log de auditoria para download
    await logAudit(c, 'PASTA_VIRTUAL_DOWNLOAD', 'pasta_virtual_sync_log', syncId.toString(), undefined, {
      sync_id: syncId,
      funcionario_id: syncRecord.funcionario_id,
      funcionario_nome: syncRecord.funcionario_nome,
      arquivo: syncRecord.nome_arquivo_auditavel,
      tamanho_bytes: syncRecord.tamanho_bytes,
      hash_md5: syncRecord.hash_md5,
      ip_address: c.req.header('CF-Connecting-IP') || 'unknown',
      user_agent: c.req.header('User-Agent') || 'unknown'
    });

    const urlDownload = String(syncRecord.arquivo_pasta_virtual_url || '');

    // Para desenvolvimento - mock response
    if (String(urlDownload).includes('mock://')) {
      return c.json({
        success: true,
        download_type: 'mock',
        arquivo: {
          nome: syncRecord.nome_arquivo_auditavel,
          tamanho_bytes: syncRecord.tamanho_bytes,
          hash_md5: syncRecord.hash_md5,
          funcionario: syncRecord.funcionario_nome,
          treinamento: syncRecord.treinamento_nome,
          data_conclusao: syncRecord.data_conclusao,
          url_mock: urlDownload
        },
        message: 'Download simulado - arquivo mock para desenvolvimento'
      });
    }

    // Em produção: redirect para URL do R2
    return c.redirect(String(urlDownload));

  } catch (error) {
    console.error('💥 [DOWNLOAD] Erro:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno do servidor'
    }, 500);
  }
});

export default app;
