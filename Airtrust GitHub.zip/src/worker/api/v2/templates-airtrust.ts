import { Hono } from 'hono';
import * as XLSX from 'xlsx';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ CONFIGURAÇÃO PARA TEMPLATES TOTALMENTE DESPROTEGIDOS
// Templates são criados sem qualquer proteção ou restrição

// ✅ FUNÇÃO PARA CRIAR WORKBOOK TOTALMENTE DESPROTEGIDO
const criarWorkbookDesprotegido = (dados: any[], nomeSheet: string = 'Dados') => {
  console.log('📊 [TEMPLATE] Criando workbook totalmente desprotegido...');
  
  // Criar workbook vazio
  const workbook = XLSX.utils.book_new();
  
  // ✅ GARANTIR QUE NÃO HÁ PROTEÇÕES NO WORKBOOK
  // Workbook criado sem propriedades de proteção
  
  // Criar worksheet dos dados
  const worksheet = XLSX.utils.aoa_to_sheet(dados);
  
  // ✅ GARANTIR QUE NÃO HÁ PROTEÇÕES NA PLANILHA
  // Remover qualquer proteção existente
  delete worksheet['!protect'];
  
  // ✅ GARANTIR QUE TODAS AS CÉLULAS SÃO EDITÁVEIS
  const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1');
  
  for (let R = range.s.r; R <= range.e.r; ++R) {
    for (let C = range.s.c; C <= range.e.c; ++C) {
      const cellAddress = XLSX.utils.encode_cell({ r: R, c: C });
      const cell = worksheet[cellAddress];
      
      if (cell) {
        // Remover qualquer proteção da célula
        if (cell.s) {
          delete cell.s.protection;
        }
        
        // Garantir que célula não está travada
        if (!cell.s) cell.s = {};
        if (cell.s.protection) {
          delete cell.s.protection;
        }
      }
    }
  }
  
  // Definir larguras automáticas para melhor UX
  const maxWidths: number[] = [];
  dados.forEach((row: any[]) => {
    row.forEach((cell: any, colIndex: number) => {
      const cellLength = String(cell || '').length;
      maxWidths[colIndex] = Math.max(maxWidths[colIndex] || 10, Math.min(cellLength + 2, 50));
    });
  });
  
  worksheet['!cols'] = maxWidths.map(width => ({ width }));
  
  // Adicionar worksheet ao workbook
  XLSX.utils.book_append_sheet(workbook, worksheet, nomeSheet);
  
  console.log('✅ [TEMPLATE] Workbook desprotegido criado com sucesso');
  return workbook;
};

// ✅ GET /api/v2/templates-airtrust/certificacoes/csv - Template CSV Certificações (Totalmente Editável)
app.get('/certificacoes/csv', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    console.log('📋 [TEMPLATE CSV] Gerando template de certificações...');
    
    const csvTemplate = [
      // Header com todos os campos possíveis
      'funcionario_matricula,treinamento_codigo,treinamento_nome,data_conclusao,data_vencimento,instrutor,local_realizacao,nota_final,observacoes,certificado_url',
      
      // Exemplos práticos e variados
      '12345,CMA-INICIAL,Curso Medicina Aeronáutica Inicial,2024-01-15,2025-01-15,Dr. João Silva,CENIPA Brasília,9.0,Certificação inicial aprovada com excelência,',
      '12346,REV-ANUAL,Revisão Anual CMA,2024-02-20,2025-02-20,Dra. Maria Costa,Hospital Aeronáutico,8.5,Revisão anual - renovação de certificado,',
      '12347,TRM-EMERGENCIA,Treinamento Emergências Médicas,2024-03-10,2024-09-10,Cap. Pedro Santos,Centro Treinamento RJ,7.8,Treinamento obrigatório semestral concluído,',
      '12348,SIM-ALTITUDE,Simulação Medicina de Altitude,2024-04-05,2025-04-05,Maj. Ana Lima,CEMAL São Paulo,9.2,Simulação aprovada - apto para voos de altitude,',
      '12349,CUR-TOXICOLOGIA,Curso Toxicologia Aeronáutica,2024-05-12,2026-05-12,Prof. Carlos Mendes,UNIFESP,8.0,Curso bienal - certificado para 2 anos,'
    ].join('\n');
    
    await logAudit(c, 'DOWNLOAD_TEMPLATE', 'certificacoes_csv', undefined, undefined, {
      template_type: 'CSV_CERTIFICACOES',
      protection_level: 'NONE',
      file_format: 'CSV'
    });
    
    console.log('✅ [TEMPLATE CSV] Template gerado - totalmente editável');
    
    return new Response(csvTemplate, {
      headers: {
        'Content-Type': 'text/csv;charset=utf-8',
        'Content-Disposition': 'attachment; filename="Template_Certificacoes_AirTrust_Editavel.csv"',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
        'X-Template-Protection': 'NONE',
        'X-Template-Editable': 'TRUE',
        'X-AirTrust-Version': 'DESPROTEGIDO_v1.0'
      }
    });
    
  } catch (error) {
    console.error('❌ [TEMPLATE CSV] Erro:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao gerar template CSV',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// ✅ GET /api/v2/templates-airtrust/certificacoes/xlsx - Template XLSX Certificações (Totalmente Editável)
app.get('/certificacoes/xlsx', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    console.log('📊 [TEMPLATE XLSX] Gerando template Excel de certificações...');
    
    const dadosTemplate = [
      // Header descritivo
      ['funcionario_matricula', 'treinamento_codigo', 'treinamento_nome', 'data_conclusao', 'data_vencimento', 'instrutor', 'local_realizacao', 'nota_final', 'observacoes', 'certificado_url'],
      
      // Exemplos com dados realistas no formato brasileiro
      ['00300', 'CMA-INICIAL', 'Curso Medicina Aeronáutica Inicial', '20/08/2025', '19/08/2026', 'Dr. João Silva', 'CENIPA Brasília', 9.0, 'Certificação inicial aprovada com excelência', ''],
      ['00301', 'REV-ANUAL', 'Revisão Anual CMA', '17/09/2025', '16/09/2026', 'Dra. Maria Costa', 'Hospital Aeronáutico', 8.5, 'Revisão anual - renovação de certificado', ''],
      ['00302', 'TRM-EMERGENCIA', 'Treinamento Emergências Médicas', '15/08/2025', '14/02/2026', 'Cap. Pedro Santos', 'Centro Treinamento RJ', 7.8, 'Treinamento obrigatório semestral concluído', ''],
      ['00303', 'SIM-ALTITUDE', 'Simulação Medicina de Altitude', '10/09/2025', '09/09/2026', 'Maj. Ana Lima', 'CEMAL São Paulo', 9.2, 'Simulação aprovada - apto para voos de altitude', ''],
      ['00304', 'CUR-TOXICOLOGIA', 'Curso Toxicologia Aeronáutica', '25/08/2025', '24/08/2027', 'Prof. Carlos Mendes', 'UNIFESP', 8.0, 'Curso bienal - certificado para 2 anos', '']
    ];
    
    // Criar workbook totalmente desprotegido
    const workbook = criarWorkbookDesprotegido(dadosTemplate, 'Certificações');
    
    // Adicionar sheet de instruções (também desprotegido)
    const instrucoes = [
      ['📋 INSTRUÇÕES - Template Certificações AirTrust'],
      [''],
      ['✅ ARQUIVO TOTALMENTE EDITÁVEL - SEM RESTRIÇÕES'],
      ['• Você pode modificar qualquer célula, linha ou coluna'],
      ['• Pode copiar e colar dados sem avisos'],
      ['• Pode remover ou adicionar colunas livremente'],
      ['• Pode salvar em qualquer formato'],
      ['• Não há senha nem proteção'],
      [''],
      ['📋 CAMPOS OBRIGATÓRIOS:'],
      ['• funcionario_matricula: Matrícula do funcionário (deve existir no sistema)'],
      ['• treinamento_codigo: Código do treinamento'],
      ['• data_conclusao: Data no formato YYYY-MM-DD'],
      [''],
      ['📋 CAMPOS OPCIONAIS:'],
      ['• treinamento_nome: Nome do treinamento (será criado automaticamente se não existir)'],
      ['• data_vencimento: Data de vencimento'],
      ['• instrutor: Nome do instrutor'],
      ['• local_realizacao: Local onde foi realizado'],
      ['• nota_final: Nota (número decimal, ex: 8.5)'],
      ['• observacoes: Observações adicionais'],
      ['• certificado_url: URL do certificado (opcional)'],
      [''],
      ['🎯 DICAS:'],
      ['• Use a aba "Certificações" para seus dados'],
      ['• Mantenha o formato de data YYYY-MM-DD'],
      ['• Funcionários devem estar cadastrados no sistema'],
      ['• Treinamentos serão criados automaticamente se não existirem'],
      [''],
      ['✅ ARQUIVO SEM PROTEÇÃO - EDITE LIVREMENTE!']
    ];
    
    const worksheetInstrucoes = XLSX.utils.aoa_to_sheet(instrucoes);
    
    // ✅ GARANTIR QUE INSTRUÇÕES TAMBÉM NÃO TÊM PROTEÇÃO
    delete worksheetInstrucoes['!protect'];
    
    XLSX.utils.book_append_sheet(workbook, worksheetInstrucoes, 'Instruções');
    
    // Gerar arquivo Excel
    const xlsxBuffer = XLSX.write(workbook, { 
      type: 'buffer', 
      bookType: 'xlsx',
      compression: false
    });
    
    await logAudit(c, 'DOWNLOAD_TEMPLATE', 'certificacoes_xlsx', undefined, undefined, {
      template_type: 'XLSX_CERTIFICACOES',
      protection_level: 'NONE',
      file_format: 'XLSX',
      sheets: ['Certificações', 'Instruções']
    });
    
    console.log('✅ [TEMPLATE XLSX] Template Excel gerado - totalmente editável');
    
    return c.body(xlsxBuffer, 200, {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': 'attachment; filename="Template_Certificacoes_AirTrust_Editavel.xlsx"',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0',
      'X-Template-Protection': 'NONE',
      'X-Template-Editable': 'TRUE',
      'X-Template-Password': 'NONE',
      'X-AirTrust-Version': 'DESPROTEGIDO_v1.0'
    });
    
  } catch (error) {
    console.error('❌ [TEMPLATE XLSX] Erro:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao gerar template Excel',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// ✅ GET /api/v2/templates-airtrust/funcionarios/csv - Template CSV Funcionários (Totalmente Editável)
app.get('/funcionarios/csv', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    console.log('📋 [TEMPLATE CSV] Gerando template de funcionários...');
    
    const csvTemplate = [
      // Header com todos os campos
      'nome,matricula,cpf,codigo_anac,funcao,base,contrato,telefone,email,status,guerra,data_nascimento,licenca_aeronautica,codigo_canac,codigo_sispat,codigo_prestserv,data_admissao,anv,cma_numero,cma_data_vencimento,cma_status,aso_data_vencimento,nivel_icao,nivel_icao_data_vencimento,nivel_icao_status,is_instrutor,is_checador,aeronave_principal',
      
      // Exemplos
      'João Silva Santos,12345,123.456.789-01,12345-ANAC,Médico Aeronáutico,Brasília,CLT,61999887766,joao.silva@airtrust.com,ATIVO,Silva,1980-05-15,CMA-123456,CAN-001,SIS-001,PREST-001,2020-01-15,ANV-001,CMA-789123,2025-05-15,VÁLIDO,2024-12-31,ICAO-4,2025-03-20,VÁLIDO,1,0,EMB-190',
      'Maria Costa Lima,12346,987.654.321-02,67890-ANAC,Enfermeira Aero,São Paulo,PJ,11988776655,maria.costa@airtrust.com,ATIVO,Costa,1985-08-22,ENF-654321,CAN-002,SIS-002,PREST-002,2021-06-10,ANV-002,,,PENDENTE,2024-11-30,ICAO-3,2024-10-15,VÁLIDO,0,1,A320',
      'Pedro Santos Oliveira,12347,456.789.123-03,11111-ANAC,Paramédico,Rio de Janeiro,CLT,21977665544,pedro.santos@airtrust.com,ATIVO,Santos,1990-12-03,PAR-987654,CAN-003,SIS-003,PREST-003,2022-03-25,ANV-003,CMA-456789,2025-12-03,VÁLIDO,2024-10-25,ICAO-3,2025-01-10,VENCENDO,0,0,B737'
    ].join('\n');
    
    await logAudit(c, 'DOWNLOAD_TEMPLATE', 'funcionarios_csv', undefined, undefined, {
      template_type: 'CSV_FUNCIONARIOS',
      protection_level: 'NONE',
      file_format: 'CSV'
    });
    
    return new Response(csvTemplate, {
      headers: {
        'Content-Type': 'text/csv;charset=utf-8',
        'Content-Disposition': 'attachment; filename="Template_Funcionarios_AirTrust_Editavel.csv"',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
        'X-Template-Protection': 'NONE',
        'X-Template-Editable': 'TRUE'
      }
    });
    
  } catch (error) {
    console.error('❌ [TEMPLATE CSV] Erro:', error);
    return c.json({ success: false, error: 'Erro ao gerar template CSV' }, 500);
  }
});

// ✅ GET /api/v2/templates-airtrust/funcionarios/xlsx - Template XLSX Funcionários (Totalmente Editável)
app.get('/funcionarios/xlsx', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    console.log('📊 [TEMPLATE XLSX] Gerando template Excel de funcionários...');
    
    const dadosTemplate = [
      // Header
      ['nome', 'matricula', 'cpf', 'codigo_anac', 'funcao', 'base', 'contrato', 'telefone', 'email', 'status', 'guerra', 'data_nascimento', 'licenca_aeronautica', 'codigo_canac', 'codigo_sispat', 'codigo_prestserv', 'data_admissao', 'anv', 'cma_numero', 'cma_data_vencimento', 'cma_status', 'aso_data_vencimento', 'nivel_icao', 'nivel_icao_data_vencimento', 'nivel_icao_status', 'is_instrutor', 'is_checador', 'aeronave_principal'],
      
      // Exemplos
      ['João Silva Santos', '12345', '123.456.789-01', '12345-ANAC', 'Médico Aeronáutico', 'Brasília', 'CLT', '61999887766', 'joao.silva@airtrust.com', 'ATIVO', 'Silva', '1980-05-15', 'CMA-123456', 'CAN-001', 'SIS-001', 'PREST-001', '2020-01-15', 'ANV-001', 'CMA-789123', '2025-05-15', 'VÁLIDO', '2024-12-31', 'ICAO-4', '2025-03-20', 'VÁLIDO', 1, 0, 'EMB-190'],
      ['Maria Costa Lima', '12346', '987.654.321-02', '67890-ANAC', 'Enfermeira Aero', 'São Paulo', 'PJ', '11988776655', 'maria.costa@airtrust.com', 'ATIVO', 'Costa', '1985-08-22', 'ENF-654321', 'CAN-002', 'SIS-002', 'PREST-002', '2021-06-10', 'ANV-002', '', '', 'PENDENTE', '2024-11-30', 'ICAO-3', '2024-10-15', 'VÁLIDO', 0, 1, 'A320'],
      ['Pedro Santos Oliveira', '12347', '456.789.123-03', '11111-ANAC', 'Paramédico', 'Rio de Janeiro', 'CLT', '21977665544', 'pedro.santos@airtrust.com', 'ATIVO', 'Santos', '1990-12-03', 'PAR-987654', 'CAN-003', 'SIS-003', 'PREST-003', '2022-03-25', 'ANV-003', 'CMA-456789', '2025-12-03', 'VÁLIDO', '2024-10-25', 'ICAO-3', '2025-01-10', 'VENCENDO', 0, 0, 'B737']
    ];
    
    const workbook = criarWorkbookDesprotegido(dadosTemplate, 'Funcionários');
    
    // Adicionar sheet de mapeamento de campos
    const mapeamentoCampos = [
      ['📋 MAPEAMENTO DE CAMPOS - Funcionários AirTrust'],
      [''],
      ['✅ ARQUIVO TOTALMENTE EDITÁVEL - SEM RESTRIÇÕES'],
      [''],
      ['CAMPO', 'DESCRIÇÃO', 'OBRIGATÓRIO', 'FORMATO/EXEMPLO'],
      ['nome', 'Nome completo do funcionário', 'SIM', 'João Silva Santos'],
      ['matricula', 'Matrícula única (será normalizada automaticamente)', 'SIM', '12345 ou 00123'],
      ['cpf', 'CPF do funcionário', 'NÃO', '123.456.789-01'],
      ['codigo_anac', 'Código ANAC', 'NÃO', '12345-ANAC'],
      ['funcao', 'Função/cargo', 'SIM', 'Médico Aeronáutico'],
      ['base', 'Base de trabalho', 'NÃO', 'Brasília'],
      ['contrato', 'Tipo de contrato', 'NÃO', 'CLT, PJ, Terceiro'],
      ['telefone', 'Telefone de contato', 'NÃO', '61999887766'],
      ['email', 'Email corporativo', 'NÃO', 'nome@empresa.com'],
      ['status', 'Status do funcionário', 'NÃO', 'ATIVO, INATIVO'],
      ['guerra', 'Nome de guerra/apelido', 'NÃO', 'Silva'],
      ['data_nascimento', 'Data de nascimento', 'NÃO', '1980-05-15 (YYYY-MM-DD)'],
      ['licenca_aeronautica', 'Licença aeronáutica', 'NÃO', 'CMA-123456'],
      ['codigo_canac', 'Código CANAC', 'NÃO', 'CAN-001'],
      ['codigo_sispat', 'Código SISPAT', 'NÃO', 'SIS-001'],
      ['codigo_prestserv', 'Código PRESTSERV', 'NÃO', 'PREST-001'],
      ['data_admissao', 'Data de admissão', 'NÃO', '2020-01-15 (YYYY-MM-DD)'],
      ['anv', 'Código ANV', 'NÃO', 'ANV-001'],
      ['cma_numero', 'Número do CMA', 'NÃO', 'CMA-789123'],
      ['cma_data_vencimento', 'Vencimento do CMA', 'NÃO', '2025-05-15 (YYYY-MM-DD)'],
      ['cma_status', 'Status do CMA', 'NÃO', 'VÁLIDO, VENCIDO, PENDENTE'],
      ['aso_data_vencimento', 'Vencimento do ASO', 'NÃO', '2024-12-31 (YYYY-MM-DD)'],
      ['nivel_icao', 'Nível ICAO', 'NÃO', 'ICAO-4'],
      ['nivel_icao_data_vencimento', 'Vencimento ICAO', 'NÃO', '2025-03-20 (YYYY-MM-DD)'],
      ['nivel_icao_status', 'Status ICAO', 'NÃO', 'VÁLIDO, VENCIDO, VENCENDO'],
      ['is_instrutor', 'É instrutor?', 'NÃO', '1 (sim) ou 0 (não)'],
      ['is_checador', 'É checador?', 'NÃO', '1 (sim) ou 0 (não)'],
      ['aeronave_principal', 'Aeronave principal', 'NÃO', 'EMB-190, A320, B737'],
      [''],
      ['🎯 INSTRUÇÕES:'],
      ['• Campos obrigatórios: nome, matricula, funcao'],
      ['• Datas no formato YYYY-MM-DD'],
      ['• Status: use ATIVO ou INATIVO'],
      ['• Booleanos: use 1 para SIM e 0 para NÃO'],
      ['• Matrículas serão normalizadas automaticamente'],
      [''],
      ['✅ ARQUIVO TOTALMENTE EDITÁVEL - MODIFIQUE COMO DESEJAR!']
    ];
    
    const worksheetMapeamento = XLSX.utils.aoa_to_sheet(mapeamentoCampos);
    delete worksheetMapeamento['!protect'];
    XLSX.utils.book_append_sheet(workbook, worksheetMapeamento, 'Mapeamento de Campos');
    
    const xlsxBuffer = XLSX.write(workbook, { 
      type: 'buffer', 
      bookType: 'xlsx',
      compression: false 
    });
    
    await logAudit(c, 'DOWNLOAD_TEMPLATE', 'funcionarios_xlsx', undefined, undefined, {
      template_type: 'XLSX_FUNCIONARIOS',
      protection_level: 'NONE',
      file_format: 'XLSX'
    });
    
    return c.body(xlsxBuffer, 200, {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': 'attachment; filename="Template_Funcionarios_AirTrust_Editavel.xlsx"',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'X-Template-Protection': 'NONE',
      'X-Template-Editable': 'TRUE',
      'X-Template-Password': 'NONE'
    });
    
  } catch (error) {
    console.error('❌ [TEMPLATE XLSX] Erro:', error);
    return c.json({ success: false, error: 'Erro ao gerar template Excel' }, 500);
  }
});

// ✅ GET /api/v2/templates-airtrust/treinamentos/csv - Template CSV Treinamentos (Totalmente Editável)
app.get('/treinamentos/csv', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const csvTemplate = [
      'codigo,nome,descricao,categoria,periodicidade_meses,instrutor_obrigatorio,nota_minima,carga_horaria,ativo,obrigatorio_funcoes,tipo_vencimento',
      'CMA-INICIAL,Curso Medicina Aeronáutica Inicial,Curso inicial obrigatório para médicos aeronáuticos,MEDICINA,12,1,7.0,40,1,"Médico Aeronáutico;Médico Chefe",FINAL_MES',
      'REV-ANUAL,Revisão Anual CMA,Revisão anual obrigatória,MEDICINA,12,1,7.0,8,1,"Médico Aeronáutico",FINAL_MES',
      'TRM-EMERGENCIA,Treinamento Emergências Médicas,Treinamento semestral,EMERGENCIA,6,1,8.0,16,1,"Paramédico;Enfermeiro Aero",DIA_EXATO',
      'SIM-ALTITUDE,Simulação Medicina de Altitude,Treinamento específico,SIMULACAO,24,1,7.5,12,1,"Médico Aeronáutico",FINAL_MES'
    ].join('\n');
    
    return new Response(csvTemplate, {
      headers: {
        'Content-Type': 'text/csv;charset=utf-8',
        'Content-Disposition': 'attachment; filename="Template_Treinamentos_AirTrust_Editavel.csv"',
        'X-Template-Protection': 'NONE',
        'X-Template-Editable': 'TRUE'
      }
    });
    
  } catch (error) {
    return c.json({ success: false, error: 'Erro ao gerar template' }, 500);
  }
});

// ✅ GET /api/v2/templates-airtrust/treinamentos/xlsx - Template XLSX Treinamentos (Totalmente Editável)
app.get('/treinamentos/xlsx', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const dadosTemplate = [
      ['codigo', 'nome', 'descricao', 'categoria', 'periodicidade_meses', 'instrutor_obrigatorio', 'nota_minima', 'carga_horaria', 'ativo', 'obrigatorio_funcoes', 'tipo_vencimento'],
      ['CMA-INICIAL', 'Curso Medicina Aeronáutica Inicial', 'Curso inicial obrigatório para médicos aeronáuticos', 'MEDICINA', 12, 1, 7.0, 40, 1, 'Médico Aeronáutico;Médico Chefe', 'FINAL_MES'],
      ['REV-ANUAL', 'Revisão Anual CMA', 'Revisão anual obrigatória', 'MEDICINA', 12, 1, 7.0, 8, 1, 'Médico Aeronáutico', 'FINAL_MES'],
      ['TRM-EMERGENCIA', 'Treinamento Emergências Médicas', 'Treinamento semestral', 'EMERGENCIA', 6, 1, 8.0, 16, 1, 'Paramédico;Enfermeiro Aero', 'DIA_EXATO'],
      ['SIM-ALTITUDE', 'Simulação Medicina de Altitude', 'Treinamento específico', 'SIMULACAO', 24, 1, 7.5, 12, 1, 'Médico Aeronáutico', 'FINAL_MES']
    ];
    
    const workbook = criarWorkbookDesprotegido(dadosTemplate, 'Treinamentos');
    const xlsxBuffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    
    return c.body(xlsxBuffer, 200, {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': 'attachment; filename="Template_Treinamentos_AirTrust_Editavel.xlsx"',
      'X-Template-Protection': 'NONE',
      'X-Template-Editable': 'TRUE'
    });
    
  } catch (error) {
    return c.json({ success: false, error: 'Erro ao gerar template Excel' }, 500);
  }
});

// ✅ GET /api/v2/templates-airtrust/test-protection - Endpoint para testar proteções
app.get('/test-protection', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    console.log('🧪 [TEST] Testando geração de arquivo totalmente desprotegido...');
    
    const dadosTest = [
      ['Campo1', 'Campo2', 'Campo3', 'Campo4'],
      ['Teste1', 'Valor1', 'Data1', 'Info1'],
      ['Teste2', 'Valor2', 'Data2', 'Info2']
    ];
    
    const workbook = criarWorkbookDesprotegido(dadosTest, 'Teste');
    
    // Adicionar sheet de verificação
    const verificacao = [
      ['🧪 TESTE DE PROTEÇÃO - AirTrust'],
      [''],
      ['✅ Este arquivo deve estar TOTALMENTE DESPROTEGIDO'],
      [''],
      ['VERIFICAÇÕES:'],
      ['1. Nenhuma senha solicitada ao abrir ✓'],
      ['2. Todas as células editáveis ✓'],
      ['3. Colunas podem ser inseridas/removidas ✓'],
      ['4. Linhas podem ser inseridas/removidas ✓'],
      ['5. Copiar/colar funciona sem avisos ✓'],
      ['6. Pode salvar em qualquer formato ✓'],
      ['7. Não há marcação de "somente leitura" ✓'],
      ['8. Planilha não marcada como "Protegida" ✓'],
      [''],
      ['📝 INSTRUÇÕES DE TESTE:'],
      ['• Tente editar qualquer célula'],
      ['• Tente inserir uma nova coluna'],
      ['• Tente remover uma linha'],
      ['• Tente copiar/colar dados'],
      ['• Tente salvar o arquivo'],
      [''],
      ['✅ SE TODAS AÇÕES FUNCIONARAM: ARQUIVO ESTÁ CORRETO!'],
      ['❌ SE ALGUMA FALHOU: REPORTAR ERRO PARA SUPORTE'],
      [''],
      ['Timestamp:', new Date().toISOString()],
      ['Versão:', 'DESPROTEGIDO_v1.0']
    ];
    
    const worksheetVerificacao = XLSX.utils.aoa_to_sheet(verificacao);
    delete worksheetVerificacao['!protect'];
    XLSX.utils.book_append_sheet(workbook, worksheetVerificacao, 'Verificação');
    
    const xlsxBuffer = XLSX.write(workbook, { 
      type: 'buffer', 
      bookType: 'xlsx',
      compression: false
    });
    
    await logAudit(c, 'TEST_PROTECTION', 'template_test', undefined, undefined, {
      test_type: 'DESPROTECAO_COMPLETA',
      protection_level: 'NONE',
      timestamp: new Date().toISOString()
    });
    
    return c.body(xlsxBuffer, 200, {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': 'attachment; filename="TESTE_Protecao_AirTrust_DESPROTEGIDO.xlsx"',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'X-Template-Protection': 'NONE',
      'X-Template-Password': 'NONE',
      'X-Template-ReadOnly': 'FALSE',
      'X-Template-Locked': 'FALSE',
      'X-Test-Timestamp': new Date().toISOString()
    });
    
  } catch (error) {
    console.error('❌ [TEST] Erro:', error);
    return c.json({ 
      success: false, 
      error: 'Erro no teste de proteção',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
