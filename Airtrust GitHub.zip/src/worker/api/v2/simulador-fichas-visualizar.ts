import { Context } from 'hono';

interface Database {
  prepare(query: string): {
    bind(...params: any[]): {
      all(): Promise<any[]>;
      first(): Promise<any>;
      run(): Promise<any>;
    };
  };
}

function formatarDataBrasil(dateStr: string | Date): string {
  if (!dateStr) return 'N/A';
  
  try {
    const date = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
    if (isNaN(date.getTime())) return 'N/A';
    
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return 'N/A';
  }
}

// Buscar detalhes completos de uma ficha
export const buscarFichaDetalhes = async (c: Context) => {
  const { uuid } = c.req.param();
  
  if (!uuid) {
    return c.json({ error: 'UUID da ficha é obrigatório' }, 400);
  }
  
  try {
    const db = c.env.DB as Database;
    
    // Buscar dados principais da ficha
    const ficha = await db.prepare(`
      SELECT 
        f.id,
        f.ficha_uuid,
        f.status_workflow,
        f.funcao_na_sessao,
        f.ciclo_executado,
        f.resultado_final,
        f.nota_final,
        f.observacoes_instrutor,
        f.observacoes_aluno,
        f.created_at,
        f.updated_at,
        f.assinatura_aluno_timestamp,
        f.assinatura_instrutor_timestamp,
        f.assinatura_final_instrutor_timestamp,
        f.assinatura_checador_timestamp,
        -- Dados do agendamento
        a.data_inicio,
        a.data_fim,
        a.colaborador_id_checador,
        -- Dados do funcionário (aluno)
        func.nome as aluno_nome,
        func.matricula as aluno_matricula,
        func.email as aluno_email,
        -- Dados do simulador
        s.nome as simulador_nome,
        s.codigo_identificacao as simulador_codigo,
        s.tipo_simulador,
        s.aeronave_base,
        -- Dados do instrutor
        inst.nome as instrutor_nome,
        inst.matricula as instrutor_matricula,
        -- Dados do checador (se existir)
        chec.nome as checador_nome,
        chec.matricula as checador_matricula,
        -- Dados do template de sessão
        st.nome_sessao as template_nome,
        st.descricao as template_descricao,
        st.numero_sessao,
        st.treinamento_codigo
      FROM fichas_sessao f
      LEFT JOIN agendamento_slots a ON f.agendamento_slot_id = a.id
      LEFT JOIN funcionarios func ON f.colaborador_id_aluno = func.id
      LEFT JOIN simuladores s ON a.simulador_id = s.id
      LEFT JOIN funcionarios inst ON a.colaborador_id_instrutor = inst.id
      LEFT JOIN funcionarios chec ON a.colaborador_id_checador = chec.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.ficha_uuid = ? AND f.deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // Buscar manobras executadas
    const manobras = await db.prepare(`
      SELECT 
        fme.id,
        fme.nota,
        fme.observacoes as observacoes_manobra,
        mc.id as manobra_id,
        mc.manobra_id_codigo,
        mc.nome_manobra,
        mc.categoria,
        mc.criterios_aprovacao,
        mc.pontuacao_minima
      FROM fichas_manobras_executadas fme
      LEFT JOIN manobras_catalogo mc ON fme.manobra_catalogo_id = mc.id
      WHERE fme.ficha_id = ?
      ORDER BY mc.manobra_id_codigo ASC
    `).bind(ficha.id).all();
    
    // Buscar assinaturas digitais
    const assinaturas = await db.prepare(`
      SELECT 
        tipo_assinatura as tipo,
        nome_completo as nome,
        timestamp,
        protocolo,
        status,
        ip_origem
      FROM fichas_assinaturas
      WHERE ficha_id = ? AND status = 'VALIDA'
      ORDER BY timestamp ASC
    `).bind(ficha.id).all();
    
    // Formatir dados da resposta
    const fichaFormatada = {
      id: ficha.id,
      ficha_uuid: ficha.ficha_uuid,
      status_workflow: ficha.status_workflow,
      funcao_na_sessao: ficha.funcao_na_sessao,
      ciclo_executado: ficha.ciclo_executado || 1,
      resultado_final: ficha.resultado_final,
      nota_final: ficha.nota_final,
      observacoes_instrutor: ficha.observacoes_instrutor,
      observacoes_aluno: ficha.observacoes_aluno,
      
      // Datas formatadas
      data_inicio: formatarDataBrasil(ficha.data_inicio),
      data_fim: formatarDataBrasil(ficha.data_fim),
      created_at: formatarDataBrasil(ficha.created_at),
      updated_at: formatarDataBrasil(ficha.updated_at),
      
      // Dados dos participantes
      aluno_nome: ficha.aluno_nome || 'N/A',
      aluno_matricula: ficha.aluno_matricula || 'N/A',
      aluno_email: ficha.aluno_email,
      
      instrutor_nome: ficha.instrutor_nome || 'N/A',
      instrutor_matricula: ficha.instrutor_matricula,
      
      checador_nome: ficha.checador_nome,
      checador_matricula: ficha.checador_matricula,
      
      // Dados do simulador
      simulador_nome: ficha.simulador_nome || 'N/A',
      simulador_codigo: ficha.simulador_codigo,
      tipo_simulador: ficha.tipo_simulador,
      aeronave_base: ficha.aeronave_base,
      
      // Dados do template
      template_nome: ficha.template_nome || 'N/A',
      template_descricao: ficha.template_descricao,
      numero_sessao: ficha.numero_sessao,
      treinamento_codigo: ficha.treinamento_codigo,
      
      // Manobras avaliadas
      manobras: manobras.map(manobra => ({
        id: manobra.manobra_id,
        manobra_id_codigo: manobra.manobra_id_codigo,
        nome_manobra: manobra.nome_manobra,
        categoria: manobra.categoria,
        criterios_aprovacao: manobra.criterios_aprovacao,
        pontuacao_minima: manobra.pontuacao_minima,
        nota: manobra.nota,
        observacoes_manobra: manobra.observacoes_manobra
      })),
      
      // Assinaturas digitais
      assinaturas: assinaturas.map(ass => ({
        tipo: ass.tipo,
        nome: ass.nome,
        timestamp: formatarDataBrasil(ass.timestamp),
        protocolo: ass.protocolo,
        status: ass.status,
        ip_origem: ass.ip_origem
      })),
      
      // Status de assinatura
      assinatura_aluno_timestamp: ficha.assinatura_aluno_timestamp ? formatarDataBrasil(ficha.assinatura_aluno_timestamp) : null,
      assinatura_instrutor_timestamp: ficha.assinatura_instrutor_timestamp ? formatarDataBrasil(ficha.assinatura_instrutor_timestamp) : null,
      assinatura_final_instrutor_timestamp: ficha.assinatura_final_instrutor_timestamp ? formatarDataBrasil(ficha.assinatura_final_instrutor_timestamp) : null,
      assinatura_checador_timestamp: ficha.assinatura_checador_timestamp ? formatarDataBrasil(ficha.assinatura_checador_timestamp) : null
    };
    
    return c.json({
      success: true,
      ficha: fichaFormatada
    });
    
  } catch (error: any) {
    console.error('Erro ao buscar ficha:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error.message,
      uuid_solicitado: uuid
    }, 500);
  }
};

// Gerar PDF da ficha
export const gerarPDFFichaDetalhes = async (c: Context) => {
  const { uuid } = c.req.param();
  
  if (!uuid) {
    return c.json({ error: 'UUID da ficha é obrigatório' }, 400);
  }
  
  try {
    // Reutilizar a lógica de busca da ficha
    const fichaResponse = await buscarFichaDetalhes(c);
    const fichaData = await fichaResponse.json() as { success: boolean; ficha: any };
    
    if (!fichaData.success) {
      return c.json({ error: 'Ficha não encontrada para geração de PDF' }, 404);
    }
    
    const ficha = fichaData.ficha;
    
    // Gerar HTML para PDF
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Ficha de Simulador - ${uuid}</title>
          <meta charset="UTF-8">
          <style>
            body { 
              font-family: Arial, sans-serif; 
              margin: 20px; 
              font-size: 12px;
              color: #333;
            }
            .header { 
              text-align: center; 
              border-bottom: 3px solid #1e40af; 
              padding-bottom: 15px; 
              margin-bottom: 25px;
              background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
              padding: 20px;
              border-radius: 8px;
            }
            .header h1 {
              color: #1e40af;
              margin: 0;
              font-size: 24px;
            }
            .info { 
              margin: 15px 0; 
              background: #f8fafc;
              padding: 15px;
              border-radius: 6px;
              border-left: 4px solid #3b82f6;
            }
            .info h3 { 
              margin-bottom: 10px; 
              color: #1e40af;
              font-size: 16px;
            }
            table { 
              width: 100%; 
              border-collapse: collapse; 
              margin: 10px 0; 
              background: white;
            }
            th, td { 
              border: 1px solid #d1d5db; 
              padding: 10px 8px; 
              text-align: left; 
            }
            th { 
              background-color: #e5e7eb; 
              font-weight: bold;
              color: #374151;
            }
            .status { 
              font-weight: bold; 
              padding: 6px 12px; 
              border-radius: 4px;
              display: inline-block;
            }
            .status.aprovado { background-color: #d1fae5; color: #065f46; }
            .status.reprovado { background-color: #fee2e2; color: #991b1b; }
            .status.pendente { background-color: #fef3c7; color: #92400e; }
            .status.concluida { background-color: #d1fae5; color: #065f46; }
            .status.rascunho { background-color: #e5e7eb; color: #374151; }
            .nota-aprovada { color: #059669; font-weight: bold; }
            .nota-reprovada { color: #dc2626; font-weight: bold; }
            .observacoes { 
              background: #f9fafb; 
              padding: 12px; 
              border-radius: 4px; 
              border: 1px solid #e5e7eb;
              font-style: italic;
            }
            .footer {
              margin-top: 40px;
              padding-top: 20px;
              border-top: 2px solid #e5e7eb;
              font-size: 10px;
              color: #6b7280;
              text-align: center;
            }
            .assinatura-section {
              margin-top: 30px;
              border: 2px solid #3b82f6;
              border-radius: 8px;
              padding: 15px;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>📋 FICHA DE AVALIAÇÃO DE SIMULADOR</h1>
            <p><strong>UUID:</strong> ${uuid}</p>
            <p><strong>Data de Emissão:</strong> ${formatarDataBrasil(new Date())}</p>
            <div class="status ${ficha.status_workflow?.toLowerCase() || 'pendente'}">${ficha.status_workflow}</div>
          </div>
          
          <div class="info">
            <h3>🎯 Dados da Sessão</h3>
            <table>
              <tr><td><strong>Tripulante:</strong></td><td>${ficha.aluno_nome}</td></tr>
              <tr><td><strong>Matrícula:</strong></td><td>${ficha.aluno_matricula}</td></tr>
              <tr><td><strong>Simulador:</strong></td><td>${ficha.simulador_nome}</td></tr>
              <tr><td><strong>Código Simulador:</strong></td><td>${ficha.simulador_codigo || 'N/A'}</td></tr>
              <tr><td><strong>Tipo:</strong></td><td>${ficha.tipo_simulador || 'N/A'}</td></tr>
              <tr><td><strong>Aeronave Base:</strong></td><td>${ficha.aeronave_base || 'N/A'}</td></tr>
              <tr><td><strong>Instrutor:</strong></td><td>${ficha.instrutor_nome}</td></tr>
              ${ficha.checador_nome ? `<tr><td><strong>Checador:</strong></td><td>${ficha.checador_nome}</td></tr>` : ''}
              <tr><td><strong>Função na Sessão:</strong></td><td>${ficha.funcao_na_sessao}</td></tr>
              <tr><td><strong>Template:</strong></td><td>${ficha.template_nome}</td></tr>
              <tr><td><strong>Ciclo:</strong></td><td>Ciclo ${ficha.ciclo_executado}</td></tr>
              <tr><td><strong>Data/Hora Início:</strong></td><td>${ficha.data_inicio}</td></tr>
              <tr><td><strong>Data/Hora Fim:</strong></td><td>${ficha.data_fim}</td></tr>
            </table>
          </div>
          
          <div class="info">
            <h3>📊 Avaliação das Manobras</h3>
            <table>
              <tr>
                <th>Código</th>
                <th>Manobra</th>
                <th>Categoria</th>
                <th>Nota Mín.</th>
                <th>Nota Obtida</th>
                <th>Status</th>
                <th>Observações</th>
              </tr>
              ${ficha.manobras.map((manobra: any) => `
                <tr>
                  <td style="font-family: monospace; font-weight: bold;">${manobra.manobra_id_codigo || 'N/A'}</td>
                  <td>${manobra.nome_manobra || 'N/A'}</td>
                  <td>${manobra.categoria || 'N/A'}</td>
                  <td style="text-align: center; font-weight: bold;">${manobra.pontuacao_minima || 5}</td>
                  <td style="text-align: center;">
                    ${manobra.nota ? 
                      `<span class="${(manobra.nota >= (manobra.pontuacao_minima || 5)) ? 'nota-aprovada' : 'nota-reprovada'}">${manobra.nota}</span>` 
                      : '<span style="color: #6b7280;">—</span>'
                    }
                  </td>
                  <td style="text-align: center;">
                    ${manobra.nota ? 
                      (manobra.nota >= (manobra.pontuacao_minima || 5) ? 
                        '<span class="status aprovado">✅ APROVADO</span>' : 
                        '<span class="status reprovado">❌ REPROVADO</span>') 
                      : '<span class="status pendente">⏳ PENDENTE</span>'
                    }
                  </td>
                  <td>${manobra.observacoes_manobra || '—'}</td>
                </tr>
              `).join('')}
            </table>
            ${ficha.manobras.length === 0 ? '<p class="observacoes"><em>⚠️ Nenhuma manobra foi executada ainda.</em></p>' : ''}
          </div>
          
          <div class="info">
            <h3>🏆 Resultado Final</h3>
            <table>
              <tr>
                <td><strong>Conceito:</strong></td>
                <td>
                  <span class="status ${(ficha.resultado_final || 'pendente').toLowerCase()}">
                    ${ficha.resultado_final === 'APROVADO' ? '✅ APROVADO' : 
                      ficha.resultado_final === 'REPROVADO' ? '❌ REPROVADO' : 
                      '⏳ Pendente'}
                  </span>
                </td>
              </tr>
              <tr>
                <td><strong>Nota Final:</strong></td>
                <td>
                  ${ficha.nota_final ? 
                    `<span class="${ficha.nota_final >= 7 ? 'nota-aprovada' : 'nota-reprovada'}" style="font-size: 16px;">${ficha.nota_final.toFixed(1)}</span>` 
                    : '<span style="color: #6b7280;">N/A</span>'
                  }
                </td>
              </tr>
            </table>
          </div>
          
          <div class="info">
            <h3>💬 Observações do Instrutor</h3>
            <div class="observacoes">
              ${ficha.observacoes_instrutor || 'Nenhuma observação registrada pelo instrutor.'}
            </div>
          </div>
          
          <div class="info">
            <h3>💭 Observações do Aluno</h3>
            <div class="observacoes">
              ${ficha.observacoes_aluno || 'Nenhuma observação registrada pelo aluno.'}
            </div>
          </div>
          
          ${ficha.assinaturas && ficha.assinaturas.length > 0 ? `
            <div class="assinatura-section">
              <h3>✍️ Assinaturas Digitais</h3>
              <table>
                <tr>
                  <th>Tipo</th>
                  <th>Nome</th>
                  <th>Data/Hora</th>
                  <th>Protocolo</th>
                </tr>
                ${ficha.assinaturas.map((ass: any) => `
                  <tr>
                    <td><strong>${ass.tipo}</strong></td>
                    <td>${ass.nome}</td>
                    <td>${ass.timestamp}</td>
                    <td style="font-family: monospace; font-size: 10px;">${ass.protocolo}</td>
                  </tr>
                `).join('')}
              </table>
            </div>
          ` : ''}
          
          <div class="footer">
            <p><strong>📄 Documento gerado automaticamente pelo Sistema AirTrust</strong></p>
            <p>Emitido em: ${formatarDataBrasil(new Date())} | Ficha UUID: ${uuid}</p>
            <p>⚠️ Este documento possui validade legal e não deve ser alterado</p>
          </div>
        </body>
      </html>
    `;
    
    return new Response(htmlContent, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': `attachment; filename="ficha_${uuid}.html"`
      }
    });
    
  } catch (error: any) {
    console.error('Erro ao gerar PDF:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error.message 
    }, 500);
  }
};
