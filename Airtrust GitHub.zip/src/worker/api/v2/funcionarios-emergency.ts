import { Hono } from 'hono';
import { applySchemaFix } from '../../middleware/production-emergency-fix';

const app = new Hono<{ Bindings: Env }>();

/**
 * 🚨 ENDPOINT EMERGENCIAL DE DELETE - VERSÃO SUPER ROBUSTA
 * Este endpoint tem logs detalhados e correções automáticas
 */
app.delete('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  
  console.log(`🚨 [EMERGENCY DELETE] Iniciando exclusão do funcionário ID: ${id}`);
  
  try {
    // 1. VERIFICAR SE SCHEMA ESTÁ CORRETO
    console.log(`🔍 [EMERGENCY DELETE] Verificando schema...`);
    
    const schemaCheck = await db.prepare('PRAGMA table_info(funcionarios)').all();
    const hasDeletedAt = schemaCheck.results?.some((col: any) => col.name === 'deleted_at');
    
    console.log(`📊 [EMERGENCY DELETE] Schema tem deleted_at: ${hasDeletedAt ? 'SIM' : 'NÃO'}`);
    
    if (!hasDeletedAt) {
      console.log(`🔧 [EMERGENCY DELETE] Adicionando campo deleted_at AGORA...`);
      
      try {
        await db.prepare('ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP').run();
        console.log(`✅ [EMERGENCY DELETE] Campo deleted_at adicionado com sucesso`);
      } catch (alterError: any) {
        console.error(`❌ [EMERGENCY DELETE] Erro ao adicionar deleted_at:`, alterError);
        
        if (!alterError?.message?.includes('duplicate column')) {
          return c.json({
            success: false,
            error: 'Erro crítico de schema - campo deleted_at não pode ser adicionado',
            technical_details: alterError?.message || 'Erro desconhecido'
          }, 500);
        }
      }
    }

    // 2. VERIFICAR SE FUNCIONÁRIO EXISTE
    console.log(`🔍 [EMERGENCY DELETE] Buscando funcionário ${id}...`);
    
    let funcionario;
    try {
      funcionario = await db.prepare(`
        SELECT id, nome, matricula, funcao, deleted_at 
        FROM funcionarios 
        WHERE id = ?
      `).bind(id).first();
      
      console.log(`📋 [EMERGENCY DELETE] Funcionário encontrado:`, funcionario ? 
        `${funcionario.nome} (${funcionario.matricula}) - deleted_at: ${funcionario.deleted_at}` : 
        'NÃO ENCONTRADO');
      
    } catch (selectError: any) {
      console.error(`❌ [EMERGENCY DELETE] Erro ao buscar funcionário:`, selectError);
      return c.json({
        success: false,
        error: 'Erro ao buscar funcionário no banco de dados',
        technical_details: selectError?.message || 'Erro desconhecido'
      }, 500);
    }

    if (!funcionario) {
      console.log(`❌ [EMERGENCY DELETE] Funcionário ${id} não encontrado`);
      return c.json({
        success: false,
        error: 'Funcionário não encontrado'
      }, 404);
    }

    // 3. VERIFICAR SE JÁ ESTÁ DELETADO
    if (funcionario.deleted_at && funcionario.deleted_at !== '') {
      console.log(`⚠️ [EMERGENCY DELETE] Funcionário ${id} já estava deletado: ${funcionario.deleted_at}`);
      return c.json({
        success: false,
        error: 'Funcionário já foi removido anteriormente',
        deleted_at: funcionario.deleted_at
      }, 400);
    }

    // 4. APLICAR SOFT DELETE COM MÚLTIPLAS TENTATIVAS
    const now = new Date().toISOString();
    console.log(`🔧 [EMERGENCY DELETE] Aplicando soft delete com timestamp: ${now}`);

    let updateResult: any;
    try {
      // Tentativa 1: UPDATE padrão
      console.log(`🔧 [EMERGENCY DELETE] Tentativa 1: UPDATE padrão...`);
      updateResult = await db.prepare(`
        UPDATE funcionarios 
        SET deleted_at = ?, updated_at = ? 
        WHERE id = ? AND (deleted_at IS NULL OR deleted_at = '')
      `).bind(now, now, id).run();
      
      const changes = updateResult.meta?.changes || 0;
      console.log(`📊 [EMERGENCY DELETE] Resultado UPDATE: success=${updateResult.success}, changes=${changes}`);
      
      if (!updateResult.success || changes === 0) {
        // Tentativa 2: UPDATE sem condição de deleted_at
        console.log(`🔧 [EMERGENCY DELETE] Tentativa 2: UPDATE sem condição...`);
        updateResult = await db.prepare(`
          UPDATE funcionarios 
          SET deleted_at = ?, updated_at = ? 
          WHERE id = ?
        `).bind(now, now, id).run();
        
        const changes2 = updateResult.meta?.changes || 0;
        console.log(`📊 [EMERGENCY DELETE] Resultado UPDATE 2: success=${updateResult.success}, changes=${changes2}`);
      }
      
    } catch (updateError: any) {
      console.error(`❌ [EMERGENCY DELETE] Erro no UPDATE:`, updateError);
      
      // Se erro é por causa de NOT NULL constraint na funcao
      if (updateError?.message?.includes('NOT NULL constraint failed: funcionarios.funcao')) {
        console.log(`🚨 [EMERGENCY DELETE] Detectado problema de funcao NOT NULL - aplicando correção...`);
        
        // Aplicar correção de schema
        const schemaFixed = await applySchemaFix(db);
        
        if (schemaFixed) {
          console.log(`✅ [EMERGENCY DELETE] Schema corrigido, tentando DELETE novamente...`);
          
          // Tentar novamente após correção
          updateResult = await db.prepare(`
            UPDATE funcionarios 
            SET deleted_at = ?, updated_at = ? 
            WHERE id = ?
          `).bind(now, now, id).run();
          
          const changes3 = updateResult.meta?.changes || 0;
          console.log(`📊 [EMERGENCY DELETE] Resultado após correção: success=${updateResult.success}, changes=${changes3}`);
        }
      }
      
      if (!updateResult || !updateResult.success) {
        return c.json({
          success: false,
          error: 'Erro interno ao aplicar exclusão',
          technical_details: updateError?.message || 'Erro desconhecido'
        }, 500);
      }
    }

    // 5. VALIDAR QUE A EXCLUSÃO FUNCIONOU
    console.log(`🔍 [EMERGENCY DELETE] Validando exclusão...`);
    
    const verificacao = await db.prepare(`
      SELECT deleted_at FROM funcionarios WHERE id = ?
    `).bind(id).first();
    
    console.log(`📋 [EMERGENCY DELETE] Verificação pós-exclusão: deleted_at = ${verificacao?.deleted_at}`);
    
    if (!verificacao?.deleted_at) {
      console.error(`❌ [EMERGENCY DELETE] VALIDAÇÃO FALHOU: funcionário ${id} não foi marcado como deletado`);
      return c.json({
        success: false,
        error: 'Falha na validação da exclusão - operação não foi concluída',
        verification_result: verificacao
      }, 500);
    }

    // 6. SUCESSO!
    console.log(`🎯 [EMERGENCY DELETE] SUCESSO: Funcionário ${id} (${funcionario.nome}) removido com sucesso`);
    
    return c.json({
      success: true,
      message: 'Funcionário removido com sucesso',
      data: {
        id: funcionario.id,
        nome: funcionario.nome,
        matricula: funcionario.matricula,
        deleted_at: now,
        verified_at: verificacao.deleted_at
      }
    });

  } catch (error: any) {
    console.error(`❌ [EMERGENCY DELETE] ERRO CRÍTICO:`, error);
    
    return c.json({
      success: false,
      error: 'Erro crítico do sistema',
      technical_details: error?.message || 'Erro desconhecido',
      stack: error?.stack
    }, 500);
  }
});

/**
 * 🔍 ENDPOINT DE DIAGNÓSTICO COMPLETO
 */
app.get('/diagnostico/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;
  
  try {
    console.log(`🔍 [DIAGNOSTICO] Executando diagnóstico completo para funcionário ${id}...`);
    
    const diagnostico: any = {
      timestamp: new Date().toISOString(),
      funcionario_id: id,
      schema_check: {},
      funcionario_data: {},
      table_info: {},
      counts: {}
    };

    // 1. Verificar schema
    const schemaResult = await db.prepare('PRAGMA table_info(funcionarios)').all();
    diagnostico.schema_check = {
      total_columns: schemaResult.results?.length || 0,
      has_deleted_at: schemaResult.results?.some((col: any) => col.name === 'deleted_at') || false,
      columns: schemaResult.results?.map((col: any) => ({
        name: col.name,
        type: col.type,
        not_null: col.notnull,
        default: col.dflt_value
      })) || []
    };

    // 2. Buscar dados do funcionário
    try {
      const funcionario = await db.prepare(`
        SELECT * FROM funcionarios WHERE id = ?
      `).bind(id).first();
      
      diagnostico.funcionario_data = funcionario || { not_found: true };
    } catch (funcionarioError: any) {
      diagnostico.funcionario_data = { error: funcionarioError?.message || 'Erro desconhecido' };
    }

    // 3. Informações da tabela
    try {
      const tableSQL = await db.prepare(`SELECT sql FROM sqlite_master WHERE name = 'funcionarios'`).first();
      diagnostico.table_info = {
        sql: tableSQL?.sql || '',
        has_funcao_not_null: String(tableSQL?.sql || '').includes('funcao TEXT NOT NULL') || false
      };
    } catch (tableError: any) {
      diagnostico.table_info = { error: tableError?.message || 'Erro desconhecido' };
    }

    // 4. Contagens
    try {
      const counts = await db.prepare(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN deleted_at IS NULL OR deleted_at = '' THEN 1 END) as ativos,
          COUNT(CASE WHEN deleted_at IS NOT NULL AND deleted_at != '' THEN 1 END) as deletados
        FROM funcionarios
      `).first();
      
      diagnostico.counts = counts || {};
    } catch (countError: any) {
      diagnostico.counts = { error: countError?.message || 'Erro desconhecido' };
    }

    return c.json({
      success: true,
      diagnostico
    });

  } catch (error: any) {
    return c.json({
      success: false,
      error: 'Erro no diagnóstico',
      details: error?.message || 'Erro desconhecido'
    }, 500);
  }
});

export default app;
