import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação a todas as rotas
app.use('*', authMiddleware);

// GET /api/v2/dashboard/painel-estrategico - Dados do painel estratégico
app.get('/painel-estrategico', requirePermission('dashboard', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    // 1. Compliance Geral (% de funcionários em conformidade)
    const complianceResult = await db.prepare(`
      SELECT 
        COUNT(DISTINCT funcionario_id) as total_funcionarios,
        COUNT(DISTINCT CASE WHEN status IN ('EM_DIA', 'VENCENDO') THEN funcionario_id END) as funcionarios_conformes
      FROM compliance_status_v2 
      WHERE item_type = 'TREINAMENTO'
    `).first();
    
    const totalFuncionarios = (complianceResult?.total_funcionarios as number) || 1;
    const funcionariosConformes = (complianceResult?.funcionarios_conformes as number) || 0;
    const complianceGeralPercent = Math.round((funcionariosConformes / totalFuncionarios) * 100);
    
    // 2. Certificados com Anexo (simulado - precisaria da tabela certificado_anexos_v2)
    const certificadosComAnexo = await db.prepare(`
      SELECT COUNT(*) as count 
      FROM historico_certificacoes_v2 
      WHERE certificado_url IS NOT NULL AND deleted_at IS NULL
    `).first();
    
    // 3. Funcionários com Pendências
    const funcionariosComPendencias = await db.prepare(`
      SELECT COUNT(DISTINCT funcionario_id) as count
      FROM compliance_status_v2 
      WHERE status IN ('VENCIDO', 'VENCENDO', 'PENDENTE')
    `).first();
    
    // 4. Vencimentos nos próximos 30 dias
    const vencimentos30Dias = await db.prepare(`
      SELECT COUNT(*) as count
      FROM compliance_status_v2 
      WHERE status = 'VENCENDO' AND dias_para_vencimento <= 30
    `).first();

    await logAudit(c, 'READ', 'dashboard_painel_estrategico');
    
    return c.json({
      success: true,
      data: {
        compliance_geral_percent: complianceGeralPercent,
        certificados_com_anexo: (certificadosComAnexo?.count as number) || 0,
        funcionarios_com_pendencias: (funcionariosComPendencias?.count as number) || 0,
        vencimentos_30_dias: (vencimentos30Dias?.count as number) || 0
      }
    });
  } catch (error) {
    console.error('Error fetching painel estrategico:', error);
    await logAudit(c, 'read', 'dashboard_painel_estrategico', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/dashboard/status-certificacoes - Status das certificações
app.get('/status-certificacoes', requirePermission('dashboard', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const statusResult = await db.prepare(`
      SELECT 
        COUNT(CASE WHEN status = 'EM_DIA' THEN 1 END) as validos,
        COUNT(CASE WHEN status = 'VENCENDO' THEN 1 END) as proximo_vencimento,
        COUNT(CASE WHEN status = 'VENCENDO' AND dias_para_vencimento <= 7 THEN 1 END) as criticos,
        COUNT(CASE WHEN status = 'VENCIDO' THEN 1 END) as vencidos
      FROM compliance_status_v2 
      WHERE item_type = 'TREINAMENTO'
    `).first();

    await logAudit(c, 'read', 'dashboard_status_certificacoes');
    
    return c.json({
      success: true,
      data: {
        validos: (statusResult?.validos as number) || 0,
        proximo_vencimento: (statusResult?.proximo_vencimento as number) || 0,
        criticos: (statusResult?.criticos as number) || 0,
        vencidos: (statusResult?.vencidos as number) || 0
      }
    });
  } catch (error) {
    console.error('Error fetching status certificacoes:', error);
    await logAudit(c, 'read', 'dashboard_status_certificacoes', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/dashboard/rastreabilidade - Rastreabilidade documental
app.get('/rastreabilidade', requirePermission('dashboard', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    // Total de certificações
    const totalResult = await db.prepare(`
      SELECT COUNT(*) as count 
      FROM historico_certificacoes_v2 
      WHERE deleted_at IS NULL
    `).first();
    
    // Certificados com anexo (URL preenchida)
    const anexadosResult = await db.prepare(`
      SELECT COUNT(*) as count 
      FROM historico_certificacoes_v2 
      WHERE certificado_url IS NOT NULL 
      AND certificado_url != '' 
      AND deleted_at IS NULL
    `).first();
    
    const totalCertificacoes = (totalResult?.count as number) || 0;
    const certificadosAnexados = (anexadosResult?.count as number) || 0;
    const semComprovante = totalCertificacoes - certificadosAnexados;

    await logAudit(c, 'read', 'dashboard_rastreabilidade');
    
    return c.json({
      success: true,
      data: {
        total_certificacoes: totalCertificacoes,
        certificados_anexados: certificadosAnexados,
        sem_comprovante: semComprovante
      }
    });
  } catch (error) {
    console.error('Error fetching rastreabilidade:', error);
    await logAudit(c, 'read', 'dashboard_rastreabilidade', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/dashboard/treinamentos-criticos - Lista de treinamentos com baixo compliance
app.get('/treinamentos-criticos', requirePermission('dashboard', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const treinamentosResult = await db.prepare(`
      SELECT 
        t.id as treinamento_id,
        t.nome as treinamento_nome,
        t.codigo,
        COUNT(c.id) as total_funcionarios,
        COUNT(CASE WHEN c.status = 'EM_DIA' THEN 1 END) as funcionarios_em_dia,
        COUNT(CASE WHEN c.status = 'VENCENDO' THEN 1 END) as funcionarios_vencendo,
        COUNT(CASE WHEN c.status = 'VENCIDO' THEN 1 END) as funcionarios_vencidos,
        ROUND(
          (COUNT(CASE WHEN c.status IN ('EM_DIA', 'VENCENDO') THEN 1 END) * 100.0) / 
          NULLIF(COUNT(c.id), 0)
        ) as compliance_percentage
      FROM catalogo_treinamentos_v2 t
      LEFT JOIN compliance_status_v2 c ON t.id = c.treinamento_id 
        AND c.item_type = 'TREINAMENTO'
      WHERE t.deleted_at IS NULL AND t.ativo = 1
      GROUP BY t.id, t.nome, t.codigo
      HAVING COUNT(c.id) > 0
      ORDER BY compliance_percentage ASC, total_funcionarios DESC
    `).all();

    // Adicionar prioridade baseada no compliance
    const treinamentosComPrioridade = (treinamentosResult.results as any[]).map(t => ({
      ...t,
      prioridade: t.compliance_percentage < 30 ? 'CRITICA' : 
                 t.compliance_percentage < 60 ? 'ALTA' : 'MEDIA'
    }));

    await logAudit(c, 'read', 'dashboard_treinamentos_criticos');
    
    return c.json({
      success: true,
      data: treinamentosComPrioridade
    });
  } catch (error) {
    console.error('Error fetching treinamentos criticos:', error);
    await logAudit(c, 'read', 'dashboard_treinamentos_criticos', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default app;
