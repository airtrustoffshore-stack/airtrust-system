import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// GET /api/v2/simuladores-public - Listar simuladores (sem autenticação para dropdown)
app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    console.log('🎮 Carregando simuladores para dropdown...');
    
    const stmt = db.prepare(`
      SELECT id, nome, codigo_identificacao, tipo_simulador, aeronave_base,
             empresa_local, certificacao_anac, status, created_at, updated_at
      FROM simuladores 
      WHERE deleted_at IS NULL AND status = 'ATIVO'
      ORDER BY nome
    `);
    
    const result = await stmt.all();
    const simuladores = result.results;

    console.log(`✅ ${simuladores?.length || 0} simuladores carregados`);
    
    return c.json({
      success: true,
      data: simuladores,
      total: simuladores?.length || 0
    });
  } catch (error) {
    console.error('❌ Erro ao carregar simuladores:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

export default app;
