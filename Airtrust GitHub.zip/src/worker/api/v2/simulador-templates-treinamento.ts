import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.use('*', authMiddleware);

// GET /api/v2/simulador/templates/treinamento/:id - Buscar templates por treinamento
app.get('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const treinamentoId = c.req.param('id');

    // Buscar treinamento primeiro
    const treinamento = await db.prepare(`
      SELECT codigo, nome 
      FROM catalogo_treinamentos_v2 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(treinamentoId).first();

    if (!treinamento) {
      return c.json({ 
        error: 'Treinamento não encontrado',
        treinamento_id: treinamentoId 
      }, 404);
    }

    // Buscar templates do treinamento
    const templates = await db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo,
        st.numero_sessao,
        st.nome_sessao,
        st.descricao,
        st.created_at,
        COUNT(stm.manobra_catalogo_id) as total_manobras
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      WHERE st.treinamento_codigo = ?
      GROUP BY st.id
      ORDER BY st.numero_sessao ASC
    `).bind(treinamento.codigo).all();

    const templatesFormatados = templates.results.map((t: any) => ({
      id: t.id,
      codigo: t.treinamento_codigo,
      nome: t.nome_sessao,
      descricao: t.descricao,
      numero_sessao: t.numero_sessao,
      total_manobras: t.total_manobras || 0
    }));

    return c.json({
      success: true,
      treinamento: {
        id: treinamentoId,
        codigo: treinamento.codigo,
        nome: treinamento.nome
      },
      templates: templatesFormatados,
      total: templatesFormatados.length
    });

  } catch (error) {
    console.error('❌ Erro ao buscar templates por treinamento:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

export default app;
