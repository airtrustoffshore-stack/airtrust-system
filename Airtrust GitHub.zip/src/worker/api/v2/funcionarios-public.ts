import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// GET /api/v2/funcionarios-public - Listar funcionários (sem autenticação para dropdown)
app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    console.log('👥 Carregando funcionários para dropdown...');
    
    const stmt = db.prepare(`
      SELECT id, nome, matricula, funcao, is_instrutor, is_checador, status
      FROM funcionarios 
      WHERE deleted_at IS NULL AND status = 'ATIVO'
      ORDER BY nome
    `);
    
    const result = await stmt.all();
    const funcionarios = result.results;

    console.log(`✅ ${funcionarios?.length || 0} funcionários carregados`);
    
    return c.json({
      success: true,
      data: funcionarios,
      total: funcionarios?.length || 0
    });
  } catch (error) {
    console.error('❌ Erro ao carregar funcionários:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

export default app;
