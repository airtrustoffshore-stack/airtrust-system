import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';
import { gerarProximoIdCertificacao, normalizarMatricula } from '../../../shared/utils/certificacao-utils';
import { DateParser } from '../../utils/date-parser';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ FUNÇÃO CORRIGIDA PARA MAPEAR CAMPOS CSV FLEXIVELMENTE
const mapearCamposCSV = (header: string[]) => {
  const mapeamento: any = {};
  
  // Normalizar cabeçalhos (remover acentos, pontos, espaços, minúsculas)
  const normalizar = (str: string) => {
    return str.toLowerCase()
      .replace(/[áàâãäå]/g, 'a')
      .replace(/[éèêë]/g, 'e')
      .replace(/[íìîï]/g, 'i')
      .replace(/[óòôõö]/g, 'o')
      .replace(/[úùûü]/g, 'u')
      .replace(/[ç]/g, 'c')
      .replace(/[^a-z0-9]/g, ''); // Remove pontos, espaços, etc.
  };
  
  header.forEach((campo, index) => {
    const campoNormalizado = normalizar(campo);
    
    // ✅ MAPEAMENTO PARA MATRÍCULA
    if (['matricula', 'mat', 'funcionariomatricula', 'colaboradormatricula'].includes(campoNormalizado)) {
      mapeamento.funcionario_matricula = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA TREINAMENTO
    if (['treinamento', 'treinamentocodigo', 'codigo', 'codigotreinamento'].includes(campoNormalizado)) {
      mapeamento.treinamento_codigo = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA DATA CONCLUSÃO
    if (['dataconclusao', 'conclusao', 'data', 'datarealizacao'].includes(campoNormalizado)) {
      mapeamento.data_conclusao = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA INSTRUTOR
    if (['instrutor', 'professor', 'responsavel'].includes(campoNormalizado)) {
      mapeamento.instrutor = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA NOTA
    if (['nota', 'notafinal', 'pontuacao', 'resultado'].includes(campoNormalizado)) {
      mapeamento.nota_final = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA DATA VENCIMENTO
    if (['datavencimento', 'vencimento', 'validade', 'expiracao'].includes(campoNormalizado)) {
      mapeamento.data_vencimento = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA OBSERVAÇÕES
    if (['observacoes', 'obs', 'comentarios', 'notas'].includes(campoNormalizado)) {
      mapeamento.observacoes = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
  });
  
  return mapeamento;
};

// ✅ FUNÇÃO PARA BUSCAR OU CRIAR FUNCIONÁRIO COM VALIDAÇÃO RIGOROSA
const buscarOuCriarFuncionario = async (matricula: string, db: any) => {
  // VALIDAR matrícula existe no sistema ANTES de criar
  const matriculaNormalizada = normalizarMatricula(matricula);
  
  // Buscar funcionário existente
  let funcionario = await db.prepare(
    'SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL'
  ).bind(matriculaNormalizada).first();
  
  if (!funcionario) {
    // ❌ NÃO CRIAR AUTOMATICAMENTE - REJEITAR IMPORTAÇÃO
    throw new Error(`Funcionário com matrícula '${matriculaNormalizada}' não encontrado. Cadastre o funcionário antes de importar certificações.`);
  }
  
  funcionario.existia = true;
  return funcionario;
};

// ✅ FUNÇÃO PARA BUSCAR OU CRIAR TREINAMENTO
const buscarOuCriarTreinamento = async (codigo: string, nome?: string, db?: any) => {
  // Buscar treinamento existente
  let treinamento = await db.prepare(
    'SELECT id, codigo, nome FROM catalogo_treinamentos_v2 WHERE codigo = ? AND deleted_at IS NULL'
  ).bind(codigo).first();
  
  if (!treinamento) {
    // Criar treinamento automaticamente
    const nomeTrainamento = nome || `Treinamento ${codigo}`;
    const result = await db.prepare(`
      INSERT INTO catalogo_treinamentos_v2 (
        codigo, nome, categoria, ativo, created_at, updated_at
      ) VALUES (?, ?, 'IMPORTADO_CSV', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(codigo, nomeTrainamento).run();
    
    if (result.success && result.meta?.last_row_id) {
      treinamento = {
        id: result.meta.last_row_id,
        codigo: codigo,
        nome: nomeTrainamento,
        existia: false
      };
    } else {
      throw new Error(`Erro ao criar treinamento ${codigo}`);
    }
  } else {
    treinamento.existia = true;
  }
  
  return treinamento;
};

// ✅ ENDPOINT LEGADO - MANTER PARA COMPATIBILIDADE (LIMITADO A ARQUIVOS PEQUENOS)
// ⚠️ RECOMENDADO: Use /import-planilha-batch para arquivos grandes
app.post('/import-planilha', requirePermission('treinamentos', 'CREATE'), async (c) => {
  try {
    console.log('🏆 === IMPORTAÇÃO CERTIFICAÇÕES COM FORMDATA CORRETO ===');
    
    // ✅ CORREÇÃO 1: LER FORMDATA DO FRONTEND
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({
        success: false,
        batch_id: `error_${Date.now()}`,
        processing_time_ms: 0,
        rows_total: 0,
        rows_processed: 0,
        rows_failed: 0,
        rows_skipped: 0,
        duplicates_detected: 0,
        errors: [{
          row: 0,
          field: 'file',
          message: 'Arquivo CSV é obrigatório',
          error_type: 'VALIDATION',
          severity: 'CRITICAL'
        }],
        warnings: [],
        summary: 'Arquivo não fornecido'
      }, 400);
    }

    console.log('📁 [IMPORT CERTIFICAÇÕES] Processando arquivo:', file.name, 'Tamanho:', file.size);
    
    const csvText = await file.text();
    const lines = csvText.trim().split('\n');
    
    if (lines.length < 2) {
      return c.json({
        success: false,
        linhas_processadas: 0,
        criados: 0,
        atualizados: 0,
        erros: 1,
        detalhes_erros: ['Arquivo deve ter cabeçalho + pelo menos 1 linha de dados']
      }, 400);
    }

    const db = c.env.DB;
    
    // ✅ PROCESSAR CABEÇALHO COM MAPEAMENTO FLEXÍVEL
    const header = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    console.log('📋 [IMPORT CERTIFICAÇÕES] Header original:', header);
    
    // ✅ MAPEAR CAMPOS FLEXIVELMENTE
    const mapeamento = mapearCamposCSV(header);
    console.log('🔄 Mapeamento encontrado:', mapeamento);
    
    // ✅ VALIDAÇÃO RIGOROSA - MATRÍCULA E TREINAMENTO OBRIGATÓRIOS
    const errosValidacao = [];
    
    if (!mapeamento.funcionario_matricula?.encontrado) {
      errosValidacao.push("Campo obrigatório 'funcionario_matricula' não encontrado (aceita: matricula, mat, funcionario_matricula)");
    }
    
    if (!mapeamento.treinamento_codigo?.encontrado) {
      errosValidacao.push("Campo obrigatório 'treinamento_codigo' não encontrado (aceita: treinamento, treinamento_codigo, codigo)");
    }
    
    if (!mapeamento.data_conclusao?.encontrado) {
      errosValidacao.push("Campo obrigatório 'data_conclusao' não encontrado (aceita: data_conclusao, conclusao, data)");
    }
    
    if (errosValidacao.length > 0) {
      return c.json({
        success: false,
        error: 'Erros de Validação do CSV',
        detalhes_erros: errosValidacao,
        campos_encontrados: Object.keys(mapeamento).filter(k => mapeamento[k]?.encontrado),
        sugestao: "Verifique se o CSV tem colunas para: funcionario_matricula, treinamento_codigo e data_conclusao"
      }, 400);
    }

    let linhasProcessadas = 0;
    let criados = 0;
    let funcionariosCriados = 0;
    let treinamentosCriados = 0;
    const detalhes_erros: string[] = [];
    const sucessos: string[] = [];
    const novosFuncionarios: string[] = [];
    const novosTreinamentos: string[] = [];
    const startTime = Date.now();

    // ✅ PROCESSAR TODAS AS LINHAS DO ARQUIVO (NÃO LIMITAR POR PREVIEW)
    console.log(`📊 [IMPORT CERTIFICAÇÕES] Processando arquivo completo: ${lines.length - 1} linhas de dados`);
    
    for (let i = 1; i < lines.length; i++) {
      try {
        console.log(`\n🔄 --- PROCESSANDO LINHA ${i+1} ---`);
        
        const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
        
        if (values.length !== header.length) {
          const erro = `Linha ${i+1}: esperado ${header.length} campos, encontrado ${values.length}`;
          detalhes_erros.push(erro);
          continue;
        }

        // ✅ EXTRAIR DADOS USANDO MAPEAMENTO
        const rowData: any = {};
        
        // Campos obrigatórios
        rowData.funcionario_matricula = values[mapeamento.funcionario_matricula.index];
        rowData.treinamento_codigo = values[mapeamento.treinamento_codigo.index];
        rowData.data_conclusao = values[mapeamento.data_conclusao.index];
        
        // Campos opcionais
        if (mapeamento.instrutor?.encontrado) {
          rowData.instrutor = values[mapeamento.instrutor.index];
        }
        if (mapeamento.nota_final?.encontrado) {
          rowData.nota_final = values[mapeamento.nota_final.index];
        }
        if (mapeamento.data_vencimento?.encontrado) {
          rowData.data_vencimento = values[mapeamento.data_vencimento.index];
        }
        if (mapeamento.observacoes?.encontrado) {
          rowData.observacoes = values[mapeamento.observacoes.index];
        }

        console.log(`📝 Dados da linha:`, rowData);

        // Validação rigorosa de campos obrigatórios
        if (!rowData.funcionario_matricula || !rowData.treinamento_codigo || !rowData.data_conclusao) {
          const erro = `Linha ${i+1}: campos 'funcionario_matricula', 'treinamento_codigo' e 'data_conclusao' são obrigatórios`;
          detalhes_erros.push(erro);
          continue;
        }

        // ✅ PROCESSAR DATAS NO FORMATO BRASILEIRO
        let datasProcessadas;
        try {
          datasProcessadas = DateParser.processCSVDates(rowData);
          
          // Adicionar warnings se houver
          if (datasProcessadas.warnings.length > 0) {
            datasProcessadas.warnings.forEach(warning => {
              detalhes_erros.push(`Linha ${i+1}: ${warning}`);
            });
          }
          
          // Atualizar rowData com datas convertidas
          if (datasProcessadas.data_conclusao) {
            rowData.data_conclusao = datasProcessadas.data_conclusao;
          }
          if (datasProcessadas.data_vencimento) {
            rowData.data_vencimento = datasProcessadas.data_vencimento;
          }
          
        } catch (dateError) {
          const erro = `Linha ${i+1}: ${dateError instanceof Error ? dateError.message : 'Erro no processamento de datas'}`;
          detalhes_erros.push(erro);
          continue;
        }

        // 🔍 BUSCAR FUNCIONÁRIO (SEM CRIAR AUTOMATICAMENTE)
        const funcionario = await buscarOuCriarFuncionario(rowData.funcionario_matricula, db);
        if (!funcionario.existia) {
          funcionariosCriados++;
          novosFuncionarios.push(`${funcionario.nome} (${funcionario.matricula})`);
        }

        // 🔍 BUSCAR OU CRIAR TREINAMENTO  
        const treinamento = await buscarOuCriarTreinamento(rowData.treinamento_codigo, undefined, db);
        if (!treinamento.existia) {
          treinamentosCriados++;
          novosTreinamentos.push(`${treinamento.nome} (${treinamento.codigo})`);
        }

        console.log(`✅ Dependências: ${funcionario.nome} (${funcionario.matricula}) + ${treinamento.nome} (${treinamento.codigo})`);

        // ✅ GERAR ID COM FORMATO CORRETO: MATRICULA-CODIGO-ANO_CONCLUSAO-SEQUENCIAL
        const certificacaoId = await gerarProximoIdCertificacao(
          funcionario.id,
          treinamento.id,
          rowData.data_conclusao,
          db
        );

        console.log(`🎯 ID certificação CORRIGIDO: ${certificacaoId}`);

        // Verificar duplicata na tabela historico_certificacoes_v2
        const existente = await db.prepare(`
          SELECT id FROM historico_certificacoes_v2 
          WHERE funcionario_id = ? AND treinamento_id = ? 
          AND status = 'ATIVO' AND deleted_at IS NULL
        `).bind(funcionario.id, treinamento.id).first();

        if (existente) {
          console.log(`⚠️ Certificação já existe, pulando...`);
          continue;
        }

        // ✅ CRIAR CERTIFICAÇÃO V2 COM ID FORMATADO CORRETAMENTE
        const now = new Date().toISOString();
        await db.prepare(`
          INSERT INTO historico_certificacoes_v2 
          (certificacao_id, funcionario_id, treinamento_id, data_conclusao, 
           data_vencimento, instrutor, nota_final, observacoes, status, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ATIVO', ?, ?)
        `).bind(
          certificacaoId,
          funcionario.id,
          treinamento.id,
          rowData.data_conclusao,
          rowData.data_vencimento || null,
          rowData.instrutor || null,
          rowData.nota_final ? parseFloat(rowData.nota_final) : null,
          rowData.observacoes || null,
          now,
          now
        ).run();

        criados++;
        linhasProcessadas++;
        sucessos.push(`🏆 ${certificacaoId}: ${funcionario.nome} certificado em ${treinamento.nome} (${rowData.data_conclusao})`);
        console.log(`🎉 Certificação criada com ID CORRETO!`);

      } catch (error) {
        const erro = `Linha ${i+1}: ${error instanceof Error ? error.message : 'Erro desconhecido'}`;
        console.error(`❌ ${erro}`);
        detalhes_erros.push(erro);
      }
    }

    // AUDITORIA
    await logAudit(c, 'IMPORT_CERTIFICACOES', 'historico_certificacoes_v2', `batch_${Date.now()}`, undefined, {
      linhas_processadas: linhasProcessadas,
      importadas_com_sucesso: criados,
      funcionarios_criados: funcionariosCriados,
      treinamentos_criados: treinamentosCriados,
      erros_count: detalhes_erros.length
    });

    console.log(`🎯 [IMPORT CERTIFICAÇÕES] Finalizado - Processadas: ${linhasProcessadas}, Importadas: ${criados}, Funcionários criados: ${funcionariosCriados}, Treinamentos criados: ${treinamentosCriados}, Erros: ${detalhes_erros.length}`);

    // ✅ RESPOSTA FINAL COMPLETA NO FORMATO ESPERADO PELO FRONTEND
    return c.json({
      success: true,
      batch_id: `cert_batch_${Date.now()}`,
      processing_time_ms: Date.now() - startTime,
      rows_total: lines.length - 1,
      rows_processed: linhasProcessadas,
      rows_failed: detalhes_erros.length,
      rows_skipped: 0,
      new_catalogs_created: treinamentosCriados,
      duplicates_detected: 0,
      errors: detalhes_erros.slice(0, 20).map((erro, index) => ({
        row: index + 1,
        field: 'linha',
        message: erro,
        error_type: 'VALIDATION' as const,
        severity: 'MEDIUM' as const
      })),
      warnings: [],
      summary: `${criados} certificações importadas com sucesso! ${funcionariosCriados} funcionários encontrados, ${treinamentosCriados} treinamentos criados automaticamente.`
    });

  } catch (error) {
    console.error('💥 ERRO CRÍTICO:', error);
    return c.json({
      success: false,
      batch_id: `error_${Date.now()}`,
      processing_time_ms: 0,
      rows_total: 0,
      rows_processed: 0,
      rows_failed: 1,
      rows_skipped: 0,
      duplicates_detected: 0,
      errors: [{
        row: 0,
        field: 'system',
        message: error instanceof Error ? error.message : 'Erro interno do servidor',
        error_type: 'SYSTEM' as const,
        severity: 'CRITICAL' as const
      }],
      warnings: [],
      summary: 'Falha crítica no sistema'
    }, 500);
  }
});

export default app;
