import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

/**
 * 🔧 ENDPOINTS PARA CHECADORES - AIRTRUST
 * 
 * Implementa os endpoints necessários para o sistema de check:
 * - Listar checadores internos
 * - Listar simuladores
 * - Listar funcionários/tripulantes
 * - Suporte ao formulário único
 */

// GET /api/v2/simulador/simuladores - Listar simuladores para dropdown
app.get('/simuladores', async (c) => {
  try {
    console.log('🔍 Buscando simuladores para dropdown...');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT 
        id,
        nome,
        codigo_identificacao,
        tipo_simulador,
        aeronave_base,
        status
      FROM simuladores 
      WHERE deleted_at IS NULL AND status = 'ATIVO'
      ORDER BY nome ASC
    `);
    
    const result = await stmt.all();
    const simuladores = result.results || [];
    
    console.log(`🎮 Encontrados ${simuladores.length} simuladores ativos`);
    
    return c.json({
      success: true,
      simuladores: simuladores,
      total: simuladores.length,
      message: `${simuladores.length} simuladores disponíveis`
    });
    
  } catch (error) {
    console.error('❌ Erro ao listar simuladores:', error);
    return c.json({
      success: false,
      simuladores: [],
      error: 'Erro ao carregar simuladores',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/simulador/funcionarios - Listar funcionários para dropdown
app.get('/funcionarios', async (c) => {
  try {
    console.log('🔍 Buscando funcionários para dropdown...');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT 
        id,
        nome,
        matricula,
        funcao,
        is_instrutor,
        is_checador,
        status
      FROM funcionarios 
      WHERE deleted_at IS NULL AND status = 'ATIVO'
      ORDER BY nome ASC
    `);
    
    const result = await stmt.all();
    const funcionarios = result.results || [];
    
    // Separar por função
    const instrutores = funcionarios.filter((f: any) => f.is_instrutor === 1);
    const checadores = funcionarios.filter((f: any) => f.is_checador === 1);
    const tripulantes = funcionarios; // Todos podem ser tripulantes
    
    console.log(`👥 Encontrados:`, {
      total: funcionarios.length,
      instrutores: instrutores.length,
      checadores: checadores.length,
      tripulantes: tripulantes.length
    });
    
    return c.json({
      success: true,
      funcionarios: funcionarios,
      instrutores: instrutores,
      checadores: checadores,
      tripulantes: tripulantes,
      total: funcionarios.length,
      message: `${funcionarios.length} funcionários carregados`
    });
    
  } catch (error) {
    console.error('❌ Erro ao listar funcionários:', error);
    return c.json({
      success: false,
      funcionarios: [],
      instrutores: [],
      checadores: [],
      tripulantes: [],
      error: 'Erro ao carregar funcionários',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/simulador/checadores - Listar apenas checadores
app.get('/checadores', async (c) => {
  try {
    console.log('🔍 Buscando checadores especificamente...');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT 
        id,
        nome,
        matricula,
        funcao,
        codigo_anac,
        nivel_icao,
        aeronave_principal
      FROM funcionarios 
      WHERE deleted_at IS NULL 
        AND status = 'ATIVO' 
        AND is_checador = 1
      ORDER BY nome ASC
    `);
    
    const result = await stmt.all();
    const checadores = result.results || [];
    
    console.log(`✅ Encontrados ${checadores.length} checadores internos`);
    
    return c.json({
      success: true,
      checadores: checadores,
      total: checadores.length,
      message: `${checadores.length} checadores internos disponíveis`
    });
    
  } catch (error) {
    console.error('❌ Erro ao listar checadores:', error);
    return c.json({
      success: false,
      checadores: [],
      error: 'Erro ao carregar checadores',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/simulador/instrutores - Listar apenas instrutores
app.get('/instrutores', async (c) => {
  try {
    console.log('🔍 Buscando instrutores especificamente...');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT 
        id,
        nome,
        matricula,
        funcao,
        codigo_anac,
        nivel_icao,
        aeronave_principal
      FROM funcionarios 
      WHERE deleted_at IS NULL 
        AND status = 'ATIVO' 
        AND is_instrutor = 1
      ORDER BY nome ASC
    `);
    
    const result = await stmt.all();
    const instrutores = result.results || [];
    
    console.log(`👨‍🏫 Encontrados ${instrutores.length} instrutores`);
    
    return c.json({
      success: true,
      instrutores: instrutores,
      total: instrutores.length,
      message: `${instrutores.length} instrutores disponíveis`
    });
    
  } catch (error) {
    console.error('❌ Erro ao listar instrutores:', error);
    return c.json({
      success: false,
      instrutores: [],
      error: 'Erro ao carregar instrutores',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/simulador/tripulantes - Listar todos os funcionários que podem ser tripulantes
app.get('/tripulantes', async (c) => {
  try {
    console.log('🔍 Buscando tripulantes...');
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT 
        id,
        nome,
        matricula,
        funcao,
        codigo_anac,
        nivel_icao,
        aeronave_principal,
        is_instrutor,
        is_checador
      FROM funcionarios 
      WHERE deleted_at IS NULL 
        AND status = 'ATIVO'
      ORDER BY nome ASC
    `);
    
    const result = await stmt.all();
    const tripulantes = result.results || [];
    
    console.log(`👨‍✈️ Encontrados ${tripulantes.length} tripulantes`);
    
    return c.json({
      success: true,
      tripulantes: tripulantes,
      total: tripulantes.length,
      message: `${tripulantes.length} tripulantes disponíveis`
    });
    
  } catch (error) {
    console.error('❌ Erro ao listar tripulantes:', error);
    return c.json({
      success: false,
      tripulantes: [],
      error: 'Erro ao carregar tripulantes',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/simulador/estatisticas - Estatísticas gerais para debug
app.get('/estatisticas', async (c) => {
  try {
    console.log('📊 Coletando estatísticas do sistema...');
    const db = c.env.DB;
    
    // Contar registros em cada tabela
    const estatisticas = {
      simuladores: { total: 0, ativos: 0 },
      funcionarios: { total: 0, ativos: 0, instrutores: 0, checadores: 0 },
      templates: { total: 0 },
      agendamentos: { total: 0, ativos: 0 }
    };
    
    try {
      // Simuladores
      const simCount = await db.prepare('SELECT COUNT(*) as count FROM simuladores WHERE deleted_at IS NULL').first();
      const simAtivos = await db.prepare('SELECT COUNT(*) as count FROM simuladores WHERE deleted_at IS NULL AND status = "ATIVO"').first();
      estatisticas.simuladores.total = (simCount?.count as number) || 0;
      estatisticas.simuladores.ativos = (simAtivos?.count as number) || 0;
      
      // Funcionários
      const funcCount = await db.prepare('SELECT COUNT(*) as count FROM funcionarios WHERE deleted_at IS NULL').first();
      const funcAtivos = await db.prepare('SELECT COUNT(*) as count FROM funcionarios WHERE deleted_at IS NULL AND status = "ATIVO"').first();
      const instCount = await db.prepare('SELECT COUNT(*) as count FROM funcionarios WHERE deleted_at IS NULL AND is_instrutor = 1').first();
      const checkCount = await db.prepare('SELECT COUNT(*) as count FROM funcionarios WHERE deleted_at IS NULL AND is_checador = 1').first();
      
      estatisticas.funcionarios.total = (funcCount?.count as number) || 0;
      estatisticas.funcionarios.ativos = (funcAtivos?.count as number) || 0;
      estatisticas.funcionarios.instrutores = (instCount?.count as number) || 0;
      estatisticas.funcionarios.checadores = (checkCount?.count as number) || 0;
      
      // Templates
      const tempCount = await db.prepare('SELECT COUNT(*) as count FROM sessoes_template').first();
      estatisticas.templates.total = (tempCount?.count as number) || 0;
      
      // Agendamentos
      const agendCount = await db.prepare('SELECT COUNT(*) as count FROM agendamento_slots').first();
      const agendAtivos = await db.prepare('SELECT COUNT(*) as count FROM agendamento_slots WHERE status_slot = "AGENDADO"').first();
      estatisticas.agendamentos.total = (agendCount?.count as number) || 0;
      estatisticas.agendamentos.ativos = (agendAtivos?.count as number) || 0;
      
    } catch (error) {
      console.error('❌ Erro ao coletar algumas estatísticas:', error);
    }
    
    return c.json({
      success: true,
      estatisticas: estatisticas,
      timestamp: new Date().toISOString(),
      message: 'Estatísticas coletadas com sucesso'
    });
    
  } catch (error) {
    console.error('❌ Erro ao coletar estatísticas:', error);
    return c.json({
      success: false,
      error: 'Erro ao coletar estatísticas',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// POST /api/v2/simulador/verificar-sistema - Verificação de saúde do sistema
app.post('/verificar-sistema', async (c) => {
  try {
    console.log('🏥 Executando verificação completa do sistema...');
    const db = c.env.DB;
    
    const verificacao = {
      banco_conectado: false,
      tabelas_ok: [] as string[],
      tabelas_erro: [] as string[],
      dados_consistentes: true,
      problemas: [] as string[],
      timestamp: new Date().toISOString()
    };
    
    // Testar conexão
    try {
      await db.prepare('SELECT 1 as test').first();
      verificacao.banco_conectado = true;
    } catch (error) {
      verificacao.problemas.push('Banco de dados não acessível');
      return c.json({
        success: false,
        verificacao: verificacao,
        error: 'Banco de dados não acessível'
      }, 500);
    }
    
    // Verificar tabelas essenciais
    const tabelasEssenciais = [
      'simuladores',
      'funcionarios', 
      'sessoes_template',
      'agendamento_slots',
      'fichas_sessao'
    ];
    
    for (const tabela of tabelasEssenciais) {
      try {
        await db.prepare(`SELECT COUNT(*) as count FROM ${tabela} LIMIT 1`).first();
        verificacao.tabelas_ok.push(tabela);
      } catch (error) {
        verificacao.tabelas_erro.push(tabela);
        verificacao.problemas.push(`Tabela ${tabela} não acessível`);
        verificacao.dados_consistentes = false;
      }
    }
    
    // Verificar consistência dos dados
    if (verificacao.tabelas_ok.includes('funcionarios')) {
      const instrutoresSemFlag = await db.prepare(`
        SELECT COUNT(*) as count FROM funcionarios 
        WHERE funcao LIKE '%INSTRUTOR%' AND is_instrutor = 0 AND deleted_at IS NULL
      `).first();
      
      if (instrutoresSemFlag && (instrutoresSemFlag.count as number) > 0) {
        verificacao.problemas.push(`${instrutoresSemFlag.count} funcionários com função de instrutor mas flag is_instrutor = 0`);
      }
    }
    
    const status = verificacao.problemas.length === 0 ? 'EXCELENTE' : 
                  verificacao.problemas.length < 3 ? 'BOM' : 'RUIM';
    
    return c.json({
      success: true,
      verificacao: verificacao,
      status: status,
      message: `Verificação concluída - Status: ${status}`
    });
    
  } catch (error) {
    console.error('❌ Erro na verificação do sistema:', error);
    return c.json({
      success: false,
      error: 'Erro na verificação do sistema',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;