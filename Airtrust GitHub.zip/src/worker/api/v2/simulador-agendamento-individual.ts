import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';
import { 
  validarDataBrasileira, 
  converterDataHoraBrasileira, 
  gerarUuidSessao 
} from '../../utils/date-utils-brasileiro';

const app = new Hono<{ Bindings: Env }>();

/**
 * ⚠️ PADRÃO BRASILEIRO OBRIGATÓRIO - AIRTRUST ⚠️
 * 
 * API para Sistema de Controle Individual de Treinamentos por Tripulante em Sessões Duplas
 * 
 * Características obrigatórias:
 * ✅ Datas: SEMPRE dd/mm/aaaa (nunca mm/dd/yyyy ou yyyy-mm-dd)
 * ✅ Validação: SEMPRE formato brasileiro
 * ✅ Conversão: SEMPRE para Date usando padrão brasileiro
 * ✅ Cultura: SEMPRE pt-BR
 */

// Schema para dados gerais da sessão individual
const DadosGeraisSchema = z.object({
  data_inicio: z.string().min(1, 'Data de início obrigatória'),
  hora_inicio: z.string().min(1, 'Hora de início obrigatória'),
  data_fim: z.string().min(1, 'Data de fim obrigatória'),
  hora_fim: z.string().min(1, 'Hora de fim obrigatória'),
  simulador_id: z.string().min(1, 'Simulador obrigatório'),
  instrutor_id: z.string().min(1, 'Instrutor obrigatório'),
  observacoes: z.string().optional()
});

// Schema para participante individual
const ParticipanteSchema = z.object({
  id: z.number().int(),
  colaborador_id: z.string().min(1, 'Colaborador obrigatório'),
  treinamento_id: z.string().min(1, 'Treinamento obrigatório'),
  template_sessao_id: z.string().min(1, 'Template obrigatório'),
  funcao_na_sessao: z.enum(['PIC', 'SIC', 'DUAL'], {
    errorMap: () => ({ message: 'Função deve ser PIC, SIC ou DUAL' })
  }),
  sessao_numero: z.number().int().min(1),
  total_sessoes_treinamento: z.number().int().min(1)
});

// Schema para criar sessão individual
const CriarSessaoIndividualSchema = z.object({
  dados_gerais: DadosGeraisSchema,
  participantes: z.array(ParticipanteSchema).min(1, 'Pelo menos um participante é obrigatório')
});

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

/**
 * Classe para gerenciar finalização individual de treinamentos
 */
class FinalizacaoIndividualService {
  
  /**
   * Processar aprovação individual de um participante
   */
  static async processarAprovacaoIndividual(
    sessaoParticipanteId: number, 
    conceito: string, 
    instrutorId: number,
    db: any
  ) {
    // Buscar participante
    const participante = await db.prepare(`
      SELECT sp.*, ss.sessao_uuid, f.nome as colaborador_nome, f.matricula
      FROM sessao_participantes sp
      JOIN sessoes_simulador ss ON sp.sessao_id = ss.id
      JOIN funcionarios f ON sp.colaborador_id = f.id
      WHERE sp.id = ?
    `).bind(sessaoParticipanteId).first();
    
    if (!participante) {
      throw new Error('Participante não encontrado');
    }
    
    // 1. Atualizar status individual do participante
    await db.prepare(`
      UPDATE sessao_participantes 
      SET status_individual = ?, conceito_individual = ?, data_conclusao_individual = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      conceito === 'APROVADO' ? 'APROVADO' : 'REPROVADO',
      conceito,
      sessaoParticipanteId
    ).run();
    
    // 2. Se aprovado, atualizar progresso do treinamento
    if (conceito === 'APROVADO') {
      await this.atualizarProgressoTreinamento(
        participante.colaborador_id,
        participante.treinamento_id,
        instrutorId,
        db
      );
    }
    
    return participante;
  }
  
  /**
   * Atualizar progresso individual do treinamento
   */
  static async atualizarProgressoTreinamento(
    colaboradorId: number,
    treinamentoId: number,
    instrutorId: number,
    db: any
  ) {
    // Buscar progresso atual
    let progresso = await db.prepare(`
      SELECT * FROM progresso_treinamento_individual 
      WHERE colaborador_id = ? AND treinamento_id = ?
    `).bind(colaboradorId, treinamentoId).first();
    
    if (!progresso) {
      // Buscar total de sessões necessárias do treinamento
      const infoTreinamento = await db.prepare(`
        SELECT COUNT(*) as total_sessoes FROM sessoes_template st
        JOIN catalogo_treinamentos_v2 ct ON st.treinamento_codigo = ct.codigo
        WHERE ct.id = ?
      `).bind(treinamentoId).first();
      
      const totalSessoes = infoTreinamento?.total_sessoes || 3;
      
      // Criar progresso
      const resultado = await db.prepare(`
        INSERT INTO progresso_treinamento_individual 
        (colaborador_id, treinamento_id, total_sessoes_necessarias, sessoes_concluidas)
        VALUES (?, ?, ?, 1)
      `).bind(colaboradorId, treinamentoId, totalSessoes).run();
      
      progresso = {
        id: resultado.meta.last_row_id,
        colaborador_id: colaboradorId,
        treinamento_id: treinamentoId,
        sessoes_concluidas: 1,
        total_sessoes_necessarias: totalSessoes,
        status_treinamento: 'EM_ANDAMENTO'
      };
    } else {
      // Incrementar sessões concluídas
      const novasSessoesCompletas = progresso.sessoes_concluidas + 1;
      
      await db.prepare(`
        UPDATE progresso_treinamento_individual 
        SET sessoes_concluidas = ?
        WHERE id = ?
      `).bind(novasSessoesCompletas, progresso.id).run();
      
      progresso.sessoes_concluidas = novasSessoesCompletas;
    }
    
    // Verificar se completou o treinamento
    if (progresso.sessoes_concluidas >= progresso.total_sessoes_necessarias) {
      await db.prepare(`
        UPDATE progresso_treinamento_individual 
        SET status_treinamento = 'CONCLUIDO', data_conclusao = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(progresso.id).run();
      
      // Disparar certificação individual
      await this.gerarCertificacaoIndividual(
        colaboradorId,
        treinamentoId,
        instrutorId,
        db
      );
    }
  }
  
  /**
   * Gerar certificação individual quando treinamento for completado
   */
  static async gerarCertificacaoIndividual(
    colaboradorId: number,
    treinamentoId: number,
    instrutorId: number,
    db: any
  ) {
    // Buscar dados do colaborador e treinamento
    const colaborador = await db.prepare(`
      SELECT nome, matricula FROM funcionarios WHERE id = ?
    `).bind(colaboradorId).first();
    
    const treinamento = await db.prepare(`
      SELECT codigo, nome FROM catalogo_treinamentos_v2 WHERE id = ?
    `).bind(treinamentoId).first();
    
    if (!colaborador || !treinamento) {
      throw new Error('Dados não encontrados para certificação');
    }
    
    // Buscar todas as sessões aprovadas do treinamento
    const sessoesCompletas = await db.prepare(`
      SELECT sp.*, ss.data_inicio, ss.sessao_uuid
      FROM sessao_participantes sp
      JOIN sessoes_simulador ss ON sp.sessao_id = ss.id
      WHERE sp.colaborador_id = ? AND sp.treinamento_id = ? AND sp.status_individual = 'APROVADO'
      ORDER BY sp.sessao_numero
    `).bind(colaboradorId, treinamentoId).all();
    
    // Gerar ID único da certificação
    const agora = new Date();
    const dataFormatada = agora.toLocaleDateString('pt-BR').replace(/\//g, '');
    const numeroSequencial = Math.floor(Math.random() * 99999).toString().padStart(5, '0');
    const certificacaoId = `CERT-${dataFormatada}-${numeroSequencial}`;
    
    // Calcular data de validade (12 meses)
    const dataValidade = new Date();
    dataValidade.setMonth(dataValidade.getMonth() + 12);
    const dataValidadeBrasil = dataValidade.toLocaleDateString('pt-BR');
    
    // Registrar certificação no sistema
    const certificacao = {
      certificacao_id: certificacaoId,
      funcionario_matricula: colaborador.matricula,
      treinamento_codigo: treinamento.codigo,
      data_conclusao: agora.toLocaleDateString('pt-BR'),
      data_vencimento: dataValidadeBrasil,
      instrutor: `ID: ${instrutorId}`,
      local_realizacao: 'Simulador - Controle Individual',
      observacoes: `Treinamento concluído através de ${sessoesCompletas.results?.length || 0} sessões individuais`,
      tipo_operacao: 'NOVA',
      compliance_status: 'VALIDO',
      created_by: `SISTEMA_INDIVIDUAL_${instrutorId}`
    };
    
    // Inserir na tabela de certificações
    await db.prepare(`
      INSERT INTO certificacoes_v3 (
        certificacao_id, funcionario_matricula, treinamento_codigo,
        data_conclusao, data_vencimento, instrutor, local_realizacao,
        observacoes, tipo_operacao, compliance_status, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      certificacao.certificacao_id,
      certificacao.funcionario_matricula,
      certificacao.treinamento_codigo,
      certificacao.data_conclusao,
      certificacao.data_vencimento,
      certificacao.instrutor,
      certificacao.local_realizacao,
      certificacao.observacoes,
      certificacao.tipo_operacao,
      certificacao.compliance_status,
      certificacao.created_by
    ).run();
    
    console.log(`Certificação individual gerada: ${certificacaoId} para ${colaborador.nome}`);
    
    return certificacao;
  }
}

// POST /api/v2/simulador/agendar-individual - Criar sessão com controle individual
app.post('/agendar-individual', 
  requirePermission('simuladores', 'CREATE'), 
  zValidator('json', CriarSessaoIndividualSchema), 
  async (c) => {
    try {
      const { dados_gerais, participantes } = c.req.valid('json');
      const userId = 1; // Default user for demo
      const db = c.env.DB;
      
      // Validar formato brasileiro das datas
      if (!validarDataBrasileira(dados_gerais.data_inicio)) {
        return c.json({ 
          error: 'Data de início deve estar no formato brasileiro dd/mm/aaaa',
          exemplo: '20/12/2024'
        }, 400);
      }
      
      if (!validarDataBrasileira(dados_gerais.data_fim)) {
        return c.json({ 
          error: 'Data de fim deve estar no formato brasileiro dd/mm/aaaa',
          exemplo: '20/12/2024'
        }, 400);
      }
      
      // Converter datas brasileiras para formato ISO
      const dataHoraInicio = converterDataHoraBrasileira(dados_gerais.data_inicio, dados_gerais.hora_inicio);
      const dataHoraFim = converterDataHoraBrasileira(dados_gerais.data_fim, dados_gerais.hora_fim);
      
      if (!dataHoraInicio || !dataHoraFim) {
        return c.json({ error: 'Erro ao converter datas brasileiras' }, 400);
      }
      
      // Verificar se não há participantes duplicados
      const colaboradorIds = participantes.map(p => p.colaborador_id);
      if (new Set(colaboradorIds).size !== colaboradorIds.length) {
        return c.json({ error: 'Não pode ter o mesmo tripulante duas vezes na sessão' }, 400);
      }
      
      // Gerar UUID único da sessão
      const sessaoUuid = gerarUuidSessao();
      
      let sessaoId: number;
      
      // 1. Criar sessão principal
      const resultSessao = await db.prepare(`
        INSERT INTO sessoes_simulador (
          sessao_uuid, data_inicio, data_fim, simulador_id, instrutor_id, observacoes, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(
        sessaoUuid,
        dataHoraInicio.toISOString(),
        dataHoraFim.toISOString(),
        parseInt(dados_gerais.simulador_id),
        parseInt(dados_gerais.instrutor_id),
        dados_gerais.observacoes || null,
        userId
      ).run();
      
      if (!resultSessao.success) {
        return c.json({ error: 'Erro ao criar sessão principal' }, 500);
      }
      
      sessaoId = resultSessao.meta.last_row_id as number;
      
      // 2. Criar cada participante individual
      for (const participante of participantes) {
        // Verificar/criar progresso do treinamento
        const progressoExistente = await db.prepare(`
          SELECT * FROM progresso_treinamento_individual 
          WHERE colaborador_id = ? AND treinamento_id = ?
        `).bind(
          parseInt(participante.colaborador_id),
          parseInt(participante.treinamento_id)
        ).first();
        
        if (!progressoExistente) {
          // Criar novo progresso
          await db.prepare(`
            INSERT INTO progresso_treinamento_individual (
              colaborador_id, treinamento_id, total_sessoes_necessarias, sessoes_concluidas
            ) VALUES (?, ?, ?, 0)
          `).bind(
            parseInt(participante.colaborador_id),
            parseInt(participante.treinamento_id),
            participante.total_sessoes_treinamento
          ).run();
        }
        
        // Criar participante da sessão
        await db.prepare(`
          INSERT INTO sessao_participantes (
            sessao_id, colaborador_id, treinamento_id, template_sessao_id,
            funcao_na_sessao, sessao_numero, total_sessoes_treinamento
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(
          sessaoId,
          parseInt(participante.colaborador_id),
          parseInt(participante.treinamento_id),
          parseInt(participante.template_sessao_id),
          participante.funcao_na_sessao,
          participante.sessao_numero,
          participante.total_sessoes_treinamento
        ).run();
      }
      
      // 3. Registrar auditoria
      await logAudit(c, 'CREATE', 'sessoes_simulador', sessaoId.toString(), undefined, {
        tipo: 'SESSAO_INDIVIDUAL',
        participantes: participantes.length,
        treinamentos_diferentes: [...new Set(participantes.map(p => p.treinamento_id))].length,
        sessao_uuid: sessaoUuid
      });
      
      return c.json({ 
        success: true, 
        message: 'Sessão com controle individual criada com sucesso!',
        sessao_uuid: sessaoUuid,
        sessao_id: sessaoId,
        participantes_criados: participantes.length
      }, 201);
      
    } catch (error) {
      console.error('Erro ao criar sessão individual:', error);
      await logAudit(c, 'CREATE', 'sessoes_simulador', undefined, undefined, undefined, 'ERROR');
      return c.json({ 
        error: 'Erro interno do servidor',
        details: error instanceof Error ? error.message : 'Erro desconhecido'
      }, 500);
    }
  }
);

// GET /api/v2/simulador/sessoes-individuais - Listar sessões com controle individual
app.get('/sessoes-individuais', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    const limit = parseInt(c.req.query('limit') || '50');
    const offset = parseInt(c.req.query('offset') || '0');
    
    const stmt = db.prepare(`
      SELECT 
        ss.id, ss.sessao_uuid, ss.data_inicio, ss.data_fim, ss.status_geral, ss.observacoes,
        s.nome as simulador_nome, s.codigo_identificacao,
        fi.nome as instrutor_nome, fi.matricula as instrutor_matricula,
        COUNT(sp.id) as total_participantes,
        COUNT(CASE WHEN sp.status_individual = 'APROVADO' THEN 1 END) as participantes_aprovados,
        COUNT(CASE WHEN sp.status_individual = 'REPROVADO' THEN 1 END) as participantes_reprovados,
        COUNT(CASE WHEN sp.status_individual = 'PENDENTE' THEN 1 END) as participantes_pendentes
      FROM sessoes_simulador ss
      JOIN simuladores s ON ss.simulador_id = s.id
      JOIN funcionarios fi ON ss.instrutor_id = fi.id
      LEFT JOIN sessao_participantes sp ON ss.id = sp.sessao_id
      GROUP BY ss.id
      ORDER BY ss.data_inicio DESC
      LIMIT ? OFFSET ?
    `);
    
    const result = await stmt.bind(limit, offset).all();
    const sessoes = result.results || [];
    
    // Para cada sessão, buscar detalhes dos participantes
    for (const sessao of sessoes) {
      const participantesStmt = db.prepare(`
        SELECT 
          sp.id, sp.colaborador_id, sp.treinamento_id, sp.funcao_na_sessao,
          sp.sessao_numero, sp.total_sessoes_treinamento, sp.status_individual,
          sp.conceito_individual, sp.data_conclusao_individual,
          f.nome as colaborador_nome, f.matricula as colaborador_matricula,
          ct.codigo as treinamento_codigo, ct.nome as treinamento_nome,
          st.nome_sessao as template_nome
        FROM sessao_participantes sp
        JOIN funcionarios f ON sp.colaborador_id = f.id
        JOIN catalogo_treinamentos_v2 ct ON sp.treinamento_id = ct.id
        LEFT JOIN sessoes_template st ON sp.template_sessao_id = st.id
        WHERE sp.sessao_id = ?
        ORDER BY sp.funcao_na_sessao, f.nome
      `);
      
      const participantesResult = await participantesStmt.bind(sessao.id).all();
      (sessao as any).participantes = participantesResult.results || [];
    }
    
    await logAudit(c, 'LIST', 'sessoes_simulador');
    
    return c.json({
      success: true,
      data: sessoes,
      total: sessoes.length,
      limit,
      offset
    });
  } catch (error) {
    console.error('Erro ao listar sessões individuais:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// POST /api/v2/simulador/aprovar-participante/:id - Aprovar participante individual
app.post('/aprovar-participante/:id', 
  requirePermission('simuladores', 'UPDATE'), 
  zValidator('json', z.object({
    conceito: z.enum(['APROVADO', 'REPROVADO']),
    observacoes: z.string().optional()
  })), 
  async (c) => {
    try {
      const participanteId = parseInt(c.req.param('id'));
      const { conceito, observacoes } = c.req.valid('json');
      const instrutorId = 1; // Default user for demo
      const db = c.env.DB;
      
      // Processar aprovação individual
      const participante = await FinalizacaoIndividualService.processarAprovacaoIndividual(
        participanteId,
        conceito,
        instrutorId,
        db
      );
      
      // Atualizar observações se fornecidas
      if (observacoes) {
        await db.prepare(`
          UPDATE sessao_participantes 
          SET observacoes_individuais = ?
          WHERE id = ?
        `).bind(observacoes, participanteId).run();
      }
      
      await logAudit(c, 'UPDATE', 'sessao_participantes', participanteId.toString(), undefined, {
        conceito,
        observacoes,
        colaborador_nome: participante.colaborador_nome
      });
      
      return c.json({
        success: true,
        message: `Participante ${conceito.toLowerCase()} com sucesso!`,
        data: {
          participante_id: participanteId,
          conceito,
          colaborador: participante.colaborador_nome
        }
      });
    } catch (error) {
      console.error('Erro ao aprovar participante:', error);
      return c.json({ 
        error: 'Erro interno do servidor',
        details: error instanceof Error ? error.message : 'Erro desconhecido'
      }, 500);
    }
  }
);

// GET /api/v2/simulador/progresso-individual/:colaborador_id - Obter progresso individual de um colaborador
app.get('/progresso-individual/:colaborador_id', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const colaboradorId = parseInt(c.req.param('colaborador_id'));
    const db = c.env.DB;
    
    const stmt = db.prepare(`
      SELECT 
        pti.*, 
        ct.codigo as treinamento_codigo, ct.nome as treinamento_nome,
        f.nome as colaborador_nome, f.matricula as colaborador_matricula
      FROM progresso_treinamento_individual pti
      JOIN catalogo_treinamentos_v2 ct ON pti.treinamento_id = ct.id
      JOIN funcionarios f ON pti.colaborador_id = f.id
      WHERE pti.colaborador_id = ?
      ORDER BY pti.data_inicio DESC
    `);
    
    const result = await stmt.bind(colaboradorId).all();
    const progressos = result.results || [];
    
    return c.json({
      success: true,
      data: progressos,
      total: progressos.length
    });
  } catch (error) {
    console.error('Erro ao buscar progresso individual:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// ===== FUNÇÕES AUXILIARES =====

// As funções auxiliares foram movidas para src/worker/utils/date-utils-brasileiro.ts

export default app;
