import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

interface Env {
  DB: any;
}

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// GET /api/v2/certificados-download/:id - Download de certificados via GitHub
app.get('/:id', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const id = c.req.param('id');
    
    if (!id) {
      return c.json({ error: 'ID do arquivo não fornecido' }, 400);
    }
    
    console.log('🔗 Download GitHub - ID:', id);
    
    const db = c.env.DB;
    
    const result = await db.prepare(
      'SELECT arquivo_github_url, nome_arquivo FROM certificado_anexos_v2 WHERE id = ?'
    ).bind(id).first();
    
    if (!result || !result.arquivo_github_url) {
      console.error('Certificado não encontrado para ID:', id);
      
      await logAudit(c, 'DOWNLOAD', 'certificado_anexos_v2', id, undefined, { 
        status: 'file_not_found',
        arquivo_id: id
      });

      return c.json({
        success: false,
        error: 'Certificado não encontrado'
      }, 404);
    }

    console.log('🔗 Redirecionando para GitHub:', result.arquivo_github_url);

    await logAudit(c, 'DOWNLOAD', 'certificado_anexos_v2', id, undefined, { 
      status: 'github_redirect',
      arquivo_github_url: result.arquivo_github_url,
      nome_arquivo: result.nome_arquivo
    });

    return c.redirect(result.arquivo_github_url);

  } catch (error) {
    console.error('❌ Erro download:', error);
    await logAudit(c, 'DOWNLOAD', 'certificado_anexos_v2', undefined, undefined, undefined, 'ERROR');
    
    return c.json({ 
      success: false, 
      error: 'Erro no download'
    }, 500);
  }
});

// GET /api/v2/certificados-download/by-historico/:historicoId - Download por histórico ID
app.get('/by-historico/:historicoId', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const historicoId = c.req.param('historicoId');
    const db = c.env.DB;

    // Buscar o primeiro arquivo do histórico
    const result = await db.prepare(
      'SELECT id FROM certificado_anexos_v2 WHERE historico_id = ? ORDER BY created_at DESC LIMIT 1'
    ).bind(historicoId).first();

    if (!result) {
      return c.json({ error: 'Nenhum arquivo encontrado para este histórico' }, 404);
    }

    // Redirecionar para o download do arquivo
    return c.redirect(`/api/v2/certificados-download/${result.id}`);

  } catch (error) {
    console.error('Error finding file by historico:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default app;
