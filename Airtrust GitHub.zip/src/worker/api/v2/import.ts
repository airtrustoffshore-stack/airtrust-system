import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';
import { validarDadosImportacao } from '../../../shared/utils/certificacao-utils';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// Função helper simples para parsear CSV
function parseCSV(csvText: string): Array<Record<string, string>> {
  const lines = csvText.trim().split('\n');
  if (lines.length < 2) return [];
  
  const header = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
  const data: Array<Record<string, string>> = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
    if (values.length === header.length) {
      const row: Record<string, string> = {};
      header.forEach((col, idx) => {
        row[col.toLowerCase().replace(/\s+/g, '_')] = values[idx] || '';
      });
      data.push(row);
    }
  }
  
  return data;
}

// Função auxiliar para busca flexível de funcionários - CORREÇÃO ROBUSTA
const buscarFuncionario = async (identificador: string, db: any) => {
  console.log(`🔍 [BUSCAR_FUNCIONARIO] Iniciando busca: "${identificador}"`);
  
  if (!identificador || identificador.trim() === '') {
    console.log(`❌ [BUSCAR_FUNCIONARIO] Identificador vazio`);
    return null;
  }
  
  const id = identificador.trim();
  
  // Estratégias de busca em ordem de prioridade
  const estrategias = [
    // 1. Busca exata
    async () => {
      console.log(`🎯 [BUSCAR_FUNCIONARIO] Estratégia 1: busca exata por "${id}"`);
      return await db.prepare(`SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL LIMIT 1`).bind(id).first();
    },
    
    // 2. Busca sem zeros à esquerda  
    async () => {
      const semZeros = id.replace(/^0+/, '') || '0';
      console.log(`🎯 [BUSCAR_FUNCIONARIO] Estratégia 2: sem zeros à esquerda "${semZeros}"`);
      return await db.prepare(`SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL LIMIT 1`).bind(semZeros).first();
    },
    
    // 3. Busca com zeros à esquerda (5 dígitos)
    async () => {
      const comZeros = id.padStart(5, '0');
      console.log(`🎯 [BUSCAR_FUNCIONARIO] Estratégia 3: com zeros à esquerda "${comZeros}"`);
      return await db.prepare(`SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL LIMIT 1`).bind(comZeros).first();
    },
    
    // 4. Busca com 3 dígitos padronizados
    async () => {
      const com3Zeros = id.padStart(3, '0');
      console.log(`🎯 [BUSCAR_FUNCIONARIO] Estratégia 4: 3 dígitos "${com3Zeros}"`);
      return await db.prepare(`SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL LIMIT 1`).bind(com3Zeros).first();
    },
    
    // 5. Busca LIKE para casos flexíveis
    async () => {
      console.log(`🎯 [BUSCAR_FUNCIONARIO] Estratégia 5: busca LIKE "%${id}%"`);
      return await db.prepare(`SELECT id, nome, matricula FROM funcionarios WHERE matricula LIKE ? AND deleted_at IS NULL LIMIT 1`).bind(`%${id}%`).first();
    },
    
    // 6. Busca por nome se não for numérico
    async () => {
      if (isNaN(parseInt(id))) {
        console.log(`🎯 [BUSCAR_FUNCIONARIO] Estratégia 6: busca por nome "${id}"`);
        return await db.prepare(`SELECT id, nome, matricula FROM funcionarios WHERE nome LIKE ? AND deleted_at IS NULL LIMIT 1`).bind(`%${id}%`).first();
      }
      return null;
    }
  ];
  
  for (let i = 0; i < estrategias.length; i++) {
    try {
      const funcionario = await estrategias[i]();
      if (funcionario) {
        console.log(`✅ [BUSCAR_FUNCIONARIO] Encontrado (estratégia ${i+1}): ${funcionario.nome} (${funcionario.matricula})`);
        return funcionario;
      }
    } catch (error) {
      console.log(`⚠️ [BUSCAR_FUNCIONARIO] Estratégia ${i+1} falhou:`, error);
    }
  }
  
  console.log(`❌ [BUSCAR_FUNCIONARIO] Funcionário "${identificador}" não encontrado em nenhuma estratégia`);
  return null;
};

// POST /api/v2/import/treinamentos - Importação SIMPLES de treinamentos
app.post('/treinamentos', requirePermission('treinamentos', 'CREATE'), async (c) => {
  const startTime = Date.now();
  
  try {
    const db = c.env.DB;
    let csvData: Array<Record<string, string>> = [];

    const contentType = c.req.header('content-type') || '';

    if (contentType.includes('multipart/form-data')) {
      const formData = await c.req.formData();
      const file = formData.get('file') as File;
      
      if (!file) {
        return c.json({ success: false, error: 'Arquivo não fornecido' }, 400);
      }
      
      const csvText = await file.text();
      csvData = parseCSV(csvText);
    } else if (contentType.includes('application/json')) {
      const jsonBody = await c.req.json();
      
      if (jsonBody.csv_data) {
        csvData = parseCSV(jsonBody.csv_data);
      } else if (jsonBody.data && Array.isArray(jsonBody.data)) {
        csvData = jsonBody.data;
      } else {
        return c.json({ success: false, error: 'Formato JSON inválido' }, 400);
      }
    }

    if (!csvData || csvData.length === 0) {
      return c.json({ success: false, error: 'Nenhum dado válido encontrado' }, 400);
    }

    let processadas = 0;
    let criadas = 0;
    let atualizadas = 0;
    let erros = 0;

    // Processar cada linha - SIMPLES
    for (const registro of csvData) {
      try {
        if (!registro.codigo || !registro.nome) {
          erros++;
          continue;
        }

        const existing = await db.prepare(
          'SELECT id FROM catalogo_treinamentos_v2 WHERE codigo = ? AND deleted_at IS NULL'
        ).bind(registro.codigo).first();

        if (existing) {
          await db.prepare(`
            UPDATE catalogo_treinamentos_v2 
            SET nome = ?, categoria = ?, updated_at = CURRENT_TIMESTAMP
            WHERE codigo = ? AND deleted_at IS NULL
          `).bind(
            registro.nome,
            registro.categoria || 'IMPORTADO',
            registro.codigo
          ).run();
          atualizadas++;
        } else {
          await db.prepare(`
            INSERT INTO catalogo_treinamentos_v2 (
              codigo, nome, categoria, ativo, created_at, updated_at
            ) VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(
            registro.codigo,
            registro.nome,
            registro.categoria || 'IMPORTADO'
          ).run();
          criadas++;
        }
        
        processadas++;
      } catch (error) {
        erros++;
      }
    }

    const processTime = Date.now() - startTime;

    await logAudit(c, 'IMPORT_TREINAMENTOS', 'catalogo_treinamentos_v2', undefined, undefined, {
      processadas, criadas, atualizadas, erros, duracao_ms: processTime
    });

    return c.json({
      success: true,
      processadas,
      criadas,
      atualizadas,
      erros,
      duracao_ms: processTime
    });

  } catch (error) {
    return c.json({
      success: false,
      error: (error as Error).message
    }, 500);
  }
});

// ✅ ATUALIZAÇÂO DO ENDPOINT DE IMPORTAÇÃO COM VALIDAÇÃO
app.post('/certificacoes', requirePermission('treinamentos', 'CREATE'), async (c) => {
  try {
    const dados = await processarCSV(c);
    
    // VALIDAR DADOS PRIMEIRO
    const errosValidacao = await validarDadosImportacao(dados, c.env.DB);
    if (errosValidacao.length > 0) {
      return c.json({
        success: false,
        message: 'Dados inválidos encontrados',
        erros: errosValidacao
      }, 400);
    }
    
    // Só importar se validação passou
    const resultado = await importarCertificacoes(dados, c.env.DB);
    
    return c.json({
      success: true,
      processadas: dados.length,
      sucessos: resultado.sucessos.length,
      erros: resultado.erros.length,
      detalhes: resultado
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: (error as Error).message
    }, 500);
  }
});

// POST /api/v2/import/certificacoes - Importação de CERTIFICAÇÕES CORRIGIDA E ROBUSTA
const processarCSV = async (c: any) => {
  const contentType = c.req.header('content-type') || '';
  let csvData: Array<Record<string, string>> = [];

  if (contentType.includes('multipart/form-data')) {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      throw new Error('Arquivo CSV é obrigatório');
    }
    
    const csvText = await file.text();
    csvData = parseCSV(csvText);
  } else if (contentType.includes('application/json')) {
    const jsonBody = await c.req.json();
    
    if (jsonBody.csv_data) {
      csvData = parseCSV(jsonBody.csv_data);
    } else if (jsonBody.data && Array.isArray(jsonBody.data)) {
      csvData = jsonBody.data;
    } else {
      throw new Error('Formato JSON inválido. Use: { data: [...] } ou { csv_data: "..." }');
    }
  } else {
    throw new Error('Content-Type deve ser multipart/form-data ou application/json');
  }

  if (!csvData || csvData.length === 0) {
    throw new Error('Arquivo deve ter cabeçalho + pelo menos 1 linha de dados');
  }

  return csvData;
};

const importarCertificacoes = async (csvData: any[], db: any): Promise<{ sucessos: string[], erros: any[] }> => {
  const sucessos: string[] = [];
  const erros: any[] = [];

  for (let i = 0; i < csvData.length; i++) {
    const registro = csvData[i];
    
    try {
      // Detectar campos do CSV automaticamente - FLEXÍVEL
      const funcionarioMatricula = registro.funcionario_matricula || 
                                 registro.matricula || 
                                 registro.colaborador || 
                                 registro.funcionario ||
                                 registro.employee ||
                                 '';
      
      const treinamentoCodigo = registro.treinamento_codigo || 
                              registro.treinamento || 
                              registro.curso || 
                              registro.training ||
                              '';
      
      const dataConclusao = registro.data_conclusao || 
                          registro.data_certificacao ||
                          registro.date ||
                          new Date().toISOString().split('T')[0];

      // Validar campos obrigatórios
      if (!funcionarioMatricula || !treinamentoCodigo) {
        erros.push({
          linha: i + 1,
          erro: 'Campos obrigatórios: funcionario_matricula/matricula/colaborador E treinamento_codigo/treinamento',
          dados: registro
        });
        continue;
      }

      // 1. Buscar funcionário com BUSCA FLEXÍVEL
      const funcionario = await buscarFuncionario(funcionarioMatricula, db);

      if (!funcionario) {
        erros.push({
          linha: i + 1,
          erro: `Funcionário com matrícula '${funcionarioMatricula}' não encontrado`,
          dados: registro
        });
        continue;
      }

      // 2. Find-or-Create treinamento - TAMBÉM FLEXÍVEL
      let treinamento = await db.prepare(
        'SELECT id, codigo, nome FROM catalogo_treinamentos_v2 WHERE (codigo = ? OR nome LIKE ?) AND deleted_at IS NULL LIMIT 1'
      ).bind(treinamentoCodigo, `%${treinamentoCodigo}%`).first();

      if (!treinamento) {
        // Auto-criar treinamento
        const insertTreinamentoStmt = db.prepare(`
          INSERT INTO catalogo_treinamentos_v2 (
            codigo, nome, categoria, ativo, created_at, updated_at
          ) VALUES (?, ?, 'AUTO_CRIADO_CSV', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `);
        
        const treinamentoNome = registro.treinamento_nome || 
                              registro.nome_treinamento ||
                              registro.curso_nome ||
                              `Auto-criado: ${treinamentoCodigo}`;
        
        const insertResult = await insertTreinamentoStmt.bind(
          treinamentoCodigo,
          treinamentoNome
        ).run();
        
        if (insertResult.success && insertResult.meta?.last_row_id) {
          treinamento = { 
            id: insertResult.meta.last_row_id, 
            codigo: treinamentoCodigo,
            nome: treinamentoNome
          };
        } else {
          erros.push({
            linha: i + 1,
            erro: `Erro ao criar treinamento '${treinamentoCodigo}'`,
            dados: registro
          });
          continue;
        }
      }

      // 3. Atualizar certificação anterior para SUBSTITUIDO 
      await db.prepare(`
        UPDATE historico_certificacoes_v2 
        SET status = 'SUBSTITUIDO', updated_at = CURRENT_TIMESTAMP
        WHERE funcionario_id = ? AND treinamento_id = ? AND status = 'ATIVO' AND deleted_at IS NULL
      `).bind(funcionario.id, treinamento.id).run();

      // 4. Inserir nova certificação
      const insertStmt = db.prepare(`
        INSERT INTO historico_certificacoes_v2 (
          funcionario_id, treinamento_id, data_conclusao, data_vencimento,
          instrutor, nota_final, observacoes, certificado_url, status,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ATIVO', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `);
      
      const result = await insertStmt.bind(
        funcionario.id,
        treinamento.id,
        dataConclusao,
        registro.data_vencimento || null,
        registro.instrutor || null,
        registro.nota_final ? parseFloat(registro.nota_final) : null,
        registro.observacoes || null,
        registro.certificado_url || null
      ).run();

      if (result.success && result.meta?.last_row_id) {
        const sucesso = `✅ ${funcionario.nome} (${funcionario.matricula}) certificado em ${treinamento.nome || treinamento.codigo}`;
        sucessos.push(sucesso);
      } else {
        erros.push({
          linha: i + 1,
          erro: 'Falha ao inserir certificação no banco de dados',
          dados: registro
        });
      }

    } catch (error) {
      erros.push({
        linha: i + 1,
        erro: (error as Error).message,
        dados: registro
      });
    }
  }

  return { sucessos, erros };
};

// GET /api/v2/import/template/treinamentos - Template CSV para treinamentos
app.get('/template/treinamentos', async () => {
  const template = [
    'codigo,nome,descricao,categoria,periodicidade_meses,instrutor_obrigatorio,nota_minima,carga_horaria',
    'TRN-001,Nome do Treinamento,Descrição do treinamento,CATEGORIA,12,true,7.0,8'
  ].join('\n');

  return new Response(template, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="template_treinamentos.csv"'
    }
  });
});

// GET /api/v2/import/template/certificacoes - Template CSV para certificações
app.get('/template/certificacoes', async () => {
  const template = [
    'funcionario_matricula,treinamento_codigo,treinamento_nome,data_conclusao,data_vencimento,instrutor,nota_final,observacoes',
    'FUNC001,TRN-001,Nome do Treinamento,2024-01-15,2025-01-15,Nome Instrutor,8.5,Observações da certificação'
  ].join('\n');

  return new Response(template, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="template_certificacoes.csv"'
    }
  });
});

export default app;
