import { Hono } from 'hono';
import { z } from 'zod';

const importManobrasApi = new Hono<{ Bindings: Env }>();

// Schema para validação do CSV
const ManobraCSVSchema = z.object({
  manobra_id_codigo: z.string().min(1, 'Código da manobra é obrigatório'),
  nome_manobra: z.string().min(1, 'Nome da manobra é obrigatório'),
  categoria: z.string().min(1, 'Categoria é obrigatória'),
  criterios_aprovacao: z.string().optional(),
  pontuacao_minima: z.string().transform(val => parseInt(val) || 5),
  ciclos_csv: z.string().optional() // Ex: "1,2,3"
});

// POST /api/v2/import/manobras
importManobrasApi.post('/manobras', async (c) => {
  try {
    const body = await c.req.json();
    const { csv_content } = body;

    if (!csv_content) {
      return c.json({ error: 'Conteúdo CSV é obrigatório' }, 400);
    }

    const db = c.env.DB;
    const lines: string[] = csv_content.trim().split('\n');
    
    // Remove header se existir
    const dataLines = lines.filter(line => 
      line.trim() && !line.toLowerCase().includes('manobra_id_codigo')
    );

    const results = {
      success: 0,
      errors: 0,
      warnings: 0,
      details: [] as any[]
    };

    for (let i = 0; i < dataLines.length; i++) {
      const line = dataLines[i];
      const lineNumber = i + 1;

      try {
        // Parse CSV line (considerando aspas duplas)
        const values = parseCSVLine(line);
        
        if (values.length < 3) {
          results.errors++;
          results.details.push({
            linha: lineNumber,
            status: 'ERROR',
            erro: 'Linha com poucos campos (mínimo: código, nome, categoria)'
          });
          continue;
        }

        const manobraData = {
          manobra_id_codigo: values[0]?.trim() || '',
          nome_manobra: values[1]?.trim() || '',
          categoria: values[2]?.trim() || '',
          criterios_aprovacao: values[3]?.trim() || '',
          pontuacao_minima: values[4]?.trim() || '5',
          ciclos_csv: values[5]?.trim() || ''
        };

        // Validar dados
        const parsed = ManobraCSVSchema.parse(manobraData);

        // Verificar se a manobra já existe (Upsert logic)
        const existingManobra = await db.prepare(`
          SELECT id FROM manobras_catalogo WHERE manobra_id_codigo = ?
        `).bind(parsed.manobra_id_codigo).first();

        let manobraId;

        if (existingManobra) {
          // Atualizar manobra existente
          await db.prepare(`
            UPDATE manobras_catalogo 
            SET nome_manobra = ?, categoria = ?, criterios_aprovacao = ?, 
                pontuacao_minima = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
            WHERE manobra_id_codigo = ?
          `).bind(
            parsed.nome_manobra,
            parsed.categoria,
            parsed.criterios_aprovacao,
            parsed.pontuacao_minima,
            'import_csv',
            parsed.manobra_id_codigo
          ).run();

          manobraId = existingManobra.id;

          results.details.push({
            linha: lineNumber,
            status: 'SUCCESS',
            acao: 'ATUALIZADA',
            manobra_codigo: parsed.manobra_id_codigo
          });

        } else {
          // Criar nova manobra
          const result = await db.prepare(`
            INSERT INTO manobras_catalogo (
              manobra_id_codigo, nome_manobra, categoria, criterios_aprovacao, 
              pontuacao_minima, created_by
            ) VALUES (?, ?, ?, ?, ?, ?)
          `).bind(
            parsed.manobra_id_codigo,
            parsed.nome_manobra,
            parsed.categoria,
            parsed.criterios_aprovacao,
            parsed.pontuacao_minima,
            'import_csv'
          ).run();

          manobraId = result.meta.last_row_id;

          results.details.push({
            linha: lineNumber,
            status: 'SUCCESS',
            acao: 'CRIADA',
            manobra_codigo: parsed.manobra_id_codigo
          });
        }

        // Processar ciclos se fornecidos
        if (parsed.ciclos_csv) {
          // Remover associações existentes
          await db.prepare(`
            DELETE FROM manobras_catalogo_ciclos WHERE manobra_catalogo_id = ?
          `).bind(manobraId).run();

          // Parse dos ciclos (ex: "1,2,3")
          const ciclos = parsed.ciclos_csv.split(',')
            .map(c => parseInt(c.trim()))
            .filter(c => !isNaN(c) && c >= 1 && c <= 3);

          // Adicionar novas associações
          for (const cicloNumero of ciclos) {
            // Verificar se o ciclo existe
            const ciclo = await db.prepare(`
              SELECT id FROM ciclos WHERE numero_ciclo = ?
            `).bind(cicloNumero).first();

            if (ciclo) {
              await db.prepare(`
                INSERT OR IGNORE INTO manobras_catalogo_ciclos (manobra_catalogo_id, ciclo_id)
                VALUES (?, ?)
              `).bind(manobraId, ciclo.id).run();
            }
          }

          if (ciclos.length > 0) {
            const lastDetail = results.details[results.details.length - 1];
            if (lastDetail) {
              (lastDetail as any).ciclos_associados = ciclos;
            }
          }
        }

        results.success++;

      } catch (error) {
        results.errors++;
        results.details.push({
          linha: lineNumber,
          status: 'ERROR',
          erro: error instanceof Error ? error.message : 'Erro desconhecido',
          dados_linha: line
        });
      }
    }

    return c.json({
      message: `Importação concluída: ${results.success} sucessos, ${results.errors} erros`,
      results
    });

  } catch (error) {
    console.error('Erro na importação de manobras:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// Função para fazer parse de linha CSV considerando aspas duplas
function parseCSVLine(line: string): string[] {
  const result = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current); // Add the last field
  return result;
}

// GET /api/v2/import/manobras/template
importManobrasApi.get('/manobras/template', async () => {
  const template = `manobra_id_codigo,nome_manobra,categoria,criterios_aprovacao,pontuacao_minima,ciclos_csv
"M-101.A","Decolagem CAT II","IFR","Critério de aprovação detalhado",5,"1,2"
"M-102.B","Pouso de Emergência","VFR","Critério de aprovação detalhado",6,"2,3"
"M-103.C","Navegação por Instrumentos","IFR","Critério de aprovação detalhado",7,"1,3"`;

  return new Response(template, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="template_manobras.csv"'
    }
  });
});

export default importManobrasApi;
