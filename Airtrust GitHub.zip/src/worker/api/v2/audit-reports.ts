import { Hono } from 'hono';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';

const auditReportsApi = new Hono<{ Bindings: Env }>();

// Apply auth middleware
auditReportsApi.use('*', authMiddleware);

// Schema para filtros de relatório
const ReportFiltersSchema = z.object({
  data_inicio: z.string().optional(),
  data_fim: z.string().optional(),
  tipo_acao: z.string().optional(),
  ficha_uuid: z.string().optional(),
  usuario_id: z.string().optional(),
  formato: z.enum(['json', 'csv', 'pdf']).default('json')
});

// GET /api/v2/audit-reports/simulador - Relatório de auditoria do módulo simulador
auditReportsApi.get('/simulador', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const query = c.req.query();
    const filters = ReportFiltersSchema.parse(query);

    const db = c.env.DB;
    
    // Construir query com filtros dinâmicos
    let whereConditions = ['1=1'];
    let params: any[] = [];

    if (filters.data_inicio) {
      whereConditions.push('timestamp_acao >= ?');
      params.push(filters.data_inicio);
    }

    if (filters.data_fim) {
      whereConditions.push('timestamp_acao <= ?');
      params.push(filters.data_fim);
    }

    if (filters.tipo_acao) {
      whereConditions.push('acao = ?');
      params.push(filters.tipo_acao);
    }

    if (filters.ficha_uuid) {
      whereConditions.push('ficha_uuid = ?');
      params.push(filters.ficha_uuid);
    }

    if (filters.usuario_id) {
      whereConditions.push('usuario_id = ?');
      params.push(filters.usuario_id);
    }

    const auditLogs = await db.prepare(`
      SELECT 
        as.*,
        f.nome as usuario_nome
      FROM auditoria_simulador as
      LEFT JOIN funcionarios f ON as.usuario_id = f.id
      WHERE ${whereConditions.join(' AND ')}
      ORDER BY timestamp_acao DESC
      LIMIT 1000
    `).bind(...params).all();

    // Estatísticas resumidas
    const estatisticas = await db.prepare(`
      SELECT 
        acao,
        COUNT(*) as total,
        DATE(timestamp_acao) as data
      FROM auditoria_simulador
      WHERE ${whereConditions.join(' AND ')}
      GROUP BY acao, DATE(timestamp_acao)
      ORDER BY data DESC, total DESC
    `).bind(...params).all();

    const dados = {
      logs: auditLogs.results || [],
      estatisticas: estatisticas.results || [],
      filtros_aplicados: filters,
      total_registros: auditLogs.results?.length || 0,
      data_geracao: new Date().toISOString()
    };

    // Formatar resposta baseado no formato solicitado
    switch (filters.formato) {
      case 'csv':
        return gerarCSVAuditoria(c, dados);
      case 'pdf':
        return gerarPDFAuditoria(c, dados);
      default:
        return c.json({
          success: true,
          data: dados
        });
    }

  } catch (error) {
    console.error('Erro ao gerar relatório de auditoria:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/audit-reports/integridade - Relatório de integridade do sistema
auditReportsApi.get('/integridade', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const db = c.env.DB;

    // Verificações de integridade em tempo real
    const verificacoes = await Promise.all([
      // 1. Fichas órfãs
      db.prepare(`
        SELECT COUNT(*) as count
        FROM fichas_sessao fs
        LEFT JOIN agendamento_slots ags ON fs.agendamento_slot_id = ags.id
        WHERE ags.id IS NULL AND fs.deleted_at IS NULL
      `).first(),

      // 2. Slots com datas inconsistentes
      db.prepare(`
        SELECT COUNT(*) as count
        FROM agendamento_slots
        WHERE data_inicio >= data_fim AND status_slot != 'CANCELADO'
      `).first(),

      // 3. Status inconsistentes
      db.prepare(`
        SELECT COUNT(*) as count
        FROM fichas_sessao fs
        JOIN agendamento_slots ags ON fs.agendamento_slot_id = ags.id
        WHERE ags.status_slot = 'CANCELADO' 
        AND fs.status_workflow NOT IN ('CANCELADO', 'RASCUNHO')
      `).first(),

      // 4. Certificações pendentes
      db.prepare(`
        SELECT COUNT(*) as count
        FROM fichas_sessao
        WHERE status_workflow = 'CONCLUIDA'
        AND resultado_final = 'APROVADO'
        AND certificacao_automatica_executada = 0
        AND created_at < datetime('now', '-7 days')
      `).first(),

      // 5. Instrutores inválidos
      db.prepare(`
        SELECT COUNT(*) as count
        FROM agendamento_slots ags
        LEFT JOIN funcionarios f ON ags.colaborador_id_instrutor = f.id
        WHERE f.id IS NULL OR f.is_instrutor = 0
      `).first()
    ]);

    const [fichasOrfas, datasInconsistentes, statusInconsistentes, certPendentes, instrutoresInvalidos] = verificacoes;

    // Estatísticas gerais
    const estatisticasGerais = await db.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM agendamento_slots WHERE status_slot != 'CANCELADO') as slots_ativos,
        (SELECT COUNT(*) FROM fichas_sessao WHERE deleted_at IS NULL) as fichas_ativas,
        (SELECT COUNT(*) FROM simuladores WHERE status = 'ATIVO') as simuladores_ativos,
        (SELECT COUNT(*) FROM manobras_catalogo WHERE ativo = 1) as manobras_ativas,
        (SELECT COUNT(*) FROM sessoes_template) as sessoes_template
    `).first();

    // Últimas auditorias executadas
    const ultimasAuditorias = await db.prepare(`
      SELECT *
      FROM auditoria_limpeza_dados
      WHERE operacao LIKE '%SIMULADOR%'
      ORDER BY data_execucao DESC
      LIMIT 10
    `).all();

    const relatorioIntegridade = {
      timestamp: new Date().toISOString(),
      status_geral: 'OK',
      verificacoes: {
        fichas_orfas: fichasOrfas?.count || 0,
        datas_inconsistentes: datasInconsistentes?.count || 0,
        status_inconsistentes: statusInconsistentes?.count || 0,
        certificacoes_pendentes: certPendentes?.count || 0,
        instrutores_invalidos: instrutoresInvalidos?.count || 0
      },
      estatisticas_gerais: estatisticasGerais,
      ultimas_auditorias: ultimasAuditorias.results,
      recomendacoes: gerarRecomendacoes(verificacoes)
    };

    // Determinar status geral
    const problemasCriticos = (fichasOrfas?.count as number || 0) + (instrutoresInvalidos?.count as number || 0);
    const problemasAltos = (datasInconsistentes?.count as number || 0);
    
    if (problemasCriticos > 0) {
      relatorioIntegridade.status_geral = 'CRITICO';
    } else if (problemasAltos > 0) {
      relatorioIntegridade.status_geral = 'ATENCAO';
    } else if ((statusInconsistentes?.count as number || 0) + (certPendentes?.count as number || 0) > 0) {
      relatorioIntegridade.status_geral = 'AVISO';
    }

    return c.json({
      success: true,
      data: relatorioIntegridade
    });

  } catch (error) {
    console.error('Erro ao gerar relatório de integridade:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// POST /api/v2/audit-reports/executar-auditoria - Executar auditoria manual
auditReportsApi.post('/executar-auditoria', requirePermission('simuladores', 'UPDATE'), async (c) => {
  try {
    const { executarAuditoriaSemanal } = await import('../../cron-auditoria-semanal');
    
    // Executar auditoria semanal manualmente
    await executarAuditoriaSemanal(c.env);

    return c.json({
      success: true,
      message: 'Auditoria de integridade executada com sucesso'
    });

  } catch (error) {
    console.error('Erro ao executar auditoria manual:', error);
    return c.json({
      error: 'Erro ao executar auditoria',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// Função para gerar CSV
function gerarCSVAuditoria(_c: any, dados: any) {
  const headers = [
    'Timestamp',
    'Ação',
    'Ficha UUID',
    'Usuário',
    'IP',
    'Detalhes'
  ];

  const rows = dados.logs.map((log: any) => [
    log.timestamp_acao,
    log.acao,
    log.ficha_uuid || '',
    log.usuario_nome || log.usuario_id,
    log.ip_origem || '',
    log.detalhes_acao || ''
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map((row: any[]) => row.map(cell => `"${cell}"`).join(','))
  ].join('\n');

  return new Response(csvContent, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename="auditoria_simulador_${new Date().toISOString().split('T')[0]}.csv"`
    }
  });
}

// Função para gerar PDF (simplificado - retorna HTML que pode ser convertido)
function gerarPDFAuditoria(_c: any, dados: any) {
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Relatório de Auditoria - Simuladores</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .header { text-align: center; margin-bottom: 30px; }
        .stats { background-color: #f8f9fa; padding: 15px; margin: 20px 0; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>Relatório de Auditoria - Módulo Simuladores</h1>
        <p>Gerado em: ${new Date().toLocaleString('pt-BR')}</p>
      </div>

      <div class="stats">
        <h2>Resumo</h2>
        <p>Total de registros: ${dados.total_registros}</p>
        <p>Período: ${dados.filtros_aplicados.data_inicio || 'Não especificado'} a ${dados.filtros_aplicados.data_fim || 'Atual'}</p>
      </div>

      <h2>Logs de Auditoria</h2>
      <table>
        <thead>
          <tr>
            <th>Data/Hora</th>
            <th>Ação</th>
            <th>Ficha</th>
            <th>Usuário</th>
            <th>IP</th>
          </tr>
        </thead>
        <tbody>
          ${dados.logs.map((log: any) => `
            <tr>
              <td>${new Date(log.timestamp_acao).toLocaleString('pt-BR')}</td>
              <td>${log.acao}</td>
              <td>${log.ficha_uuid || '-'}</td>
              <td>${log.usuario_nome || log.usuario_id}</td>
              <td>${log.ip_origem || '-'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <h2>Estatísticas por Ação</h2>
      <table>
        <thead>
          <tr>
            <th>Ação</th>
            <th>Data</th>
            <th>Quantidade</th>
          </tr>
        </thead>
        <tbody>
          ${dados.estatisticas.map((stat: any) => `
            <tr>
              <td>${stat.acao}</td>
              <td>${stat.data}</td>
              <td>${stat.total}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </body>
    </html>
  `;

  return new Response(htmlContent, {
    headers: {
      'Content-Type': 'text/html',
      'Content-Disposition': `inline; filename="auditoria_simulador_${new Date().toISOString().split('T')[0]}.html"`
    }
  });
}

// Função para gerar recomendações baseadas nas verificações
function gerarRecomendacoes(verificacoes: any[]): string[] {
  const recomendacoes: string[] = [];
  
  const [fichasOrfas, datasInconsistentes, statusInconsistentes, certPendentes, instrutoresInvalidos] = verificacoes;

  if ((fichasOrfas?.count || 0) > 0) {
    recomendacoes.push(`Existem ${fichasOrfas.count} fichas órfãs que devem ser investigadas e removidas.`);
  }

  if ((datasInconsistentes?.count || 0) > 0) {
    recomendacoes.push(`${datasInconsistentes.count} slots têm datas inconsistentes e devem ser corrigidos.`);
  }

  if ((statusInconsistentes?.count || 0) > 0) {
    recomendacoes.push(`${statusInconsistentes.count} fichas têm status inconsistente com seus slots.`);
  }

  if ((certPendentes?.count || 0) > 0) {
    recomendacoes.push(`${certPendentes.count} certificações estão pendentes há mais de 7 dias.`);
  }

  if ((instrutoresInvalidos?.count || 0) > 0) {
    recomendacoes.push(`${instrutoresInvalidos.count} slots têm instrutores inválidos atribuídos.`);
  }

  if (recomendacoes.length === 0) {
    recomendacoes.push('Sistema está íntegro. Nenhuma ação corretiva necessária.');
  }

  return recomendacoes;
}

export default auditReportsApi;
