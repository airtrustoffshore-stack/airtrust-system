import { Context } from 'hono';

// GET /api/v2/simulador/ficha/{uuid} - VISUALIZAR FICHA ESPECÍFICA
export const buscarFichaPorUuid = async (c: Context) => {
  const { uuid } = c.req.param();
  
  if (!uuid) {
    return c.json({ error: 'UUID da ficha é obrigatório' }, 400);
  }
  
  try {
    console.log(`🔍 Buscando ficha com UUID: ${uuid}`);
    
    const db = c.env.DB;
    
    // Buscar ficha com todos os dados relacionados
    const ficha = await db.prepare(`
      SELECT 
        f.*,
        slot.data_inicio,
        slot.data_fim,
        sim.nome as simulador_nome,
        sim.codigo_identificacao as simulador_codigo,
        inst.nome as instrutor_nome,
        inst.matricula as instrutor_matricula,
        checador.nome as checador_nome,
        aluno.nome as aluno_nome,
        aluno.matricula as aluno_matricula,
        aluno.funcao as aluno_funcao,
        st.nome_sessao as template_nome,
        st.descricao as template_descricao,
        st.numero_sessao
      FROM fichas_sessao f
      LEFT JOIN agendamento_slots slot ON f.agendamento_slot_id = slot.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      LEFT JOIN funcionarios checador ON slot.colaborador_id_checador = checador.id
      LEFT JOIN funcionarios aluno ON f.colaborador_id_aluno = aluno.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.ficha_uuid = ?
    `).bind(uuid).first();
    
    if (!ficha) {
      console.log(`❌ Ficha não encontrada: ${uuid}`);
      return c.json({ 
        error: 'Ficha não encontrada',
        uuid: uuid 
      }, 404);
    }
    
    // Buscar manobras executadas
    const manobras = await db.prepare(`
      SELECT 
        mc.id,
        mc.manobra_id_codigo as codigo,
        mc.nome_manobra as nome,
        mc.descricao_detalhada as descricao,
        mc.categoria,
        mc.criterios_aprovacao,
        mc.pontuacao_minima,
        me.nota,
        me.observacoes,
        CASE WHEN me.id IS NOT NULL THEN 1 ELSE 0 END as executada
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      JOIN manobras_catalogo_ciclos mcc ON mc.id = mcc.manobra_catalogo_id
      LEFT JOIN fichas_manobras_executadas me ON me.ficha_id = ? AND me.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ? 
      AND mcc.ciclo_id = ?
      AND mc.ativo = 1
      ORDER BY mc.manobra_id_codigo
    `).bind(ficha.id, ficha.sessao_template_id, ficha.ciclo_executado).all();
    
    // Formatar dados para resposta
    const fichaFormatada = {
      id: ficha.id,
      uuid: ficha.ficha_uuid,
      data_sessao: formatarDataBrasil(ficha.created_at),
      hora_inicio: ficha.created_at,
      hora_fim: ficha.updated_at,
      status_workflow: ficha.status_workflow,
      conceito_final: ficha.resultado_final,
      nota_final: ficha.nota_final,
      funcao_na_sessao: ficha.funcao_na_sessao,
      ciclo_executado: ficha.ciclo_executado,
      observacoes: ficha.observacoes_instrutor,
      
      // Dados relacionados
      colaborador: {
        id: ficha.colaborador_id_aluno,
        nome: ficha.aluno_nome,
        matricula: ficha.aluno_matricula,
        funcao: ficha.aluno_funcao
      },
      instrutor: {
        nome: ficha.instrutor_nome,
        matricula: ficha.instrutor_matricula
      },
      checador: ficha.checador_nome ? {
        nome: ficha.checador_nome
      } : null,
      simulador: {
        nome: ficha.simulador_nome,
        codigo_identificacao: ficha.simulador_codigo
      },
      template: {
        nome: ficha.template_nome,
        descricao: ficha.template_descricao,
        numero_sessao: ficha.numero_sessao
      },
      
      // Manobras executadas
      manobras: manobras.results?.map((manobra: any) => ({
        id: manobra.id,
        codigo: manobra.codigo,
        nome: manobra.nome,
        descricao: manobra.descricao,
        categoria: manobra.categoria,
        criterios_aprovacao: manobra.criterios_aprovacao,
        pontuacao_minima: manobra.pontuacao_minima,
        nota: manobra.nota,
        observacoes: manobra.observacoes,
        executada: manobra.executada === 1
      })) || [],
      
      // Metadados
      created_at: formatarDataBrasil(ficha.created_at),
      updated_at: formatarDataBrasil(ficha.updated_at)
    };
    
    console.log(`✅ Ficha encontrada: ${uuid} - Status: ${ficha.status_workflow}`);
    
    return c.json({
      success: true,
      ficha: fichaFormatada
    });
    
  } catch (error: any) {
    console.error(`❌ Erro ao buscar ficha ${uuid}:`, error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error.message
    }, 500);
  }
};

// GET /api/v2/simulador/ficha/{uuid}/avaliacao - DADOS PARA AVALIAR FICHA
export const buscarFichaParaAvaliacao = async (c: Context) => {
  const { uuid } = c.req.param();
  
  if (!uuid) {
    return c.json({ error: 'UUID da ficha é obrigatório' }, 400);
  }
  
  try {
    console.log(`📝 Buscando ficha para avaliação: ${uuid}`);
    
    const db = c.env.DB;
    
    // Verificar se ficha existe e pode ser avaliada
    const ficha = await db.prepare(`
      SELECT 
        f.*,
        aluno.nome as aluno_nome,
        aluno.matricula as aluno_matricula,
        sim.nome as simulador_nome,
        st.nome_sessao as template_nome
      FROM fichas_sessao f
      LEFT JOIN funcionarios aluno ON f.colaborador_id_aluno = aluno.id
      LEFT JOIN agendamento_slots slot ON f.agendamento_slot_id = slot.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.ficha_uuid = ?
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ 
        error: 'Ficha não encontrada',
        uuid: uuid 
      }, 404);
    }
    
    // Verificar se pode ser avaliada
    const statusPermitidos = ['PENDENTE_ALUNO', 'PENDENTE_INSTRUTOR_FINAL', 'RASCUNHO'];
    if (!statusPermitidos.includes(ficha.status_workflow)) {
      return c.json({
        error: 'Esta ficha não pode ser avaliada no status atual',
        status_atual: ficha.status_workflow,
        uuid: uuid
      }, 400);
    }
    
    // Buscar manobras para avaliação
    const manobras = await db.prepare(`
      SELECT 
        mc.id,
        mc.manobra_id_codigo as codigo,
        mc.nome_manobra as nome,
        mc.categoria,
        mc.criterios_aprovacao,
        mc.pontuacao_minima,
        me.nota as nota_atual,
        me.observacoes as observacoes_atual,
        CASE WHEN me.id IS NOT NULL THEN 1 ELSE 0 END as executada
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      JOIN manobras_catalogo_ciclos mcc ON mc.id = mcc.manobra_catalogo_id
      LEFT JOIN fichas_manobras_executadas me ON me.ficha_id = ? AND me.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ? 
      AND mcc.ciclo_id = ?
      AND mc.ativo = 1
      ORDER BY mc.manobra_id_codigo
    `).bind(ficha.id, ficha.sessao_template_id, ficha.ciclo_executado).all();
    
    // Dados para avaliação
    const dadosAvaliacao = {
      ficha: {
        uuid: ficha.ficha_uuid,
        colaborador: ficha.aluno_nome,
        matricula: ficha.aluno_matricula,
        simulador: ficha.simulador_nome,
        template: ficha.template_nome,
        data_sessao: formatarDataBrasil(ficha.created_at),
        status_workflow: ficha.status_workflow,
        funcao_na_sessao: ficha.funcao_na_sessao,
        ciclo_executado: ficha.ciclo_executado
      },
      manobras: manobras.results?.map((manobra: any) => ({
        id: manobra.id,
        codigo: manobra.codigo,
        nome: manobra.nome,
        categoria: manobra.categoria,
        criterios_aprovacao: manobra.criterios_aprovacao,
        pontuacao_minima: manobra.pontuacao_minima,
        nota_atual: manobra.nota_atual,
        observacoes_atual: manobra.observacoes_atual,
        executada: manobra.executada === 1
      })) || [],
      pode_avaliar: true
    };
    
    return c.json({
      success: true,
      avaliacao: dadosAvaliacao
    });
    
  } catch (error: any) {
    console.error(`❌ Erro ao buscar ficha para avaliação ${uuid}:`, error);
    return c.json({ 
      error: 'Erro interno do servidor'
    }, 500);
  }
};

// PUT /api/v2/simulador/ficha/{uuid}/avaliar - SALVAR AVALIAÇÃO
export const salvarAvaliacaoFicha = async (c: Context) => {
  const { uuid } = c.req.param();
  
  try {
    const dadosAvaliacao = await c.req.json();
    
    console.log(`💾 Salvando avaliação da ficha: ${uuid}`);
    
    const db = c.env.DB;
    
    // Verificar se ficha existe
    const ficha = await db.prepare(`
      SELECT id, status_workflow 
      FROM fichas_sessao 
      WHERE ficha_uuid = ?
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // Atualizar manobras avaliadas
    if (dadosAvaliacao.manobras && Array.isArray(dadosAvaliacao.manobras)) {
      for (const manobra of dadosAvaliacao.manobras) {
        await db.prepare(`
          INSERT OR REPLACE INTO fichas_manobras_executadas (
            ficha_id, manobra_catalogo_id, nota, observacoes
          ) VALUES (?, ?, ?, ?)
        `).bind(
          ficha.id,
          manobra.id,
          manobra.nota === 'NR' ? null : parseFloat(manobra.nota) || null,
          manobra.observacoes || null
        ).run();
      }
    }
    
    // Calcular nota final
    const manobrasAvaliadas = await db.prepare(`
      SELECT nota 
      FROM fichas_manobras_executadas 
      WHERE ficha_id = ? AND nota IS NOT NULL
    `).bind(ficha.id).all();
    
    let notaFinal = null;
    let conceitoFinal = null;
    
    if (manobrasAvaliadas.results && manobrasAvaliadas.results.length > 0) {
      const notas = manobrasAvaliadas.results.map((m: any) => parseFloat(m.nota));
      notaFinal = notas.reduce((sum: number, nota: number) => sum + nota, 0) / notas.length;
      
      // Verificar se tem nota < 5 (regra rigorosa)
      const temNotaBaixa = notas.some((nota: number) => nota < 5);
      conceitoFinal = temNotaBaixa ? 'REPROVADO' : 'APROVADO';
    }
    
    // Atualizar ficha
    const novoStatus = dadosAvaliacao.finalizar ? 
      (conceitoFinal === 'REPROVADO' ? 'REPROVADA' : 'PENDENTE_CHECK') : 
      ficha.status_workflow;
    
    await db.prepare(`
      UPDATE fichas_sessao 
      SET resultado_final = ?, nota_final = ?, status_workflow = ?, 
          observacoes_instrutor = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      conceitoFinal,
      notaFinal,
      novoStatus,
      dadosAvaliacao.observacoes_gerais || null,
      ficha.id
    ).run();
    
    return c.json({
      success: true,
      ficha: {
        uuid: uuid,
        conceito_final: conceitoFinal,
        nota_final: notaFinal,
        status_workflow: novoStatus
      },
      message: 'Avaliação salva com sucesso'
    });
    
  } catch (error: any) {
    console.error(`❌ Erro ao salvar avaliação ${uuid}:`, error);
    return c.json({ 
      error: 'Erro interno do servidor'
    }, 500);
  }
};

// Função auxiliar para formatar data brasileira
function formatarDataBrasil(data: Date | string | null): string {
  if (!data) return '';
  
  try {
    const date = typeof data === 'string' ? new Date(data) : data;
    return date.toLocaleDateString('pt-BR');
  } catch {
    return '';
  }
}
