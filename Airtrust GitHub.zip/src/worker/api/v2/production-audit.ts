/**
 * AIRTRUST PRODUCTION AUDIT API
 * Endpoints para auditoria de limpeza de dados demo
 */

import { Hono } from 'hono';
import { auditDemoDataInDatabase } from '../../middleware/demo-data-blocker';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

/**
 * GET /audit/demo-data
 * Audita banco para detectar dados de teste/demo
 */
app.get('/demo-data', async (c) => {
  try {
    console.log('🔍 Iniciando auditoria de dados demo...');
    
    const db = c.env.DB;
    
    // Executar auditoria
    const auditResult = await auditDemoDataInDatabase(db);
    
    // Contar registros ativos
    const funcionariosAtivos = await db.prepare(`
      SELECT COUNT(*) as count FROM funcionarios 
      WHERE deleted_at IS NULL OR deleted_at = ''
    `).first();
    
    const treinamentosAtivos = await db.prepare(`
      SELECT COUNT(*) as count FROM catalogo_treinamentos_v2 
      WHERE deleted_at IS NULL OR deleted_at = ''
    `).first();
    
    const certificacoesAtivas = await db.prepare(`
      SELECT COUNT(*) as count FROM historico_certificacoes_v2 
      WHERE deleted_at IS NULL OR deleted_at = ''
    `).first();
    
    return c.json({
      timestamp: new Date().toISOString(),
      audit_status: auditResult.hasDemoData ? 'FAILED' : 'PASSED',
      demo_data_detected: auditResult.hasDemoData,
      violations: auditResult.violations,
      database_state: {
        funcionarios_ativos: funcionariosAtivos.count,
        treinamentos_ativos: treinamentosAtivos.count,
        certificacoes_ativas: certificacoesAtivas.count,
        is_blank_state: funcionariosAtivos.count === 0
      },
      production_policy: {
        policy: 'ZERO_DEMO_DATA_TOLERANCE',
        enforcement: 'ACTIVE',
        middleware_active: true
      },
      recommendations: auditResult.hasDemoData ? [
        'Remover todos os dados de teste listados em violations',
        'Executar limpeza completa do banco',
        'Verificar código fonte para seeds/mocks',
        'Re-executar esta auditoria até status PASSED'
      ] : [
        'Sistema limpo e pronto para produção',
        'Manter política de zero dados demo',
        'Importar apenas dados reais via interface'
      ]
    });
    
  } catch (error) {
    console.error('❌ Erro na auditoria de dados demo:', error);
    
    return c.json({
      error: 'AUDIT_FAILED',
      message: 'Falha na auditoria de dados demo',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

/**
 * POST /audit/cleanup-demo-data
 * Remove forçadamente todos os dados de teste (EMERGENCY ONLY)
 */
app.post('/cleanup-demo-data', async (c) => {
  try {
    console.log('🚨 CLEANUP EMERGENCIAL DE DADOS DEMO...');
    
    const db = c.env.DB;
    const removedRecords = [];
    
    // Nomes proibidos para limpeza
    const forbiddenNames = [
      'Maria Oliveira Costa',
      'Ricardo Silva Santos', 
      'João Pedro Lima',
      'Ana Paula Ferreira',
      'Carlos Eduardo Souza'
    ];
    
    const forbiddenMatriculas = [
      'C001', 'C002', 'C003', 'C004', 'C005',
      'SGV-001', 'TEST-001', 'DEMO-001'
    ];
    
    // Remover funcionários de teste
    for (const name of forbiddenNames) {
      const result = await db.prepare(`
        DELETE FROM funcionarios WHERE LOWER(nome) LIKE ?
      `).bind(`%${name.toLowerCase()}%`).run();
      
      if (result.changes > 0) {
        removedRecords.push(`Funcionários com nome "${name}": ${result.changes} registros`);
      }
    }
    
    for (const matricula of forbiddenMatriculas) {
      const result = await db.prepare(`
        DELETE FROM funcionarios WHERE UPPER(matricula) = ?
      `).bind(matricula.toUpperCase()).run();
      
      if (result.changes > 0) {
        removedRecords.push(`Funcionários com matrícula "${matricula}": ${result.changes} registros`);
      }
    }
    
    // Limpar certificações órfãs
    const orphanCleanup = await db.prepare(`
      DELETE FROM historico_certificacoes_v2 
      WHERE funcionario_id NOT IN (SELECT id FROM funcionarios WHERE deleted_at IS NULL OR deleted_at = '')
    `).run();
    
    if (orphanCleanup.changes > 0) {
      removedRecords.push(`Certificações órfãs: ${orphanCleanup.changes} registros`);
    }
    
    // Limpar compliance órfão
    const complianceCleanup = await db.prepare(`
      DELETE FROM compliance_status_v2 
      WHERE funcionario_id NOT IN (SELECT id FROM funcionarios WHERE deleted_at IS NULL OR deleted_at = '')
    `).run();
    
    if (complianceCleanup.changes > 0) {
      removedRecords.push(`Status compliance órfãos: ${complianceCleanup.changes} registros`);
    }
    
    // Log auditoria
    await db.prepare(`
      INSERT INTO auditoria_limpeza_dados (
        operacao, tabela_afetada, registros_removidos, 
        criterio_remocao, usuario_responsavel, observacoes
      ) VALUES (?, ?, ?, ?, ?, ?)
    `).bind(
      'CLEANUP_DEMO_DATA',
      'funcionarios,historico_certificacoes_v2,compliance_status_v2',
      removedRecords.length,
      'Remoção automática dados de teste/demo',
      'PRODUCTION_AUDIT_API',
      JSON.stringify(removedRecords)
    ).run();
    
    console.log('✅ Cleanup de dados demo concluído:', removedRecords);
    
    return c.json({
      operation: 'CLEANUP_DEMO_DATA',
      status: 'COMPLETED',
      records_removed: removedRecords,
      total_operations: removedRecords.length,
      timestamp: new Date().toISOString(),
      next_action: 'Execute nova auditoria para confirmar limpeza'
    });
    
  } catch (error) {
    console.error('❌ Erro no cleanup de dados demo:', error);
    
    return c.json({
      error: 'CLEANUP_FAILED',
      message: 'Falha no cleanup de dados demo',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

/**
 * GET /audit/blank-state-status
 * Verifica se sistema está em blank state (zero dados)
 */
app.get('/blank-state-status', async (c) => {
  try {
    const db = c.env.DB;
    
    const counts = await db.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL OR deleted_at = '') as funcionarios,
        (SELECT COUNT(*) FROM catalogo_treinamentos_v2 WHERE deleted_at IS NULL OR deleted_at = '') as treinamentos,
        (SELECT COUNT(*) FROM historico_certificacoes_v2 WHERE deleted_at IS NULL OR deleted_at = '') as certificacoes,
        (SELECT COUNT(*) FROM aeronaves WHERE ativo = 1) as aeronaves,
        (SELECT COUNT(*) FROM simuladores WHERE deleted_at IS NULL) as simuladores
    `).first();
    
    const isBlankState = Object.values(counts).every(count => count === 0);
    
    return c.json({
      is_blank_state: isBlankState,
      counts: counts,
      status: isBlankState ? 'CLEAN_PRODUCTION_READY' : 'HAS_DATA',
      recommendation: isBlankState 
        ? 'Sistema pronto para importação de dados reais'
        : 'Sistema contém dados - verificar se são dados reais ou de teste'
    });
    
  } catch (error) {
    console.error('❌ Erro ao verificar blank state:', error);
    
    return c.json({
      error: 'BLANK_STATE_CHECK_FAILED',
      message: 'Falha ao verificar blank state',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
