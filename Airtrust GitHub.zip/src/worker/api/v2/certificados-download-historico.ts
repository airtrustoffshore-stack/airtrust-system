import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// GET /api/v2/treinamentos/historico-certificacoes/:id/certificado - Download certificado anexado
app.get('/historico-certificacoes/:id/certificado', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const historicoId = c.req.param('id');
    console.log(`📎 [DOWNLOAD CERTIFICADO] Buscando certificado para histórico ID: ${historicoId}`);
    
    const db = c.env.DB;
    
    // 1. Buscar certificação com dados do anexo
    const certificacao = await db.prepare(`
      SELECT 
        h.id,
        h.funcionario_id,
        h.treinamento_id,
        h.certificado_url,
        h.status,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        t.nome as treinamento_nome,
        t.codigo as treinamento_codigo,
        ca.id as anexo_id,
        ca.nome_arquivo,
        ca.url_arquivo,
        ca.tipo_arquivo,
        ca.arquivo_github_url
      FROM historico_certificacoes_v2 h
      LEFT JOIN funcionarios f ON h.funcionario_id = f.id
      LEFT JOIN catalogo_treinamentos_v2 t ON h.treinamento_id = t.id
      LEFT JOIN certificado_anexos_v2 ca ON h.id = ca.historico_id
      WHERE h.id = ? AND h.deleted_at IS NULL
    `).bind(historicoId).first();
    
    if (!certificacao) {
      console.log(`❌ [DOWNLOAD CERTIFICADO] Certificação não encontrada: ${historicoId}`);
      return c.json({
        success: false,
        error: 'Certificação não encontrada'
      }, 404);
    }
    
    console.log(`📋 [DOWNLOAD CERTIFICADO] Certificação encontrada:`, {
      id: certificacao.id,
      funcionario: certificacao.funcionario_nome,
      treinamento: certificacao.treinamento_nome,
      tem_certificado_url: !!certificacao.certificado_url,
      tem_anexo: !!certificacao.anexo_id,
      nome_arquivo: certificacao.nome_arquivo
    });
    
    // 2. Determinar URL do arquivo
    let arquivoUrl = null;
    let nomeArquivo = 'certificado.pdf';
    
    // Prioridade: anexo específico > certificado_url geral
    if (certificacao.arquivo_github_url) {
      arquivoUrl = certificacao.arquivo_github_url as string;
      nomeArquivo = certificacao.nome_arquivo as string || nomeArquivo;
      console.log(`📁 [DOWNLOAD CERTIFICADO] Usando GitHub URL: ${arquivoUrl}`);
    } else if (certificacao.url_arquivo) {
      arquivoUrl = certificacao.url_arquivo as string;
      nomeArquivo = certificacao.nome_arquivo as string || nomeArquivo;
      console.log(`📁 [DOWNLOAD CERTIFICADO] Usando URL do anexo: ${arquivoUrl}`);
    } else if (certificacao.certificado_url) {
      const certUrl = certificacao.certificado_url as string;
      // ❌ BLOQUEAR URLs GENÉRICAS/DESENVOLVIMENTO
      if (certUrl.includes('Certificado - Modo Desenvolvimento') || 
          certUrl.includes('certificado-generico') ||
          certUrl.includes('dev-certificate') ||
          certUrl === 'certificado.pdf') {
        console.log(`❌ [DOWNLOAD CERTIFICADO] URL genérica detectada e bloqueada: ${certUrl}`);
        arquivoUrl = null; // Forçar erro
      } else {
        arquivoUrl = certUrl;
        console.log(`📁 [DOWNLOAD CERTIFICADO] Usando certificado_url: ${arquivoUrl}`);
      }
    }
    
    if (!arquivoUrl) {
      console.log(`❌ [DOWNLOAD CERTIFICADO] Nenhum arquivo real anexado encontrado para ID: ${historicoId}`);
      return c.json({
        success: false,
        error: 'Nenhum certificado original anexado encontrado. Por favor, anexe o arquivo PDF real da certificação.'
      }, 404);
    }
    
    // 3. Registrar auditoria
    await logAudit(c, 'DOWNLOAD', 'certificado_anexo', historicoId, undefined, {
      funcionario: certificacao.funcionario_nome,
      treinamento: certificacao.treinamento_nome,
      arquivo_url: arquivoUrl,
      nome_arquivo: nomeArquivo
    });
    
    // 4. Fazer download direto do arquivo real
    try {
      console.log(`🌐 [DOWNLOAD CERTIFICADO] Fazendo download direto: ${arquivoUrl}`);
      
      // Se for URL externa válida (GitHub, R2, etc.), fazer download direto
      if (arquivoUrl.startsWith('http://') || arquivoUrl.startsWith('https://')) {
        console.log(`📁 [DOWNLOAD CERTIFICADO] Fazendo fetch do arquivo: ${arquivoUrl}`);
        
        const fileResponse = await fetch(arquivoUrl);
        
        if (fileResponse.ok) {
          const fileBlob = await fileResponse.arrayBuffer();
          const contentType = fileResponse.headers.get('content-type') || 'application/pdf';
          
          // Gerar nome de arquivo descritivo
          const nomeDescritivo = `Certificado_${certificacao.treinamento_codigo}_${(certificacao.funcionario_nome as string)?.replace(/\s+/g, '_') || 'Funcionario'}_${certificacao.id}.pdf`;
          
          console.log(`✅ [DOWNLOAD CERTIFICADO] Arquivo baixado com sucesso: ${nomeDescritivo}`);
          
          return c.body(fileBlob, 200, {
            'Content-Type': contentType,
            'Content-Disposition': `attachment; filename="${nomeDescritivo}"`,
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0'
          });
        } else {
          console.log(`⚠️ [DOWNLOAD CERTIFICADO] Arquivo não acessível (HTTP ${fileResponse.status}): ${arquivoUrl}`);
          return c.json({
            success: false,
            error: `Arquivo não encontrado no storage (HTTP ${fileResponse.status})`
          }, 404);
        }
      }
      
      // Se for caminho local, tentar buscar via fetch
      if (arquivoUrl.startsWith('uploads/') || 
          arquivoUrl.startsWith('pasta-virtual/') || 
          arquivoUrl.startsWith('/')) {
        
        const localResponse = await fetch(arquivoUrl);
        
        if (localResponse.ok) {
          console.log(`✅ [DOWNLOAD CERTIFICADO] Arquivo local encontrado: ${arquivoUrl}`);
          
          const arrayBuffer = await localResponse.arrayBuffer();
          const contentType = localResponse.headers.get('content-type') || 'application/pdf';
          
          // Gerar nome de arquivo descritivo
          const nomeDescritivo = `Certificado_${certificacao.treinamento_codigo}_${(certificacao.funcionario_nome as string).replace(/\s+/g, '_')}_${certificacao.id}.pdf`;
          
          return c.body(arrayBuffer, 200, {
            'Content-Type': contentType,
            'Content-Disposition': `attachment; filename="${nomeDescritivo}"`,
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0'
          });
        }
      }
      
      // Fallback: retornar URL mesmo se não conseguiu verificar
      console.log(`🔄 [DOWNLOAD CERTIFICADO] Fallback - retornando URL: ${arquivoUrl}`);
      return c.json({
        success: true,
        download_url: arquivoUrl,
        filename: nomeArquivo,
        warning: 'Não foi possível verificar a acessibilidade do arquivo'
      });
      
    } catch (fetchError) {
      console.error(`💥 [DOWNLOAD CERTIFICADO] Erro ao acessar arquivo:`, fetchError);
      
      // Ainda assim tentar retornar a URL
      return c.json({
        success: true,
        download_url: arquivoUrl,
        filename: nomeArquivo,
        warning: `Erro ao verificar arquivo: ${fetchError instanceof Error ? fetchError.message : 'Erro desconhecido'}`
      });
    }
    
  } catch (error) {
    console.error('💥 [DOWNLOAD CERTIFICADO] Erro crítico:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno do servidor'
    }, 500);
  }
});

export default app;
