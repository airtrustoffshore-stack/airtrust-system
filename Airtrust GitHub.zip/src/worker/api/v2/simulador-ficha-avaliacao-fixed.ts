import { Hono } from 'hono';
import type { Env } from '../../types/index';

const fichaAvaliacaoApi = new Hono<{ Bindings: Env }>();

// GET /api/v2/simulador/ficha/:uuid - Buscar ficha específica
fichaAvaliacaoApi.get('/:uuid', async (c) => {
  const { uuid } = c.req.param();
  
  try {
    const db = c.env.DB;
    console.log(`🔍 Buscando ficha: ${uuid}`);
    
    // Buscar dados principais da ficha
    const fichaQuery = await db.prepare(`
      SELECT 
        fs.id,
        fs.ficha_uuid,
        fs.agendamento_slot_id,
        fs.colaborador_id_aluno,
        fs.funcao_na_sessao,
        fs.sessao_template_id,
        fs.ciclo_executado,
        fs.status_workflow,
        fs.resultado_final,
        fs.nota_final,
        fs.observacoes_instrutor,
        fs.observacoes_aluno,
        fs.created_at,
        fs.updated_at,
        
        -- Dados do slot/agendamento
        slot.data_inicio,
        slot.data_fim,
        slot.simulador_id,
        slot.colaborador_id_instrutor,
        slot.colaborador_id_checador,
        slot.status_slot,
        
        -- Dados do aluno
        aluno.nome as aluno_nome,
        aluno.matricula as aluno_matricula,
        aluno.funcao as aluno_funcao,
        
        -- Dados do instrutor
        instrutor.nome as instrutor_nome,
        instrutor.matricula as instrutor_matricula,
        
        -- Dados do checador
        checador.nome as checador_nome,
        checador.matricula as checador_matricula,
        
        -- Dados do simulador
        sim.nome as simulador_nome,
        sim.codigo_identificacao as simulador_codigo,
        
        -- Dados do template
        st.nome as template_nome,
        st.descricao as template_descricao,
        st.numero_sessao as template_numero
        
      FROM fichas_sessao fs
      LEFT JOIN agendamento_slots slot ON fs.agendamento_slot_id = slot.id
      LEFT JOIN funcionarios aluno ON fs.colaborador_id_aluno = aluno.id
      LEFT JOIN funcionarios instrutor ON slot.colaborador_id_instrutor = instrutor.id
      LEFT JOIN funcionarios checador ON slot.colaborador_id_checador = checador.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN sessoes_template st ON fs.sessao_template_id = st.id
      WHERE fs.ficha_uuid = ? AND fs.deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!fichaQuery) {
      return c.json({
        success: false,
        error: 'Ficha não encontrada'
      }, 404);
    }
    
    // Buscar manobras do template
    const manobrasQuery = await db.prepare(`
      SELECT 
        mc.id,
        mc.manobra_id_codigo,
        mc.nome_manobra,
        mc.descricao_detalhada,
        mc.categoria,
        mc.criterios_aprovacao,
        mc.pontuacao_minima,
        mc.ativo
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ? AND mc.ativo = 1
      ORDER BY mc.categoria, mc.manobra_id_codigo
    `).bind(fichaQuery.sessao_template_id || 1).all();
    
    // Buscar notas já existentes
    const notasQuery = await db.prepare(`
      SELECT 
        fme.manobra_catalogo_id,
        fme.nota,
        fme.observacoes
      FROM fichas_manobras_executadas fme
      WHERE fme.ficha_id = ?
    `).bind(fichaQuery.id).all();
    
    // Mapear notas por manobra
    const notasPorManobra: Record<number, any> = {};
    notasQuery.results.forEach((nota: any) => {
      notasPorManobra[nota.manobra_catalogo_id] = {
        nota: nota.nota,
        observacoes: nota.observacoes
      };
    });
    
    // Combinar manobras com notas
    const manobras = manobrasQuery.results.map((manobra: any) => {
      const notaExistente = notasPorManobra[manobra.id];
      return {
        id: manobra.id,
        manobra_id_codigo: manobra.manobra_id_codigo,
        nome_manobra: manobra.nome_manobra,
        descricao: manobra.descricao_detalhada,
        categoria: manobra.categoria,
        criterios_aprovacao: manobra.criterios_aprovacao,
        pontuacao_minima: manobra.pontuacao_minima,
        nota: notaExistente?.nota,
        observacoes_manobra: notaExistente?.observacoes,
        executada: !!notaExistente
      };
    });
    
    // Montar response
    const ficha = {
      id: fichaQuery.id,
      ficha_uuid: fichaQuery.ficha_uuid,
      status_workflow: fichaQuery.status_workflow,
      funcao_na_sessao: fichaQuery.funcao_na_sessao,
      ciclo_executado: fichaQuery.ciclo_executado,
      resultado_final: fichaQuery.resultado_final,
      nota_final: fichaQuery.nota_final,
      observacoes_instrutor: fichaQuery.observacoes_instrutor,
      observacoes_aluno: fichaQuery.observacoes_aluno,
      
      // Formatação de datas
      data_inicio: fichaQuery.data_inicio ? new Date(fichaQuery.data_inicio).toISOString() : null,
      data_fim: fichaQuery.data_fim ? new Date(fichaQuery.data_fim).toISOString() : null,
      data_sessao: fichaQuery.data_inicio ? new Date(fichaQuery.data_inicio).toLocaleDateString('pt-BR') : 'Data inválida',
      
      // Dados relacionados
      colaborador: {
        id: fichaQuery.colaborador_id_aluno,
        nome: fichaQuery.aluno_nome || 'Aluno não encontrado',
        matricula: fichaQuery.aluno_matricula || 'N/A',
        funcao: fichaQuery.aluno_funcao || 'N/A'
      },
      
      instrutor: {
        id: fichaQuery.colaborador_id_instrutor,
        nome: fichaQuery.instrutor_nome || 'Instrutor não encontrado',
        matricula: fichaQuery.instrutor_matricula || 'N/A'
      },
      
      checador: fichaQuery.colaborador_id_checador ? {
        id: fichaQuery.colaborador_id_checador,
        nome: fichaQuery.checador_nome || 'Checador não encontrado',
        matricula: fichaQuery.checador_matricula || 'N/A'
      } : null,
      
      simulador: {
        id: fichaQuery.simulador_id,
        nome: fichaQuery.simulador_nome || 'Simulador não encontrado',
        codigo_identificacao: fichaQuery.simulador_codigo || 'N/A'
      },
      
      template: {
        id: fichaQuery.sessao_template_id,
        nome: fichaQuery.template_nome || 'Template não encontrado',
        descricao: fichaQuery.template_descricao,
        numero_sessao: fichaQuery.template_numero || 1
      },
      
      manobras: manobras
    };
    
    console.log(`✅ Ficha ${uuid} encontrada com ${manobras.length} manobras`);
    
    return c.json({
      success: true,
      ficha: ficha
    });
    
  } catch (error) {
    console.error(`❌ Erro ao buscar ficha ${uuid}:`, error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor',
      details: (error as Error).message
    }, 500);
  }
});

// PATCH /api/v2/simulador/ficha/:uuid/notas - Salvar/atualizar notas das manobras
fichaAvaliacaoApi.patch('/:uuid/notas', async (c) => {
  const { uuid } = c.req.param();
  const { manobras, observacoes_instrutor } = await c.req.json();
  
  try {
    const db = c.env.DB;
    console.log(`📝 Salvando notas para ficha: ${uuid}`);
    
    // Verificar se ficha existe
    const ficha = await db.prepare(`
      SELECT id, status_workflow FROM fichas_sessao 
      WHERE ficha_uuid = ? AND deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({
        success: false,
        error: 'Ficha não encontrada'
      }, 404);
    }
    
    // Verificar se pode editar
    const statusEditaveis = ['RASCUNHO', 'PENDENTE_ALUNO'];
    if (!statusEditaveis.includes(ficha.status_workflow)) {
      return c.json({
        success: false,
        error: `Ficha não pode ser editada no status: ${ficha.status_workflow}`
      }, 400);
    }
    
    // Atualizar ou inserir notas das manobras
    for (const manobra of manobras) {
      if (!manobra.manobra_id || manobra.nota === undefined) {
        continue; // Pular manobras inválidas
      }
      
      // Verificar se já existe nota para esta manobra
      const notaExistente = await db.prepare(`
        SELECT id FROM fichas_manobras_executadas 
        WHERE ficha_id = ? AND manobra_catalogo_id = ?
      `).bind(ficha.id, manobra.manobra_id).first();
      
      if (notaExistente) {
        // Atualizar nota existente
        await db.prepare(`
          UPDATE fichas_manobras_executadas 
          SET nota = ?, observacoes = ?
          WHERE id = ?
        `).bind(
          manobra.nota,
          manobra.observacoes || null,
          notaExistente.id
        ).run();
      } else {
        // Inserir nova nota
        await db.prepare(`
          INSERT INTO fichas_manobras_executadas (
            ficha_id, manobra_catalogo_id, nota, observacoes
          ) VALUES (?, ?, ?, ?)
        `).bind(
          ficha.id,
          manobra.manobra_id,
          manobra.nota,
          manobra.observacoes || null
        ).run();
      }
    }
    
    // Calcular resultado final
    const todasNotasQuery = await db.prepare(`
      SELECT nota FROM fichas_manobras_executadas 
      WHERE ficha_id = ? AND nota NOT IN ('NR', '')
    `).bind(ficha.id).all();
    
    let resultadoFinal = null;
    let notaFinal = null;
    
    if (todasNotasQuery.results.length > 0) {
      const notas = todasNotasQuery.results
        .map((r: any) => Number(r.nota))
        .filter((n: number) => !isNaN(n));
        
      if (notas.length > 0) {
        // Aplicar regra: qualquer nota < 5 = REPROVADO
        const temNotaBaixa = notas.some((nota: number) => nota < 5);
        resultadoFinal = temNotaBaixa ? 'REPROVADO' : 'APROVADO';
        notaFinal = notas.reduce((sum: number, nota: number) => sum + nota, 0) / notas.length;
      }
    }
    
    // Atualizar ficha com resultado e observações
    await db.prepare(`
      UPDATE fichas_sessao 
      SET resultado_final = ?,
          nota_final = ?,
          observacoes_instrutor = ?,
          status_workflow = CASE 
            WHEN ? IS NOT NULL THEN 'PENDENTE_INSTRUTOR_FINAL'
            ELSE status_workflow 
          END,
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(
      resultadoFinal,
      notaFinal,
      observacoes_instrutor || null,
      resultadoFinal,
      ficha.id
    ).run();
    
    console.log(`✅ Notas salvas para ficha ${uuid}: ${resultadoFinal || 'Em andamento'}`);
    
    return c.json({
      success: true,
      message: 'Notas salvas com sucesso',
      resultado_final: resultadoFinal,
      nota_final: notaFinal
    });
    
  } catch (error) {
    console.error(`❌ Erro ao salvar notas da ficha ${uuid}:`, error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor',
      details: (error as Error).message
    }, 500);
  }
});

// PUT /api/v2/simulador/ficha/:uuid/status - Alterar status da ficha
fichaAvaliacaoApi.put('/:uuid/status', async (c) => {
  const { uuid } = c.req.param();
  const { status } = await c.req.json();
  
  try {
    const db = c.env.DB;
    
    const validStatuses = [
      'RASCUNHO', 'PENDENTE_ALUNO', 'PENDENTE_INSTRUTOR_FINAL', 
      'PENDENTE_CHECK', 'CONCLUIDA', 'REPROVADA'
    ];
    
    if (!validStatuses.includes(status)) {
      return c.json({
        success: false,
        error: 'Status inválido'
      }, 400);
    }
    
    const resultado = await db.prepare(`
      UPDATE fichas_sessao 
      SET status_workflow = ?, updated_at = datetime('now')
      WHERE ficha_uuid = ? AND deleted_at IS NULL
    `).bind(status, uuid).run();
    
    if (resultado.changes === 0) {
      return c.json({
        success: false,
        error: 'Ficha não encontrada'
      }, 404);
    }
    
    return c.json({
      success: true,
      message: `Status da ficha alterado para ${status}`,
      novo_status: status
    });
    
  } catch (error) {
    console.error(`❌ Erro ao alterar status da ficha ${uuid}:`, error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor',
      details: (error as Error).message
    }, 500);
  }
});

export default fichaAvaliacaoApi;
