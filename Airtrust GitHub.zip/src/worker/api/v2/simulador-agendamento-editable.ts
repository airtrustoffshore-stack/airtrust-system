import { Hono } from 'hono';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const editableAgendamentoApi = new Hono<{ Bindings: Env }>();

// Apply auth middleware
editableAgendamentoApi.use('*', authMiddleware);

// Schema para edição de slot
const EditSlotSchema = z.object({
  simulador_id: z.number().optional(),
  instrutor_id: z.number().optional(),
  checador_id: z.number().optional(),
  data_inicio: z.string().optional(),
  data_fim: z.string().optional(),
  status_slot: z.enum(['AGENDADO', 'EM_ANDAMENTO', 'CONCLUIDO', 'CANCELADO']).optional()
});

// PUT /api/v2/simulador/agendamento/:id - Editar slot de agendamento
editableAgendamentoApi.put('/:id', requirePermission('simuladores', 'UPDATE'), async (c) => {
  try {
    const slotId = parseInt(c.req.param('id'));
    const body = await c.req.json();
    const updateData = EditSlotSchema.parse(body);

    const db = c.env.DB;

    // 1. Verificar se o slot existe e buscar dados atuais
    const existingSlot = await db.prepare(`
      SELECT * FROM agendamento_slots WHERE id = ?
    `).bind(slotId).first();

    if (!existingSlot) {
      return c.json({ error: 'Slot de agendamento não encontrado' }, 404);
    }

    // 2. Verificar se o slot pode ser editado (não pode estar CONCLUIDO)
    if (existingSlot.status_slot === 'CONCLUIDO') {
      return c.json({ error: 'Não é possível editar sessões já concluídas' }, 400);
    }

    // 3. Validações de conflito se mudou data/simulador
    if (updateData.data_inicio || updateData.data_fim || updateData.simulador_id) {
      const novoSimuladorId = updateData.simulador_id || existingSlot.simulador_id;
      const novaDataInicio = updateData.data_inicio || existingSlot.data_inicio;
      const novaDataFim = updateData.data_fim || existingSlot.data_fim;

      const conflito = await db.prepare(`
        SELECT id FROM agendamento_slots 
        WHERE simulador_id = ? 
        AND id != ?
        AND status_slot != 'CANCELADO'
        AND (
          (data_inicio <= ? AND data_fim > ?) OR
          (data_inicio < ? AND data_fim >= ?) OR
          (data_inicio >= ? AND data_fim <= ?)
        )
      `).bind(
        novoSimuladorId,
        slotId,
        novaDataInicio, novaDataInicio,
        novaDataFim, novaDataFim,
        novaDataInicio, novaDataFim
      ).first();

      if (conflito) {
        return c.json({ error: 'Conflito de horário detectado com outro agendamento' }, 409);
      }
    }

    // 4. Validar se instrutor/checador existem
    if (updateData.instrutor_id) {
      const instrutor = await db.prepare(
        'SELECT id FROM funcionarios WHERE id = ? AND is_instrutor = 1'
      ).bind(updateData.instrutor_id).first();

      if (!instrutor) {
        return c.json({ error: 'Instrutor não encontrado ou inválido' }, 404);
      }
    }

    if (updateData.checador_id) {
      const checador = await db.prepare(
        'SELECT id FROM funcionarios WHERE id = ? AND is_checador = 1'
      ).bind(updateData.checador_id).first();

      if (!checador) {
        return c.json({ error: 'Checador não encontrado ou inválido' }, 404);
      }
    }

    // 5. Preparar campos para update
    const updateFields: string[] = [];
    const params: any[] = [];

    Object.entries(updateData).forEach(([key, value]) => {
      if (value !== undefined) {
        if (key === 'instrutor_id') {
          updateFields.push('colaborador_id_instrutor = ?');
        } else if (key === 'checador_id') {
          updateFields.push('colaborador_id_checador = ?');
        } else {
          updateFields.push(`${key} = ?`);
        }
        params.push(value);
      }
    });

    updateFields.push('updated_at = CURRENT_TIMESTAMP');
    updateFields.push('updated_by = ?');
    params.push('sistema'); // TODO: Get from auth context
    params.push(slotId);

    // 6. Executar update do slot
    const updateResult = await db.prepare(`
      UPDATE agendamento_slots 
      SET ${updateFields.join(', ')}
      WHERE id = ?
    `).bind(...params).run();

    if (!updateResult.success) {
      return c.json({ error: 'Erro ao atualizar slot' }, 400);
    }

    // 7. Sincronizar fichas associadas se necessário
    if (updateData.data_inicio || updateData.data_fim || updateData.status_slot === 'CANCELADO') {
      const fichas = await db.prepare(`
        SELECT id, ficha_uuid FROM fichas_sessao WHERE agendamento_slot_id = ?
      `).bind(slotId).all();

      for (const ficha of fichas.results) {
        if (updateData.status_slot === 'CANCELADO') {
          // Marcar todas as fichas como canceladas
          await db.prepare(`
            UPDATE fichas_sessao 
            SET status_workflow = 'CANCELADO', updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `).bind(ficha.id).run();
        }

        // Registrar auditoria para cada ficha afetada
        await db.prepare(`
          INSERT INTO auditoria_simulador (
            ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem
          ) VALUES (?, ?, ?, ?, ?)
        `).bind(
          ficha.ficha_uuid,
          999, // TODO: Get from auth context
          'SLOT_EDITADO',
          JSON.stringify({ 
            slot_id: slotId,
            alteracoes: updateData,
            dados_anteriores: existingSlot
          }),
          c.req.header('CF-Connecting-IP') || 'unknown'
        ).run();
      }
    }

    // 8. Registrar auditoria da operação
    await logAudit(
      c,
      'UPDATE',
      'agendamento_slots',
      slotId.toString(),
      existingSlot,
      updateData
    );

    return c.json({
      success: true,
      message: 'Slot atualizado com sucesso',
      fichas_afetadas: updateData.status_slot === 'CANCELADO' ? (await db.prepare(
        'SELECT COUNT(*) as count FROM fichas_sessao WHERE agendamento_slot_id = ?'
      ).bind(slotId).first())?.count || 0 : 0
    });

  } catch (error) {
    console.error('Erro ao editar slot:', error);
    await logAudit(c, 'UPDATE', 'agendamento_slots', c.req.param('id'), undefined, undefined, 'ERROR');
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// DELETE /api/v2/simulador/agendamento/:id - Excluir slot (soft delete por padrão)
editableAgendamentoApi.delete('/:id', requirePermission('simuladores', 'DELETE'), async (c) => {
  try {
    const slotId = parseInt(c.req.param('id'));
    const forceDelete = c.req.query('force') === 'true';

    const db = c.env.DB;

    // 1. Verificar se o slot existe
    const existingSlot = await db.prepare(`
      SELECT * FROM agendamento_slots WHERE id = ?
    `).bind(slotId).first();

    if (!existingSlot) {
      return c.json({ error: 'Slot de agendamento não encontrado' }, 404);
    }

    // 2. Verificar se pode ser excluído
    if (existingSlot.status_slot === 'EM_ANDAMENTO') {
      return c.json({ error: 'Não é possível excluir sessões em andamento' }, 400);
    }

    if (existingSlot.status_slot === 'CONCLUIDO') {
      return c.json({ error: 'Não é possível excluir sessões já concluídas' }, 400);
    }

    // 3. Buscar fichas associadas
    const fichas = await db.prepare(`
      SELECT id, ficha_uuid FROM fichas_sessao WHERE agendamento_slot_id = ?
    `).bind(slotId).all();

    if (forceDelete) {
      // 4a. Hard delete - remover tudo
      
      // Primeiro, remover fichas e suas manobras
      for (const ficha of fichas.results) {
        await db.prepare('DELETE FROM fichas_manobras_executadas WHERE ficha_id = ?')
          .bind(ficha.id).run();
        await db.prepare('DELETE FROM fichas_sessao WHERE id = ?')
          .bind(ficha.id).run();
      }

      // Remover o slot
      await db.prepare('DELETE FROM agendamento_slots WHERE id = ?')
        .bind(slotId).run();

      await logAudit(c, 'HARD_DELETE', 'agendamento_slots', slotId.toString(), existingSlot);

      return c.json({
        success: true,
        message: 'Slot e todas as fichas associadas foram permanentemente excluídos',
        fichas_removidas: fichas.results.length
      });

    } else {
      // 4b. Soft delete - marcar como cancelado
      
      await db.prepare(`
        UPDATE agendamento_slots 
        SET status_slot = 'CANCELADO', updated_at = CURRENT_TIMESTAMP, updated_by = ?
        WHERE id = ?
      `).bind('sistema', slotId).run();

      // Marcar fichas como canceladas
      for (const ficha of fichas.results) {
        await db.prepare(`
          UPDATE fichas_sessao 
          SET status_workflow = 'CANCELADO', updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `).bind(ficha.id).run();

        // Auditoria para cada ficha
        await db.prepare(`
          INSERT INTO auditoria_simulador (
            ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem
          ) VALUES (?, ?, ?, ?, ?)
        `).bind(
          ficha.ficha_uuid,
          999, // TODO: Get from auth context
          'SLOT_CANCELADO',
          JSON.stringify({ slot_id: slotId, motivo: 'Slot excluído' }),
          c.req.header('CF-Connecting-IP') || 'unknown'
        ).run();
      }

      await logAudit(c, 'SOFT_DELETE', 'agendamento_slots', slotId.toString(), existingSlot);

      return c.json({
        success: true,
        message: 'Slot cancelado com sucesso',
        fichas_canceladas: fichas.results.length
      });
    }

  } catch (error) {
    console.error('Erro ao excluir slot:', error);
    await logAudit(c, 'DELETE', 'agendamento_slots', c.req.param('id'), undefined, undefined, 'ERROR');
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/simulador/agendamento/:id - Obter detalhes de um slot específico
editableAgendamentoApi.get('/:id', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const slotId = parseInt(c.req.param('id'));
    const db = c.env.DB;

    const slot = await db.prepare(`
      SELECT 
        s.*,
        sim.nome as simulador_nome,
        inst.nome as instrutor_nome,
        check.nome as checador_nome
      FROM agendamento_slots s
      LEFT JOIN simuladores sim ON s.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON s.colaborador_id_instrutor = inst.id
      LEFT JOIN funcionarios check ON s.colaborador_id_checador = check.id
      WHERE s.id = ?
    `).bind(slotId).first();

    if (!slot) {
      return c.json({ error: 'Slot não encontrado' }, 404);
    }

    // Buscar fichas associadas
    const fichas = await db.prepare(`
      SELECT 
        f.*,
        aluno.nome as aluno_nome,
        aluno.matricula as aluno_matricula,
        st.nome_sessao as template_nome
      FROM fichas_sessao f
      LEFT JOIN funcionarios aluno ON f.colaborador_id_aluno = aluno.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.agendamento_slot_id = ?
    `).bind(slotId).all();

    slot.fichas = fichas.results;

    return c.json({
      success: true,
      data: slot
    });

  } catch (error) {
    console.error('Erro ao buscar slot:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default editableAgendamentoApi;
