import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ===== FUNÇÃO PARA GERAR HASH DO DOCUMENTO =====
function gerarHashDocumento(dados: any): string {
  // Criar um hash baseado nos dados principais do documento
  const conteudo = JSON.stringify({
    ficha_uuid: dados.ficha_uuid,
    colaborador_id: dados.colaborador_id_aluno,
    manobras: dados.manobras_executadas?.map((m: any) => ({ 
      manobra_id: m.manobra_catalogo_id, 
      nota: m.nota 
    })),
    conceito: dados.resultado_final,
    timestamp: dados.updated_at
  }, null, 0);
  
  // Simular um hash SHA-256 simples (em produção usar crypto real)
  let hash = 0;
  for (let i = 0; i < conteudo.length; i++) {
    const char = conteudo.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Converter para 32bit
  }
  return Math.abs(hash).toString(16).padStart(16, '0');
}

// ===== FUNÇÃO AUXILIAR PARA BUSCAR NOTA ANTERIOR =====
async function buscarNotaAnterior(
  db: D1Database, 
  funcionarioId: number, 
  manobraId: number, 
  dataSessaoAtual: string
): Promise<{ nota: string; data_avaliacao: string } | null> {
  try {
    const stmt = db.prepare(`
      SELECT CASE 
               WHEN fme.nota = 0 THEN 'NR'
               ELSE CAST(fme.nota AS TEXT)
             END as nota, 
             COALESCE(fme.data_avaliacao, fs.created_at) as data_avaliacao
      FROM fichas_manobras_executadas fme
      JOIN fichas_sessao fs ON fme.ficha_id = fs.id
      WHERE fs.colaborador_id_aluno = ? 
        AND fme.manobra_catalogo_id = ?
        AND fs.created_at < ?
        AND fs.deleted_at IS NULL
      ORDER BY fs.created_at DESC
      LIMIT 1
    `);
    
    const result = await stmt.bind(funcionarioId, manobraId, dataSessaoAtual).first();
    return result ? {
      nota: result.nota as string,
      data_avaliacao: result.data_avaliacao as string
    } : null;
  } catch (error) {
    console.error('Erro ao buscar nota anterior:', error);
    return null;
  }
}

// GET /api/v2/simulador/ficha/:uuid/pdf - Gerar PDF da ficha oficial
app.get('/ficha/:uuid/pdf', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const { uuid } = c.req.param();
    const db = c.env.DB;
    
    // 1. Buscar dados completos da ficha
    const fichaStmt = db.prepare(`
      SELECT fs.id, fs.ficha_uuid, fs.colaborador_id_aluno, fs.ciclo_executado,
             fs.status_workflow, fs.resultado_final, fs.nota_final, 
             fs.created_at, fs.updated_at, fs.sessao_template_id,
             f.nome as colaborador_nome, f.matricula as colaborador_matricula,
             st.nome_sessao, st.treinamento_codigo,
             s.nome as simulador_nome, s.codigo_identificacao as simulador_codigo,
             fi.nome as instrutor_nome, fc.nome as checador_nome,
             aslt.data_inicio, aslt.data_fim
      FROM fichas_sessao fs
      JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      JOIN sessoes_template st ON fs.sessao_template_id = st.id
      JOIN agendamento_slots aslt ON fs.agendamento_slot_id = aslt.id
      JOIN simuladores s ON aslt.simulador_id = s.id
      JOIN funcionarios fi ON aslt.colaborador_id_instrutor = fi.id
      LEFT JOIN funcionarios fc ON aslt.colaborador_id_checador = fc.id
      WHERE fs.ficha_uuid = ? AND fs.deleted_at IS NULL
    `);
    
    const dadosCompletos = await fichaStmt.bind(uuid).first();
    
    if (!dadosCompletos) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // 2. Buscar manobras executadas
    const manobrasStmt = db.prepare(`
      SELECT CASE 
               WHEN fme.nota = 0 THEN 'NR'
               ELSE CAST(fme.nota AS TEXT)
             END as nota, 
             fme.observacoes, 
             COALESCE(fme.data_avaliacao, fme.created_at) as created_at,
             mc.id as manobra_id, mc.manobra_id_codigo, mc.nome_manobra, mc.categoria
      FROM fichas_manobras_executadas fme
      JOIN manobras_catalogo mc ON fme.manobra_catalogo_id = mc.id
      WHERE fme.ficha_id = ?
      ORDER BY mc.categoria, mc.nome_manobra
    `);
    
    const manobrasExecutadas = await manobrasStmt.bind(dadosCompletos.id).all();
    
    // 3. Para cada manobra, buscar nota anterior - Conforme especificação do prompt
    const manobrasPDF = await Promise.all(
      manobrasExecutadas.results.map(async (execucao: any) => {
        const notaAnterior = await buscarNotaAnterior(
          db,
          dadosCompletos.colaborador_id_aluno as number,
          execucao.manobra_id as number,
          dadosCompletos.created_at as string
        );
        
        return {
          codigo: execucao.manobra_id_codigo,
          descricao: execucao.nome_manobra,
          categoria: execucao.categoria,
          nota_anterior: notaAnterior?.nota || '—',
          data_anterior: notaAnterior?.data_avaliacao || null,
          nota_atual: execucao.nota,
          observacoes: execucao.observacoes
        };
      })
    );
    
    // 4. Gerar hash e assinaturas
    const hashDocumento = gerarHashDocumento(dadosCompletos);
    const assinaturas = [{
      tipo_assinatura: 'INSTRUTOR',
      nome_completo: dadosCompletos.instrutor_nome,
      timestamp: new Date(dadosCompletos.updated_at as string),
      ip_origem: 'sistema',
      hash_auditoria: hashDocumento
    }];
    
    // 5. Gerar HTML do documento
    const htmlTemplate = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Ficha Oficial de Avaliação - ${dadosCompletos.ficha_uuid}</title>
        <style>
          body { 
            font-family: 'Arial', sans-serif; 
            margin: 15mm; 
            font-size: 12px;
            line-height: 1.4;
            color: #333;
          }
          .header { 
            text-align: center; 
            margin-bottom: 25px; 
            border-bottom: 3px solid #2563eb;
            padding-bottom: 15px;
          }
          .header h1 {
            color: #1e40af;
            margin: 0 0 5px 0;
            font-size: 20px;
            font-weight: bold;
          }
          .header h2 {
            color: #3b82f6;
            margin: 0;
            font-size: 14px;
            font-weight: normal;
          }
          .dados-basicos { 
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px; 
            background-color: #f8fafc;
            padding: 15px;
            border-radius: 8px;
          }
          .dados-basicos .campo {
            margin-bottom: 8px;
          }
          .dados-basicos .label {
            font-weight: bold;
            color: #475569;
          }
          .dados-basicos .valor {
            color: #1e293b;
          }
          .tabela-manobras { 
            width: 100%; 
            border-collapse: collapse; 
            margin: 20px 0; 
            font-size: 11px;
          }
          .tabela-manobras th, .tabela-manobras td { 
            border: 1px solid #d1d5db; 
            padding: 8px; 
            text-align: center; 
            vertical-align: middle;
          }
          .tabela-manobras th { 
            background-color: #1e40af; 
            color: white;
            font-weight: bold; 
            text-transform: uppercase;
            font-size: 10px;
          }
          .tabela-manobras td.descricao {
            text-align: left;
            max-width: 200px;
          }
          .tabela-manobras .nota-anterior {
            background-color: #fef3c7;
            color: #92400e;
            font-weight: bold;
          }
          .tabela-manobras .nota-atual {
            background-color: #dbeafe;
            color: #1e40af;
            font-weight: bold;
            font-size: 14px;
          }
          .conceito { 
            font-size: 18px; 
            font-weight: bold; 
            text-align: center; 
            margin: 25px 0; 
            padding: 15px; 
            border-radius: 8px;
          }
          .aprovado { 
            color: #059669; 
            background-color: #d1fae5; 
            border: 2px solid #10b981;
          }
          .reprovado { 
            color: #dc2626; 
            background-color: #fee2e2; 
            border: 2px solid #ef4444;
          }
          .assinatura-digital { 
            border: 2px solid #1e40af; 
            padding: 15px; 
            margin: 20px 0;
            background-color: #f8fafc; 
            border-radius: 8px;
          }
          .assinatura-digital h4 {
            margin-top: 0;
            color: #1e40af;
            font-size: 14px;
          }
          .assinatura-digital p {
            margin: 5px 0;
            font-size: 11px;
          }
          .rodape { 
            margin-top: 30px; 
            font-size: 9px; 
            text-align: center; 
            border-top: 1px solid #d1d5db; 
            padding-top: 15px;
            color: #6b7280;
          }
          .categoria {
            background-color: #e0e7ff;
            color: #3730a3;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 9px;
            font-weight: bold;
          }
          .observacoes {
            font-style: italic;
            color: #4b5563;
            font-size: 10px;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>FICHA OFICIAL DE AVALIAÇÃO DE SIMULADOR</h1>
          <h2>Sistema AirTrust - Documento com Validade Legal ANAC</h2>
        </div>
        
        <div class="dados-basicos">
          <div>
            <div class="campo">
              <span class="label">Tripulante:</span> 
              <span class="valor">${dadosCompletos.colaborador_nome}</span>
            </div>
            <div class="campo">
              <span class="label">Matrícula:</span> 
              <span class="valor">${dadosCompletos.colaborador_matricula}</span>
            </div>
            <div class="campo">
              <span class="label">Sessão:</span> 
              <span class="valor">${dadosCompletos.nome_sessao}</span>
            </div>
            <div class="campo">
              <span class="label">Treinamento:</span> 
              <span class="valor">${dadosCompletos.treinamento_codigo}</span>
            </div>
          </div>
          <div>
            <div class="campo">
              <span class="label">Data:</span> 
              <span class="valor">${new Date(dadosCompletos.data_inicio as string).toLocaleDateString('pt-BR')}</span>
            </div>
            <div class="campo">
              <span class="label">Simulador:</span> 
              <span class="valor">${dadosCompletos.simulador_nome} (${dadosCompletos.simulador_codigo})</span>
            </div>
            <div class="campo">
              <span class="label">Instrutor:</span> 
              <span class="valor">${dadosCompletos.instrutor_nome}</span>
            </div>
            <div class="campo">
              <span class="label">Ciclo Executado:</span> 
              <span class="valor">${dadosCompletos.ciclo_executado}</span>
            </div>
          </div>
        </div>
        
        <table class="tabela-manobras">
          <thead>
            <tr>
              <th>Código</th>
              <th>Descrição da Manobra</th>
              <th>Categoria</th>
              <th>Nota Anterior</th>
              <th>Nota Atual</th>
              <th>Observações</th>
            </tr>
          </thead>
          <tbody>
            ${manobrasPDF.map(manobra => `
              <tr>
                <td><strong>${manobra.codigo}</strong></td>
                <td class="descricao">${manobra.descricao}</td>
                <td><span class="categoria">${manobra.categoria}</span></td>
                <td class="nota-anterior">${manobra.nota_anterior}</td>
                <td class="nota-atual"><strong>${manobra.nota_atual}</strong></td>
                <td class="observacoes">${manobra.observacoes || '—'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div class="conceito ${(dadosCompletos.resultado_final as string).toLowerCase()}">
          CONCEITO FINAL: ${dadosCompletos.resultado_final}
          ${dadosCompletos.nota_final ? `| NOTA FINAL: ${dadosCompletos.nota_final}` : ''}
        </div>
        
        ${assinaturas.map(assinatura => `
          <div class="assinatura-digital">
            <h4>🔐 ASSINATURA DIGITAL ${assinatura.tipo_assinatura}</h4>
            <p><strong>Assinado por:</strong> ${assinatura.nome_completo}</p>
            <p><strong>Data/Hora:</strong> ${assinatura.timestamp.toLocaleString('pt-BR')}</p>
            <p><strong>IP:</strong> ${assinatura.ip_origem}</p>
            <p><strong>UUID da Ficha:</strong> ${uuid}</p>
            <p><strong>Hash de Integridade:</strong> ${assinatura.hash_auditoria}</p>
            <p><em>Assinatura digital oficial, auditada e rastreável - ANAC RBAC-61/IS 61-004</em></p>
          </div>
        `).join('')}
        
        <div class="rodape">
          <p><strong>Documento Nº ${(dadosCompletos.id as number).toString().padStart(8, '0')}</strong> | 
             Hash de Integridade: <strong>${hashDocumento}</strong> | 
             Gerado em: <strong>${new Date().toLocaleString('pt-BR')}</strong></p>
          <p>Sistema AirTrust v2.0 - Gestão de Segurança e Operações Aeronáuticas</p>
          <p>Este documento possui validade legal e pode ser verificado através do hash de integridade</p>
        </div>
      </body>
      </html>
    `;
    
    await logAudit(c, 'GENERATE_PDF', 'ficha_simulador', uuid);
    
    // 6. Retornar HTML para conversão em PDF no frontend ou serviço externo
    return c.html(htmlTemplate);
    
  } catch (error) {
    console.error('Erro ao gerar PDF da ficha:', error);
    await logAudit(c, 'GENERATE_PDF', 'ficha_simulador', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// GET /api/v2/simulador/ficha/:uuid/pdf-data - Obter dados estruturados para PDF
app.get('/ficha/:uuid/pdf-data', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const { uuid } = c.req.param();
    const db = c.env.DB;
    
    // Buscar todos os dados necessários para o PDF de forma estruturada
    const fichaStmt = db.prepare(`
      SELECT fs.id, fs.ficha_uuid, fs.colaborador_id_aluno, fs.ciclo_executado,
             fs.status_workflow, fs.resultado_final, fs.nota_final, 
             fs.created_at, fs.updated_at, fs.sessao_template_id,
             f.nome as colaborador_nome, f.matricula as colaborador_matricula,
             st.nome_sessao, st.treinamento_codigo,
             s.nome as simulador_nome, s.codigo_identificacao as simulador_codigo,
             fi.nome as instrutor_nome, fc.nome as checador_nome,
             aslt.data_inicio, aslt.data_fim
      FROM fichas_sessao fs
      JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      JOIN sessoes_template st ON fs.sessao_template_id = st.id
      JOIN agendamento_slots aslt ON fs.agendamento_slot_id = aslt.id
      JOIN simuladores s ON aslt.simulador_id = s.id
      JOIN funcionarios fi ON aslt.colaborador_id_instrutor = fi.id
      LEFT JOIN funcionarios fc ON aslt.colaborador_id_checador = fc.id
      WHERE fs.ficha_uuid = ? AND fs.deleted_at IS NULL
    `);
    
    const dadosCompletos = await fichaStmt.bind(uuid).first();
    
    if (!dadosCompletos) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // Buscar manobras com histórico
    const manobrasStmt = db.prepare(`
      SELECT fme.nota, fme.observacoes, fme.created_at,
             mc.id as manobra_id, mc.manobra_id_codigo, mc.nome_manobra, mc.categoria
      FROM fichas_manobras_executadas fme
      JOIN manobras_catalogo mc ON fme.manobra_catalogo_id = mc.id
      WHERE fme.ficha_id = ?
      ORDER BY mc.categoria, mc.nome_manobra
    `);
    
    const manobrasExecutadas = await manobrasStmt.bind(dadosCompletos.id).all();
    
    // Buscar histórico para cada manobra
    const manobrasPDF = await Promise.all(
      manobrasExecutadas.results.map(async (execucao: any) => {
        const notaAnterior = await buscarNotaAnterior(
          db,
          dadosCompletos.colaborador_id_aluno as number,
          execucao.manobra_id,
          dadosCompletos.created_at as string
        );
        
        return {
          codigo: execucao.manobra_id_codigo,
          descricao: execucao.nome_manobra,
          categoria: execucao.categoria,
          nota_anterior: notaAnterior?.nota || null,
          data_anterior: notaAnterior?.data_avaliacao || null,
          nota_atual: execucao.nota,
          observacoes: execucao.observacoes
        };
      })
    );
    
    const hashDocumento = gerarHashDocumento(dadosCompletos);
    
    return c.json({
      success: true,
      data: {
        ficha: {
          uuid: dadosCompletos.ficha_uuid,
          numero_documento: (dadosCompletos.id as number).toString().padStart(8, '0'),
          hash_integridade: hashDocumento
        },
        colaborador: {
          nome: dadosCompletos.colaborador_nome,
          matricula: dadosCompletos.colaborador_matricula
        },
        sessao: {
          nome: dadosCompletos.nome_sessao,
          treinamento_codigo: dadosCompletos.treinamento_codigo,
          ciclo: dadosCompletos.ciclo_executado,
          data: dadosCompletos.data_inicio,
          simulador: `${dadosCompletos.simulador_nome} (${dadosCompletos.simulador_codigo})`,
          instrutor: dadosCompletos.instrutor_nome,
          checador: dadosCompletos.checador_nome
        },
        avaliacao: {
          conceito_final: dadosCompletos.resultado_final,
          nota_final: dadosCompletos.nota_final,
          status_workflow: dadosCompletos.status_workflow
        },
        manobras: manobrasPDF,
        assinaturas: [{
          tipo: 'INSTRUTOR',
          nome: dadosCompletos.instrutor_nome,
          timestamp: dadosCompletos.updated_at,
          hash: hashDocumento
        }],
        metadados: {
          gerado_em: new Date().toISOString(),
          sistema: 'AirTrust v2.0',
          validade_legal: true
        }
      }
    });
  } catch (error) {
    console.error('Erro ao obter dados do PDF:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

export default app;
