import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
// Simplified environment detection
function detectActiveEnvironment(): string {
  return 'production';
}
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// GET /api/v2/system/health - Health check simples
app.get('/health', requirePermission('system', 'HEALTH_CHECK'), async (c) => {
  try {
    const db = c.env.DB;
    
    // Test database connection
    await db.prepare('SELECT 1').first();
    
    return c.json({
      overall_status: 'HEALTHY',
      environment: detectActiveEnvironment(),
      timestamp: new Date().toISOString(),
      database: 'OK'
    }, 200);
  } catch (error) {
    console.error('❌ Health check error:', error);
    return c.json({
      overall_status: 'FAILED',
      environment: detectActiveEnvironment(),
      timestamp: new Date().toISOString(),
      error: (error as Error).message
    }, 503);
  }
});

// GET /api/v2/system/health/legacy - Health check original (mantido para compatibilidade)
app.get('/health/legacy', requirePermission('system', 'HEALTH_CHECK'), async (c) => {
  const checks = [];
  const db = c.env.DB;

  // 1. Verificar se todas as tabelas existem
  const tables = [
    'funcionarios', 'funcoes', 'user_profiles_v2', 'user_permissions_v2', 'auditoria_avancada_v2',
    'catalogo_treinamentos_v2', 'historico_certificacoes_v2', 'certificado_anexos_v2', 'compliance_status_v2'
  ];
  
  for (const table of tables) {
    try {
      await db.prepare(`SELECT 1 FROM ${table} LIMIT 1`).first();
      checks.push({ 
        module: 'Schema', 
        table: table, 
        status: 'OK' 
      });
    } catch (error) {
      checks.push({ 
        module: 'Schema', 
        table: table, 
        status: 'FAIL', 
        error: (error as Error).message 
      });
    }
  }

  // 2. Verificar integridade referencial Funcionário <-> Função (Aplicação)
  try {
    const result = await db.prepare(`
      SELECT COUNT(f.id) as count 
      FROM funcionarios f 
      WHERE f.funcao NOT IN (SELECT nome FROM funcoes WHERE deleted_at IS NULL) 
      AND f.deleted_at IS NULL
    `).first();
    
    const invalidCount = result ? result.count : 0;
    checks.push({   
      check: 'referential_integrity_funcionario_funcao', 
      status: invalidCount === 0 ? 'OK' : 'FAIL',
      details: `Found ${invalidCount} funcionarios with invalid 'funcao'.` 
    });
  } catch (error) {
    checks.push({ 
      check: 'referential_integrity', 
      status: 'FAIL', 
      error: (error as Error).message 
    });
  }

  // 3. Verificar integridade referencial Histórico <-> Funcionário
  try {
    const result = await db.prepare(`
      SELECT COUNT(h.id) as count 
      FROM historico_certificacoes_v2 h 
      WHERE h.funcionario_id NOT IN (SELECT id FROM funcionarios WHERE deleted_at IS NULL) 
      AND h.deleted_at IS NULL
    `).first();
    
    const invalidCount = result ? result.count : 0;
    checks.push({   
      check: 'referential_integrity_historico_funcionario', 
      status: invalidCount === 0 ? 'OK' : 'FAIL',
      details: `Found ${invalidCount} historico with invalid funcionario_id.` 
    });
  } catch (error) {
    checks.push({ 
      check: 'referential_integrity_historico_funcionario', 
      status: 'FAIL', 
      error: (error as Error).message 
    });
  }

  // 4. Verificar integridade referencial Histórico <-> Treinamento
  try {
    const result = await db.prepare(`
      SELECT COUNT(h.id) as count 
      FROM historico_certificacoes_v2 h 
      WHERE h.treinamento_id NOT IN (SELECT id FROM catalogo_treinamentos_v2 WHERE deleted_at IS NULL) 
      AND h.deleted_at IS NULL
    `).first();
    
    const invalidCount = result ? result.count : 0;
    checks.push({   
      check: 'referential_integrity_historico_treinamento', 
      status: invalidCount === 0 ? 'OK' : 'FAIL',
      details: `Found ${invalidCount} historico with invalid treinamento_id.` 
    });
  } catch (error) {
    checks.push({ 
      check: 'referential_integrity_historico_treinamento', 
      status: 'FAIL', 
      error: (error as Error).message 
    });
  }

  // 5. Verificar integridade referencial Compliance <-> Funcionário
  try {
    const result = await db.prepare(`
      SELECT COUNT(c.id) as count 
      FROM compliance_status_v2 c 
      WHERE c.funcionario_id NOT IN (SELECT id FROM funcionarios WHERE deleted_at IS NULL)
    `).first();
    
    const invalidCount = result ? result.count : 0;
    checks.push({   
      check: 'referential_integrity_compliance_funcionario', 
      status: invalidCount === 0 ? 'OK' : 'FAIL',
      details: `Found ${invalidCount} compliance with invalid funcionario_id.` 
    });
  } catch (error) {
    checks.push({ 
      check: 'referential_integrity_compliance_funcionario', 
      status: 'FAIL', 
      error: (error as Error).message 
    });
  }

  // 6. Verificar integridade referencial Compliance <-> Treinamento  
  try {
    const result = await db.prepare(`
      SELECT COUNT(c.id) as count 
      FROM compliance_status_v2 c 
      WHERE c.treinamento_id NOT IN (SELECT id FROM catalogo_treinamentos_v2 WHERE deleted_at IS NULL)
    `).first();
    
    const invalidCount = result ? result.count : 0;
    checks.push({   
      check: 'referential_integrity_compliance_treinamento', 
      status: invalidCount === 0 ? 'OK' : 'FAIL',
      details: `Found ${invalidCount} compliance with invalid treinamento_id.` 
    });
  } catch (error) {
    checks.push({ 
      check: 'referential_integrity_compliance_treinamento', 
      status: 'FAIL', 
      error: (error as Error).message 
    });
  }

  // 7. Verificar se existem dados de teste (Módulo 1 + Módulo 2)
  try {
    const funcionariosResult = await db.prepare(`
      SELECT COUNT(*) as count FROM funcionarios WHERE deleted_at IS NULL
    `).first();
    
    const funcoesResult = await db.prepare(`
      SELECT COUNT(*) as count FROM funcoes WHERE deleted_at IS NULL
    `).first();

    const treinamentosResult = await db.prepare(`
      SELECT COUNT(*) as count FROM catalogo_treinamentos_v2 WHERE deleted_at IS NULL
    `).first();

    const funcionariosCount = (funcionariosResult?.count as number) || 0;
    const funcoesCount = (funcoesResult?.count as number) || 0;
    const treinamentosCount = (treinamentosResult?.count as number) || 0;

    checks.push({
      check: 'test_data_modules',
      status: (funcionariosCount >= 1 && funcoesCount >= 1 && treinamentosCount >= 3) ? 'OK' : 'FAIL',
      details: `Funcionarios: ${funcionariosCount}, Funcoes: ${funcoesCount}, Treinamentos: ${treinamentosCount}`
    });
  } catch (error) {
    checks.push({
      check: 'test_data_modules',
      status: 'FAIL',
      error: (error as Error).message
    });
  }

  // 4. Verificar performance básica
  const startTime = Date.now();
  try {
    await db.prepare(`SELECT COUNT(*) FROM funcionarios`).first();
    const queryTime = Date.now() - startTime;
    
    checks.push({
      check: 'performance',
      status: queryTime < 200 ? 'OK' : 'SLOW',
      details: `Query time: ${queryTime}ms`
    });
  } catch (error) {
    checks.push({
      check: 'performance',
      status: 'FAIL',
      error: (error as Error).message
    });
  }

  const allHealthy = checks.every(check => check.status === 'OK' || check.status === 'SLOW');
  
  return c.json({
    status: allHealthy ? 'HEALTHY' : 'DEGRADED',
    checks,
    timestamp: new Date().toISOString(),
    environment: detectActiveEnvironment()
  }, allHealthy ? 200 : 503);
});

// GET /api/v2/system/info - Informações básicas do sistema
app.get('/info', requirePermission('system', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const stats: Record<string, number | string> = {};
    
    // Contar registros por tabela
    const tables = [
      'funcionarios', 'funcoes', 'user_profiles_v2', 'auditoria_avancada_v2',
      'catalogo_treinamentos_v2', 'historico_certificacoes_v2', 'compliance_status_v2'
    ];
    
    for (const table of tables) {
      try {
        const result = await db.prepare(`SELECT COUNT(*) as count FROM ${table}`).first();
        stats[table] = (result?.count as number) || 0;
      } catch (error) {
        stats[table] = 'ERROR';
      }
    }

    return c.json({
      success: true,
      data: {
        system: 'AirTrust',
        version: '1.0.0',
        environment: detectActiveEnvironment(),
        timestamp: new Date().toISOString(),
        database_stats: stats
      }
    });
  } catch (error) {
    console.error('Error getting system info:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// GET /api/v2/system/export-data - Exportar dados do sistema para backup
app.get('/export-data', requirePermission('system', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    // Exportar todas as tabelas críticas
    const funcionarios = await db.prepare('SELECT * FROM funcionarios WHERE deleted_at IS NULL ORDER BY matricula').all();
    const treinamentos = await db.prepare('SELECT * FROM catalogo_treinamentos_v2 WHERE deleted_at IS NULL ORDER BY codigo').all();
    const certificacoes = await db.prepare(`
      SELECT hc.*, f.matricula as funcionario_matricula, t.codigo as treinamento_codigo
      FROM historico_certificacoes_v2 hc
      JOIN funcionarios f ON hc.funcionario_id = f.id
      JOIN catalogo_treinamentos_v2 t ON hc.treinamento_id = t.id
      WHERE hc.deleted_at IS NULL
      ORDER BY hc.created_at
    `).all();
    
    // Exportar arquivos de certificados (URLs do Cloudflare R2)
    const arquivos = await db.prepare(`
      SELECT hc.id as certificacao_id, hc.certificado_url, ca.nome_arquivo, ca.url_arquivo, ca.tipo_arquivo
      FROM historico_certificacoes_v2 hc 
      LEFT JOIN certificado_anexos_v2 ca ON hc.id = ca.historico_id
      WHERE (hc.certificado_url IS NOT NULL OR ca.url_arquivo IS NOT NULL)
      AND hc.deleted_at IS NULL
    `).all();

    const exportData = {
      version: '1.0',
      exported_at: new Date().toISOString(),
      data: {
        funcionarios: funcionarios.results,
        treinamentos: treinamentos.results,
        certificacoes: certificacoes.results,
        arquivos: arquivos.results
      },
      metadata: {
        total_funcionarios: funcionarios.results?.length || 0,
        total_treinamentos: treinamentos.results?.length || 0,
        total_certificacoes: certificacoes.results?.length || 0,
        total_arquivos: arquivos.results?.length || 0
      }
    };

    await logAudit(c, 'EXPORT', 'system_backup', undefined, undefined, { 
      export_size: JSON.stringify(exportData).length,
      tables_exported: ['funcionarios', 'treinamentos', 'certificacoes', 'arquivos']
    });

    return c.json(exportData);
  } catch (error) {
    console.error('Error exporting data:', error);
    await logAudit(c, 'EXPORT', 'system_backup', undefined, undefined, undefined, 'ERROR');
    return c.json({ success: false, error: 'Erro interno do servidor' }, 500);
  }
});

// POST /api/v2/system/import-data - Importar/restaurar dados do backup
app.post('/import-data', requirePermission('system', 'READ'), async (c) => {
  try {
    const exportData = await c.req.json();
    
    if (!exportData.data) {
      throw new Error('Formato de dados inválido');
    }

    const db = c.env.DB;
    let stats = { 
      funcionarios_importados: 0,
      treinamentos_importados: 0, 
      certificacoes_importadas: 0
    };

    // Importar funcionários (com upsert por matrícula)
    for (const funcionario of exportData.data.funcionarios || []) {
      try {
        await db.prepare(`
          INSERT OR REPLACE INTO funcionarios (
            matricula, nome, cpf, email, telefone, funcao, status,
            anv, data_nascimento, licenca_aeronautica, codigo_canac,
            codigo_sispat, codigo_prestserv, data_admissao, base, contrato,
            codigo_anac, cma_numero, cma_data_vencimento, cma_status,
            aso_data_vencimento, nivel_icao, nivel_icao_data_vencimento, nivel_icao_status,
            is_instrutor, is_checador, aeronave_principal, avatar,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          funcionario.matricula, funcionario.nome, funcionario.cpf, 
          funcionario.email, funcionario.telefone, funcionario.funcao, funcionario.status,
          funcionario.anv, funcionario.data_nascimento, funcionario.licenca_aeronautica,
          funcionario.codigo_canac, funcionario.codigo_sispat, funcionario.codigo_prestserv,
          funcionario.data_admissao, funcionario.base, funcionario.contrato,
          funcionario.codigo_anac, funcionario.cma_numero, funcionario.cma_data_vencimento, funcionario.cma_status,
          funcionario.aso_data_vencimento, funcionario.nivel_icao, funcionario.nivel_icao_data_vencimento, funcionario.nivel_icao_status,
          funcionario.is_instrutor || 0, funcionario.is_checador || 0, funcionario.aeronave_principal, funcionario.avatar,
          funcionario.created_at, funcionario.updated_at
        ).run();
        
        stats.funcionarios_importados++;
      } catch (error) {
        console.warn('Erro ao importar funcionário:', funcionario.matricula, error);
      }
    }

    // Importar treinamentos (com upsert por código)
    for (const treinamento of exportData.data.treinamentos || []) {
      try {
        await db.prepare(`
          INSERT OR REPLACE INTO catalogo_treinamentos_v2 (
            codigo, nome, descricao, categoria, periodicidade_meses, 
            tipo_vencimento, instrutor_obrigatorio, nota_minima, carga_horaria, ativo, 
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          treinamento.codigo, treinamento.nome, treinamento.descricao,
          treinamento.categoria, treinamento.periodicidade_meses,
          treinamento.tipo_vencimento || 'FINAL_MES', 
          treinamento.instrutor_obrigatorio || 0, treinamento.nota_minima || 7.0, treinamento.carga_horaria,
          treinamento.ativo ? 1 : 0, treinamento.created_at, treinamento.updated_at
        ).run();
        
        stats.treinamentos_importados++;
      } catch (error) {
        console.warn('Erro ao importar treinamento:', treinamento.codigo, error);
      }
    }

    // Importar certificações (preservando relações por matrícula e código)
    for (const cert of exportData.data.certificacoes || []) {
      try {
        // Buscar IDs atuais de funcionário e treinamento
        const funcionario = await db.prepare(
          'SELECT id FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL'
        ).bind(cert.funcionario_matricula).first();
        
        const treinamento = await db.prepare(
          'SELECT id FROM catalogo_treinamentos_v2 WHERE codigo = ? AND deleted_at IS NULL'
        ).bind(cert.treinamento_codigo).first();

        if (funcionario && treinamento) {
          await db.prepare(`
            INSERT OR REPLACE INTO historico_certificacoes_v2 (
              funcionario_id, treinamento_id, data_conclusao, data_vencimento,
              status, instrutor, observacoes, certificado_url, nota_final,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `).bind(
            funcionario.id, treinamento.id, cert.data_conclusao, cert.data_vencimento,
            cert.status || 'ATIVO', cert.instrutor, cert.observacoes, cert.certificado_url, cert.nota_final,
            cert.created_at, cert.updated_at
          ).run();
          
          stats.certificacoes_importadas++;
        }
      } catch (error) {
        console.warn('Erro ao importar certificação:', cert.id, error);
      }
    }

    await logAudit(c, 'IMPORT', 'system_restore', undefined, undefined, stats);

    return c.json({ 
      success: true, 
      message: 'Dados importados com sucesso',
      stats 
    });

  } catch (error) {
    console.error('Error importing data:', error);
    await logAudit(c, 'IMPORT', 'system_restore', undefined, undefined, undefined, 'ERROR');
    return c.json({ success: false, error: error instanceof Error ? error.message : 'Erro interno do servidor' }, 500);
  }
});

export default app;
