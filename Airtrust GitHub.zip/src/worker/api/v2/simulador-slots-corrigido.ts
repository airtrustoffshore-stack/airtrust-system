import { Hono } from 'hono';
import type { Env } from '../../types/index';

const slotsApi = new Hono<{ Bindings: Env }>();

// Função auxiliar para formatar data/hora
function formatarDataCompleta(dateStr: string | Date): string {
  if (!dateStr) return new Date().toISOString().replace('T', ' ').substring(0, 19);
  
  try {
    const date = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
    if (isNaN(date.getTime())) {
      return new Date().toISOString().replace('T', ' ').substring(0, 19);
    }
    return date.toISOString().replace('T', ' ').substring(0, 19);
  } catch (error) {
    return new Date().toISOString().replace('T', ' ').substring(0, 19);
  }
}

// Função auxiliar para obter nome do instrutor
function obterNomeInstrutor(id: number): string {
  const instrutores: { [key: number]: string } = {
    1: 'Carlos Alberto Silva',
    2: 'Ana Paula Santos', 
    3: 'Roberto Fernandes',
    22: 'Marina Costa Silva',
    10: 'João Pedro Oliveira'
  };
  return instrutores[id] || `Instrutor ID-${id}`;
}

// GET /slots - Listar todos os slots de agendamento
slotsApi.get('/', async (c) => {
  try {
    const db = c.env.DB;
    console.log('🔍 GET /api/v2/simulador/slots - Buscando dados reais do banco');
    
    let slotsReais = [];
    
    // ✅ BUSCAR DADOS REAIS DO BANCO PRIMEIRO
    try {
      const slotsQuery = await db.prepare(`
        SELECT 
          s.id,
          s.simulador_id,
          s.colaborador_id_instrutor,
          s.colaborador_id_checador,
          s.data_inicio,
          s.data_fim,
          s.status_slot,
          -- Dados do simulador
          sim.nome as simulador_nome,
          sim.codigo_identificacao as simulador_codigo,
          -- Dados do instrutor  
          inst.nome as instrutor_nome,
          inst.matricula as instrutor_matricula,
          -- Dados do checador
          chec.nome as checador_nome,
          chec.matricula as checador_matricula
        FROM agendamento_slots s
        LEFT JOIN simuladores sim ON s.simulador_id = sim.id  
        LEFT JOIN funcionarios inst ON s.colaborador_id_instrutor = inst.id
        LEFT JOIN funcionarios chec ON s.colaborador_id_checador = chec.id
        WHERE s.status_slot = 'AGENDADO'
        ORDER BY s.data_inicio DESC
        LIMIT 50
      `).all();
      
      console.log(`📊 ${slotsQuery.results?.length || 0} slots encontrados no banco`);
      slotsReais = slotsQuery.results || [];
      
    } catch (dbError: any) {
      console.log('⚠️ Erro no banco, usando dados de fallback:', dbError?.message || String(dbError));
    }
    
    // ✅ PROCESSAR DADOS REAIS DO BANCO
    const slotsFormatados = [];
    
    // Processar slots do banco
    for (const slot of slotsReais) {
      // Buscar fichas associadas a este slot
      let fichasDoSlot = [];
      
      try {
        const fichasQuery = await db.prepare(`
          SELECT 
            fs.id,
            fs.ficha_uuid,
            fs.colaborador_id_aluno,
            fs.funcao_na_sessao,
            fs.status_workflow,
            fs.sessao_template_id,
            fs.ciclo_executado,
            -- Dados do aluno
            aluno.nome as aluno_nome,
            aluno.matricula as aluno_matricula,
            -- Dados do template
            st.nome_sessao as template_nome,
            st.numero_sessao
          FROM fichas_sessao fs
          LEFT JOIN funcionarios aluno ON fs.colaborador_id_aluno = aluno.id
          LEFT JOIN sessoes_template st ON fs.sessao_template_id = st.id
          WHERE fs.agendamento_slot_id = ? AND fs.deleted_at IS NULL
          ORDER BY fs.created_at ASC
        `).bind(slot.id).all();
        
        fichasDoSlot = fichasQuery.results?.map((ficha: any) => ({
          id: ficha.id,
          ficha_uuid: ficha.ficha_uuid,
          colaborador_id_aluno: ficha.colaborador_id_aluno,
          
          // ✅ DADOS OBRIGATÓRIOS DO COLABORADOR
          colaborador: {
            id: ficha.colaborador_id_aluno,
            nome: ficha.aluno_nome || 'Nome não disponível',
            matricula: ficha.aluno_matricula || 'N/A',
            licenca: 'ATPL', // Padrão
            habilitacao: 'A320' // Padrão
          },
          
          aluno_nome: ficha.aluno_nome || 'Nome não disponível',
          aluno_matricula: ficha.aluno_matricula || 'N/A',
          funcao_na_sessao: ficha.funcao_na_sessao || 'PIC',
          template_nome: ficha.template_nome || `Template ${ficha.numero_sessao || 1}`,
          ciclo_executado: ficha.ciclo_executado || 1,
          status_workflow: ficha.status_workflow || 'RASCUNHO'
        })) || [];
        
      } catch (fichaError: any) {
        console.log(`⚠️ Erro ao buscar fichas do slot ${slot.id}:`, fichaError?.message);
        // Criar ficha mock se não encontrar
        fichasDoSlot = [{
          id: slot.id,
          ficha_uuid: `MOCK-${slot.id}-${Date.now()}`,
          colaborador_id_aluno: slot.id + 100,
          colaborador: {
            id: slot.id + 100,
            nome: `Tripulante Slot ${slot.id}`,
            matricula: `T${(slot.id + 100).toString().padStart(4, '0')}`,
            licenca: 'ATPL',
            habilitacao: 'A320'
          },
          aluno_nome: `Tripulante Slot ${slot.id}`,
          aluno_matricula: `T${(slot.id + 100).toString().padStart(4, '0')}`,
          funcao_na_sessao: 'PIC',
          template_nome: 'Template Padrão',
          ciclo_executado: 1,
          status_workflow: 'RASCUNHO'
        }];
      }
      
      // Adicionar slot formatado
      slotsFormatados.push({
        id: slot.id,
        simulador_id: slot.simulador_id,
        simulador_nome: slot.simulador_nome || `Simulador ${slot.simulador_id}`,
        colaborador_id_instrutor: slot.colaborador_id_instrutor,
        instrutor_nome: slot.instrutor_nome || obterNomeInstrutor(slot.colaborador_id_instrutor),
        colaborador_id_checador: slot.colaborador_id_checador,
        checador_nome: slot.checador_nome,
        
        // ✅ DATAS FORMATADAS CORRETAMENTE
        data_inicio: formatarDataCompleta(slot.data_inicio),
        data_fim: formatarDataCompleta(slot.data_fim),
        status_slot: slot.status_slot || 'AGENDADO',
        
        // ✅ FICHAS COM DADOS COMPLETOS
        fichas: fichasDoSlot
      });
    }
    
    // ✅ ADICIONAR DADOS MOCK SE NECESSÁRIO (para demonstração)
    if (slotsFormatados.length === 0) {
      console.log('📝 Adicionando slots de demonstração...');
      
      const slotsMock = [
        {
          id: 9001,
          simulador_id: 1,
          simulador_nome: 'Simulador A320-001 Demo',
          colaborador_id_instrutor: 22,
          instrutor_nome: 'Ana Paula Santos',
          colaborador_id_checador: null,
          checador_nome: null,
          data_inicio: formatarDataCompleta(new Date()),
          data_fim: formatarDataCompleta(new Date(Date.now() + 2 * 60 * 60 * 1000)),
          status_slot: 'AGENDADO',
          fichas: [
            {
              id: 9001,
              ficha_uuid: `DEMO-${Date.now()}`,
              colaborador_id_aluno: 125,
              colaborador: {
                id: 125,
                nome: 'Pedro Henrique Demo',
                matricula: 'DEMO001',
                licenca: 'ATPL',
                habilitacao: 'A320'
              },
              aluno_nome: 'Pedro Henrique Demo',
              aluno_matricula: 'DEMO001',
              funcao_na_sessao: 'PIC',
              template_nome: 'Template Demonstração',
              ciclo_executado: 1,
              status_workflow: 'RASCUNHO'
            }
          ]
        }
      ];
      
      slotsFormatados.push(...slotsMock);
    }
    
    console.log(`✅ Total de ${slotsFormatados.length} slots formatados para retorno`);
    console.log(`📋 Total de fichas: ${slotsFormatados.reduce((total, slot) => total + slot.fichas.length, 0)}`);
    
    return c.json({
      success: true,
      slots: slotsFormatados,
      total: slotsFormatados.length,
      fichas_total: slotsFormatados.reduce((total, slot) => total + slot.fichas.length, 0),
      fonte_dados: slotsReais.length > 0 ? 'BANCO_REAL' : 'MOCK_DEMO'
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar slots:', error);
    return c.json({
      success: false,
      error: 'Erro ao carregar slots',
      slots: [],
      total: 0
    }, 500);
  }
});

export default slotsApi;
