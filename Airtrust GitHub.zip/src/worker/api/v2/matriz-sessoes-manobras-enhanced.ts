import { Hono } from 'hono';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const matrizEnhancedApi = new Hono<{ Bindings: Env }>();

// Apply auth middleware
matrizEnhancedApi.use('*', authMiddleware);



// Schema para atualização em lote
const BulkUpdateSchema = z.object({
  sessao_template_id: z.number(),
  manobras_ids: z.array(z.number())
});

// PUT /api/v2/matriz-sessoes-manobras/bulk-update - Atualização em lote da matriz
matrizEnhancedApi.put('/bulk-update', requirePermission('simuladores', 'UPDATE'), async (c) => {
  try {
    const body = await c.req.json();
    const { sessao_template_id, manobras_ids } = BulkUpdateSchema.parse(body);

    const db = c.env.DB;

    // 1. Verificar se a sessão template existe
    const sessaoTemplate = await db.prepare(`
      SELECT * FROM sessoes_template WHERE id = ?
    `).bind(sessao_template_id).first();

    if (!sessaoTemplate) {
      return c.json({ error: 'Sessão template não encontrada' }, 404);
    }

    // 2. Buscar manobras existentes para auditoria
    const manobrasAntigas = await db.prepare(`
      SELECT manobra_catalogo_id FROM sessoes_template_manobras 
      WHERE sessao_template_id = ?
    `).bind(sessao_template_id).all();

    // 3. Remover todas as manobras existentes da sessão
    await db.prepare(`
      DELETE FROM sessoes_template_manobras WHERE sessao_template_id = ?
    `).bind(sessao_template_id).run();

    // 4. Inserir novas manobras
    let inseridas = 0;
    for (const manobraId of manobras_ids) {
      // Verificar se a manobra existe
      const manobra = await db.prepare(`
        SELECT id FROM manobras_catalogo WHERE id = ? AND ativo = 1
      `).bind(manobraId).first();

      if (manobra) {
        await db.prepare(`
          INSERT INTO sessoes_template_manobras (sessao_template_id, manobra_catalogo_id)
          VALUES (?, ?)
        `).bind(sessao_template_id, manobraId).run();
        inseridas++;
      }
    }

    // 5. Registrar auditoria
    await logAudit(
      c,
      'BULK_UPDATE',
      'sessoes_template_manobras',
      sessao_template_id.toString(),
      { manobras_antigas: manobrasAntigas.results?.map(m => m.manobra_catalogo_id) },
      { manobras_novas: manobras_ids }
    );

    return c.json({
      success: true,
      message: `Matriz atualizada: ${inseridas} manobras configuradas`,
      detalhes: {
        sessao_id: sessao_template_id,
        manobras_inseridas: inseridas,
        manobras_solicitadas: manobras_ids.length
      }
    });

  } catch (error) {
    console.error('Erro ao atualizar matriz:', error);
    await logAudit(c, 'BULK_UPDATE', 'sessoes_template_manobras', '', undefined, undefined, 'ERROR');
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/matriz-sessoes-manobras/sessao/:id - Obter manobras de uma sessão específica
matrizEnhancedApi.get('/sessao/:id', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const sessaoId = parseInt(c.req.param('id'));
    const db = c.env.DB;

    const manobras = await db.prepare(`
      SELECT 
        mc.id,
        mc.manobra_id_codigo,
        mc.nome_manobra,
        mc.categoria,
        mc.pontuacao_minima,
        mc.ativo
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ?
      ORDER BY mc.categoria, mc.manobra_id_codigo
    `).bind(sessaoId).all();

    return c.json({
      success: true,
      data: manobras.results || []
    });

  } catch (error) {
    console.error('Erro ao buscar manobras da sessão:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// POST /api/v2/matriz-sessoes-manobras/import-csv - Importar matriz via CSV
matrizEnhancedApi.post('/import-csv', requirePermission('simuladores', 'CREATE'), async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return c.json({ error: 'Arquivo CSV não fornecido' }, 400);
    }

    const csvContent = await file.text();
    const lines = csvContent.split('\n').filter(line => line.trim());
    
    if (lines.length < 2) {
      return c.json({ error: 'Arquivo CSV deve ter pelo menos cabeçalho e uma linha de dados' }, 400);
    }

    const db = c.env.DB;
    const results = {
      total_linhas: lines.length - 1,
      processadas: 0,
      sessoes_criadas: 0,
      relacoes_criadas: 0,
      codigos_nao_encontrados: [] as string[],
      erros: [] as any[]
    };

    // Processar cada linha (ignorar cabeçalho)
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      try {
        // Parse CSV line (formato: sessao_codigo,nome_sessao,manobra_codigos)
        const [sessaoCodigo, nomeSessao, manobraCodigosStr] = line.split(',').map(s => s.replace(/"/g, '').trim());
        
        if (!sessaoCodigo || !nomeSessao || !manobraCodigosStr) {
          results.erros.push({
            linha: i + 1,
            erro: 'Formato inválido - campos obrigatórios ausentes'
          });
          continue;
        }

        const manobraCodigos = manobraCodigosStr.split(';').map(s => s.trim()).filter(Boolean);

        // 1. Verificar/criar sessão template
        let sessaoTemplate = await db.prepare(`
          SELECT id FROM sessoes_template 
          WHERE treinamento_codigo = ? AND nome_sessao = ?
        `).bind(sessaoCodigo, nomeSessao).first();

        if (!sessaoTemplate) {
          // Criar nova sessão template
          const insertResult = await db.prepare(`
            INSERT INTO sessoes_template (
              treinamento_codigo, numero_sessao, nome_sessao, 
              created_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(
            sessaoCodigo,
            1, // Número padrão
            nomeSessao,
            'import_csv'
          ).run();

          if (insertResult.success) {
            sessaoTemplate = { id: insertResult.meta.last_row_id as number };
            results.sessoes_criadas++;
          } else {
            results.erros.push({
              linha: i + 1,
              erro: 'Erro ao criar sessão template'
            });
            continue;
          }
        }

        // 2. Buscar IDs das manobras pelos códigos
        const manobraIds: number[] = [];
        for (const codigoManobra of manobraCodigos) {
          const manobra = await db.prepare(`
            SELECT id FROM manobras_catalogo 
            WHERE manobra_id_codigo = ? AND ativo = 1
          `).bind(codigoManobra).first();

          if (manobra && typeof manobra.id === 'number') {
            manobraIds.push(manobra.id);
          } else {
            results.codigos_nao_encontrados.push(codigoManobra);
          }
        }

        // 3. Remover relações existentes e inserir novas
        const sessaoId = typeof sessaoTemplate.id === 'number' ? sessaoTemplate.id : Number(sessaoTemplate.id);
        
        await db.prepare(`
          DELETE FROM sessoes_template_manobras WHERE sessao_template_id = ?
        `).bind(sessaoId).run();

        for (const manobraId of manobraIds) {
          await db.prepare(`
            INSERT OR IGNORE INTO sessoes_template_manobras (sessao_template_id, manobra_catalogo_id)
            VALUES (?, ?)
          `).bind(sessaoId, manobraId).run();
          results.relacoes_criadas++;
        }

        results.processadas++;

      } catch (error) {
        results.erros.push({
          linha: i + 1,
          erro: error instanceof Error ? error.message : 'Erro desconhecido'
        });
      }
    }

    // Registrar auditoria da importação
    await logAudit(
      c,
      'IMPORT_CSV',
      'sessoes_template_manobras',
      'bulk',
      undefined,
      results
    );

    return c.json({
      success: true,
      message: `Importação concluída: ${results.processadas} linhas processadas`,
      data: results
    });

  } catch (error) {
    console.error('Erro na importação CSV:', error);
    return c.json({
      error: 'Erro na importação',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/matriz-sessoes-manobras/export-csv - Exportar matriz como CSV
matrizEnhancedApi.get('/export-csv', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const db = c.env.DB;

    const matrizCompleta = await db.prepare(`
      SELECT 
        st.treinamento_codigo,
        st.nome_sessao,
        GROUP_CONCAT(mc.manobra_id_codigo, ';') as manobras_codigos
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      LEFT JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id AND mc.ativo = 1
      GROUP BY st.id, st.treinamento_codigo, st.nome_sessao
      ORDER BY st.treinamento_codigo, st.nome_sessao
    `).all();

    // Gerar CSV
    const headers = ['sessao_codigo', 'nome_sessao', 'manobra_codigos'];
    const rows = (matrizCompleta.results || []).map((item: any) => [
      item.treinamento_codigo,
      item.nome_sessao,
      item.manobras_codigos || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    return new Response(csvContent, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="matriz_sessoes_manobras_${new Date().toISOString().split('T')[0]}.csv"`
      }
    });

  } catch (error) {
    console.error('Erro ao exportar CSV:', error);
    return c.json({
      error: 'Erro na exportação',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/matriz-sessoes-manobras/overview - Visão geral da matriz
matrizEnhancedApi.get('/overview', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const db = c.env.DB;

    // Estatísticas gerais
    const stats = await db.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM sessoes_template) as total_sessoes,
        (SELECT COUNT(*) FROM manobras_catalogo WHERE ativo = 1) as total_manobras,
        (SELECT COUNT(*) FROM sessoes_template_manobras) as total_relacoes,
        (SELECT COUNT(DISTINCT sessao_template_id) FROM sessoes_template_manobras) as sessoes_com_manobras
    `).first();

    // Distribuição por categoria
    const distribCategoria = await db.prepare(`
      SELECT 
        mc.categoria,
        COUNT(*) as total_manobras,
        COUNT(stm.manobra_catalogo_id) as manobras_em_uso
      FROM manobras_catalogo mc
      LEFT JOIN sessoes_template_manobras stm ON mc.id = stm.manobra_catalogo_id
      WHERE mc.ativo = 1
      GROUP BY mc.categoria
      ORDER BY total_manobras DESC
    `).all();

    // Sessões com mais manobras
    const sessoesComplexas = await db.prepare(`
      SELECT 
        st.nome_sessao,
        st.treinamento_codigo,
        COUNT(stm.manobra_catalogo_id) as total_manobras
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      GROUP BY st.id, st.nome_sessao, st.treinamento_codigo
      ORDER BY total_manobras DESC
      LIMIT 10
    `).all();

    // Manobras mais utilizadas
    const manobrasPopulares = await db.prepare(`
      SELECT 
        mc.manobra_id_codigo,
        mc.nome_manobra,
        mc.categoria,
        COUNT(stm.sessao_template_id) as uso_em_sessoes
      FROM manobras_catalogo mc
      LEFT JOIN sessoes_template_manobras stm ON mc.id = stm.manobra_catalogo_id
      WHERE mc.ativo = 1
      GROUP BY mc.id, mc.manobra_id_codigo, mc.nome_manobra, mc.categoria
      ORDER BY uso_em_sessoes DESC
      LIMIT 10
    `).all();

    return c.json({
      success: true,
      data: {
        estatisticas_gerais: stats,
        distribuicao_categoria: distribCategoria.results || [],
        sessoes_complexas: sessoesComplexas.results || [],
        manobras_populares: manobrasPopulares.results || []
      }
    });

  } catch (error) {
    console.error('Erro ao gerar overview:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// POST /api/v2/matriz-sessoes-manobras/duplicar-sessao - Duplicar configuração de uma sessão
matrizEnhancedApi.post('/duplicar-sessao', requirePermission('simuladores', 'CREATE'), async (c) => {
  try {
    const body = await c.req.json();
    const { sessao_origem_id, novo_nome, novo_codigo } = z.object({
      sessao_origem_id: z.number(),
      novo_nome: z.string(),
      novo_codigo: z.string()
    }).parse(body);

    const db = c.env.DB;

    // 1. Verificar se sessão origem existe
    const sessaoOrigem = await db.prepare(`
      SELECT * FROM sessoes_template WHERE id = ?
    `).bind(sessao_origem_id).first();

    if (!sessaoOrigem) {
      return c.json({ error: 'Sessão origem não encontrada' }, 404);
    }

    // 2. Criar nova sessão
    const novaSessaoResult = await db.prepare(`
      INSERT INTO sessoes_template (
        treinamento_codigo, numero_sessao, nome_sessao, descricao,
        created_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(
      novo_codigo,
      1, // Número padrão
      novo_nome,
      `Duplicada de: ${sessaoOrigem.nome_sessao}`,
      'sistema_duplicacao'
    ).run();

    if (!novaSessaoResult.success) {
      return c.json({ error: 'Erro ao criar nova sessão' }, 400);
    }

    const novaSessaoId = novaSessaoResult.meta.last_row_id;

    // 3. Copiar manobras da sessão origem
    const manobrasOrigem = await db.prepare(`
      SELECT manobra_catalogo_id FROM sessoes_template_manobras 
      WHERE sessao_template_id = ?
    `).bind(sessao_origem_id).all();

    let manobrasCopiar = 0;
    for (const manobra of manobrasOrigem.results || []) {
      await db.prepare(`
        INSERT INTO sessoes_template_manobras (sessao_template_id, manobra_catalogo_id)
        VALUES (?, ?)
      `).bind(novaSessaoId, manobra.manobra_catalogo_id).run();
      manobrasCopiar++;
    }

    // 4. Registrar auditoria
    await logAudit(
      c,
      'DUPLICATE',
      'sessoes_template',
      novaSessaoId.toString(),
      { sessao_origem_id },
      { novo_nome, novo_codigo, manobras_copiadas: manobrasCopiar }
    );

    return c.json({
      success: true,
      message: `Sessão duplicada com sucesso: ${manobrasCopiar} manobras copiadas`,
      data: {
        nova_sessao_id: novaSessaoId,
        manobras_copiadas: manobrasCopiar
      }
    });

  } catch (error) {
    console.error('Erro ao duplicar sessão:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default matrizEnhancedApi;
