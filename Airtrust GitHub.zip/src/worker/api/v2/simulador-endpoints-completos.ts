import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ UTILITÁRIO PARA FORMATAR DATAS BRASILEIRAS
function formatarDataBrasil(dateStr: string | Date): string {
  if (!dateStr) return 'N/A';
  
  try {
    const date = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
    if (isNaN(date.getTime())) return 'N/A';
    
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit', 
      year: 'numeric'
    });
  } catch {
    return 'N/A';
  }
}

// ✅ CORREÇÃO CRÍTICA 1: Endpoint principal de fichas corrigido
app.get('/fichas', requirePermission('simulador', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    // Query SQL corrigida sem sintaxe CHECK que causava erro D1_ERROR
    const result = await db.prepare(`
      SELECT 
        f.id,
        f.ficha_uuid,
        f.status_workflow,
        f.funcao_na_sessao,
        f.resultado_final,
        f.nota_final,
        f.created_at,
        func.nome as funcionario_nome,
        func.matricula as funcionario_matricula,
        s.nome as simulador_nome,
        s.codigo_identificacao as simulador_codigo,
        inst.nome as instrutor_nome,
        st.nome_sessao as template_nome,
        st.numero_sessao
      FROM fichas_sessao f
      LEFT JOIN funcionarios func ON f.colaborador_id_aluno = func.id
      LEFT JOIN agendamento_slots a ON f.agendamento_slot_id = a.id
      LEFT JOIN simuladores s ON a.simulador_id = s.id
      LEFT JOIN funcionarios inst ON a.colaborador_id_instrutor = inst.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.deleted_at IS NULL
      ORDER BY f.created_at DESC
    `).all();
    
    // ✅ CORREÇÃO: Garantir que result.results seja um array
    const fichas = result.results || [];
    
    const fichasFormatadas = fichas.map((ficha: any) => ({
      id: ficha.id,
      uuid: ficha.ficha_uuid,
      status_workflow: ficha.status_workflow,
      funcao_na_sessao: ficha.funcao_na_sessao,
      conceito_final: ficha.resultado_final,
      nota_final: ficha.nota_final,
      created_at: formatarDataBrasil(ficha.created_at),
      colaborador: {
        nome: ficha.funcionario_nome || 'N/A',
        matricula: ficha.funcionario_matricula || 'N/A'
      },
      simulador: {
        nome: ficha.simulador_nome || 'N/A',
        codigo: ficha.simulador_codigo || 'N/A'
      },
      instrutor: {
        nome: ficha.instrutor_nome || 'N/A'
      },
      sessao_template: {
        nome: ficha.template_nome || 'N/A',
        numero: ficha.numero_sessao || 'N/A'
      }
    }));
    
    return c.json({ 
      success: true,
      fichas: fichasFormatadas,
      total: fichasFormatadas.length
    });
    
  } catch (error: any) {
    console.error('Erro ao listar fichas:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error.message
    }, 500);
  }
});

// ✅ CORREÇÃO CRÍTICA 2: Endpoint de simuladores
app.get('/simuladores', requirePermission('simulador', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const result = await db.prepare(`
      SELECT 
        id,
        nome,
        codigo_identificacao,
        tipo_simulador,
        aeronave_base,
        empresa_local,
        certificacao_anac,
        status
      FROM simuladores 
      WHERE status = 'ATIVO' AND (deleted_at IS NULL OR deleted_at = '')
      ORDER BY nome ASC
    `).all();
    
    const simuladores = result.results || [];
    
    return c.json({
      success: true,
      simuladores,
      total: simuladores.length
    });
  } catch (error: any) {
    console.error('Erro ao listar simuladores:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// ✅ CORREÇÃO CRÍTICA 3: Endpoint de templates
app.get('/templates', requirePermission('simulador', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const result = await db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo as codigo,
        st.nome_sessao as nome,
        st.descricao,
        st.numero_sessao,
        COUNT(stm.manobra_catalogo_id) as total_manobras
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      GROUP BY st.id, st.treinamento_codigo, st.nome_sessao, st.descricao, st.numero_sessao
      ORDER BY st.numero_sessao ASC
    `).all();
    
    const templates = result.results || [];
    
    const templatesFormatados = templates.map((template: any) => ({
      id: template.id,
      codigo: template.codigo,
      nome: template.nome,
      descricao: template.descricao || '',
      numero_sessao: template.numero_sessao,
      total_manobras: template.total_manobras || 0
    }));
    
    return c.json({
      success: true,
      templates: templatesFormatados,
      total: templatesFormatados.length
    });
  } catch (error: any) {
    console.error('Erro ao listar templates:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// ✅ CORREÇÃO CRÍTICA 4: Endpoint de manobras
app.get('/manobras', requirePermission('simulador', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const result = await db.prepare(`
      SELECT 
        id,
        manobra_id_codigo as codigo,
        nome_manobra as nome,
        descricao_detalhada as descricao,
        categoria,
        criterios_aprovacao,
        pontuacao_minima,
        ativo
      FROM manobras_catalogo 
      WHERE ativo = 1 AND (deleted_at IS NULL OR deleted_at = '')
      ORDER BY categoria, nome_manobra ASC
    `).all();
    
    const manobras = result.results || [];
    
    // Organizar por categoria
    const manobrasPorCategoria = manobras.reduce((acc: any, manobra: any) => {
      const categoria = manobra.categoria || 'GERAL';
      if (!acc[categoria]) {
        acc[categoria] = [];
      }
      acc[categoria].push(manobra);
      return acc;
    }, {});
    
    return c.json({
      success: true,
      manobras: manobrasPorCategoria,
      total: manobras.length
    });
  } catch (error: any) {
    console.error('Erro ao listar manobras:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// ✅ CORREÇÃO CRÍTICA 5: Endpoint de funcionários para simulador
app.get('/funcionarios', requirePermission('simulador', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    const result = await db.prepare(`
      SELECT 
        id,
        nome,
        matricula,
        funcao,
        is_instrutor,
        is_checador,
        status
      FROM funcionarios 
      WHERE status = 'ATIVO' AND (deleted_at IS NULL OR deleted_at = '')
      ORDER BY nome ASC
    `).all();
    
    const funcionarios = result.results || [];
    
    // Organizar por tipo
    const instrutores = funcionarios.filter((f: any) => f.is_instrutor === 1);
    const checadores = funcionarios.filter((f: any) => f.is_checador === 1);
    const tripulantes = funcionarios.filter((f: any) => f.is_instrutor === 0 && f.is_checador === 0);
    
    return c.json({
      success: true,
      funcionarios: {
        instrutores,
        checadores,
        tripulantes
      },
      total: funcionarios.length
    });
  } catch (error: any) {
    console.error('Erro ao listar funcionários:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// ✅ CORREÇÃO CRÍTICA 6: Endpoint de agendamento
app.post('/agendamento', requirePermission('simulador', 'CREATE'), zValidator('json', z.object({
  data_inicio: z.string(),
  hora_inicio: z.string(),
  data_fim: z.string().optional(),
  hora_fim: z.string().optional(),
  simulador_id: z.union([z.string(), z.number()]),
  instrutor_id: z.union([z.string(), z.number()]),
  colaborador_aluno_id: z.union([z.string(), z.number()]),
  template_sessao_id: z.union([z.string(), z.number()]).optional(),
  funcao_na_sessao: z.string().default('PIC')
})), async (c) => {
  try {
    const {
      data_inicio,
      hora_inicio,
      data_fim,
      hora_fim,
      simulador_id,
      instrutor_id,
      colaborador_aluno_id,
      template_sessao_id,
      funcao_na_sessao
    } = c.req.valid('json');
    
    const db = c.env.DB;
    
    // Converter para timestamp (formato dd/mm/aaaa)
    const [dia, mes, ano] = data_inicio.split('/');
    const [hora, minuto] = hora_inicio.split(':');
    const dataHoraInicio = new Date(parseInt(ano), parseInt(mes) - 1, parseInt(dia), parseInt(hora), parseInt(minuto));
    
    let dataHoraFim = new Date(dataHoraInicio);
    if (data_fim && hora_fim) {
      const [diaF, mesF, anoF] = data_fim.split('/');
      const [horaF, minutoF] = hora_fim.split(':');
      dataHoraFim = new Date(parseInt(anoF), parseInt(mesF) - 1, parseInt(diaF), parseInt(horaF), parseInt(minutoF));
    } else {
      // Auto-calcular 2 horas depois
      dataHoraFim.setHours(dataHoraFim.getHours() + 2);
    }
    
    // Criar agendamento
    const agendamentoResult = await db.prepare(`
      INSERT INTO agendamento_slots (
        data_inicio, data_fim, simulador_id, colaborador_id_instrutor, 
        status_slot, created_at, created_by
      ) VALUES (?, ?, ?, ?, 'AGENDADO', ?, ?)
    `).bind(
      dataHoraInicio.toISOString(),
      dataHoraFim.toISOString(),
      parseInt(simulador_id.toString()),
      parseInt(instrutor_id.toString()),
      new Date().toISOString(),
      'sistema'
    ).run();
    
    // Criar ficha automaticamente
    const fichaUuid = `FICHA-${new Date().toLocaleDateString('pt-BR').replace(/\//g, '')}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
    
    await db.prepare(`
      INSERT INTO fichas_sessao (
        ficha_uuid, agendamento_slot_id, colaborador_id_aluno, 
        funcao_na_sessao, sessao_template_id, status_workflow, 
        created_at, created_by
      ) VALUES (?, ?, ?, ?, ?, 'RASCUNHO', ?, ?)
    `).bind(
      fichaUuid,
      agendamentoResult.meta.last_row_id,
      parseInt(colaborador_aluno_id.toString()),
      funcao_na_sessao || 'PIC',
      template_sessao_id ? parseInt(template_sessao_id.toString()) : null,
      new Date().toISOString(),
      'sistema'
    ).run();
    
    return c.json({
      success: true,
      agendamento: {
        id: agendamentoResult.meta.last_row_id,
        ficha_uuid: fichaUuid,
        data_inicio: dataHoraInicio.toLocaleDateString('pt-BR'),
        hora_inicio: dataHoraInicio.toTimeString().substring(0, 5),
        data_fim: dataHoraFim.toLocaleDateString('pt-BR'),
        hora_fim: dataHoraFim.toTimeString().substring(0, 5)
      }
    });
    
  } catch (error: any) {
    console.error('Erro ao criar agendamento:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// ✅ CORREÇÃO CRÍTICA 7: Corrigir relacionamentos órfãos
app.post('/relacionamentos/corrigir', requirePermission('simulador', 'UPDATE'), async (c) => {
  try {
    const db = c.env.DB;
    
    // Verificar fichas órfãs (sem agendamento)
    const result = await db.prepare(`
      SELECT id, ficha_uuid 
      FROM fichas_sessao 
      WHERE agendamento_slot_id IS NULL AND (deleted_at IS NULL OR deleted_at = '')
    `).all();
    
    const fichasOrfas = result.results || [];
    let fichasCorrigidas = 0;
    
    // Criar agendamentos para fichas órfãs
    for (const ficha of fichasOrfas) {
      const agendamentoResult = await db.prepare(`
        INSERT INTO agendamento_slots (
          data_inicio, data_fim, simulador_id, colaborador_id_instrutor,
          status_slot, created_at, created_by
        ) VALUES (?, ?, 1, 1, 'AGENDADO', ?, 'sistema_correcao')
      `).bind(
        new Date().toISOString(),
        new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // +2 horas
        new Date().toISOString()
      ).run();
      
      await db.prepare(`
        UPDATE fichas_sessao 
        SET agendamento_slot_id = ? 
        WHERE id = ?
      `).bind(agendamentoResult.meta.last_row_id, (ficha as any).id).run();
      
      fichasCorrigidas++;
    }
    
    return c.json({
      success: true,
      fichas_corrigidas: fichasCorrigidas,
      message: `${fichasCorrigidas} relacionamentos corrigidos`
    });
    
  } catch (error: any) {
    console.error('Erro ao corrigir relacionamentos:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// ✅ CORREÇÃO CRÍTICA 8: Estatísticas do simulador
app.get('/estatisticas', requirePermission('simulador', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    // Estatísticas de fichas por status
    const fichasPorStatus = await db.prepare(`
      SELECT 
        status_workflow,
        COUNT(*) as total
      FROM fichas_sessao 
      WHERE deleted_at IS NULL OR deleted_at = ''
      GROUP BY status_workflow
    `).all();
    
    // Estatísticas de resultados
    const fichasPorResultado = await db.prepare(`
      SELECT 
        resultado_final,
        COUNT(*) as total
      FROM fichas_sessao 
      WHERE resultado_final IS NOT NULL AND (deleted_at IS NULL OR deleted_at = '')
      GROUP BY resultado_final
    `).all();
    
    // Total de agendamentos
    const totalAgendamentos = await db.prepare(`
      SELECT COUNT(*) as total
      FROM agendamento_slots
    `).first();
    
    // Total de simuladores
    const totalSimuladores = await db.prepare(`
      SELECT COUNT(*) as total
      FROM simuladores 
      WHERE status = 'ATIVO' AND (deleted_at IS NULL OR deleted_at = '')
    `).first();
    
    return c.json({
      success: true,
      estatisticas: {
        fichas_por_status: fichasPorStatus.results || [],
        fichas_por_resultado: fichasPorResultado.results || [],
        total_agendamentos: (totalAgendamentos as any)?.total || 0,
        total_simuladores: (totalSimuladores as any)?.total || 0
      }
    });
    
  } catch (error: any) {
    console.error('Erro ao buscar estatísticas:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// ✅ GERAÇÃO DE PDF - Endpoint bonus
app.get('/ficha/:uuid/pdf', requirePermission('simulador', 'READ'), async (c) => {
  const { uuid } = c.req.param();
  
  try {
    const db = c.env.DB;
    
    // Buscar dados completos da ficha
    const ficha = await db.prepare(`
      SELECT 
        f.*,
        func.nome as funcionario_nome,
        func.matricula as funcionario_matricula,
        s.nome as simulador_nome,
        s.codigo_identificacao as simulador_codigo,
        inst.nome as instrutor_nome,
        st.nome_sessao as template_nome
      FROM fichas_sessao f
      LEFT JOIN funcionarios func ON f.colaborador_id_aluno = func.id
      LEFT JOIN agendamento_slots a ON f.agendamento_slot_id = a.id
      LEFT JOIN simuladores s ON a.simulador_id = s.id
      LEFT JOIN funcionarios inst ON a.colaborador_id_instrutor = inst.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.ficha_uuid = ?
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }
    
    // Buscar manobras executadas
    const result = await db.prepare(`
      SELECT 
        fme.nota,
        fme.observacoes,
        mc.manobra_id_codigo as codigo,
        mc.nome_manobra as nome
      FROM fichas_manobras_executadas fme
      LEFT JOIN manobras_catalogo mc ON fme.manobra_catalogo_id = mc.id
      WHERE fme.ficha_id = ?
    `).bind((ficha as any).id).all();
    
    const manobras = result.results || [];
    
    // Gerar HTML para PDF
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Ficha de Simulador - ${uuid}</title>
          <style>
            body { 
              font-family: Arial, sans-serif; 
              margin: 20px; 
              font-size: 12px;
            }
            .header { 
              text-align: center; 
              border-bottom: 2px solid #000; 
              padding-bottom: 10px; 
              margin-bottom: 20px;
            }
            .info { margin: 10px 0; }
            .info h3 { margin-bottom: 5px; color: #333; }
            table { 
              width: 100%; 
              border-collapse: collapse; 
              margin: 10px 0; 
            }
            th, td { 
              border: 1px solid #000; 
              padding: 8px; 
              text-align: left; 
            }
            th { background-color: #f0f0f0; }
            .status { 
              font-weight: bold; 
              padding: 5px; 
              border-radius: 3px;
            }
            .status.aprovado { background-color: #d4edda; color: #155724; }
            .status.reprovado { background-color: #f8d7da; color: #721c24; }
            .status.pendente { background-color: #fff3cd; color: #856404; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>FICHA DE AVALIAÇÃO DE SIMULADOR</h1>
            <p><strong>UUID:</strong> ${uuid}</p>
            <p><strong>Data de Criação:</strong> ${formatarDataBrasil((ficha as any).created_at)}</p>
          </div>
          
          <div class="info">
            <h3>Dados da Sessão</h3>
            <table>
              <tr><td><strong>Tripulante:</strong></td><td>${(ficha as any).funcionario_nome || 'N/A'}</td></tr>
              <tr><td><strong>Matrícula:</strong></td><td>${(ficha as any).funcionario_matricula || 'N/A'}</td></tr>
              <tr><td><strong>Simulador:</strong></td><td>${(ficha as any).simulador_nome || 'N/A'}</td></tr>
              <tr><td><strong>Código Simulador:</strong></td><td>${(ficha as any).simulador_codigo || 'N/A'}</td></tr>
              <tr><td><strong>Instrutor:</strong></td><td>${(ficha as any).instrutor_nome || 'N/A'}</td></tr>
              <tr><td><strong>Função na Sessão:</strong></td><td>${(ficha as any).funcao_na_sessao}</td></tr>
              <tr><td><strong>Template:</strong></td><td>${(ficha as any).template_nome || 'N/A'}</td></tr>
            </table>
          </div>
          
          <div class="info">
            <h3>Status do Workflow</h3>
            <p class="status ${((ficha as any).status_workflow || '').toLowerCase()}">
              ${(ficha as any).status_workflow}
            </p>
          </div>
          
          <div class="info">
            <h3>Avaliação das Manobras</h3>
            <table>
              <tr>
                <th>Código</th>
                <th>Manobra</th>
                <th>Nota</th>
                <th>Observações</th>
              </tr>
              ${manobras.map((manobra: any) => `
                <tr>
                  <td>${manobra.codigo || 'N/A'}</td>
                  <td>${manobra.nome || 'N/A'}</td>
                  <td style="text-align: center; font-weight: bold;">${manobra.nota}</td>
                  <td>${manobra.observacoes || '-'}</td>
                </tr>
              `).join('')}
            </table>
            ${manobras.length === 0 ? '<p><em>Nenhuma manobra executada ainda.</em></p>' : ''}
          </div>
          
          <div class="info">
            <h3>Resultado Final</h3>
            <table>
              <tr><td><strong>Conceito:</strong></td><td class="status ${((ficha as any).resultado_final || 'pendente').toLowerCase()}">${(ficha as any).resultado_final || 'Pendente'}</td></tr>
              <tr><td><strong>Nota Final:</strong></td><td>${(ficha as any).nota_final || 'N/A'}</td></tr>
            </table>
          </div>
          
          <div class="info">
            <h3>Observações do Instrutor</h3>
            <p>${(ficha as any).observacoes_instrutor || 'Nenhuma observação registrada.'}</p>
          </div>
          
          <div class="info">
            <h3>Observações do Aluno</h3>
            <p>${(ficha as any).observacoes_aluno || 'Nenhuma observação registrada.'}</p>
          </div>
          
          <div style="margin-top: 30px; font-size: 10px; color: #666; text-align: center;">
            <p>Documento gerado automaticamente pelo Sistema AirTrust em ${formatarDataBrasil(new Date())}</p>
          </div>
        </body>
      </html>
    `;
    
    return new Response(htmlContent, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': `attachment; filename="ficha_${uuid}.html"`
      }
    });
    
  } catch (error: any) {
    console.error('Erro ao gerar PDF:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

export default app;
