import { Hono } from 'hono';

const app = new Hono();

// GET /api/v2/simuladores/ciclos/listar
app.get('/listar', async (c) => {
  try {
    console.log('🔄 Carregando ciclos...');
    
    // Dados mock robustos para garantir funcionamento
    const ciclos = [
      { 
        id: 1, 
        numero_ciclo: 1,
        nome: 'Ciclo 2025-Q1', 
        descricao: 'Primeiro trimestre 2025',
        data_inicio: '2025-01-01', 
        data_fim: '2025-03-31', 
        status: 'ATIVO' 
      },
      { 
        id: 2, 
        numero_ciclo: 2,
        nome: 'Ciclo 2025-Q2', 
        descricao: 'Segundo trimestre 2025',
        data_inicio: '2025-04-01', 
        data_fim: '2025-06-30', 
        status: 'ATIVO' 
      },
      { 
        id: 3, 
        numero_ciclo: 3,
        nome: 'Ciclo 2025-Q3', 
        descricao: 'Terceiro trimestre 2025',
        data_inicio: '2025-07-01', 
        data_fim: '2025-09-30', 
        status: 'PLANEJADO' 
      }
    ];
    
    console.log(`✅ ${ciclos.length} ciclos carregados`);
    
    return c.json({ 
      success: true, 
      data: ciclos,
      total: ciclos.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Erro ao carregar ciclos:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao carregar ciclos',
      details: (error as Error).message 
    }, 500);
  }
});

// GET /api/v2/simuladores/ciclos (sem /listar)
app.get('/', async (c) => {
  return c.redirect('/api/v2/simuladores/ciclos/listar');
});

export default app;
