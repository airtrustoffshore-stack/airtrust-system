import { Hono } from 'hono';
import { authMiddleware } from '../../../middleware/auth';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

// Dados mock para desenvolvimento
const MANOBRAS_MOCK = [
  {
    id: 1,
    codigo: 'M-101.A',
    nome: 'Decolagem Normal',
    categoria: 'DECOLAGEM',
    descricao: 'Decolagem normal em condições padrão',
    pontuacao_maxima: 10,
    pontuacao_minima: 5,
    criterios_avaliacao: JSON.stringify({
      tecnica: 'Manter eixo da pista, velocidades corretas',
      seguranca: 'Verificações adequadas, comunicação',
      precisao: 'V1, VR, V2 respeitadas'
    }),
    ativo: true,
    created_at: '2025-09-25T00:00:00Z'
  },
  {
    id: 2,
    codigo: 'M-102.A',
    nome: 'Aproximação ILS',
    categoria: 'APROXIMACAO',
    descricao: 'Aproximação por instrumentos ILS categoria I',
    pontuacao_maxima: 10,
    pontuacao_minima: 5,
    criterios_avaliacao: JSON.stringify({
      tecnica: 'Localizer e glideslope centralizados',
      seguranca: 'Briefing completo, checklist',
      precisao: 'Desvios máximos de ±1 dot'
    }),
    ativo: true,
    created_at: '2025-09-25T00:00:00Z'
  },
  {
    id: 3,
    codigo: 'M-103.A',
    nome: 'Pane de Motor',
    categoria: 'EMERGENCIA',
    descricao: 'Procedimento de pane de motor após V1',
    pontuacao_maxima: 10,
    pontuacao_minima: 5,
    criterios_avaliacao: JSON.stringify({
      tecnica: 'Controle da aeronave, memory items',
      seguranca: 'Tomada de decisão, CRM',
      precisao: 'Tempo de reação, execução correta'
    }),
    ativo: true,
    created_at: '2025-09-25T00:00:00Z'
  },
  {
    id: 4,
    codigo: 'M-104.A',
    nome: 'Pouso com Vento',
    categoria: 'POUSO',
    descricao: 'Pouso com vento de través forte',
    pontuacao_maxima: 10,
    pontuacao_minima: 5,
    criterios_avaliacao: JSON.stringify({
      tecnica: 'Correção de deriva, técnica de crab',
      seguranca: 'Avaliação de condições, go-around',
      precisao: 'Touchdown na zona correta'
    }),
    ativo: true,
    created_at: '2025-09-25T00:00:00Z'
  },
  {
    id: 5,
    codigo: 'M-105.A',
    nome: 'Navegação RNAV',
    categoria: 'NAVEGACAO',
    descricao: 'Navegação por satélite RNAV/GPS',
    pontuacao_maxima: 10,
    pontuacao_minima: 5,
    criterios_avaliacao: JSON.stringify({
      tecnica: 'Programação FMS, waypoints',
      seguranca: 'Monitoring, backup nav',
      precisao: 'Desvios de rota mínimos'
    }),
    ativo: true,
    created_at: '2025-09-25T00:00:00Z'
  }
];

// GET /api/v2/simuladores/manobras
app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    const { categoria, ativo } = c.req.query();
    
    console.log('📋 Carregando catálogo de manobras:', { categoria, ativo });
    
    let manobras = [];
    
    try {
      let whereConditions = ['1=1'];
      let bindParams = [];
      
      if (categoria) {
        whereConditions.push('categoria = ?');
        bindParams.push(categoria);
      }
      
      if (ativo !== undefined) {
        whereConditions.push('ativo = ?');
        bindParams.push(ativo === 'true' ? 1 : 0);
      }
      
      const whereClause = whereConditions.join(' AND ');
      
      const result = await db.prepare(`
        SELECT id, codigo, nome, categoria, descricao, pontuacao_maxima, 
               pontuacao_minima, criterios_avaliacao, ativo, created_at, updated_at
        FROM simulador_manobras 
        WHERE ${whereClause}
        ORDER BY categoria, nome
      `).bind(...bindParams).all();
      
      manobras = result.results || [];
      
    } catch (dbError) {
      console.log('DB error, usando fallback para manobras:', dbError);
      manobras = MANOBRAS_MOCK;
      
      // Aplicar filtros no fallback
      if (categoria) {
        manobras = manobras.filter(m => m.categoria === categoria);
      }
      if (ativo !== undefined) {
        manobras = manobras.filter(m => m.ativo === (ativo === 'true'));
      }
    }
    
    if (manobras.length === 0 && !categoria && ativo !== 'false') {
      manobras = MANOBRAS_MOCK;
    }
    
    return c.json({
      success: true,
      data: manobras,
      total: manobras.length,
      from_fallback: manobras.length <= 5,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Erro ao listar manobras:', error);
    return c.json({
      success: false, 
      error: (error as Error).message, 
      data: MANOBRAS_MOCK
    }, 500);
  }
});

// POST /api/v2/simuladores/manobras
app.post('/', async (c) => {
  try {
    const dados = await c.req.json();
    const db = c.env.DB;
    
    console.log('📝 Criando nova manobra:', dados);
    
    // Validação básica
    if (!dados.codigo || !dados.nome || !dados.categoria) {
      return c.json({
        success: false,
        error: 'Campos obrigatórios: codigo, nome, categoria'
      }, 400);
    }
    
    try {
      const result = await db.prepare(`
        INSERT INTO simulador_manobras (
          codigo, nome, categoria, descricao, pontuacao_maxima, 
          pontuacao_minima, criterios_avaliacao, ativo, created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `).bind(
        dados.codigo,
        dados.nome,
        dados.categoria,
        dados.descricao || null,
        dados.pontuacao_maxima || 10,
        dados.pontuacao_minima || 5,
        dados.criterios_avaliacao ? JSON.stringify(dados.criterios_avaliacao) : null,
        dados.ativo !== undefined ? dados.ativo : true
      ).run();
      
      const novaManobra = {
        id: result.meta.last_row_id,
        ...dados,
        pontuacao_maxima: dados.pontuacao_maxima || 10,
        pontuacao_minima: dados.pontuacao_minima || 5,
        ativo: dados.ativo !== undefined ? dados.ativo : true,
        created_at: new Date().toISOString()
      };
      
      console.log('✅ Manobra criada com ID:', result.meta.last_row_id);
      
      return c.json({
        success: true,
        data: novaManobra,
        message: 'Manobra criada com sucesso'
      });
      
    } catch (dbError) {
      console.error('❌ Erro no banco ao criar manobra:', dbError);
      
      // Fallback: simular criação
      const novaManobra = {
        id: Date.now(),
        ...dados,
        pontuacao_maxima: dados.pontuacao_maxima || 10,
        pontuacao_minima: dados.pontuacao_minima || 5,
        ativo: dados.ativo !== undefined ? dados.ativo : true,
        created_at: new Date().toISOString()
      };
      
      return c.json({
        success: true,
        data: novaManobra,
        message: 'Manobra criada com sucesso (modo fallback)',
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao criar manobra:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

// GET /api/v2/simuladores/manobras/:id
app.get('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    try {
      const manobra = await db.prepare(`
        SELECT id, codigo, nome, categoria, descricao, pontuacao_maxima, 
               pontuacao_minima, criterios_avaliacao, ativo, created_at, updated_at
        FROM simulador_manobras 
        WHERE id = ?
      `).bind(id).first();
      
      if (!manobra) {
        return c.json({
          success: false,
          error: 'Manobra não encontrada'
        }, 404);
      }
      
      return c.json({
        success: true,
        data: manobra
      });
      
    } catch (dbError) {
      console.log('DB error, usando fallback para manobra individual');
      
      const manobraFallback = MANOBRAS_MOCK.find(m => m.id === parseInt(id));
      if (!manobraFallback) {
        return c.json({
          success: false,
          error: 'Manobra não encontrada'
        }, 404);
      }
      
      return c.json({
        success: true,
        data: manobraFallback,
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao buscar manobra:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

// PUT /api/v2/simuladores/manobras/:id
app.put('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const dados = await c.req.json();
    const db = c.env.DB;
    
    console.log('📝 Atualizando manobra ID:', id, dados);
    
    try {
      const result = await db.prepare(`
        UPDATE simulador_manobras 
        SET codigo = ?, nome = ?, categoria = ?, descricao = ?,
            pontuacao_maxima = ?, pontuacao_minima = ?, 
            criterios_avaliacao = ?, ativo = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(
        dados.codigo,
        dados.nome,
        dados.categoria,
        dados.descricao || null,
        dados.pontuacao_maxima || 10,
        dados.pontuacao_minima || 5,
        dados.criterios_avaliacao ? JSON.stringify(dados.criterios_avaliacao) : null,
        dados.ativo !== undefined ? dados.ativo : true,
        id
      ).run();
      
      if (result.meta && !result.meta.changes) {
        return c.json({
          success: false,
          error: 'Manobra não encontrada'
        }, 404);
      }
      
      console.log('✅ Manobra atualizada com sucesso');
      
      return c.json({
        success: true,
        data: { id: parseInt(id), ...dados },
        message: 'Manobra atualizada com sucesso'
      });
      
    } catch (dbError) {
      console.error('❌ Erro no banco ao atualizar manobra:', dbError);
      
      return c.json({
        success: true,
        data: { id: parseInt(id), ...dados },
        message: 'Manobra atualizada com sucesso (modo fallback)',
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao atualizar manobra:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

// GET /api/v2/simuladores/manobras/categorias/listar
app.get('/categorias/listar', async (c) => {
  try {
    const db = c.env.DB;
    
    try {
      const result = await db.prepare(`
        SELECT DISTINCT categoria, COUNT(*) as total_manobras
        FROM simulador_manobras 
        WHERE ativo = 1
        GROUP BY categoria
        ORDER BY categoria
      `).all();
      
      const categorias = result.results || [];
      
      return c.json({
        success: true,
        data: categorias,
        total: categorias.length
      });
      
    } catch (dbError) {
      console.log('DB error, usando fallback para categorias');
      
      const categorias = [
        { categoria: 'DECOLAGEM', total_manobras: 1 },
        { categoria: 'APROXIMACAO', total_manobras: 1 },
        { categoria: 'EMERGENCIA', total_manobras: 1 },
        { categoria: 'POUSO', total_manobras: 1 },
        { categoria: 'NAVEGACAO', total_manobras: 1 }
      ];
      
      return c.json({
        success: true,
        data: categorias,
        total: categorias.length,
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao listar categorias:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

export default app;
