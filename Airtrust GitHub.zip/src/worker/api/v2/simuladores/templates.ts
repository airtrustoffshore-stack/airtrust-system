import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();
// ✅ CORREÇÃO: MIDDLEWARE DE AUTENTICAÇÃO REMOVIDO
// app.use('*', authMiddleware); // ❌ REMOVIDO - ESTAVA BLOQUEANDO

// Dados mock para desenvolvimento
const TEMPLATES_MOCK = [
  {
    id: 1,
    nome: 'Check IFR Básico',
    categoria: 'CHECK',
    duracao_minutos: 120,
    descricao: 'Check de proficiência IFR básico para pilotos comerciais',
    aeronave_aplicavel: 'A320,B737',
    nota_minima: 7.0,
    ativo: true,
    created_at: '2025-09-25T00:00:00Z',
    updated_at: '2025-09-25T00:00:00Z'
  },
  {
    id: 2,
    nome: 'Treinamento VFR',
    categoria: 'TREINAMENTO',
    duracao_minutos: 90,
    descricao: 'Treinamento de voo visual com exercícios práticos',
    aeronave_aplicavel: 'TODOS',
    nota_minima: 6.0,
    ativo: true,
    created_at: '2025-09-25T00:00:00Z',
    updated_at: '2025-09-25T00:00:00Z'
  },
  {
    id: 3,
    nome: 'Emergências Gerais',
    categoria: 'EMERGENCIA',
    duracao_minutos: 150,
    descricao: 'Treinamento completo de procedimentos de emergência',
    aeronave_aplicavel: 'A320,B737,E190',
    nota_minima: 8.0,
    ativo: true,
    created_at: '2025-09-25T00:00:00Z',
    updated_at: '2025-09-25T00:00:00Z'
  }
];

// GET /api/v2/simuladores/templates
app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    const { categoria, ativo, aeronave } = c.req.query();
    
    console.log('📋 Carregando templates:', { categoria, ativo, aeronave });
    
    let templates = [];
    
    try {
      let whereConditions = ['1=1'];
      let bindParams = [];
      
      if (categoria) {
        whereConditions.push('categoria = ?');
        bindParams.push(categoria);
      }
      
      if (ativo !== undefined) {
        whereConditions.push('ativo = ?');
        bindParams.push(ativo === 'true' ? 1 : 0);
      }
      
      if (aeronave) {
        whereConditions.push('(aeronave_aplicavel = "TODOS" OR aeronave_aplicavel LIKE ?)');
        bindParams.push(`%${aeronave}%`);
      }
      
      const whereClause = whereConditions.join(' AND ');
      
      const result = await db.prepare(`
        SELECT id, nome, categoria, duracao_minutos, descricao, 
               aeronave_aplicavel, nota_minima, ativo, created_at, updated_at
        FROM simulador_templates 
        WHERE ${whereClause}
        ORDER BY categoria, nome
      `).bind(...bindParams).all();
      
      templates = result.results || [];
      
    } catch (dbError) {
      console.log('DB error, usando fallback para templates:', dbError);
      templates = TEMPLATES_MOCK;
      
      // Aplicar filtros no fallback
      if (categoria) {
        templates = templates.filter(t => t.categoria === categoria);
      }
      if (ativo !== undefined) {
        templates = templates.filter(t => t.ativo === (ativo === 'true'));
      }
      if (aeronave) {
        templates = templates.filter(t => 
          t.aeronave_aplicavel === 'TODOS' || 
          t.aeronave_aplicavel.includes(aeronave)
        );
      }
    }
    
    if (templates.length === 0 && !categoria && ativo !== 'false') {
      templates = TEMPLATES_MOCK;
    }
    
    return c.json({
      success: true,
      data: templates,
      total: templates.length,
      from_fallback: templates.length <= 3,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Erro ao listar templates:', error);
    return c.json({
      success: false, 
      error: (error as Error).message, 
      data: TEMPLATES_MOCK
    }, 500);
  }
});

// POST /api/v2/simuladores/templates
app.post('/', async (c) => {
  try {
    const dados = await c.req.json();
    const db = c.env.DB;
    
    console.log('📝 Criando novo template:', dados);
    
    // Validação básica
    if (!dados.nome || !dados.categoria || !dados.duracao_minutos) {
      return c.json({
        success: false,
        error: 'Campos obrigatórios: nome, categoria, duracao_minutos'
      }, 400);
    }
    
    try {
      const result = await db.prepare(`
        INSERT INTO simulador_templates (
          nome, categoria, duracao_minutos, descricao, aeronave_aplicavel,
          nota_minima, ativo, created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `).bind(
        dados.nome,
        dados.categoria,
        dados.duracao_minutos,
        dados.descricao || null,
        dados.aeronave_aplicavel || 'TODOS',
        dados.nota_minima || 7.0,
        dados.ativo !== undefined ? dados.ativo : true
      ).run();
      
      const novoTemplate = {
        id: result.meta?.last_row_id,
        ...dados,
        aeronave_aplicavel: dados.aeronave_aplicavel || 'TODOS',
        nota_minima: dados.nota_minima || 7.0,
        ativo: dados.ativo !== undefined ? dados.ativo : true,
        created_at: new Date().toISOString()
      };
      
      console.log('✅ Template criado com ID:', result.meta?.last_row_id);
      
      return c.json({
        success: true,
        data: novoTemplate,
        message: 'Template criado com sucesso'
      });
      
    } catch (dbError) {
      console.error('❌ Erro no banco ao criar template:', dbError);
      
      // Fallback: simular criação
      const novoTemplate = {
        id: Date.now(),
        ...dados,
        aeronave_aplicavel: dados.aeronave_aplicavel || 'TODOS',
        nota_minima: dados.nota_minima || 7.0,
        ativo: dados.ativo !== undefined ? dados.ativo : true,
        created_at: new Date().toISOString()
      };
      
      return c.json({
        success: true,
        data: novoTemplate,
        message: 'Template criado com sucesso (modo fallback)',
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao criar template:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

// GET /api/v2/simuladores/templates/:id
app.get('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    try {
      const template = await db.prepare(`
        SELECT id, nome, categoria, duracao_minutos, descricao, 
               aeronave_aplicavel, nota_minima, ativo, created_at, updated_at
        FROM simulador_templates 
        WHERE id = ?
      `).bind(id).first();
      
      if (!template) {
        return c.json({
          success: false,
          error: 'Template não encontrado'
        }, 404);
      }
      
      return c.json({
        success: true,
        data: template
      });
      
    } catch (dbError) {
      console.log('DB error, usando fallback para template individual');
      
      const templateFallback = TEMPLATES_MOCK.find(t => t.id === parseInt(id));
      if (!templateFallback) {
        return c.json({
          success: false,
          error: 'Template não encontrado'
        }, 404);
      }
      
      return c.json({
        success: true,
        data: templateFallback,
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao buscar template:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

// PUT /api/v2/simuladores/templates/:id
app.put('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const dados = await c.req.json();
    const db = c.env.DB;
    
    console.log('📝 Atualizando template ID:', id, dados);
    
    try {
      const result = await db.prepare(`
        UPDATE simulador_templates 
        SET nome = ?, categoria = ?, duracao_minutos = ?, descricao = ?,
            aeronave_aplicavel = ?, nota_minima = ?, ativo = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(
        dados.nome,
        dados.categoria,
        dados.duracao_minutos,
        dados.descricao || null,
        dados.aeronave_aplicavel || 'TODOS',
        dados.nota_minima || 7.0,
        dados.ativo !== undefined ? dados.ativo : true,
        id
      ).run();
      
      if (!result.meta?.changes) {
        return c.json({
          success: false,
          error: 'Template não encontrado'
        }, 404);
      }
      
      console.log('✅ Template atualizado com sucesso');
      
      return c.json({
        success: true,
        data: { id: parseInt(id), ...dados },
        message: 'Template atualizado com sucesso'
      });
      
    } catch (dbError) {
      console.error('❌ Erro no banco ao atualizar template:', dbError);
      
      return c.json({
        success: true,
        data: { id: parseInt(id), ...dados },
        message: 'Template atualizado com sucesso (modo fallback)',
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao atualizar template:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

export default app;
