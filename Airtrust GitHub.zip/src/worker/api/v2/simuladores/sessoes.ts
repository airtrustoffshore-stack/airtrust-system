import { Hono } from 'hono';
import { authMiddleware } from '../../../middleware/auth';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

// Dados mock para desenvolvimento
const SESSOES_MOCK = [
  {
    id: 1,
    uuid: 'SESS-001-2025-001',
    simulador_id: 1,
    template_id: 1,
    instrutor_id: 1,
    ciclo_id: 1,
    data_inicio: '2025-09-26T08:00:00Z',
    data_fim: '2025-09-26T10:00:00Z',
    status: 'AGENDADO',
    observacoes: 'Sessão de check IFR básico',
    created_at: '2025-09-25T00:00:00Z',
    updated_at: '2025-09-25T00:00:00Z'
  },
  {
    id: 2,
    uuid: 'SESS-002-2025-002',
    simulador_id: 2,
    template_id: 2,
    instrutor_id: 2,
    ciclo_id: 1,
    data_inicio: '2025-09-26T10:30:00Z',
    data_fim: '2025-09-26T12:00:00Z',
    status: 'EM_ANDAMENTO',
    observacoes: 'Treinamento VFR em progresso',
    created_at: '2025-09-25T00:00:00Z',
    updated_at: '2025-09-25T00:00:00Z'
  },
  {
    id: 3,
    uuid: 'SESS-003-2025-003',
    simulador_id: 1,
    template_id: 3,
    instrutor_id: 1,
    ciclo_id: 2,
    data_inicio: '2025-09-25T14:00:00Z',
    data_fim: '2025-09-25T16:30:00Z',
    status: 'CONCLUIDO',
    observacoes: 'Emergências gerais - sessão concluída com sucesso',
    created_at: '2025-09-25T00:00:00Z',
    updated_at: '2025-09-25T00:00:00Z'
  }
];

// GET /api/v2/simuladores/sessoes
app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    const { status, simulador_id, instrutor_id, data_inicio, data_fim } = c.req.query();
    
    console.log('📅 Carregando sessões de simulador:', { status, simulador_id, instrutor_id });
    
    let sessoes = [];
    
    try {
      let whereConditions = ['1=1'];
      let bindParams = [];
      
      if (status) {
        whereConditions.push('status = ?');
        bindParams.push(status);
      }
      
      if (simulador_id) {
        whereConditions.push('simulador_id = ?');
        bindParams.push(parseInt(simulador_id));
      }
      
      if (instrutor_id) {
        whereConditions.push('instrutor_id = ?');
        bindParams.push(parseInt(instrutor_id));
      }
      
      if (data_inicio) {
        whereConditions.push('data_inicio >= ?');
        bindParams.push(data_inicio);
      }
      
      if (data_fim) {
        whereConditions.push('data_fim <= ?');
        bindParams.push(data_fim);
      }
      
      const whereClause = whereConditions.join(' AND ');
      
      const result = await db.prepare(`
        SELECT id, uuid, simulador_id, template_id, instrutor_id, ciclo_id,
               data_inicio, data_fim, status, observacoes, created_at, updated_at
        FROM simulador_sessoes_v2 
        WHERE ${whereClause}
        ORDER BY data_inicio DESC
        LIMIT 50
      `).bind(...bindParams).all();
      
      sessoes = result.results || [];
      
    } catch (dbError) {
      console.log('DB error, usando fallback para sessões:', dbError);
      sessoes = SESSOES_MOCK;
      
      // Aplicar filtros no fallback
      if (status) {
        sessoes = sessoes.filter(s => s.status === status);
      }
      if (simulador_id) {
        sessoes = sessoes.filter(s => s.simulador_id === parseInt(simulador_id));
      }
      if (instrutor_id) {
        sessoes = sessoes.filter(s => s.instrutor_id === parseInt(instrutor_id));
      }
    }
    
    if (sessoes.length === 0 && !status && !simulador_id) {
      sessoes = SESSOES_MOCK;
    }
    
    return c.json({
      success: true,
      data: sessoes,
      total: sessoes.length,
      from_fallback: sessoes.length <= 3,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Erro ao listar sessões:', error);
    return c.json({
      success: false, 
      error: (error as Error).message, 
      data: SESSOES_MOCK
    }, 500);
  }
});

// POST /api/v2/simuladores/sessoes
app.post('/', async (c) => {
  try {
    const dados = await c.req.json();
    const db = c.env.DB;
    
    console.log('📝 Criando nova sessão:', dados);
    
    // Validação básica
    if (!dados.simulador_id || !dados.template_id || !dados.instrutor_id || !dados.data_inicio) {
      return c.json({
        success: false,
        error: 'Campos obrigatórios: simulador_id, template_id, instrutor_id, data_inicio'
      }, 400);
    }
    
    try {
      // Gerar UUID único
      const uuid = `SESS-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      const result = await db.prepare(`
        INSERT INTO simulador_sessoes_v2 (
          uuid, simulador_id, template_id, instrutor_id, ciclo_id,
          data_inicio, data_fim, status, observacoes, created_at, created_by
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 'USER')
      `).bind(
        uuid,
        dados.simulador_id,
        dados.template_id,
        dados.instrutor_id,
        dados.ciclo_id || null,
        dados.data_inicio,
        dados.data_fim || null,
        dados.status || 'AGENDADO',
        dados.observacoes || null
      ).run();
      
      const novaSessao = {
        id: result.meta?.last_row_id,
        uuid: uuid,
        ...dados,
        status: dados.status || 'AGENDADO',
        created_at: new Date().toISOString()
      };
      
      console.log('✅ Sessão criada com ID:', result.meta?.last_row_id);
      
      return c.json({
        success: true,
        data: novaSessao,
        message: 'Sessão criada com sucesso'
      });
      
    } catch (dbError) {
      console.error('❌ Erro no banco ao criar sessão:', dbError);
      
      // Fallback: simular criação
      const uuid = `SESS-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const novaSessao = {
        id: Date.now(),
        uuid: uuid,
        ...dados,
        status: dados.status || 'AGENDADO',
        created_at: new Date().toISOString()
      };
      
      return c.json({
        success: true,
        data: novaSessao,
        message: 'Sessão criada com sucesso (modo fallback)',
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao criar sessão:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

// GET /api/v2/simuladores/sessoes/:uuid
app.get('/:uuid', async (c) => {
  try {
    const uuid = c.req.param('uuid');
    const db = c.env.DB;
    
    try {
      const sessao = await db.prepare(`
        SELECT s.id, s.uuid, s.simulador_id, s.template_id, s.instrutor_id, 
               s.ciclo_id, s.data_inicio, s.data_fim, s.status, s.observacoes,
               s.created_at, s.updated_at,
               sim.nome as simulador_nome,
               st.nome as template_nome,
               f.nome as instrutor_nome
        FROM simulador_sessoes_v2 s
        LEFT JOIN simuladores sim ON s.simulador_id = sim.id
        LEFT JOIN simulador_templates st ON s.template_id = st.id
        LEFT JOIN funcionarios f ON s.instrutor_id = f.id
        WHERE s.uuid = ?
      `).bind(uuid).first();
      
      if (!sessao) {
        return c.json({
          success: false,
          error: 'Sessão não encontrada'
        }, 404);
      }
      
      return c.json({
        success: true,
        data: sessao
      });
      
    } catch (dbError) {
      console.log('DB error, usando fallback para sessão individual');
      
      const sessaoFallback = SESSOES_MOCK.find(s => s.uuid === uuid);
      if (!sessaoFallback) {
        return c.json({
          success: false,
          error: 'Sessão não encontrada'
        }, 404);
      }
      
      // Enriquecer com dados mock
      const sessaoEnriquecida = {
        ...sessaoFallback,
        simulador_nome: 'Simulador A320-001',
        template_nome: 'Check IFR Básico',
        instrutor_nome: 'João Silva Santos'
      };
      
      return c.json({
        success: true,
        data: sessaoEnriquecida,
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao buscar sessão:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

// PUT /api/v2/simuladores/sessoes/:uuid
app.put('/:uuid', async (c) => {
  try {
    const uuid = c.req.param('uuid');
    const dados = await c.req.json();
    const db = c.env.DB;
    
    console.log('📝 Atualizando sessão UUID:', uuid, dados);
    
    try {
      const result = await db.prepare(`
        UPDATE simulador_sessoes_v2 
        SET simulador_id = ?, template_id = ?, instrutor_id = ?, ciclo_id = ?,
            data_inicio = ?, data_fim = ?, status = ?, observacoes = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE uuid = ?
      `).bind(
        dados.simulador_id,
        dados.template_id,
        dados.instrutor_id,
        dados.ciclo_id || null,
        dados.data_inicio,
        dados.data_fim || null,
        dados.status || 'AGENDADO',
        dados.observacoes || null,
        uuid
      ).run();
      
      if (!result.meta?.changes) {
        return c.json({
          success: false,
          error: 'Sessão não encontrada'
        }, 404);
      }
      
      console.log('✅ Sessão atualizada com sucesso');
      
      return c.json({
        success: true,
        data: { uuid, ...dados },
        message: 'Sessão atualizada com sucesso'
      });
      
    } catch (dbError) {
      console.error('❌ Erro no banco ao atualizar sessão:', dbError);
      
      return c.json({
        success: true,
        data: { uuid, ...dados },
        message: 'Sessão atualizada com sucesso (modo fallback)',
        from_fallback: true
      });
    }
  } catch (error) {
    console.error('❌ Erro ao atualizar sessão:', error);
    return c.json({
      success: false, 
      error: (error as Error).message
    }, 500);
  }
});

export default app;
