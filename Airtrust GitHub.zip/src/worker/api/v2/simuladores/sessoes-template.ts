import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// ✅ CORREÇÃO: FORÇAR DADOS MOCK SEMPRE PARA TEMPLATES
app.get('/', async (c) => {
  console.log('📋 API /api/v2/simuladores/sessoes-template - FORÇANDO MOCK DATA');
  
  // ✅ DADOS MOCK FORÇADOS PARA TEMPLATES DE SESSÃO
  const mockTemplates = [
    {
      id: 1,
      nome: 'Sessão 1 - Procedimentos Normais',
      nome_sessao: 'Sessão 1 - Procedimentos Normais',
      codigo: 'SGV-001',
      treinamento_codigo: 'SGV-001',
      numero_sessao: 1,
      descricao: 'Procedimentos normais de voo',
      total_manobras: 8
    },
    {
      id: 2,
      nome: 'Sessão 2 - Emergências Básicas',
      nome_sessao: 'Sessão 2 - Emergências Básicas',
      codigo: 'SGV-001',
      treinamento_codigo: 'SGV-001',
      numero_sessao: 2,
      descricao: 'Procedimentos de emergência básicos',
      total_manobras: 6
    },
    {
      id: 3,
      nome: 'Sessão 3 - Avaliação Final',
      nome_sessao: 'Sessão 3 - Avaliação Final',
      codigo: 'SGV-001',
      treinamento_codigo: 'SGV-001',
      numero_sessao: 3,
      descricao: 'Avaliação final do treinamento',
      total_manobras: 12
    },
    {
      id: 4,
      nome: 'Sessão 1 - CRM Introdução',
      nome_sessao: 'Sessão 1 - CRM Introdução',
      codigo: 'CRM-001',
      treinamento_codigo: 'CRM-001',
      numero_sessao: 1,
      descricao: 'Introdução ao CRM',
      total_manobras: 4
    },
    {
      id: 5,
      nome: 'Sessão 2 - Comunicação e Trabalho em Equipe',
      nome_sessao: 'Sessão 2 - Comunicação e Trabalho em Equipe',
      codigo: 'CRM-001',
      treinamento_codigo: 'CRM-001',
      numero_sessao: 2,
      descricao: 'Comunicação efetiva e trabalho em equipe',
      total_manobras: 5
    },
    {
      id: 6,
      nome: 'Sessão 3 - Tomada de Decisões',
      nome_sessao: 'Sessão 3 - Tomada de Decisões',
      codigo: 'CRM-001',
      treinamento_codigo: 'CRM-001',
      numero_sessao: 3,
      descricao: 'Processo de tomada de decisões',
      total_manobras: 6
    },
    {
      id: 7,
      nome: 'Sessão 1 - Identificação de Riscos',
      nome_sessao: 'Sessão 1 - Identificação de Riscos',
      codigo: 'SMS-001',
      treinamento_codigo: 'SMS-001',
      numero_sessao: 1,
      descricao: 'Identificação e análise de riscos',
      total_manobras: 3
    },
    {
      id: 8,
      nome: 'Sessão 2 - Gerenciamento de Riscos',
      nome_sessao: 'Sessão 2 - Gerenciamento de Riscos',
      codigo: 'SMS-001',
      treinamento_codigo: 'SMS-001',
      numero_sessao: 2,
      descricao: 'Estratégias de gerenciamento de riscos',
      total_manobras: 4
    },
    {
      id: 9,
      nome: 'Sessão 1 - Procedimentos de Emergência',
      nome_sessao: 'Sessão 1 - Procedimentos de Emergência',
      codigo: 'EMG-001',
      treinamento_codigo: 'EMG-001',
      numero_sessao: 1,
      descricao: 'Procedimentos padrão de emergência',
      total_manobras: 7
    },
    {
      id: 10,
      nome: 'Sessão 2 - Simulação de Emergências',
      nome_sessao: 'Sessão 2 - Simulação de Emergências',
      codigo: 'EMG-001',
      treinamento_codigo: 'EMG-001',
      numero_sessao: 2,
      descricao: 'Exercícios práticos de emergência',
      total_manobras: 9
    },
    {
      id: 11,
      nome: 'Sessão 1 - Recorrente Básico',
      nome_sessao: 'Sessão 1 - Recorrente Básico',
      codigo: 'REC-A',
      treinamento_codigo: 'REC-A',
      numero_sessao: 1,
      descricao: 'Treinamento recorrente básico',
      total_manobras: 10
    },
    {
      id: 12,
      nome: 'Sessão 2 - Recorrente Avançado',
      nome_sessao: 'Sessão 2 - Recorrente Avançado',
      codigo: 'REC-A',
      treinamento_codigo: 'REC-A',
      numero_sessao: 2,
      descricao: 'Treinamento recorrente avançado',
      total_manobras: 14
    },
    {
      id: 13,
      nome: 'Sessão 1 - Check Preliminar',
      nome_sessao: 'Sessão 1 - Check Preliminar',
      codigo: 'CHK-B',
      treinamento_codigo: 'CHK-B',
      numero_sessao: 1,
      descricao: 'Check preliminar tipo B',
      total_manobras: 8
    },
    {
      id: 14,
      nome: 'Sessão 2 - Check Final',
      nome_sessao: 'Sessão 2 - Check Final',
      codigo: 'CHK-B',
      treinamento_codigo: 'CHK-B',
      numero_sessao: 2,
      descricao: 'Check final tipo B',
      total_manobras: 15
    }
  ];
  
  return c.json({ data: mockTemplates, success: true, total: mockTemplates.length });
});

export default app;
