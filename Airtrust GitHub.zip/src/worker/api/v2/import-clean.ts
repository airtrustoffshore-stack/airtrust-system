import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// Função helper para parsear CSV simples (sem dependências externas)
function parseCSV(csvText: string): Array<Record<string, string>> {
  const lines = csvText.trim().split('\n');
  if (lines.length < 2) return [];
  
  // Parse header
  const header = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
  
  // Parse data rows
  const data: Array<Record<string, string>> = [];
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
    if (values.length === header.length) {
      const row: Record<string, string> = {};
      header.forEach((col, idx) => {
        row[col.toLowerCase().replace(/\s+/g, '_')] = values[idx] || '';
      });
      data.push(row);
    }
  }
  
  return data;
}

// POST /api/v2/import-clean/treinamentos - Importação SIMPLES de treinamentos
app.post('/treinamentos', requirePermission('treinamentos', 'CREATE'), async (c) => {
  const startTime = Date.now();
  
  try {
    const db = c.env.DB;
    let csvData: Array<Record<string, string>> = [];

    // Tentar múltiplos formatos de entrada
    const contentType = c.req.header('content-type') || '';

    if (contentType.includes('multipart/form-data')) {
      const formData = await c.req.formData();
      const file = formData.get('file') as File;
      
      if (!file) {
        return c.json({ success: false, error: 'Arquivo não fornecido' }, 400);
      }
      
      const csvText = await file.text();
      csvData = parseCSV(csvText);
    } else if (contentType.includes('application/json')) {
      const jsonBody = await c.req.json();
      
      if (jsonBody.csv_data) {
        csvData = parseCSV(jsonBody.csv_data);
      } else if (jsonBody.data && Array.isArray(jsonBody.data)) {
        csvData = jsonBody.data;
      } else {
        return c.json({ 
          success: false,
          error: 'Formato JSON inválido. Use: { data: [...] } ou { csv_data: "..." }' 
        }, 400);
      }
    }

    if (!csvData || csvData.length === 0) {
      return c.json({ success: false, error: 'Nenhum dado válido encontrado' }, 400);
    }

    let processadas = 0;
    let criadas = 0;
    let atualizadas = 0;
    let erros = 0;

    // Processar cada linha - LÓGICA SIMPLES
    for (const registro of csvData) {
      try {
        // Validação básica
        if (!registro.codigo || !registro.nome) {
          erros++;
          continue;
        }

        // Find-or-create pattern simples
        const existing = await db.prepare(
          'SELECT id FROM catalogo_treinamentos_v2 WHERE codigo = ? AND deleted_at IS NULL'
        ).bind(registro.codigo).first();

        if (existing) {
          // UPDATE simples
          await db.prepare(`
            UPDATE catalogo_treinamentos_v2 
            SET nome = ?, categoria = ?, updated_at = CURRENT_TIMESTAMP
            WHERE codigo = ? AND deleted_at IS NULL
          `).bind(
            registro.nome,
            registro.categoria || 'IMPORTADO',
            registro.codigo
          ).run();
          atualizadas++;
        } else {
          // CREATE simples
          await db.prepare(`
            INSERT INTO catalogo_treinamentos_v2 (
              codigo, nome, categoria, ativo, created_at, updated_at
            ) VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(
            registro.codigo,
            registro.nome,
            registro.categoria || 'IMPORTADO'
          ).run();
          criadas++;
        }
        
        processadas++;
      } catch (error) {
        erros++;
      }
    }

    const processTime = Date.now() - startTime;

    // Log simples de auditoria
    await logAudit(c, 'IMPORT_TREINAMENTOS', 'catalogo_treinamentos_v2', undefined, undefined, {
      processadas, criadas, atualizadas, erros, duracao_ms: processTime
    });

    return c.json({
      success: true,
      processadas,
      criadas,
      atualizadas,
      erros,
      duracao_ms: processTime,
      message: `Importação concluída: ${criadas} criados, ${atualizadas} atualizados, ${erros} erros`
    });

  } catch (error) {
    console.error('Erro na importação:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno'
    }, 500);
  }
});

// POST /api/v2/import-clean/certificacoes - Importação SIMPLES de certificações
app.post('/certificacoes', requirePermission('treinamentos', 'CREATE'), async (c) => {
  const startTime = Date.now();
  
  try {
    const db = c.env.DB;
    let csvData: Array<Record<string, string>> = [];

    // Entrada de dados igual ao de treinamentos
    const contentType = c.req.header('content-type') || '';

    if (contentType.includes('multipart/form-data')) {
      const formData = await c.req.formData();
      const file = formData.get('file') as File;
      
      if (!file) {
        return c.json({ success: false, error: 'Arquivo não fornecido' }, 400);
      }
      
      const csvText = await file.text();
      csvData = parseCSV(csvText);
    } else if (contentType.includes('application/json')) {
      const jsonBody = await c.req.json();
      
      if (jsonBody.csv_data) {
        csvData = parseCSV(jsonBody.csv_data);
      } else if (jsonBody.data && Array.isArray(jsonBody.data)) {
        csvData = jsonBody.data;
      } else {
        return c.json({ success: false, error: 'Formato JSON inválido' }, 400);
      }
    }

    if (!csvData || csvData.length === 0) {
      return c.json({ success: false, error: 'Nenhum dado válido encontrado' }, 400);
    }

    let processadas = 0;
    let criadas = 0;
    let erros = 0;

    // Processar cada certificação - LÓGICA SIMPLES
    for (const registro of csvData) {
      try {
        // Validação básica
        if (!registro.funcionario_matricula || !registro.treinamento_codigo || !registro.data_conclusao) {
          erros++;
          continue;
        }

        // 1. Buscar funcionário
        const funcionario = await db.prepare(
          'SELECT id FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL'
        ).bind(registro.funcionario_matricula).first();

        if (!funcionario) {
          erros++;
          continue;
        }

        // 2. Buscar ou criar treinamento
        let treinamento = await db.prepare(
          'SELECT id FROM catalogo_treinamentos_v2 WHERE codigo = ? AND deleted_at IS NULL'
        ).bind(registro.treinamento_codigo).first();

        if (!treinamento) {
          // Auto-criar treinamento
          const insertResult = await db.prepare(`
            INSERT INTO catalogo_treinamentos_v2 (
              codigo, nome, categoria, ativo, created_at, updated_at
            ) VALUES (?, ?, 'AUTO_CRIADO', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(
            registro.treinamento_codigo,
            registro.treinamento_nome || `Auto: ${registro.treinamento_codigo}`
          ).run();
          
          if (insertResult.success && insertResult.meta?.last_row_id) {
            treinamento = { id: insertResult.meta.last_row_id };
          } else {
            erros++;
            continue;
          }
        }

        // 3. Inserir certificação
        await db.prepare(`
          INSERT INTO historico_certificacoes_v2 (
            funcionario_id, treinamento_id, data_conclusao, data_vencimento,
            instrutor, nota_final, status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, 'ATIVO', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `).bind(
          funcionario.id,
          treinamento.id,
          registro.data_conclusao,
          registro.data_vencimento || null,
          registro.instrutor || null,
          registro.nota_final ? parseFloat(registro.nota_final) : null
        ).run();

        criadas++;
        processadas++;
      } catch (error) {
        erros++;
      }
    }

    const processTime = Date.now() - startTime;

    // Log simples de auditoria
    await logAudit(c, 'IMPORT_CERTIFICACOES', 'historico_certificacoes_v2', undefined, undefined, {
      processadas, criadas, erros, duracao_ms: processTime
    });

    return c.json({
      success: true,
      processadas,
      criadas,
      erros,
      duracao_ms: processTime,
      message: `Importação concluída: ${criadas} certificações criadas, ${erros} erros`
    });

  } catch (error) {
    console.error('Erro na importação:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno'
    }, 500);
  }
});

export default app;
