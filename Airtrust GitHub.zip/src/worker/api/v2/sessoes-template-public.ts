import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// GET /api/v2/sessoes-template-public - Listar sessões template (sem autenticação para dropdown)
app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    const treinamento_codigo = c.req.query('treinamento_codigo');
    
    console.log('📋 Carregando sessões template para dropdown...', { treinamento_codigo });
    
    let whereClause = '';
    const params = [];
    
    if (treinamento_codigo) {
      whereClause = 'WHERE st.treinamento_codigo = ?';
      params.push(treinamento_codigo);
    }
    
    const stmt = db.prepare(`
      SELECT st.id, st.treinamento_codigo, st.numero_sessao, st.nome_sessao,
             st.descricao, st.created_at, st.updated_at,
             COUNT(stm.manobra_catalogo_id) as total_manobras
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      ${whereClause}
      GROUP BY st.id
      ORDER BY st.treinamento_codigo, st.numero_sessao
    `);
    
    const result = await stmt.bind(...params).all();
    const sessoes = result.results;

    console.log(`✅ ${sessoes?.length || 0} sessões template carregadas`);
    
    return c.json({
      success: true,
      data: sessoes,
      total: sessoes?.length || 0
    });
  } catch (error) {
    console.error('❌ Erro ao carregar sessões template:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

// GET /api/v2/sessoes-template-public/treinamento/:id - Templates por treinamento ID
app.get('/treinamento/:id', async (c) => {
  try {
    const db = c.env.DB;
    const treinamentoId = c.req.param('id');
    
    console.log(`📋 Carregando templates para treinamento ID: ${treinamentoId}`);
    
    // Buscar treinamento primeiro
    const treinamento = await db.prepare(`
      SELECT codigo, nome 
      FROM catalogo_treinamentos_v2 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(treinamentoId).first();

    if (!treinamento) {
      return c.json({ 
        error: 'Treinamento não encontrado',
        treinamento_id: treinamentoId 
      }, 404);
    }

    // Buscar templates do treinamento
    const templates = await db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo,
        st.numero_sessao,
        st.nome_sessao,
        st.descricao,
        st.created_at,
        COUNT(stm.manobra_catalogo_id) as total_manobras
      FROM sessoes_template st
      LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
      WHERE st.treinamento_codigo = ?
      GROUP BY st.id
      ORDER BY st.numero_sessao ASC
    `).bind(treinamento.codigo).all();

    const templatesFormatados = templates.results.map((t: any) => ({
      id: t.id,
      codigo: t.treinamento_codigo,
      nome: t.nome_sessao,
      descricao: t.descricao,
      numero_sessao: t.numero_sessao,
      total_manobras: t.total_manobras || 0
    }));

    console.log(`✅ ${templatesFormatados.length} templates carregados para treinamento ${treinamento.nome}`);

    return c.json({
      success: true,
      treinamento: {
        id: treinamentoId,
        codigo: treinamento.codigo,
        nome: treinamento.nome
      },
      templates: templatesFormatados,
      data: templatesFormatados,
      total: templatesFormatados.length
    });

  } catch (error) {
    console.error('❌ Erro ao buscar templates por treinamento:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

export default app;
