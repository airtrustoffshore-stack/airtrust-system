import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    // Buscar todas as sessões com detalhes
    const sessoes = await db.prepare(`
      SELECT 
        fs.ficha_uuid,
        fs.status_workflow,
        fs.resultado_final,
        fs.nota_final,
        fs.created_at,
        as_slot.data_inicio,
        as_slot.data_fim,
        as_slot.status_slot,
        s.nome as simulador_nome,
        s.codigo_identificacao as simulador_codigo,
        f.nome as colaborador_nome,
        f.matricula as colaborador_matricula,
        instrutor.nome as instrutor_nome,
        st.nome_sessao as template_nome
      FROM fichas_sessao fs
      JOIN agendamento_slots as_slot ON fs.agendamento_slot_id = as_slot.id
      LEFT JOIN simuladores s ON as_slot.simulador_id = s.id
      LEFT JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      LEFT JOIN funcionarios instrutor ON as_slot.colaborador_id_instrutor = instrutor.id
      LEFT JOIN sessoes_template st ON fs.sessao_template_id = st.id
      ORDER BY as_slot.data_inicio DESC
      LIMIT 50
    `).all();
    
    const sessoesFormatadas = (sessoes.results || []).map((sessao: any) => ({
      ficha_uuid: sessao.ficha_uuid,
      status_workflow: sessao.status_workflow,
      resultado_final: sessao.resultado_final,
      nota_final: sessao.nota_final,
      data_sessao: sessao.data_inicio,
      data_fim: sessao.data_fim,
      status_slot: sessao.status_slot,
      simulador: {
        nome: sessao.simulador_nome || 'N/A',
        codigo: sessao.simulador_codigo || 'N/A'
      },
      colaborador: {
        nome: sessao.colaborador_nome || 'N/A',
        matricula: sessao.colaborador_matricula || 'N/A'
      },
      instrutor: {
        nome: sessao.instrutor_nome || 'N/A'
      },
      template: {
        nome: sessao.template_nome || 'N/A'
      },
      created_at: sessao.created_at
    }));
    
    // Calcular estatísticas
    const totalSessoes = sessoesFormatadas.length;
    const sessoesAprovadas = sessoesFormatadas.filter((s: any) => s.resultado_final === 'APROVADO').length;
    const sessoesReprovadas = sessoesFormatadas.filter((s: any) => s.resultado_final === 'REPROVADO').length;
    const sessoesPendentes = sessoesFormatadas.filter((s: any) => !s.resultado_final).length;
    
    return c.json({
      success: true,
      sessoes: sessoesFormatadas,
      estatisticas: {
        total: totalSessoes,
        aprovadas: sessoesAprovadas,
        reprovadas: sessoesReprovadas,
        pendentes: sessoesPendentes,
        taxa_aprovacao: totalSessoes > 0 ? Math.round((sessoesAprovadas / totalSessoes) * 100) : 0
      }
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar sessões:', error);
    return c.json({ 
      error: 'Erro ao buscar sessões',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET - Buscar sessões por colaborador
app.get('/colaborador/:id', async (c) => {
  try {
    const db = c.env.DB;
    const { id } = c.req.param();
    
    const sessoes = await db.prepare(`
      SELECT 
        fs.ficha_uuid,
        fs.status_workflow,
        fs.resultado_final,
        fs.nota_final,
        as_slot.data_inicio,
        s.nome as simulador_nome
      FROM fichas_sessao fs
      JOIN agendamento_slots as_slot ON fs.agendamento_slot_id = as_slot.id
      LEFT JOIN simuladores s ON as_slot.simulador_id = s.id
      WHERE fs.colaborador_id_aluno = ?
      ORDER BY as_slot.data_inicio DESC
      LIMIT 20
    `).bind(id).all();
    
    return c.json({
      success: true,
      sessoes: sessoes.results || [],
      colaborador_id: id
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar sessões do colaborador:', error);
    return c.json({ 
      error: 'Erro ao buscar sessões do colaborador',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET - Buscar sessões por simulador
app.get('/simulador/:id', async (c) => {
  try {
    const db = c.env.DB;
    const { id } = c.req.param();
    
    const sessoes = await db.prepare(`
      SELECT 
        fs.ficha_uuid,
        fs.status_workflow,
        fs.resultado_final,
        as_slot.data_inicio,
        f.nome as colaborador_nome
      FROM fichas_sessao fs
      JOIN agendamento_slots as_slot ON fs.agendamento_slot_id = as_slot.id
      LEFT JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      WHERE as_slot.simulador_id = ?
      ORDER BY as_slot.data_inicio DESC
      LIMIT 20
    `).bind(id).all();
    
    return c.json({
      success: true,
      sessoes: sessoes.results || [],
      simulador_id: id
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar sessões do simulador:', error);
    return c.json({ 
      error: 'Erro ao buscar sessões do simulador',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
