import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.use('*', authMiddleware);

// GET /api/v2/simulador/agendamentos - Listar todos os agendamentos
app.get('/', async (c) => {
  try {
    const db = c.env.DB;

    const agendamentos = await db.prepare(`
      SELECT 
        ags.id,
        ags.simulador_id,
        ags.colaborador_id_instrutor,
        ags.colaborador_id_checador,
        ags.data_inicio,
        ags.data_fim,
        ags.status_slot,
        ags.created_at,
        s.nome as simulador_nome,
        s.codigo_identificacao as simulador_codigo,
        fi.nome as instrutor_nome,
        fc.nome as checador_nome,
        COUNT(fs.id) as total_fichas
      FROM agendamento_slots ags
      LEFT JOIN simuladores s ON ags.simulador_id = s.id
      LEFT JOIN funcionarios fi ON ags.colaborador_id_instrutor = fi.id
      LEFT JOIN funcionarios fc ON ags.colaborador_id_checador = fc.id
      LEFT JOIN fichas_sessao fs ON fs.agendamento_slot_id = ags.id
      GROUP BY ags.id
      ORDER BY ags.data_inicio DESC
    `).all();

    const agendamentosFormatados = agendamentos.results.map((a: any) => ({
      id: a.id,
      simulador: {
        id: a.simulador_id,
        nome: a.simulador_nome || 'N/A',
        codigo: a.simulador_codigo || 'N/A'
      },
      instrutor: {
        id: a.colaborador_id_instrutor,
        nome: a.instrutor_nome || 'N/A'
      },
      checador: a.colaborador_id_checador ? {
        id: a.colaborador_id_checador,
        nome: a.checador_nome || 'N/A'
      } : null,
      data_inicio: a.data_inicio,
      data_fim: a.data_fim,
      status: a.status_slot,
      total_fichas: a.total_fichas || 0,
      created_at: a.created_at
    }));

    return c.json({
      success: true,
      agendamentos: agendamentosFormatados,
      total: agendamentosFormatados.length
    });

  } catch (error) {
    console.error('❌ Erro ao listar agendamentos:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

// POST /api/v2/simulador/agendamentos - Criar novo agendamento
app.post('/', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();

    const { 
      simulador_id, 
      instrutor_id, 
      checador_id, 
      data_inicio, 
      data_fim,
      participantes = []
    } = body;

    // Validações básicas
    if (!simulador_id || !instrutor_id || !data_inicio || !data_fim) {
      return c.json({ 
        error: 'Campos obrigatórios: simulador_id, instrutor_id, data_inicio, data_fim' 
      }, 400);
    }

    // Criar slot de agendamento
    const resultSlot = await db.prepare(`
      INSERT INTO agendamento_slots (
        simulador_id,
        colaborador_id_instrutor,
        colaborador_id_checador,
        data_inicio,
        data_fim,
        status_slot,
        created_at,
        created_by
      ) VALUES (?, ?, ?, ?, ?, 'AGENDADO', datetime('now'), 'SISTEMA')
    `).bind(
      simulador_id,
      instrutor_id,
      checador_id || null,
      data_inicio,
      data_fim
    ).run();

    const slotId = resultSlot.meta.last_row_id;

    // Criar fichas para os participantes
    for (const participante of participantes) {
      const fichaUuid = `FICHA-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      await db.prepare(`
        INSERT INTO fichas_sessao (
          ficha_uuid,
          agendamento_slot_id,
          colaborador_id_aluno,
          funcao_na_sessao,
          sessao_template_id,
          ciclo_executado,
          status_workflow,
          created_at,
          created_by
        ) VALUES (?, ?, ?, ?, ?, ?, 'RASCUNHO', datetime('now'), 'SISTEMA')
      `).bind(
        fichaUuid,
        slotId,
        participante.colaborador_id,
        participante.funcao || 'PIC',
        participante.template_id || null,
        participante.ciclo || 1
      ).run();
    }

    return c.json({
      success: true,
      message: 'Agendamento criado com sucesso',
      slot_id: slotId,
      participantes_adicionados: participantes.length
    });

  } catch (error) {
    console.error('❌ Erro ao criar agendamento:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

// PUT /api/v2/simulador/agendamentos/:id - Editar agendamento
app.put('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    const body = await c.req.json();

    const { 
      simulador_id, 
      instrutor_id, 
      checador_id, 
      data_inicio, 
      data_fim,
      status_slot
    } = body;

    await db.prepare(`
      UPDATE agendamento_slots 
      SET 
        simulador_id = ?,
        colaborador_id_instrutor = ?,
        colaborador_id_checador = ?,
        data_inicio = ?,
        data_fim = ?,
        status_slot = ?,
        updated_at = datetime('now'),
        updated_by = 'SISTEMA'
      WHERE id = ?
    `).bind(
      simulador_id,
      instrutor_id,
      checador_id || null,
      data_inicio,
      data_fim,
      status_slot || 'AGENDADO',
      id
    ).run();

    return c.json({
      success: true,
      message: 'Agendamento atualizado com sucesso'
    });

  } catch (error) {
    console.error('❌ Erro ao editar agendamento:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

// DELETE /api/v2/simulador/agendamentos/:id - Excluir agendamento
app.delete('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');

    // Verificar se existem fichas associadas
    const fichas = await db.prepare(`
      SELECT COUNT(*) as total 
      FROM fichas_sessao 
      WHERE agendamento_slot_id = ?
    `).bind(id).first();

    if (fichas && fichas.total > 0) {
      return c.json({ 
        error: 'Não é possível excluir agendamento com fichas associadas',
        total_fichas: fichas.total
      }, 400);
    }

    await db.prepare(`
      DELETE FROM agendamento_slots WHERE id = ?
    `).bind(id).run();

    return c.json({
      success: true,
      message: 'Agendamento excluído com sucesso'
    });

  } catch (error) {
    console.error('❌ Erro ao excluir agendamento:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: (error as Error).message 
    }, 500);
  }
});

export default app;
