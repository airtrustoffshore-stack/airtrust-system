import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';

const auditIntegrityApi = new Hono<{ Bindings: Env }>();

// Apply auth middleware
auditIntegrityApi.use('*', authMiddleware);

// Interface para resultados de auditoria
interface AuditIssue {
  tabela: string;
  problema: string;
  gravidade: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  detalhes: string;
  query_correcao?: string;
  registros_afetados?: number;
}

interface AuditResult {
  data_execucao: string;
  total_problemas: number;
  problemas_por_gravidade: Record<string, number>;
  problemas: AuditIssue[];
  acoes_executadas: string[];
  tempo_execucao_ms: number;
}

// POST /api/v2/audit/integrity/run - Executar auditoria de integridade
auditIntegrityApi.post('/run', requirePermission('system', 'ADMIN'), async (c) => {
  const startTime = Date.now();
  
  try {
    const db = c.env.DB;
    const autofix = c.req.query('autofix') === 'true';
    
    const problemas: AuditIssue[] = [];
    const acoesExecutadas: string[] = [];

    // 1. VERIFICAR SLOTS ÓRFÃOS (sem simulador)
    const slotsOrfaos = await db.prepare(`
      SELECT COUNT(*) as count FROM agendamento_slots 
      WHERE simulador_id NOT IN (SELECT id FROM simuladores WHERE deleted_at IS NULL)
    `).first();

    if (slotsOrfaos && Number(slotsOrfaos.count) > 0) {
      problemas.push({
        tabela: 'agendamento_slots',
        problema: 'Slots referenciando simuladores inexistentes',
        gravidade: 'HIGH',
        detalhes: `${Number(slotsOrfaos.count)} slots órfãos encontrados`,
        query_correcao: 'UPDATE agendamento_slots SET status_slot = "CANCELADO" WHERE simulador_id NOT IN (SELECT id FROM simuladores WHERE deleted_at IS NULL)',
        registros_afetados: Number(slotsOrfaos.count)
      });

      if (autofix) {
        await db.prepare(`
          UPDATE agendamento_slots 
          SET status_slot = 'CANCELADO', updated_at = CURRENT_TIMESTAMP 
          WHERE simulador_id NOT IN (SELECT id FROM simuladores WHERE deleted_at IS NULL)
        `).run();
        acoesExecutadas.push(`Cancelados ${Number(slotsOrfaos.count)} slots órfãos`);
      }
    }

    // 2. VERIFICAR FICHAS SEM SLOT
    const fichasSemSlot = await db.prepare(`
      SELECT COUNT(*) as count FROM fichas_sessao 
      WHERE agendamento_slot_id NOT IN (SELECT id FROM agendamento_slots)
    `).first();

    if (fichasSemSlot && Number(fichasSemSlot.count) > 0) {
      problemas.push({
        tabela: 'fichas_sessao',
        problema: 'Fichas sem slot de agendamento válido',
        gravidade: 'CRITICAL',
        detalhes: `${Number(fichasSemSlot.count)} fichas órfãs encontradas`,
        query_correcao: 'UPDATE fichas_sessao SET deleted_at = CURRENT_TIMESTAMP WHERE agendamento_slot_id NOT IN (SELECT id FROM agendamento_slots)',
        registros_afetados: Number(fichasSemSlot.count)
      });

      if (autofix) {
        await db.prepare(`
          UPDATE fichas_sessao 
          SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
          WHERE agendamento_slot_id NOT IN (SELECT id FROM agendamento_slots)
        `).run();
        acoesExecutadas.push(`Removidas ${Number(fichasSemSlot.count)} fichas órfãs`);
      }
    }

    // 3. VERIFICAR DUPLICIDADE DE UUIDs
    const uuidsDuplicados = await db.prepare(`
      SELECT ficha_uuid, COUNT(*) as count 
      FROM fichas_sessao 
      WHERE deleted_at IS NULL
      GROUP BY ficha_uuid 
      HAVING COUNT(*) > 1
    `).all();

    if (uuidsDuplicados.results.length > 0) {
      problemas.push({
        tabela: 'fichas_sessao',
        problema: 'UUIDs duplicados em fichas ativas',
        gravidade: 'CRITICAL',
        detalhes: `${uuidsDuplicados.results.length} UUIDs duplicados`,
        registros_afetados: uuidsDuplicados.results.reduce((acc: number, item: any) => acc + item.count, 0)
      });

      if (autofix) {
        // Para cada UUID duplicado, manter apenas o mais recente
        for (const item of uuidsDuplicados.results) {
          await db.prepare(`
            UPDATE fichas_sessao 
            SET deleted_at = CURRENT_TIMESTAMP 
            WHERE ficha_uuid = ? 
            AND id NOT IN (
              SELECT id FROM (
                SELECT id FROM fichas_sessao 
                WHERE ficha_uuid = ? 
                ORDER BY created_at DESC 
                LIMIT 1
              ) t
            )
          `).bind(item.ficha_uuid, item.ficha_uuid).run();
        }
        acoesExecutadas.push(`Corrigidos ${uuidsDuplicados.results.length} UUIDs duplicados`);
      }
    }

    // 4. VERIFICAR STATUS INVÁLIDOS
    const statusInvalidosSlots = await db.prepare(`
      SELECT COUNT(*) as count FROM agendamento_slots 
      WHERE status_slot NOT IN ('AGENDADO', 'EM_ANDAMENTO', 'CONCLUIDO', 'CANCELADO')
    `).first();

    if (statusInvalidosSlots && Number(statusInvalidosSlots.count) > 0) {
      problemas.push({
        tabela: 'agendamento_slots',
        problema: 'Status inválidos em slots',
        gravidade: 'MEDIUM',
        detalhes: `${Number(statusInvalidosSlots.count)} slots com status inválido`,
        query_correcao: 'UPDATE agendamento_slots SET status_slot = "AGENDADO" WHERE status_slot NOT IN (\'AGENDADO\', \'EM_ANDAMENTO\', \'CONCLUIDO\', \'CANCELADO\')',
        registros_afetados: Number(statusInvalidosSlots.count)
      });

      if (autofix) {
        await db.prepare(`
          UPDATE agendamento_slots 
          SET status_slot = 'AGENDADO', updated_at = CURRENT_TIMESTAMP 
          WHERE status_slot NOT IN ('AGENDADO', 'EM_ANDAMENTO', 'CONCLUIDO', 'CANCELADO')
        `).run();
        acoesExecutadas.push(`Corrigidos ${Number(statusInvalidosSlots.count)} status inválidos em slots`);
      }
    }

    const statusInvalidosFichas = await db.prepare(`
      SELECT COUNT(*) as count FROM fichas_sessao 
      WHERE status_workflow NOT IN ('RASCUNHO', 'PENDENTE_ALUNO', 'PENDENTE_INSTRUTOR_FINAL', 'PENDENTE_CHECK', 'CONCLUIDA', 'REPROVADA', 'CANCELADO')
      AND deleted_at IS NULL
    `).first();

    if (statusInvalidosFichas && Number(statusInvalidosFichas.count) > 0) {
      problemas.push({
        tabela: 'fichas_sessao',
        problema: 'Status workflow inválidos',
        gravidade: 'MEDIUM',
        detalhes: `${Number(statusInvalidosFichas.count)} fichas com status inválido`,
        query_correcao: 'UPDATE fichas_sessao SET status_workflow = "RASCUNHO" WHERE status_workflow NOT IN workflow válidos',
        registros_afetados: Number(statusInvalidosFichas.count)
      });

      if (autofix) {
        await db.prepare(`
          UPDATE fichas_sessao 
          SET status_workflow = 'RASCUNHO', updated_at = CURRENT_TIMESTAMP 
          WHERE status_workflow NOT IN ('RASCUNHO', 'PENDENTE_ALUNO', 'PENDENTE_INSTRUTOR_FINAL', 'PENDENTE_CHECK', 'CONCLUIDA', 'REPROVADA', 'CANCELADO')
          AND deleted_at IS NULL
        `).run();
        acoesExecutadas.push(`Corrigidos ${Number(statusInvalidosFichas.count)} status inválidos em fichas`);
      }
    }

    // 5. VERIFICAR DATAS INCONSISTENTES
    const datasInconsistentes = await db.prepare(`
      SELECT COUNT(*) as count FROM agendamento_slots 
      WHERE data_inicio >= data_fim
    `).first();

    if (datasInconsistentes && Number(datasInconsistentes.count) > 0) {
      problemas.push({
        tabela: 'agendamento_slots',
        problema: 'Datas de início >= datas de fim',
        gravidade: 'HIGH',
        detalhes: `${Number(datasInconsistentes.count)} slots com datas inconsistentes`,
        registros_afetados: Number(datasInconsistentes.count)
      });

      if (autofix) {
        // Cancelar slots com datas inconsistentes
        await db.prepare(`
          UPDATE agendamento_slots 
          SET status_slot = 'CANCELADO', updated_at = CURRENT_TIMESTAMP 
          WHERE data_inicio >= data_fim
        `).run();
        acoesExecutadas.push(`Cancelados ${Number(datasInconsistentes.count)} slots com datas inconsistentes`);
      }
    }

    // 6. VERIFICAR FUNCIONÁRIOS INVÁLIDOS
    const instrutoresInvalidos = await db.prepare(`
      SELECT COUNT(*) as count FROM agendamento_slots 
      WHERE colaborador_id_instrutor NOT IN (SELECT id FROM funcionarios WHERE is_instrutor = 1)
    `).first();

    if (instrutoresInvalidos && Number(instrutoresInvalidos.count) > 0) {
      problemas.push({
        tabela: 'agendamento_slots',
        problema: 'Instrutores inválidos em slots',
        gravidade: 'HIGH',
        detalhes: `${Number(instrutoresInvalidos.count)} slots com instrutores inválidos`,
        registros_afetados: Number(instrutoresInvalidos.count)
      });
    }

    // 7. VERIFICAR MANOBRAS ÓRFÃS
    const manobrasOrfas = await db.prepare(`
      SELECT COUNT(*) as count FROM fichas_manobras_executadas 
      WHERE ficha_id NOT IN (SELECT id FROM fichas_sessao WHERE deleted_at IS NULL)
    `).first();

    if (manobrasOrfas && Number(manobrasOrfas.count) > 0) {
      problemas.push({
        tabela: 'fichas_manobras_executadas',
        problema: 'Manobras executadas órfãs',
        gravidade: 'MEDIUM',
        detalhes: `${Number(manobrasOrfas.count)} registros de manobras sem ficha válida`,
        query_correcao: 'DELETE FROM fichas_manobras_executadas WHERE ficha_id NOT IN (SELECT id FROM fichas_sessao WHERE deleted_at IS NULL)',
        registros_afetados: Number(manobrasOrfas.count)
      });

      if (autofix) {
        await db.prepare(`
          DELETE FROM fichas_manobras_executadas 
          WHERE ficha_id NOT IN (SELECT id FROM fichas_sessao WHERE deleted_at IS NULL)
        `).run();
        acoesExecutadas.push(`Removidas ${Number(manobrasOrfas.count)} manobras órfãs`);
      }
    }

    // 8. CALCULAR ESTATÍSTICAS
    const problemasPorGravidade = problemas.reduce((acc, problema) => {
      acc[problema.gravidade] = (acc[problema.gravidade] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const tempoExecucao = Date.now() - startTime;

    // 9. REGISTRAR AUDITORIA NO BANCO
    await db.prepare(`
      INSERT INTO auditoria_limpeza_dados (
        operacao, tabela_afetada, registros_removidos, registros_atualizados,
        criterio_remocao, status_operacao, observacoes
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      'AUDITORIA_INTEGRIDADE',
      'TODAS',
      0,
      0,
      'Verificação automática de integridade',
      'CONCLUIDA',
      JSON.stringify({
        problemas_encontrados: problemas.length,
        acoes_executadas: acoesExecutadas.length,
        autofix_ativo: autofix
      })
    ).run();

    const resultado: AuditResult = {
      data_execucao: new Date().toISOString(),
      total_problemas: problemas.length,
      problemas_por_gravidade: problemasPorGravidade,
      problemas,
      acoes_executadas: acoesExecutadas,
      tempo_execucao_ms: tempoExecucao
    };

    return c.json({
      success: true,
      data: resultado
    });

  } catch (error) {
    console.error('Erro na auditoria de integridade:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/audit/integrity/history - Histórico de auditorias
auditIntegrityApi.get('/history', requirePermission('system', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    const limit = parseInt(c.req.query('limit') || '10');

    const historico = await db.prepare(`
      SELECT * FROM auditoria_limpeza_dados 
      WHERE operacao = 'AUDITORIA_INTEGRIDADE'
      ORDER BY data_execucao DESC 
      LIMIT ?
    `).bind(limit).all();

    return c.json({
      success: true,
      data: historico.results
    });

  } catch (error) {
    console.error('Erro ao buscar histórico de auditoria:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// POST /api/v2/audit/integrity/optimize-indexes - Criar/otimizar índices
auditIntegrityApi.post('/optimize-indexes', requirePermission('system', 'ADMIN'), async (c) => {
  try {
    const db = c.env.DB;
    const indicesCreated: string[] = [];

    // Índices para simuladores
    const indices = [
      {
        name: 'idx_agendamento_slots_simulador_data',
        sql: 'CREATE INDEX IF NOT EXISTS idx_agendamento_slots_simulador_data ON agendamento_slots(simulador_id, data_inicio, data_fim)'
      },
      {
        name: 'idx_agendamento_slots_status',
        sql: 'CREATE INDEX IF NOT EXISTS idx_agendamento_slots_status ON agendamento_slots(status_slot)'
      },
      {
        name: 'idx_fichas_sessao_agendamento',
        sql: 'CREATE INDEX IF NOT EXISTS idx_fichas_sessao_agendamento ON fichas_sessao(agendamento_slot_id)'
      },
      {
        name: 'idx_fichas_sessao_aluno',
        sql: 'CREATE INDEX IF NOT EXISTS idx_fichas_sessao_aluno ON fichas_sessao(colaborador_id_aluno)'
      },
      {
        name: 'idx_fichas_sessao_status',
        sql: 'CREATE INDEX IF NOT EXISTS idx_fichas_sessao_status ON fichas_sessao(status_workflow)'
      },
      {
        name: 'idx_fichas_sessao_uuid',
        sql: 'CREATE UNIQUE INDEX IF NOT EXISTS idx_fichas_sessao_uuid ON fichas_sessao(ficha_uuid) WHERE deleted_at IS NULL'
      },
      {
        name: 'idx_fichas_manobras_ficha',
        sql: 'CREATE INDEX IF NOT EXISTS idx_fichas_manobras_ficha ON fichas_manobras_executadas(ficha_id)'
      },
      {
        name: 'idx_simuladores_status',
        sql: 'CREATE INDEX IF NOT EXISTS idx_simuladores_status ON simuladores(status) WHERE deleted_at IS NULL'
      },
      {
        name: 'idx_funcionarios_instrutor',
        sql: 'CREATE INDEX IF NOT EXISTS idx_funcionarios_instrutor ON funcionarios(is_instrutor) WHERE is_instrutor = 1'
      },
      {
        name: 'idx_funcionarios_checador',
        sql: 'CREATE INDEX IF NOT EXISTS idx_funcionarios_checador ON funcionarios(is_checador) WHERE is_checador = 1'
      }
    ];

    for (const indice of indices) {
      try {
        await db.prepare(indice.sql).run();
        indicesCreated.push(indice.name);
      } catch (error) {
        console.error(`Erro ao criar índice ${indice.name}:`, error);
      }
    }

    return c.json({
      success: true,
      message: 'Otimização de índices concluída',
      indices_criados: indicesCreated
    });

  } catch (error) {
    console.error('Erro na otimização de índices:', error);
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default auditIntegrityApi;
