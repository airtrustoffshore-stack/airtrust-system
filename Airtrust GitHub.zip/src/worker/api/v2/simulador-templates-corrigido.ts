import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

/**
 * 🔧 ENDPOINT CORRIGIDO PARA TEMPLATES - AIRTRUST
 * 
 * Este endpoint resolve o problema crítico do dropdown de templates vazio.
 * Implementa busca robusta com fallback automático e estrutura de dados otimizada.
 */

// GET /api/v2/simulador/templates - Listar templates com dados completos
app.get('/templates', async (c) => {
  try {
    console.log('🔍 Buscando templates de sessão...');
    const db = c.env.DB;
    
    // Buscar templates com dados completos e manobras associadas
    const templatesStmt = db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo as codigo,
        st.nome_sessao as nome,
        st.descricao,
        st.numero_sessao,
        COALESCE(ct.nome, 'Treinamento ' || st.treinamento_codigo) as treinamento_nome,
        COALESCE(ct.categoria, 'GERAL') as nivel_treinamento,
        COALESCE(ct.carga_horaria, 2) as duracao_estimada,
        'TODAS' as aeronave_tipo,
        st.created_at,
        st.created_by
      FROM sessoes_template st
      LEFT JOIN catalogo_treinamentos_v2 ct ON st.treinamento_codigo = ct.codigo
      ORDER BY st.treinamento_codigo ASC, st.numero_sessao ASC
    `);
    
    const templatesResult = await templatesStmt.all();
    const templates = templatesResult.results || [];
    
    console.log(`📋 Encontrados ${templates.length} templates base`);
    
    // Para cada template, buscar manobras associadas
    const templatesCompletos = await Promise.all(
      templates.map(async (template: any) => {
        try {
          const manobrasStmt = db.prepare(`
            SELECT 
              mc.id,
              mc.manobra_id_codigo as codigo,
              mc.nome_manobra as nome,
              1 as ordem_execucao
            FROM sessoes_template_manobras stm
            JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
            WHERE stm.sessao_template_id = ? AND mc.deleted_at IS NULL
            ORDER BY mc.categoria, mc.nome_manobra
          `);
          
          const manobrasResult = await manobrasStmt.bind(template.id).all();
          const manobras = manobrasResult.results || [];
          
          return {
            id: template.id,
            codigo: template.codigo,
            nome: template.nome,
            descricao: template.descricao || `Template ${template.numero_sessao} do treinamento ${template.treinamento_nome}`,
            duracao_estimada: parseFloat(String(template.duracao_estimada)) || 2.0,
            nivel_treinamento: template.nivel_treinamento || 'BASICO',
            aeronave_tipo: template.aeronave_tipo || 'TODAS',
            total_manobras: manobras.length,
            numero_sessao: template.numero_sessao,
            treinamento_codigo: String(template.treinamento_codigo) || '',
            treinamento_nome: template.treinamento_nome,
            manobras: manobras,
            created_at: template.created_at,
            created_by: template.created_by
          };
        } catch (error) {
          console.error(`❌ Erro ao buscar manobras para template ${template.id}:`, error);
          return {
            id: template.id,
            codigo: template.codigo,
            nome: template.nome,
            descricao: template.descricao || `Template ${template.numero_sessao} do treinamento ${template.treinamento_nome}`,
            duracao_estimada: parseFloat(template.duracao_estimada as string) || 2.0,
            nivel_treinamento: template.nivel_treinamento || 'BASICO',
            aeronave_tipo: template.aeronave_tipo || 'TODAS',
            total_manobras: 0,
            numero_sessao: template.numero_sessao,
            treinamento_codigo: String(template.treinamento_codigo) || '',
            treinamento_nome: template.treinamento_nome,
            manobras: [],
            created_at: template.created_at,
            created_by: template.created_by
          };
        }
      })
    );
    
    console.log(`✅ Templates processados: ${templatesCompletos.length}`);
    
    // Se não houver templates, criar templates de exemplo
    if (templatesCompletos.length === 0) {
      console.log('⚠️ Nenhum template encontrado, criando templates de exemplo...');
      
      try {
        // Criar template básico se não existir
        const templateExemplo = await db.prepare(`
          INSERT INTO sessoes_template (
            treinamento_codigo, numero_sessao, nome_sessao, descricao, created_at, created_by
          ) VALUES (?, ?, ?, ?, ?, ?)
        `).bind(
          'TEMPLATE-BASICO-001',
          1,
          'Treinamento Básico - Procedimentos Normais',
          'Template básico para treinamento de procedimentos operacionais normais',
          new Date().toISOString(),
          1
        ).run();
        
        if (templateExemplo.success) {
          const novoTemplate = {
            id: templateExemplo.meta.last_row_id as number,
            codigo: 'TEMPLATE-BASICO-001',
            nome: 'Treinamento Básico - Procedimentos Normais',
            descricao: 'Template básico para treinamento de procedimentos operacionais normais',
            duracao_estimada: 2.0,
            nivel_treinamento: 'BASICO',
            aeronave_tipo: 'TODAS',
            total_manobras: 0,
            numero_sessao: 1,
            treinamento_codigo: 'TEMPLATE-BASICO-001',
            treinamento_nome: 'Treinamento Básico',
            manobras: [],
            created_at: new Date().toISOString(),
            created_by: 1
          };
          
          templatesCompletos.push(novoTemplate);
          console.log('✅ Template de exemplo criado com sucesso');
        }
      } catch (createError) {
        console.error('❌ Erro ao criar template de exemplo:', createError);
      }
    }
    
    // Fallback final se ainda não houver templates
    if (templatesCompletos.length === 0) {
      console.log('🔄 Aplicando fallback com templates estáticos...');
      
      const templatesFallback = [
        {
          id: 999,
          codigo: 'TEMPLATE-FALLBACK-001',
          nome: '⚠️ Template Padrão (Sistema Offline)',
          descricao: 'Template de fallback para quando o sistema está offline',
          duracao_estimada: 2.0,
          nivel_treinamento: 'BASICO',
          aeronave_tipo: 'TODAS',
          total_manobras: 5,
          numero_sessao: 1,
          treinamento_codigo: 'FALLBACK-001',
          treinamento_nome: 'Sistema Offline',
          manobras: [],
          created_at: new Date().toISOString(),
          created_by: 0
        },
        {
          id: 998,
          codigo: 'TEMPLATE-FALLBACK-002',
          nome: 'Template Emergencial - Procedimentos Básicos',
          descricao: 'Template de emergência com procedimentos básicos de voo',
          duracao_estimada: 2.5,
          nivel_treinamento: 'INTERMEDIARIO',
          aeronave_tipo: 'TODAS',
          total_manobras: 8,
          numero_sessao: 1,
          treinamento_codigo: 'FALLBACK-002',
          treinamento_nome: 'Procedimentos Básicos',
          manobras: [],
          created_at: new Date().toISOString(),
          created_by: 0
        }
      ];
      
      return c.json({
        success: false,
        templates: templatesFallback,
        total: templatesFallback.length,
        error: 'Templates carregados do fallback - banco de dados pode estar offline',
        fallback: true,
        message: `${templatesFallback.length} templates de fallback disponíveis`
      });
    }
    
    // Retorno de sucesso com templates reais
    return c.json({
      success: true,
      templates: templatesCompletos,
      total: templatesCompletos.length,
      message: `${templatesCompletos.length} templates disponíveis`,
      fallback: false,
      debug: {
        templates_encontrados: templates.length,
        templates_processados: templatesCompletos.length,
        timestamp: new Date().toISOString()
      }
    });
    
  } catch (error) {
    console.error('❌ Erro crítico ao listar templates:', error);
    
    // Fallback de emergência
    const templateEmergencia = [
      {
        id: 997,
        codigo: 'TEMPLATE-EMERGENCIA-001',
        nome: '🚨 Template de Emergência - Sistema com Erro',
        descricao: 'Template de emergência ativado por falha do sistema',
        duracao_estimada: 2.0,
        nivel_treinamento: 'EMERGENCIA',
        aeronave_tipo: 'TODAS',
        total_manobras: 0,
        numero_sessao: 1,
        treinamento_codigo: 'EMERGENCIA-001',
        treinamento_nome: 'Sistema com Erro',
        manobras: [],
        created_at: new Date().toISOString(),
        created_by: 0
      }
    ];
    
    return c.json({
      success: false,
      templates: templateEmergencia,
      total: 1,
      error: 'Erro crítico ao carregar templates do banco de dados',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido',
      fallback: true,
      emergency: true,
      message: 'Template de emergência ativado'
    }, 500);
  }
});

// GET /api/v2/simulador/templates/:id - Obter template específico com detalhes
app.get('/templates/:id', async (c) => {
  try {
    const templateId: string = c.req.param('id');
    const db = c.env.DB;
    
    console.log(`🔍 Buscando template específico: ${templateId}`);
    
    // Buscar template específico
    const templateStmt = db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo as codigo,
        st.nome_sessao as nome,
        st.descricao,
        st.numero_sessao,
        COALESCE(ct.nome, 'Treinamento ' || st.treinamento_codigo) as treinamento_nome,
        COALESCE(ct.categoria, 'GERAL') as nivel_treinamento,
        COALESCE(ct.carga_horaria, 2) as duracao_estimada,
        st.created_at,
        st.created_by,
        st.updated_at,
        st.updated_by
      FROM sessoes_template st
      LEFT JOIN catalogo_treinamentos_v2 ct ON st.treinamento_codigo = ct.codigo
      WHERE st.id = ?
    `);
    
    const template = await templateStmt.bind(templateId).first();
    
    if (!template) {
      return c.json({
        success: false,
        error: 'Template não encontrado',
        template_id: templateId
      }, 404);
    }
    
    // Buscar manobras do template
    const manobrasStmt = db.prepare(`
      SELECT 
        mc.id,
        mc.manobra_id_codigo as codigo,
        mc.nome_manobra as nome,
        mc.categoria,
        mc.criterios_aprovacao,
        mc.pontuacao_minima,
        1 as ordem_execucao
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ? AND mc.deleted_at IS NULL
      ORDER BY mc.categoria, mc.nome_manobra
    `);
    
    const manobrasResult = await manobrasStmt.bind(parseInt(templateId)).all();
    const manobras = manobrasResult.results || [];
    
    const templateCompleto = {
      id: template.id,
      codigo: template.codigo,
      nome: template.nome,
      descricao: template.descricao,
      duracao_estimada: parseFloat(String(template.duracao_estimada)) || 2.0,
      nivel_treinamento: template.nivel_treinamento,
      aeronave_tipo: 'TODAS',
      total_manobras: manobras.length,
      numero_sessao: template.numero_sessao,
      treinamento_codigo: (template.treinamento_codigo as string) || '',
      treinamento_nome: template.treinamento_nome,
      manobras: manobras,
      created_at: template.created_at,
      created_by: template.created_by,
      updated_at: template.updated_at,
      updated_by: template.updated_by
    };
    
    console.log(`✅ Template encontrado: ${template.nome} com ${manobras.length} manobras`);
    
    return c.json({
      success: true,
      template: templateCompleto,
      message: `Template ${template.nome} carregado com sucesso`
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar template específico:', error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor ao buscar template',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// POST /api/v2/simulador/templates/verificar-saude - Verificar saúde dos templates
app.post('/templates/verificar-saude', async (c) => {
  try {
    const db = c.env.DB;
    
    console.log('🏥 Executando verificação de saúde dos templates...');
    
    // Verificar conectividade do banco
    const healthCheck = await db.prepare('SELECT 1 as test').first();
    if (!healthCheck) {
      return c.json({
        success: false,
        error: 'Banco de dados não acessível',
        saude: 'CRITICO'
      }, 500);
    }
    
    // Verificar tabelas necessárias
    const tabelasNecessarias = [
      'sessoes_template',
      'sessoes_template_manobras', 
      'manobras_catalogo',
      'catalogo_treinamentos_v2'
    ];
    
    const tabelasExistentes: string[] = [];
    for (const tabela of tabelasNecessarias) {
      try {
        await db.prepare(`SELECT COUNT(*) as count FROM ${tabela} LIMIT 1`).first();
        tabelasExistentes.push(tabela);
      } catch (error) {
        console.error(`❌ Tabela ${tabela} não acessível:`, error);
      }
    }
    
    // Contar registros
    const contadores = {
      templates: 0,
      manobras: 0,
      treinamentos: 0,
      associacoes: 0
    };
    
    try {
      const templatesCount = await db.prepare('SELECT COUNT(*) as count FROM sessoes_template').first();
      contadores.templates = (templatesCount?.count as number) || 0;
      
      const manobrasCount = await db.prepare('SELECT COUNT(*) as count FROM manobras_catalogo WHERE deleted_at IS NULL').first();
      contadores.manobras = (manobrasCount?.count as number) || 0;
      
      const treinamentosCount = await db.prepare('SELECT COUNT(*) as count FROM catalogo_treinamentos_v2 WHERE deleted_at IS NULL').first();
      contadores.treinamentos = (treinamentosCount?.count as number) || 0;
      
      const associacoesCount = await db.prepare('SELECT COUNT(*) as count FROM sessoes_template_manobras').first();
      contadores.associacoes = (associacoesCount?.count as number) || 0;
    } catch (error) {
      console.error('❌ Erro ao contar registros:', error);
    }
    
    // Determinar status de saúde
    let saude = 'EXCELENTE';
    const problemas = [];
    
    if (tabelasExistentes.length < tabelasNecessarias.length) {
      saude = 'CRITICO';
      problemas.push(`Tabelas faltando: ${tabelasNecessarias.filter(t => !tabelasExistentes.includes(t)).join(', ')}`);
    }
    
    if (contadores.templates === 0) {
      saude = saude === 'EXCELENTE' ? 'RUIM' : saude;
      problemas.push('Nenhum template encontrado');
    }
    
    if (contadores.manobras === 0) {
      saude = saude === 'EXCELENTE' ? 'MEDIO' : saude;
      problemas.push('Nenhuma manobra cadastrada');
    }
    
    return c.json({
      success: true,
      saude: saude,
      verificacao: {
        banco_conectado: true,
        tabelas_existentes: tabelasExistentes,
        tabelas_necessarias: tabelasNecessarias,
        contadores: contadores,
        problemas: problemas,
        timestamp: new Date().toISOString()
      },
      recomendacoes: problemas.length > 0 ? [
        'Execute o endpoint de criação de templates de exemplo',
        'Verifique se as migrações foram executadas corretamente',
        'Considere importar dados de exemplo via CSV'
      ] : [
        'Sistema funcionando corretamente',
        'Templates disponíveis para uso',
        'Dados íntegros e acessíveis'
      ]
    });
    
  } catch (error) {
    console.error('❌ Erro crítico na verificação de saúde:', error);
    return c.json({
      success: false,
      saude: 'CRITICO',
      error: 'Erro crítico na verificação de saúde',
      error_details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/simulador/templates/treinamento/{id} - Endpoint para filtrar templates por treinamento
app.get('/templates/treinamento/:id', async (c) => {
  const { id } = c.req.param();
  const treinamentoId = parseInt(id);
  
  if (!treinamentoId) {
    return c.json({ error: 'ID do treinamento inválido' }, 400);
  }
  
  try {
    console.log(`📋 Buscando templates do treinamento ${treinamentoId}...`);
    const db = c.env.DB;
    
    // Primeiro, verificar se o treinamento existe
    const treinamento = await db.prepare(`
      SELECT codigo, nome FROM catalogo_treinamentos_v2 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(treinamentoId).first();
    
    if (!treinamento) {
      return c.json({ 
        error: 'Treinamento não encontrado',
        treinamento_id: treinamentoId 
      }, 404);
    }
    
    // Buscar templates associados ao treinamento
    const templatesStmt = db.prepare(`
      SELECT 
        st.id,
        st.treinamento_codigo,
        st.numero_sessao,
        st.nome_sessao as nome,
        st.descricao,
        st.created_at,
        st.created_by
      FROM sessoes_template st
      LEFT JOIN catalogo_treinamentos_v2 ct ON st.treinamento_codigo = ct.codigo
      WHERE ct.id = ?
      ORDER BY st.numero_sessao ASC
    `);
    
    const templatesResult = await templatesStmt.bind(treinamentoId).all();
    const templates = templatesResult.results || [];
    
    // Para cada template, buscar manobras associadas
    const templatesCompletos = await Promise.all(
      templates.map(async (template: any) => {
        try {
          const manobrasStmt = db.prepare(`
            SELECT COUNT(*) as total
            FROM sessoes_template_manobras stm
            JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
            WHERE stm.sessao_template_id = ? AND mc.deleted_at IS NULL
          `);
          
          const manobrasCount = await manobrasStmt.bind(template.id).first();
          
          return {
            id: template.id,
            treinamento_id: treinamentoId,
            numero_sessao: template.numero_sessao,
            nome: template.nome,
            descricao: template.descricao || `Sessão ${template.numero_sessao} do treinamento ${treinamento.nome}`,
            total_manobras: (manobrasCount?.total as number) || 0,
            treinamento_codigo: (template.treinamento_codigo as string) || ''
          };
        } catch (error) {
          console.error(`❌ Erro ao processar template ${template.id}:`, error);
          return {
            id: template.id,
            treinamento_id: treinamentoId,
            numero_sessao: template.numero_sessao,
            nome: template.nome,
            descricao: template.descricao,
            total_manobras: 0,
            treinamento_codigo: String(template.treinamento_codigo) || ''
          };
        }
      })
    );
    
    console.log(`✅ Encontrados ${templatesCompletos.length} templates para treinamento ${treinamentoId}`);
    
    return c.json({
      success: true,
      treinamento_id: treinamentoId,
      treinamento_nome: treinamento.nome,
      templates: templatesCompletos,
      total: templatesCompletos.length
    });
    
  } catch (error) {
    console.error(`❌ Erro ao buscar templates do treinamento ${treinamentoId}:`, error);
    return c.json({ 
      error: 'Erro interno do servidor',
      treinamento_id: treinamentoId
    }, 500);
  }
});

// POST /api/v2/simulador/templates - Criar novo template de sessão
app.post('/templates', async (c) => {
  try {
    const body = await c.req.json();
    const { 
      treinamento_id, 
      numero_sessao, 
      nome, 
      descricao, 
      duracao_estimada, 
      nivel_dificuldade,
      manobras 
    } = body;
    
    const db = c.env.DB;
    
    console.log('📤 Recebendo dados para criar template:', body);
    
    // Validar treinamento existe
    const treinamento = await db.prepare(`
      SELECT id, codigo FROM catalogo_treinamentos_v2 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(treinamento_id).first();
    
    if (!treinamento) {
      return c.json({ error: 'Treinamento não encontrado' }, 404);
    }
    
    // Verificar se já existe template com mesmo número de sessão para este treinamento
    const templateExistente = await db.prepare(`
      SELECT st.id 
      FROM sessoes_template st
      JOIN catalogo_treinamentos_v2 ct ON st.treinamento_codigo = ct.codigo
      WHERE ct.id = ? AND st.numero_sessao = ?
    `).bind(treinamento_id, numero_sessao).first();
    
    if (templateExistente) {
      return c.json({ 
        error: `Já existe um template da sessão ${numero_sessao} para este treinamento` 
      }, 409);
    }
    
    // Criar template
    const templateResult = await db.prepare(`
      INSERT INTO sessoes_template (
        treinamento_codigo, numero_sessao, nome_sessao, descricao, created_by
      ) VALUES (?, ?, ?, ?, ?)
    `).bind(
      treinamento.codigo,
      numero_sessao,
      nome,
      descricao || `Sessão ${numero_sessao} - ${nome}`,
      'sistema' // TODO: pegar do contexto de auth
    ).run();
    
    if (!templateResult.success) {
      return c.json({ error: 'Erro ao criar template' }, 500);
    }
    
    const templateId = templateResult.meta.last_row_id as number;
    
    // Associar manobras se fornecidas
    if (manobras && Array.isArray(manobras) && manobras.length > 0) {
      for (const manobra of manobras) {
        try {
          await db.prepare(`
            INSERT INTO sessoes_template_manobras (sessao_template_id, manobra_catalogo_id)
            VALUES (?, ?)
          `).bind(templateId, manobra.manobra_id).run();
        } catch (error) {
          console.error(`⚠️ Erro ao associar manobra ${manobra.manobra_id}:`, error);
        }
      }
    }
    
    const novoTemplate = {
      id: templateId,
      treinamento_id: treinamento_id,
      numero_sessao: numero_sessao,
      nome: nome,
      descricao: descricao,
      duracao_estimada: duracao_estimada || 2.0,
      nivel_dificuldade: nivel_dificuldade || 'BASICO',
      total_manobras: manobras?.length || 0
    };
    
    console.log(`✅ Template criado com sucesso: ID ${templateId}`);
    
    return c.json({
      success: true,
      template: novoTemplate,
      message: `Template "${nome}" criado com sucesso`
    });
    
  } catch (error) {
    console.error('❌ Erro ao criar template:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : undefined
    }, 500);
  }
});

export default app;
