import { Hono } from 'hono';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

// Middleware simples - sem auth por enquanto para debug
app.use('*', async (c, next) => {
  console.log(`📡 [SESSOES] Request: ${c.req.method} ${c.req.path}`);
  await next();
  console.log(`📡 [SESSOES] Response enviada`);
});

app.get('/', async (c) => {
  try {
    console.log('🔍 [SESSOES] Início do endpoint sessões');
    
    // Verificar DB
    const db = c.env.DB;
    console.log('🔍 [SESSOES] DB disponível?', !!db);
    
    if (!db) {
      console.log('❌ [SESSOES] Database não disponível');
      return c.json({ error: 'Database não disponível' }, 500);
    }
    
    // Tentar query teste
    try {
      const teste = await db.prepare('SELECT 1 as teste').first();
      console.log('🔍 [SESSOES] Query teste OK:', teste);
    } catch (dbError) {
      console.log('❌ [SESSOES] Erro na query teste:', dbError);
      // Continuar com dados mock
    }
    
    // Dados mock para as sessões
    const sessoesMock = [
      {
        ficha_uuid: 'FICHA-TEST-001',
        status_workflow: 'CONCLUIDA',
        resultado_final: 'APROVADO',
        nota_final: 8.5,
        data_sessao: new Date(Date.now() - 86400000).toISOString(), // 1 dia atrás
        data_fim: new Date(Date.now() - 82800000).toISOString(), // 1 hora depois
        status_slot: 'CONCLUIDO',
        simulador: {
          nome: 'Simulador AW139 - 001',
          codigo: 'SIM-AW139-001'
        },
        colaborador: {
          nome: 'João Silva',
          matricula: '00001'
        },
        instrutor: {
          nome: 'Carlos Instrutor'
        },
        template: {
          nome: 'Sessão 1 - IFR Básico'
        },
        created_at: new Date(Date.now() - 86400000).toISOString()
      },
      {
        ficha_uuid: 'FICHA-TEST-002',
        status_workflow: 'PENDENTE_INSTRUTOR_FINAL',
        resultado_final: null,
        nota_final: null,
        data_sessao: new Date().toISOString(),
        data_fim: new Date(Date.now() + 3600000).toISOString(), // em 1 hora
        status_slot: 'EM_ANDAMENTO',
        simulador: {
          nome: 'Simulador AW139 - 002',
          codigo: 'SIM-AW139-002'
        },
        colaborador: {
          nome: 'Maria Santos',
          matricula: '00002'
        },
        instrutor: {
          nome: 'Ana Instrutora'
        },
        template: {
          nome: 'Sessão 2 - Emergências'
        },
        created_at: new Date().toISOString()
      },
      {
        ficha_uuid: 'FICHA-TEST-003',
        status_workflow: 'REPROVADA',
        resultado_final: 'REPROVADO',
        nota_final: 4.0,
        data_sessao: new Date(Date.now() - 172800000).toISOString(), // 2 dias atrás
        data_fim: new Date(Date.now() - 169200000).toISOString(),
        status_slot: 'CONCLUIDO',
        simulador: {
          nome: 'Simulador AW139 - 001',
          codigo: 'SIM-AW139-001'
        },
        colaborador: {
          nome: 'Pedro Costa',
          matricula: '00003'
        },
        instrutor: {
          nome: 'Carlos Instrutor'
        },
        template: {
          nome: 'Sessão 3 - Operações Especiais'
        },
        created_at: new Date(Date.now() - 172800000).toISOString()
      }
    ];
    
    console.log('🔍 [SESSOES] Dados mock preparados:', sessoesMock.length);
    
    // Calcular estatísticas
    const totalSessoes = sessoesMock.length;
    const sessoesAprovadas = sessoesMock.filter(s => s.resultado_final === 'APROVADO').length;
    const sessoesReprovadas = sessoesMock.filter(s => s.resultado_final === 'REPROVADO').length;
    const sessoesPendentes = sessoesMock.filter(s => !s.resultado_final).length;
    
    const resposta = {
      success: true,
      sessoes: sessoesMock,
      estatisticas: {
        total: totalSessoes,
        aprovadas: sessoesAprovadas,
        reprovadas: sessoesReprovadas,
        pendentes: sessoesPendentes,
        taxa_aprovacao: totalSessoes > 0 ? Math.round((sessoesAprovadas / totalSessoes) * 100) : 0
      },
      timestamp: new Date().toISOString(),
      debug: {
        endpoint: 'sessoes-fixed',
        version: '2.0-debug',
        db_available: !!db,
        data_source: 'mock'
      }
    };
    
    console.log('✅ [SESSOES] Retornando resposta com', resposta.sessoes.length, 'sessões');
    return c.json(resposta);
    
  } catch (error) {
    console.error('❌ [SESSOES] ERRO CAPTURADO:', {
      message: error instanceof Error ? error.message : 'Erro desconhecido',
      stack: error instanceof Error ? error.stack?.substring(0, 200) : 'N/A',
      name: error instanceof Error ? error.name : 'Unknown'
    });
    
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'sessoes-fixed',
      timestamp: new Date().toISOString(),
      debug: {
        error_type: error instanceof Error ? error.constructor.name : 'Unknown',
        path: c.req.path,
        method: c.req.method
      }
    }, 500);
  }
});

// GET - Buscar sessões por colaborador (versão simplificada)
app.get('/colaborador/:id', async (c) => {
  try {
    console.log('🔍 [SESSOES] Buscando sessões do colaborador');
    
    const { id } = c.req.param();
    
    // Mock data específica do colaborador
    const sessoes = [
      {
        ficha_uuid: `FICHA-COLAB-${id}-001`,
        status_workflow: 'CONCLUIDA',
        resultado_final: 'APROVADO',
        nota_final: 8.0,
        data_inicio: new Date(Date.now() - 86400000).toISOString(),
        simulador_nome: 'Simulador AW139 - 001'
      }
    ];
    
    return c.json({
      success: true,
      sessoes: sessoes,
      colaborador_id: id,
      total: sessoes.length,
      debug: {
        endpoint: 'sessoes-colaborador-fixed',
        mock: true
      }
    });
    
  } catch (error) {
    console.error('❌ [SESSOES] Erro ao buscar sessões do colaborador:', error);
    return c.json({ 
      error: 'Erro ao buscar sessões do colaborador',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'sessoes-colaborador-fixed'
    }, 500);
  }
});

// GET - Status do endpoint
app.get('/status', async (c) => {
  return c.json({
    success: true,
    endpoint: 'simulador-sessoes-fixed',
    version: '2.0-debug',
    status: 'OPERACIONAL',
    timestamp: new Date().toISOString(),
    features: [
      'GET / - Listar todas as sessões',
      'GET /colaborador/:id - Sessões por colaborador',
      'GET /status - Status do endpoint'
    ]
  });
});

export default app;
