import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();
app.use('*', authMiddleware);

app.get('/:colaborador/:treinamento', async (c) => {
  try {
    const db = c.env.DB;
    const { colaborador, treinamento } = c.req.param();
    
    // Buscar dados do colaborador
    const colaboradorData = await db.prepare(`
      SELECT id, nome, matricula FROM funcionarios WHERE id = ?
    `).bind(colaborador).first();
    
    if (!colaboradorData) {
      return c.json({ error: 'Colaborador não encontrado' }, 404);
    }
    
    // Buscar dados do treinamento
    const treinamentoData = await db.prepare(`
      SELECT id, codigo, nome FROM catalogo_treinamentos_v2 WHERE id = ?
    `).bind(treinamento).first();
    
    if (!treinamentoData) {
      return c.json({ error: 'Treinamento não encontrado' }, 404);
    }
    
    // Buscar progresso do colaborador no treinamento
    const sessoes = await db.prepare(`
      SELECT 
        COUNT(*) as total_sessoes,
        SUM(CASE WHEN fs.resultado_final = 'APROVADO' THEN 1 ELSE 0 END) as aprovadas,
        SUM(CASE WHEN fs.resultado_final = 'REPROVADO' THEN 1 ELSE 0 END) as reprovadas,
        SUM(CASE WHEN fs.status_workflow = 'CONCLUIDA' THEN 1 ELSE 0 END) as concluidas
      FROM fichas_sessao fs
      JOIN agendamento_slots as_slot ON fs.agendamento_slot_id = as_slot.id
      WHERE fs.colaborador_id_aluno = ?
    `).bind(colaborador).first();
    
    // Buscar últimas sessões
    const ultimasSessoes = await db.prepare(`
      SELECT 
        fs.ficha_uuid,
        fs.resultado_final,
        fs.nota_final,
        fs.status_workflow,
        as_slot.data_inicio,
        s.nome as simulador_nome
      FROM fichas_sessao fs
      JOIN agendamento_slots as_slot ON fs.agendamento_slot_id = as_slot.id
      LEFT JOIN simuladores s ON as_slot.simulador_id = s.id
      WHERE fs.colaborador_id_aluno = ?
      ORDER BY as_slot.data_inicio DESC
      LIMIT 5
    `).bind(colaborador).all();
    
    const totalSessoes = sessoes.total_sessoes || 0;
    const sessoesAprovadas = sessoes.aprovadas || 0;
    const sessoesReprovadas = sessoes.reprovadas || 0;
    const sessoesConcluidas = sessoes.concluidas || 0;
    
    const percentualConclusao = totalSessoes > 0 
      ? Math.round((sessoesConcluidas / totalSessoes) * 100)
      : 0;
      
    const percentualAprovacao = sessoesConcluidas > 0
      ? Math.round((sessoesAprovadas / sessoesConcluidas) * 100)
      : 0;
    
    return c.json({
      success: true,
      progresso: {
        colaborador: {
          id: colaboradorData.id,
          nome: colaboradorData.nome,
          matricula: colaboradorData.matricula
        },
        treinamento: {
          id: treinamentoData.id,
          codigo: treinamentoData.codigo,
          nome: treinamentoData.nome
        },
        estatisticas: {
          total_sessoes: totalSessoes,
          sessoes_aprovadas: sessoesAprovadas,
          sessoes_reprovadas: sessoesReprovadas,
          sessoes_concluidas: sessoesConcluidas,
          percentual_conclusao: percentualConclusao,
          percentual_aprovacao: percentualAprovacao
        },
        ultimas_sessoes: ultimasSessoes.results || []
      }
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar progresso:', error);
    return c.json({ 
      error: 'Erro ao buscar progresso',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET - Progresso geral do colaborador
app.get('/:colaborador', async (c) => {
  try {
    const db = c.env.DB;
    const { colaborador } = c.req.param();
    
    // Buscar progresso geral
    const progressoGeral = await db.prepare(`
      SELECT 
        COUNT(*) as total_fichas,
        SUM(CASE WHEN resultado_final = 'APROVADO' THEN 1 ELSE 0 END) as aprovadas,
        SUM(CASE WHEN resultado_final = 'REPROVADO' THEN 1 ELSE 0 END) as reprovadas,
        SUM(CASE WHEN status_workflow = 'CONCLUIDA' THEN 1 ELSE 0 END) as concluidas,
        AVG(CASE WHEN nota_final IS NOT NULL THEN nota_final END) as media_notas
      FROM fichas_sessao
      WHERE colaborador_id_aluno = ?
    `).bind(colaborador).first();
    
    return c.json({
      success: true,
      progresso_geral: {
        colaborador_id: colaborador,
        total_fichas: progressoGeral.total_fichas || 0,
        fichas_aprovadas: progressoGeral.aprovadas || 0,
        fichas_reprovadas: progressoGeral.reprovadas || 0,
        fichas_concluidas: progressoGeral.concluidas || 0,
        media_notas: progressoGeral.media_notas ? Number(progressoGeral.media_notas.toFixed(1)) : null
      }
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar progresso geral:', error);
    return c.json({ 
      error: 'Erro ao buscar progresso geral',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
