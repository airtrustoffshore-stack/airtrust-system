import { Hono } from 'hono';
import { z } from 'zod';

const agendamentoAvancadoApi = new Hono<{ Bindings: Env }>();

// Schema para agendamento avançado com data/hora brasileira
const AgendarSlotAvancadoSchema = z.object({
  slot: z.object({
    simulador_id: z.number(),
    instrutor_id: z.number(),
    checador_id: z.number().optional().nullable(),
    data_inicio: z.string(), // ISO string
    data_fim: z.string(),    // ISO string
    duracao_horas: z.number().min(0.5).max(8),
    observacoes: z.string().optional()
  }),
  participantes: z.array(z.object({
    aluno_id: z.number(),
    funcao: z.enum(['PIC', 'SIC']),
    template_id: z.number(),
    ciclo: z.number().min(1).max(3)
  })).min(1).max(4)
});



// Função para calcular duração em horas
function calcularDuracao(inicio: Date, fim: Date): number {
  return (fim.getTime() - inicio.getTime()) / (1000 * 60 * 60);
}

// Verificar disponibilidade do simulador
async function verificarDisponibilidadeSimulador(
  db: any, 
  simuladorId: number, 
  inicio: Date, 
  fim: Date,
  excludeSlotId?: number
) {
  const query = `
    SELECT id, data_inicio, data_fim 
    FROM agendamento_slots 
    WHERE simulador_id = ? 
    AND status_slot != 'CANCELADO'
    ${excludeSlotId ? 'AND id != ?' : ''}
    AND (
      (data_inicio <= ? AND data_fim > ?) OR
      (data_inicio < ? AND data_fim >= ?) OR
      (data_inicio >= ? AND data_fim <= ?)
    )
  `;
  
  const params = excludeSlotId 
    ? [simuladorId, excludeSlotId, inicio.toISOString(), inicio.toISOString(), fim.toISOString(), fim.toISOString(), inicio.toISOString(), fim.toISOString()]
    : [simuladorId, inicio.toISOString(), inicio.toISOString(), fim.toISOString(), fim.toISOString(), inicio.toISOString(), fim.toISOString()];
    
  return await db.prepare(query).bind(...params).first();
}

// Verificar disponibilidade do instrutor
async function verificarDisponibilidadeInstrutor(
  db: any, 
  instrutorId: number, 
  inicio: Date, 
  fim: Date,
  excludeSlotId?: number
) {
  const query = `
    SELECT id, data_inicio, data_fim 
    FROM agendamento_slots 
    WHERE (colaborador_id_instrutor = ? OR colaborador_id_checador = ?)
    AND status_slot != 'CANCELADO'
    ${excludeSlotId ? 'AND id != ?' : ''}
    AND (
      (data_inicio <= ? AND data_fim > ?) OR
      (data_inicio < ? AND data_fim >= ?) OR
      (data_inicio >= ? AND data_fim <= ?)
    )
  `;
  
  const params = excludeSlotId 
    ? [instrutorId, instrutorId, excludeSlotId, inicio.toISOString(), inicio.toISOString(), fim.toISOString(), fim.toISOString(), inicio.toISOString(), fim.toISOString()]
    : [instrutorId, instrutorId, inicio.toISOString(), inicio.toISOString(), fim.toISOString(), fim.toISOString(), inicio.toISOString(), fim.toISOString()];
    
  return await db.prepare(query).bind(...params).first();
}

// POST /api/v2/simulador/agendar-slot-avancado
agendamentoAvancadoApi.post('/agendar-slot-avancado', async (c) => {
  try {
    const body = await c.req.json();
    console.log('Dados recebidos para agendamento:', body);
    
    const { slot, participantes } = AgendarSlotAvancadoSchema.parse(body);
    const db = c.env.DB;

    // Converter strings ISO para Date objects
    const dataInicio = new Date(slot.data_inicio);
    const dataFim = new Date(slot.data_fim);

    // Validações básicas
    if (dataFim <= dataInicio) {
      return c.json({ error: 'Data/hora de fim deve ser posterior ao início' }, 400);
    }

    const duracaoCalculada = calcularDuracao(dataInicio, dataFim);
    if (Math.abs(duracaoCalculada - slot.duracao_horas) > 0.1) {
      return c.json({ error: 'Duração informada não confere com as datas/horas' }, 400);
    }

    // Verificar se o simulador existe
    const simulador = await db.prepare('SELECT id, nome FROM simuladores WHERE id = ? AND status = "ATIVO"')
      .bind(slot.simulador_id)
      .first();

    if (!simulador) {
      return c.json({ error: 'Simulador não encontrado ou inativo' }, 404);
    }

    // Verificar se o instrutor existe
    const instrutor = await db.prepare('SELECT id, nome FROM funcionarios WHERE id = ? AND is_instrutor = 1')
      .bind(slot.instrutor_id)
      .first();

    if (!instrutor) {
      return c.json({ error: 'Instrutor não encontrado' }, 404);
    }

    // Verificar checador se informado
    let checador = null;
    if (slot.checador_id) {
      checador = await db.prepare('SELECT id, nome FROM funcionarios WHERE id = ? AND is_checador = 1')
        .bind(slot.checador_id)
        .first();

      if (!checador) {
        return c.json({ error: 'Checador não encontrado' }, 404);
      }
    }

    // Verificar conflitos de horário do simulador
    const conflitoSimulador = await verificarDisponibilidadeSimulador(
      db, slot.simulador_id, dataInicio, dataFim
    );

    if (conflitoSimulador) {
      return c.json({ 
        error: 'Simulador não disponível no horário solicitado',
        conflito: {
          inicio: conflitoSimulador.data_inicio,
          fim: conflitoSimulador.data_fim
        }
      }, 409);
    }

    // Verificar conflitos de horário do instrutor
    const conflitoInstrutor = await verificarDisponibilidadeInstrutor(
      db, slot.instrutor_id, dataInicio, dataFim
    );

    if (conflitoInstrutor) {
      return c.json({ 
        error: 'Instrutor não disponível no horário solicitado',
        conflito: {
          inicio: conflitoInstrutor.data_inicio,
          fim: conflitoInstrutor.data_fim
        }
      }, 409);
    }

    // Verificar conflitos do checador se informado
    if (slot.checador_id) {
      const conflitoChecador = await verificarDisponibilidadeInstrutor(
        db, slot.checador_id, dataInicio, dataFim
      );

      if (conflitoChecador) {
        return c.json({ 
          error: 'Checador não disponível no horário solicitado',
          conflito: {
            inicio: conflitoChecador.data_inicio,
            fim: conflitoChecador.data_fim
          }
        }, 409);
      }
    }

    // Verificar se todos os participantes existem
    for (const participante of participantes) {
      const aluno = await db.prepare('SELECT id, nome, matricula FROM funcionarios WHERE id = ?')
        .bind(participante.aluno_id)
        .first();

      if (!aluno) {
        return c.json({ error: `Funcionário ${participante.aluno_id} não encontrado` }, 404);
      }

      // Verificar se o template de sessão existe
      const template = await db.prepare('SELECT id, nome_sessao FROM sessoes_template WHERE id = ?')
        .bind(participante.template_id)
        .first();

      if (!template) {
        return c.json({ error: `Template de sessão ${participante.template_id} não encontrado` }, 404);
      }
    }

    // Criar slot de agendamento
    const resultSlot = await db.prepare(`
      INSERT INTO agendamento_slots (
        simulador_id, 
        colaborador_id_instrutor, 
        colaborador_id_checador,
        data_inicio, 
        data_fim, 
        status_slot,
        created_by,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, 'AGENDADO', 'sistema', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(
      slot.simulador_id,
      slot.instrutor_id,
      slot.checador_id || null,
      dataInicio.toISOString(),
      dataFim.toISOString()
    ).run();

    const slotId = resultSlot.meta.last_row_id;

    // Criar fichas individuais para cada participante
    const fichasCreated = [];
    
    for (const participante of participantes) {
      // Gerar UUID único para a ficha
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
      const randomNum = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
      const fichaUuid = `FICHA-${dateStr}-${randomNum}`;

      // Criar ficha individual
      const resultFicha = await db.prepare(`
        INSERT INTO fichas_sessao (
          ficha_uuid, 
          agendamento_slot_id, 
          colaborador_id_aluno, 
          funcao_na_sessao,
          sessao_template_id, 
          ciclo_executado, 
          status_workflow,
          created_by,
          created_at,
          updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'RASCUNHO', 'sistema', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `).bind(
        fichaUuid,
        slotId,
        participante.aluno_id,
        participante.funcao,
        participante.template_id,
        participante.ciclo
      ).run();

      fichasCreated.push({
        id: resultFicha.meta.last_row_id,
        uuid: fichaUuid,
        aluno_id: participante.aluno_id,
        funcao: participante.funcao,
        template_id: participante.template_id,
        ciclo: participante.ciclo
      });
    }

    // Registrar auditoria
    await db.prepare(`
      INSERT INTO auditoria_simulador (
        ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem, timestamp_acao
      ) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    `).bind(
      `SLOT-${slotId}`,
      0, // TODO: pegar do contexto de auth
      'AGENDAMENTO_CRIADO',
      JSON.stringify({
        simulador: simulador.nome,
        instrutor: instrutor.nome,
        checador: checador?.nome,
        duracao_horas: slot.duracao_horas,
        participantes_count: participantes.length
      }),
      c.req.header('CF-Connecting-IP') || 'unknown'
    ).run();

    console.log(`Agendamento criado: Slot ${slotId} com ${fichasCreated.length} fichas`);

    return c.json({
      success: true,
      slot_id: slotId,
      simulador: simulador.nome,
      instrutor: instrutor.nome,
      checador: checador?.nome,
      data_inicio: dataInicio.toISOString(),
      data_fim: dataFim.toISOString(),
      duracao_horas: duracaoCalculada,
      fichas: fichasCreated,
      observacoes: slot.observacoes
    });

  } catch (error) {
    console.error('Erro ao criar agendamento avançado:', error);
    
    if (error instanceof z.ZodError) {
      return c.json({ 
        error: 'Dados inválidos',
        details: error.errors.map(e => `${e.path.join('.')}: ${e.message}`)
      }, 400);
    }
    
    return c.json({ 
      error: 'Erro interno do servidor', 
      details: error instanceof Error ? error.message : 'Erro desconhecido' 
    }, 500);
  }
});

// GET /api/v2/simulador/verificar-disponibilidade
agendamentoAvancadoApi.post('/verificar-disponibilidade', async (c) => {
  try {
    const { simulador_id, instrutor_id, checador_id, data_inicio, data_fim, exclude_slot_id } = await c.req.json();
    const db = c.env.DB;

    const dataInicio = new Date(data_inicio);
    const dataFim = new Date(data_fim);

    const conflitos = [];

    // Verificar simulador
    const conflitoSimulador = await verificarDisponibilidadeSimulador(
      db, simulador_id, dataInicio, dataFim, exclude_slot_id
    );

    if (conflitoSimulador) {
      conflitos.push({
        tipo: 'simulador',
        recurso_id: simulador_id,
        conflito: conflitoSimulador
      });
    }

    // Verificar instrutor
    const conflitoInstrutor = await verificarDisponibilidadeInstrutor(
      db, instrutor_id, dataInicio, dataFim, exclude_slot_id
    );

    if (conflitoInstrutor) {
      conflitos.push({
        tipo: 'instrutor',
        recurso_id: instrutor_id,
        conflito: conflitoInstrutor
      });
    }

    // Verificar checador se informado
    if (checador_id) {
      const conflitoChecador = await verificarDisponibilidadeInstrutor(
        db, checador_id, dataInicio, dataFim, exclude_slot_id
      );

      if (conflitoChecador) {
        conflitos.push({
          tipo: 'checador',
          recurso_id: checador_id,
          conflito: conflitoChecador
        });
      }
    }

    return c.json({
      disponivel: conflitos.length === 0,
      conflitos
    });

  } catch (error) {
    console.error('Erro ao verificar disponibilidade:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default agendamentoAvancadoApi;
