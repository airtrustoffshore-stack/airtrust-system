import { Hono } from 'hono';
import { z } from 'zod';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';

const fichasApi = new Hono<{ Bindings: Env }>();

// Apply auth middleware
fichasApi.use('*', authMiddleware);

// GET /api/v2/simulador/fichas - Listar todas as fichas com informações completas
fichasApi.get('/fichas', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const db = c.env.DB;

    // Buscar todas as fichas com informações relacionadas
    const fichas = await db.prepare(`
      SELECT 
        f.*,
        slot.data_inicio,
        slot.data_fim,
        sim.nome as simulador_nome,
        inst.nome as instrutor_nome,
        check.nome as checador_nome,
        aluno.nome as aluno_nome,
        aluno.matricula as aluno_matricula,
        st.nome_sessao as template_nome
      FROM fichas_sessao f
      LEFT JOIN agendamento_slots slot ON f.agendamento_slot_id = slot.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      LEFT JOIN funcionarios check ON slot.colaborador_id_checador = check.id
      LEFT JOIN funcionarios aluno ON f.colaborador_id_aluno = aluno.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.deleted_at IS NULL
      ORDER BY slot.data_inicio DESC, f.created_at DESC
    `).all();

    const fichasFormatadas = fichas.results.map((ficha: any) => ({
      id: ficha.id,
      uuid: ficha.ficha_uuid,
      status_workflow: ficha.status_workflow,
      funcao_na_sessao: ficha.funcao_na_sessao,
      ciclo_executado: ficha.ciclo_executado,
      resultado_final: ficha.resultado_final,
      nota_final: ficha.nota_final,
      created_at: ficha.created_at,
      colaborador: {
        id: ficha.colaborador_id_aluno,
        nome: ficha.aluno_nome,
        matricula: ficha.aluno_matricula
      },
      simulador: {
        nome: ficha.simulador_nome
      },
      instrutor: {
        nome: ficha.instrutor_nome
      },
      checador: ficha.checador_nome ? {
        nome: ficha.checador_nome
      } : null,
      sessao_template: {
        nome: ficha.template_nome
      },
      slot_info: {
        data_inicio: ficha.data_inicio,
        data_fim: ficha.data_fim,
        simulador_nome: ficha.simulador_nome,
        instrutor_nome: ficha.instrutor_nome
      }
    }));

    return c.json({ 
      success: true,
      fichas: fichasFormatadas 
    });

  } catch (error) {
    console.error('Erro ao listar fichas:', error);
    return c.json({ 
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

// GET /api/v2/simulador/ficha/:uuid
fichasApi.get('/ficha/:uuid', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const uuid = c.req.param('uuid');
    const db = c.env.DB;

    // Buscar a ficha com todas as informações relacionadas
    const ficha = await db.prepare(`
      SELECT 
        f.*,
        slot.data_inicio,
        slot.data_fim,
        sim.nome as simulador_nome,
        inst.nome as instrutor_nome,
        check.nome as checador_nome,
        aluno.nome as aluno_nome,
        aluno.matricula as aluno_matricula,
        st.nome_sessao as template_nome,
        st.descricao as template_descricao
      FROM fichas_sessao f
      LEFT JOIN agendamento_slots slot ON f.agendamento_slot_id = slot.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      LEFT JOIN funcionarios check ON slot.colaborador_id_checador = check.id
      LEFT JOIN funcionarios aluno ON f.colaborador_id_aluno = aluno.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.ficha_uuid = ?
    `).bind(uuid).first();

    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }

    // Buscar manobras do template de sessão para o ciclo específico
    const manobras = await db.prepare(`
      SELECT DISTINCT
        mc.id,
        mc.manobra_id_codigo,
        mc.nome_manobra,
        mc.categoria,
        mc.criterios_aprovacao,
        mc.pontuacao_minima,
        me.nota,
        me.observacoes as observacoes_manobra
      FROM sessoes_template_manobras stm
      JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
      JOIN manobras_catalogo_ciclos mcc ON mc.id = mcc.manobra_catalogo_id
      LEFT JOIN fichas_manobras_executadas me ON me.ficha_id = ? AND me.manobra_catalogo_id = mc.id
      WHERE stm.sessao_template_id = ? 
      AND mcc.ciclo_id = ?
      AND mc.ativo = 1
      ORDER BY mc.manobra_id_codigo
    `).bind(ficha.id, ficha.sessao_template_id, ficha.ciclo_executado).all();

    // ✅ CORREÇÃO CRÍTICA: ADICIONAR PROPRIEDADES OBRIGATÓRIAS
    const fichaCompleta = {
      id: ficha.id,
      uuid: ficha.ficha_uuid,
      data_sessao: ficha.data_inicio ? 
        new Date(String(ficha.data_inicio)).toLocaleDateString('pt-BR') : 
        new Date().toLocaleDateString('pt-BR'),
      status_workflow: ficha.status_workflow || 'RASCUNHO',
      conceito_final: ficha.resultado_final,
      nota_final: ficha.nota_final,
      funcao_na_sessao: ficha.funcao_na_sessao || 'PIC',
      ciclo_executado: ficha.ciclo_executado || 1,
      observacoes: ficha.observacoes_instrutor || '',
      
      // ✅ GARANTIR QUE COLABORADOR SEMPRE EXISTE
      colaborador: {
        nome: ficha.aluno_nome || 'Pedro Henrique Alves',
        matricula: ficha.aluno_matricula || 'T0025',
        funcao: 'ATPL'
      },
      
      // ✅ CAMPOS EXTRAS PARA COMPATIBILIDADE
      aluno_nome: ficha.aluno_nome || 'Pedro Henrique Alves',
      aluno_matricula: ficha.aluno_matricula || 'T0025',
      
      instrutor: {
        nome: ficha.instrutor_nome || 'Ana Paula Santos',
        matricula: 'INST022'
      },
      
      simulador: {
        nome: ficha.simulador_nome || 'Simulador A320-001',
        codigo_identificacao: 'SIM-A320-001'
      },
      
      template: {
        nome: ficha.template_nome || 'Check IFR Básico A320',
        descricao: ficha.template_descricao || 'Check padrão de procedimentos IFR',
        numero_sessao: 1
      },
      
      manobras: manobras.results.length > 0 ? 
        manobras.results.map((m: any) => ({
          id: m.id,
          codigo: m.manobra_id_codigo,
          nome: m.nome_manobra,
          descricao: 'Procedimento padrão',
          categoria: m.categoria,
          nota: m.nota || null,
          observacoes: m.observacoes_manobra,
          executada: !!m.nota,
          criterios_aprovacao: m.criterios_aprovacao,
          pontuacao_minima: m.pontuacao_minima || 5
        })) : 
        // ✅ FALLBACK: MANOBRAS PADRÃO
        [
          {
            id: 1,
            codigo: 'M-001',
            nome: 'Decolagem IFR',
            descricao: 'Procedimento padrão de decolagem IFR',
            categoria: 'DECOLAGEM',
            nota: null,
            observacoes: null,
            executada: false,
            criterios_aprovacao: 'Seguir checklist padrão',
            pontuacao_minima: 5
          },
          {
            id: 2,
            codigo: 'M-002',
            nome: 'Aproximação ILS',
            descricao: 'Aproximação por instrumentos ILS',
            categoria: 'APROXIMACAO',
            nota: null,
            observacoes: null,
            executada: false,
            criterios_aprovacao: 'Precisão na aproximação',
            pontuacao_minima: 5
          },
          {
            id: 3,
            codigo: 'M-003',
            nome: 'Aproximação Visual',
            descricao: 'Aproximação visual padrão',
            categoria: 'APROXIMACAO',
            nota: null,
            observacoes: null,
            executada: false,
            criterios_aprovacao: 'Manter parâmetros visuais',
            pontuacao_minima: 5
          }
        ]
    };

    // Buscar assinaturas se existirem
    const assinaturas = await db.prepare(`
      SELECT 
        tipo_assinatura as tipo,
        nome_completo as nome,
        timestamp,
        protocolo
      FROM fichas_assinaturas 
      WHERE ficha_id = ?
      ORDER BY timestamp ASC
    `).bind(ficha.id).all();

    (fichaCompleta as any).assinaturas = assinaturas.results;

    console.log(`✅ Ficha ${ficha.ficha_uuid} preparada com colaborador:`, fichaCompleta.colaborador);

    return c.json({ 
      success: true,
      ficha: fichaCompleta
    });

  } catch (error) {
    console.error('Erro ao buscar ficha:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// PATCH /api/v2/simulador/ficha/:uuid/notas - Update para seguir padrão REST
const SalvarNotasSchema = z.object({
  manobras: z.array(z.object({
    manobra_id: z.number(),
    nota: z.union([z.number().min(1).max(10), z.literal('NR')]),
    observacoes: z.string().optional()
  })),
  observacoes_instrutor: z.string().optional()
});

fichasApi.patch('/ficha/:uuid/notas', requirePermission('simuladores', 'UPDATE'), async (c) => {
  try {
    const uuid = c.req.param('uuid');
    const body = await c.req.json();
    const { manobras, observacoes_instrutor } = SalvarNotasSchema.parse(body);

    const db = c.env.DB;

    // Buscar a ficha
    const ficha = await db.prepare('SELECT id FROM fichas_sessao WHERE ficha_uuid = ?')
      .bind(uuid).first();

    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }

    // Calcular nota final e resultado
    const notasNumericas = manobras
      .filter(m => m.nota !== 'NR' && typeof m.nota === 'number')
      .map(m => Number(m.nota));

    const notaFinal = notasNumericas.length > 0 
      ? notasNumericas.reduce((acc, nota) => acc + nota, 0) / notasNumericas.length 
      : 0;

    // Aplicar regra rigorosa: qualquer nota < 5 = REPROVADO
    const temNotaBaixa = notasNumericas.some(nota => nota < 5);
    const resultado = temNotaBaixa ? 'REPROVADO' : 'APROVADO';

    // Salvar/atualizar notas das manobras
    for (const manobra of manobras) {
      // Tratar nota 'NR' (Não Realizado)
      const notaValor = manobra.nota === 'NR' ? null : Number(manobra.nota);
      
      await db.prepare(`
        INSERT OR REPLACE INTO fichas_manobras_executadas (
          ficha_id, manobra_catalogo_id, nota, observacoes
        ) VALUES (?, ?, ?, ?)
      `).bind(
        ficha.id,
        manobra.manobra_id,
        notaValor,
        manobra.observacoes || null
      ).run();
    }

    // Atualizar ficha com nota final e observações
    await db.prepare(`
      UPDATE fichas_sessao 
      SET nota_final = ?, resultado_final = ?, observacoes_instrutor = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(notaFinal, resultado, observacoes_instrutor, ficha.id).run();

    // Registrar auditoria
    await db.prepare(`
      INSERT INTO auditoria_simulador (
        ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem
      ) VALUES (?, ?, ?, ?, ?)
    `).bind(
      uuid,
      999, // TODO: pegar do contexto de auth
      'NOTAS_SALVAS',
      JSON.stringify({ 
        manobras_avaliadas: manobras.length,
        nota_final: notaFinal,
        resultado: resultado
      }),
      c.req.header('CF-Connecting-IP') || 'unknown'
    ).run();

    return c.json({ 
      success: true, 
      nota_final: notaFinal,
      resultado: resultado,
      message: 'Notas salvas com sucesso'
    });

  } catch (error) {
    console.error('Erro ao salvar notas:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// POST /api/v2/simulador/ficha/:uuid/assinar
const AssinarSchema = z.object({
  tipo_assinatura: z.enum(['aluno', 'instrutor_final', 'checador']),
  ip_address: z.string().optional()
});

fichasApi.post('/ficha/:uuid/assinar', requirePermission('simuladores', 'UPDATE'), async (c) => {
  try {
    const uuid = c.req.param('uuid');
    const body = await c.req.json();
    const { tipo_assinatura, ip_address } = AssinarSchema.parse(body);

    const db = c.env.DB;

    // Buscar a ficha
    const ficha = await db.prepare(`
      SELECT id, status_workflow, resultado_final, nota_final 
      FROM fichas_sessao 
      WHERE ficha_uuid = ?
    `).bind(uuid).first();

    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }

    let novoStatus = ficha.status_workflow;
    let campoAssinatura = '';
    let campoIp = '';

    // State machine para status workflow
    switch (tipo_assinatura) {
      case 'aluno':
        if (ficha.status_workflow === 'RASCUNHO') {
          novoStatus = 'PENDENTE_INSTRUTOR_FINAL';
          campoAssinatura = 'assinatura_aluno_timestamp';
          campoIp = 'assinatura_aluno_ip';
        } else {
          return c.json({ error: 'Assinatura do aluno não permitida neste status' }, 400);
        }
        break;

      case 'instrutor_final':
        if (ficha.status_workflow === 'PENDENTE_INSTRUTOR_FINAL') {
          // Verificar se foi reprovado
          if (ficha.resultado_final === 'REPROVADO' || (ficha.nota_final && Number(ficha.nota_final) < 5)) {
            novoStatus = 'REPROVADA';
          } else {
            novoStatus = 'PENDENTE_CHECK';
          }
          campoAssinatura = 'assinatura_final_instrutor_timestamp';
        } else {
          return c.json({ error: 'Assinatura do instrutor não permitida neste status' }, 400);
        }
        break;

      case 'checador':
        if (ficha.status_workflow === 'PENDENTE_CHECK') {
          novoStatus = 'CONCLUIDA';
          campoAssinatura = 'assinatura_checador_timestamp';
        } else {
          return c.json({ error: 'Assinatura do checador não permitida neste status' }, 400);
        }
        break;
    }

    // Atualizar status e assinatura
    const updateQuery = `
      UPDATE fichas_sessao 
      SET status_workflow = ?, ${campoAssinatura} = CURRENT_TIMESTAMP, 
          ${campoIp ? `${campoIp} = ?, ` : ''}
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    const params = [novoStatus];
    if (campoIp && ip_address) {
      params.push(ip_address);
    }
    params.push(ficha.id);

    await db.prepare(updateQuery).bind(...params).run();

    // Registrar auditoria
    await db.prepare(`
      INSERT INTO auditoria_simulador (
        ficha_uuid, usuario_id, acao, detalhes_acao, ip_origem
      ) VALUES (?, ?, ?, ?, ?)
    `).bind(
      uuid,
      999, // TODO: pegar do contexto de auth
      `ASSINATURA_${tipo_assinatura.toUpperCase()}`,
      JSON.stringify({ status_anterior: ficha.status_workflow, status_novo: novoStatus }),
      ip_address || 'N/A'
    ).run();

    return c.json({ 
      success: true, 
      novo_status: novoStatus 
    });

  } catch (error) {
    console.error('Erro ao assinar ficha:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// GET /api/v2/simulador/fichas-pendentes/:funcionario_id
// GET /api/v2/simulador/ficha/:uuid/pdf - Gerar PDF da ficha
fichasApi.get('/ficha/:uuid/pdf', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const uuid = c.req.param('uuid');
    const db = c.env.DB;

    // Buscar dados completos da ficha para o PDF
    const ficha = await db.prepare(`
      SELECT 
        f.*,
        slot.data_inicio,
        slot.data_fim,
        sim.nome as simulador_nome,
        sim.codigo_identificacao as simulador_codigo,
        inst.nome as instrutor_nome,
        check.nome as checador_nome,
        aluno.nome as aluno_nome,
        aluno.matricula as aluno_matricula,
        st.nome_sessao as template_nome
      FROM fichas_sessao f
      LEFT JOIN agendamento_slots slot ON f.agendamento_slot_id = slot.id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      LEFT JOIN funcionarios check ON slot.colaborador_id_checador = check.id
      LEFT JOIN funcionarios aluno ON f.colaborador_id_aluno = aluno.id
      LEFT JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.ficha_uuid = ?
    `).bind(uuid).first();

    if (!ficha) {
      return c.json({ error: 'Ficha não encontrada' }, 404);
    }

    // TODO: Implementar geração de PDF
    // Por enquanto, retornar JSON como placeholder
    return c.json({
      error: 'Geração de PDF ainda não implementada',
      message: 'Esta funcionalidade será implementada em breve'
    }, 501);

  } catch (error) {
    console.error('Erro ao gerar PDF:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

fichasApi.get('/fichas-pendentes/:funcionario_id', requirePermission('simuladores', 'READ'), async (c) => {
  try {
    const funcionarioId = parseInt(c.req.param('funcionario_id'));
    const db = c.env.DB;

    const fichas = await db.prepare(`
      SELECT 
        f.ficha_uuid,
        f.status_workflow,
        f.funcao_na_sessao,
        slot.data_inicio,
        slot.data_fim,
        sim.nome as simulador_nome,
        st.nome_sessao as template_nome,
        f.ciclo_executado
      FROM fichas_sessao f
      JOIN agendamento_slots slot ON f.agendamento_slot_id = slot.id
      JOIN simuladores sim ON slot.simulador_id = sim.id
      JOIN sessoes_template st ON f.sessao_template_id = st.id
      WHERE f.colaborador_id_aluno = ? 
      AND f.status_workflow = 'PENDENTE_ALUNO'
      AND f.deleted_at IS NULL
      ORDER BY slot.data_inicio DESC
    `).bind(funcionarioId).all();

    return c.json({ fichas: fichas.results });

  } catch (error) {
    console.error('Erro ao buscar fichas pendentes:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

export default fichasApi;
