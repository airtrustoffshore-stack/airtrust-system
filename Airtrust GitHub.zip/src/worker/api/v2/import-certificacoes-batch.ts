import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';
import { gerarProximoIdCertificacao, normalizarMatricula } from '../../../shared/utils/certificacao-utils';
import { DateParser } from '../../utils/date-parser';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// ✅ CONFIGURAÇÕES DE BATCH PARA EVITAR RATE LIMIT
const BATCH_CONFIG = {
  LINHAS_POR_BATCH: 25,           // Limite seguro: 25 linhas por batch
  DELAY_ENTRE_BATCHES_MS: 250,   // Pausa de 250ms entre batches
  MAX_RETRIES: 3,                // Máximo 3 tentativas por batch
  BACKOFF_INICIAL_MS: 1000,      // Backoff inicial de 1s
  BACKOFF_MULTIPLICADOR: 2,      // Multiplicador para backoff exponencial
  TIMEOUT_BATCH_MS: 10000        // Timeout de 10s por batch
};

// ✅ FUNÇÃO DE SLEEP PARA CONTROLAR RATE LIMIT
const sleep = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

// ✅ FUNÇÃO PARA DETECTAR ERRO DE RATE LIMIT
const isRateLimitError = (error: any): boolean => {
  const errorMessage = error?.message?.toLowerCase() || '';
  return errorMessage.includes('too many') || 
         errorMessage.includes('rate limit') ||
         errorMessage.includes('quota') ||
         errorMessage.includes('throttle');
};

// ✅ FUNÇÃO CORRIGIDA PARA MAPEAR CAMPOS CSV FLEXIVELMENTE
const mapearCamposCSV = (header: string[]) => {
  const mapeamento: any = {};
  
  // Normalizar cabeçalhos (remover acentos, pontos, espaços, minúsculas)
  const normalizar = (str: string) => {
    return str.toLowerCase()
      .replace(/[áàâãäå]/g, 'a')
      .replace(/[éèêë]/g, 'e')
      .replace(/[íìîï]/g, 'i')
      .replace(/[óòôõö]/g, 'o')
      .replace(/[úùûü]/g, 'u')
      .replace(/[ç]/g, 'c')
      .replace(/[^a-z0-9]/g, ''); // Remove pontos, espaços, etc.
  };
  
  header.forEach((campo, index) => {
    const campoNormalizado = normalizar(campo);
    
    // ✅ MAPEAMENTO PARA MATRÍCULA
    if (['matricula', 'mat', 'funcionariomatricula', 'colaboradormatricula'].includes(campoNormalizado)) {
      mapeamento.funcionario_matricula = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA TREINAMENTO
    if (['treinamento', 'treinamentocodigo', 'codigo', 'codigotreinamento'].includes(campoNormalizado)) {
      mapeamento.treinamento_codigo = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA DATA CONCLUSÃO
    if (['dataconclusao', 'conclusao', 'data', 'datarealizacao'].includes(campoNormalizado)) {
      mapeamento.data_conclusao = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA INSTRUTOR
    if (['instrutor', 'professor', 'responsavel'].includes(campoNormalizado)) {
      mapeamento.instrutor = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA NOTA
    if (['nota', 'notafinal', 'pontuacao', 'resultado'].includes(campoNormalizado)) {
      mapeamento.nota_final = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA DATA VENCIMENTO
    if (['datavencimento', 'vencimento', 'validade', 'expiracao'].includes(campoNormalizado)) {
      mapeamento.data_vencimento = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
    
    // ✅ MAPEAMENTO PARA OBSERVAÇÕES
    if (['observacoes', 'obs', 'comentarios', 'notas'].includes(campoNormalizado)) {
      mapeamento.observacoes = {
        index: index,
        original: campo,
        encontrado: true
      };
    }
  });
  
  return mapeamento;
};

// ✅ FUNÇÃO PARA BUSCAR OU CRIAR FUNCIONÁRIO COM VALIDAÇÃO RIGOROSA
const buscarOuCriarFuncionario = async (matricula: string, db: any) => {
  const matriculaNormalizada = normalizarMatricula(matricula);
  
  const funcionario = await db.prepare(
    'SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL'
  ).bind(matriculaNormalizada).first();
  
  if (!funcionario) {
    throw new Error(`Funcionário com matrícula '${matriculaNormalizada}' não encontrado. Cadastre o funcionário antes de importar certificações.`);
  }
  
  funcionario.existia = true;
  return funcionario;
};

// ✅ FUNÇÃO PARA BUSCAR OU CRIAR TREINAMENTO
const buscarOuCriarTreinamento = async (codigo: string, nome?: string, db?: any) => {
  let treinamento = await db.prepare(
    'SELECT id, codigo, nome FROM catalogo_treinamentos_v2 WHERE codigo = ? AND deleted_at IS NULL'
  ).bind(codigo).first();
  
  if (!treinamento) {
    const nomeTrainamento = nome || `Treinamento ${codigo}`;
    const result = await db.prepare(`
      INSERT INTO catalogo_treinamentos_v2 (
        codigo, nome, categoria, ativo, created_at, updated_at
      ) VALUES (?, ?, 'IMPORTADO_CSV', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(codigo, nomeTrainamento).run();
    
    if (result.success && result.meta?.last_row_id) {
      treinamento = {
        id: result.meta.last_row_id,
        codigo: codigo,
        nome: nomeTrainamento,
        existia: false
      };
    } else {
      throw new Error(`Erro ao criar treinamento ${codigo}`);
    }
  } else {
    treinamento.existia = true;
  }
  
  return treinamento;
};

// ✅ PROCESSAMENTO DE UM ÚNICO BATCH COM RETRY E BACKOFF
const processarBatch = async (
  linhas: string[], 
  startIndex: number, 
  batchSize: number, 
  header: string[], 
  mapeamento: any, 
  db: any, 
  batchNumber: number
): Promise<{
  linhas_processadas: number;
  criados: number;
  funcionariosCriados: number;
  treinamentosCriados: number;
  erros: string[];
  sucessos: string[];
  duplicatas: number;
  tentativas: number;
  tempo_batch_ms: number;
  pausas_aplicadas: number;
}> => {
  const startTime = Date.now();
  let tentativas = 0;
  let linhas_processadas = 0;
  let criados = 0;
  let funcionariosCriados = 0;
  let treinamentosCriados = 0;
  let duplicatas = 0;
  let pausas_aplicadas = 0;
  const erros: string[] = [];
  const sucessos: string[] = [];
  const novosFuncionarios: string[] = [];
  const novosTreinamentos: string[] = [];

  const endIndex = Math.min(startIndex + batchSize, linhas.length);
  console.log(`📦 [BATCH ${batchNumber}] Processando linhas ${startIndex + 1} a ${endIndex} (${endIndex - startIndex} linhas)`);

  while (tentativas < BATCH_CONFIG.MAX_RETRIES) {
    tentativas++;
    
    try {
      // ✅ PROCESSAR LINHAS DO BATCH ATUAL
      for (let i = startIndex; i < endIndex; i++) {
        try {
          const values = linhas[i].split(',').map(v => v.trim().replace(/"/g, ''));
          
          if (values.length !== header.length) {
            const erro = `Batch ${batchNumber}, Linha ${i+1}: esperado ${header.length} campos, encontrado ${values.length}`;
            erros.push(erro);
            continue;
          }

          // ✅ EXTRAIR DADOS USANDO MAPEAMENTO
          const rowData: any = {};
          
          rowData.funcionario_matricula = values[mapeamento.funcionario_matricula.index];
          rowData.treinamento_codigo = values[mapeamento.treinamento_codigo.index];
          rowData.data_conclusao = values[mapeamento.data_conclusao.index];
          
          if (mapeamento.instrutor?.encontrado) {
            rowData.instrutor = values[mapeamento.instrutor.index];
          }
          if (mapeamento.nota_final?.encontrado) {
            rowData.nota_final = values[mapeamento.nota_final.index];
          }
          if (mapeamento.data_vencimento?.encontrado) {
            rowData.data_vencimento = values[mapeamento.data_vencimento.index];
          }
          if (mapeamento.observacoes?.encontrado) {
            rowData.observacoes = values[mapeamento.observacoes.index];
          }

          // Validação rigorosa de campos obrigatórios
          if (!rowData.funcionario_matricula || !rowData.treinamento_codigo || !rowData.data_conclusao) {
            const erro = `Batch ${batchNumber}, Linha ${i+1}: campos 'funcionario_matricula', 'treinamento_codigo' e 'data_conclusao' são obrigatórios`;
            erros.push(erro);
            continue;
          }

          // ✅ PROCESSAR DATAS NO FORMATO BRASILEIRO
          let datasProcessadas;
          try {
            datasProcessadas = DateParser.processCSVDates(rowData);
            
            // Adicionar warnings se houver
            if (datasProcessadas.warnings.length > 0) {
              datasProcessadas.warnings.forEach(warning => {
                erros.push(`Batch ${batchNumber}, Linha ${i+1}: ${warning}`);
              });
            }
            
            // Atualizar rowData com datas convertidas
            if (datasProcessadas.data_conclusao) {
              rowData.data_conclusao = datasProcessadas.data_conclusao;
            }
            if (datasProcessadas.data_vencimento) {
              rowData.data_vencimento = datasProcessadas.data_vencimento;
            }
            
          } catch (dateError) {
            const erro = `Batch ${batchNumber}, Linha ${i+1}: ${dateError instanceof Error ? dateError.message : 'Erro no processamento de datas'}`;
            erros.push(erro);
            continue;
          }

          // 🔍 BUSCAR FUNCIONÁRIO
          const funcionario = await buscarOuCriarFuncionario(rowData.funcionario_matricula, db);
          if (!funcionario.existia) {
            funcionariosCriados++;
            novosFuncionarios.push(`${funcionario.nome} (${funcionario.matricula})`);
          }

          // 🔍 BUSCAR OU CRIAR TREINAMENTO  
          const treinamento = await buscarOuCriarTreinamento(rowData.treinamento_codigo, undefined, db);
          if (!treinamento.existia) {
            treinamentosCriados++;
            novosTreinamentos.push(`${treinamento.nome} (${treinamento.codigo})`);
          }

          // ✅ GERAR ID COM FORMATO CORRETO
          const certificacaoId = await gerarProximoIdCertificacao(
            funcionario.id,
            treinamento.id,
            rowData.data_conclusao,
            db
          );

          // Verificar duplicata
          const existente = await db.prepare(`
            SELECT id FROM historico_certificacoes_v2 
            WHERE funcionario_id = ? AND treinamento_id = ? 
            AND status = 'ATIVO' AND deleted_at IS NULL
          `).bind(funcionario.id, treinamento.id).first();

          if (existente) {
            duplicatas++;
            continue;
          }

          // ✅ CRIAR CERTIFICAÇÃO
          const now = new Date().toISOString();
          await db.prepare(`
            INSERT INTO historico_certificacoes_v2 
            (funcionario_id, treinamento_id, data_conclusao, 
             data_vencimento, instrutor, nota_final, observacoes, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'ATIVO', ?, ?)
          `).bind(
            funcionario.id,
            treinamento.id,
            rowData.data_conclusao,
            rowData.data_vencimento || null,
            rowData.instrutor || null,
            rowData.nota_final ? parseFloat(rowData.nota_final) : null,
            rowData.observacoes || null,
            now,
            now
          ).run();

          criados++;
          linhas_processadas++;
          sucessos.push(`🏆 ${certificacaoId}: ${funcionario.nome} certificado em ${treinamento.nome} (${rowData.data_conclusao})`);

        } catch (error) {
          // ✅ DETECTAR RATE LIMIT E APLICAR BACKOFF
          if (isRateLimitError(error)) {
            const backoffTime = BATCH_CONFIG.BACKOFF_INICIAL_MS * Math.pow(BATCH_CONFIG.BACKOFF_MULTIPLICADOR, tentativas - 1);
            console.log(`⚠️ [BATCH ${batchNumber}] Rate limit detectado na linha ${i+1}, aplicando backoff de ${backoffTime}ms`);
            await sleep(backoffTime);
            pausas_aplicadas++;
            throw error; // Re-throw para tentar novamente o batch completo
          }
          
          const erro = `Batch ${batchNumber}, Linha ${i+1}: ${error instanceof Error ? error.message : 'Erro desconhecido'}`;
          erros.push(erro);
        }
      }

      // ✅ SE CHEGOU AQUI, BATCH FOI PROCESSADO COM SUCESSO
      console.log(`✅ [BATCH ${batchNumber}] Processado com sucesso em ${tentativas} tentativa(s)`);
      break;

    } catch (batchError) {
      console.error(`❌ [BATCH ${batchNumber}] Erro na tentativa ${tentativas}:`, batchError);
      
      if (isRateLimitError(batchError)) {
        const backoffTime = BATCH_CONFIG.BACKOFF_INICIAL_MS * Math.pow(BATCH_CONFIG.BACKOFF_MULTIPLICADOR, tentativas - 1);
        console.log(`🔄 [BATCH ${batchNumber}] Tentativa ${tentativas}/${BATCH_CONFIG.MAX_RETRIES} falhou, aguardando ${backoffTime}ms antes da próxima tentativa`);
        await sleep(backoffTime);
        pausas_aplicadas++;
      } else {
        // Se não é rate limit, não faz sentido tentar novamente
        erros.push(`Batch ${batchNumber}: ${batchError instanceof Error ? batchError.message : 'Erro crítico no batch'}`);
        break;
      }

      if (tentativas === BATCH_CONFIG.MAX_RETRIES) {
        erros.push(`Batch ${batchNumber}: Máximo de tentativas excedido (${BATCH_CONFIG.MAX_RETRIES})`);
      }
    }
  }

  const tempo_batch_ms = Date.now() - startTime;
  console.log(`⏱️ [BATCH ${batchNumber}] Finalizado: ${linhas_processadas} processadas, ${criados} criadas, ${erros.length} erros (${tempo_batch_ms}ms, ${tentativas} tentativas, ${pausas_aplicadas} pausas)`);

  return {
    linhas_processadas,
    criados,
    funcionariosCriados,
    treinamentosCriados,
    erros,
    sucessos,
    duplicatas,
    tentativas,
    tempo_batch_ms,
    pausas_aplicadas
  };
};

// ✅ ENDPOINT PRINCIPAL COM PROCESSAMENTO EM BATCHES CONTROLADOS
app.post('/import-planilha-batch', requirePermission('treinamentos', 'CREATE'), async (c) => {
  const startTime = Date.now();
  const batchId = `batch_${Date.now()}`;

  try {
    console.log('🚀 === IMPORTAÇÃO CERTIFICAÇÕES COM BATCHES CONTROLADOS ===');
    console.log(`⚙️ Configuração de batches: ${BATCH_CONFIG.LINHAS_POR_BATCH} linhas por batch, ${BATCH_CONFIG.DELAY_ENTRE_BATCHES_MS}ms de delay`);
    
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        total_rows: 0,
        linhas_processadas: 0,
        importadas_com_sucesso: 0,
        erros_por_lote: 0,
        total_batches: 0,
        linhas_reprocessadas: 0,
        pausas_aplicadas: 0,
        rate_limits_detectados: 0,
        errors: [{
          row: 0,
          field: 'file',
          message: 'Arquivo CSV é obrigatório',
          error_type: 'VALIDATION',
          severity: 'CRITICAL'
        }],
        warnings: [],
        summary: 'Arquivo não fornecido',
        limite_seguro_recomendado: BATCH_CONFIG.LINHAS_POR_BATCH
      }, 400);
    }

    console.log('📁 Processando arquivo:', file.name, 'Tamanho:', file.size);
    
    const csvText = await file.text();
    const lines = csvText.trim().split('\n');
    
    if (lines.length < 2) {
      return c.json({
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        total_rows: 0,
        linhas_processadas: 0,
        importadas_com_sucesso: 0,
        erros_por_lote: 1,
        total_batches: 0,
        linhas_reprocessadas: 0,
        pausas_aplicadas: 0,
        rate_limits_detectados: 0,
        errors: [{
          row: 0,
          field: 'file_content',
          message: 'Arquivo deve ter cabeçalho + pelo menos 1 linha de dados',
          error_type: 'VALIDATION',
          severity: 'CRITICAL'
        }],
        warnings: [],
        summary: 'Arquivo inválido',
        limite_seguro_recomendado: BATCH_CONFIG.LINHAS_POR_BATCH
      }, 400);
    }

    const db = c.env.DB;
    
    // ✅ PROCESSAR CABEÇALHO
    const header = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    console.log('📋 Header original:', header);
    
    const mapeamento = mapearCamposCSV(header);
    console.log('🔄 Mapeamento encontrado:', mapeamento);
    
    // ✅ VALIDAÇÃO RIGOROSA
    const errosValidacao = [];
    
    if (!mapeamento.funcionario_matricula?.encontrado) {
      errosValidacao.push("Campo obrigatório 'funcionario_matricula' não encontrado");
    }
    
    if (!mapeamento.treinamento_codigo?.encontrado) {
      errosValidacao.push("Campo obrigatório 'treinamento_codigo' não encontrado");
    }
    
    if (!mapeamento.data_conclusao?.encontrado) {
      errosValidacao.push("Campo obrigatório 'data_conclusao' não encontrado");
    }
    
    if (errosValidacao.length > 0) {
      return c.json({
        success: false,
        batch_id: batchId,
        processing_time_ms: Date.now() - startTime,
        total_rows: lines.length - 1,
        linhas_processadas: 0,
        importadas_com_sucesso: 0,
        erros_por_lote: errosValidacao.length,
        total_batches: 0,
        linhas_reprocessadas: 0,
        pausas_aplicadas: 0,
        rate_limits_detectados: 0,
        errors: errosValidacao.map((erro) => ({
          row: 0,
          field: 'header_validation',
          message: erro,
          error_type: 'VALIDATION' as const,
          severity: 'CRITICAL' as const
        })),
        warnings: [],
        summary: 'Erros de validação do cabeçalho CSV',
        limite_seguro_recomendado: BATCH_CONFIG.LINHAS_POR_BATCH
      }, 400);
    }

    // ✅ CALCULAR BATCHES
    const totalLinhas = lines.length - 1; // Excluir header
    const totalBatches = Math.ceil(totalLinhas / BATCH_CONFIG.LINHAS_POR_BATCH);
    
    console.log(`📊 Total de ${totalLinhas} linhas de dados, divididas em ${totalBatches} batches de até ${BATCH_CONFIG.LINHAS_POR_BATCH} linhas`);

    // ✅ CONTADORES GLOBAIS
    let totalLinhasProcessadas = 0;
    let totalCriados = 0;
    let totalFuncionariosCriados = 0;
    let totalTreinamentosCriados = 0;
    let totalDuplicatas = 0;
    let totalTentativas = 0;
    let totalPausas = 0;
    const todosErros: string[] = [];
    const todosSucessos: string[] = [];
    const batchesLogs: any[] = [];

    // ✅ PROCESSAR CADA BATCH SEQUENCIALMENTE
    for (let batchNum = 0; batchNum < totalBatches; batchNum++) {
      const startIndex = batchNum * BATCH_CONFIG.LINHAS_POR_BATCH + 1; // +1 para pular header
      
      console.log(`\n🔥 Iniciando processamento do batch ${batchNum + 1}/${totalBatches}`);
      
      const resultadoBatch = await processarBatch(
        lines,
        startIndex,
        BATCH_CONFIG.LINHAS_POR_BATCH,
        header,
        mapeamento,
        db,
        batchNum + 1
      );

      // ✅ ACUMULAR RESULTADOS
      totalLinhasProcessadas += resultadoBatch.linhas_processadas;
      totalCriados += resultadoBatch.criados;
      totalFuncionariosCriados += resultadoBatch.funcionariosCriados;
      totalTreinamentosCriados += resultadoBatch.treinamentosCriados;
      totalDuplicatas += resultadoBatch.duplicatas;
      totalTentativas += resultadoBatch.tentativas;
      totalPausas += resultadoBatch.pausas_aplicadas;
      todosErros.push(...resultadoBatch.erros);
      todosSucessos.push(...resultadoBatch.sucessos);

      // ✅ LOG DETALHADO DO BATCH
      const batchLog = {
        batch_numero: batchNum + 1,
        linhas_inicio: startIndex,
        linhas_fim: Math.min(startIndex + BATCH_CONFIG.LINHAS_POR_BATCH - 1, lines.length - 1),
        linhas_processadas: resultadoBatch.linhas_processadas,
        certificacoes_criadas: resultadoBatch.criados,
        duplicatas_detectadas: resultadoBatch.duplicatas,
        erros_count: resultadoBatch.erros.length,
        tentativas_necessarias: resultadoBatch.tentativas,
        pausas_aplicadas: resultadoBatch.pausas_aplicadas,
        tempo_processamento_ms: resultadoBatch.tempo_batch_ms,
        status: resultadoBatch.erros.length === 0 ? 'SUCESSO' : 'SUCESSO_PARCIAL'
      };
      
      batchesLogs.push(batchLog);
      console.log(`📝 [BATCH ${batchNum + 1}] Log:`, batchLog);

      // ✅ DELAY ENTRE BATCHES PARA CONTROLAR RATE LIMIT
      if (batchNum < totalBatches - 1) { // Não fazer delay após o último batch
        console.log(`⏳ Aguardando ${BATCH_CONFIG.DELAY_ENTRE_BATCHES_MS}ms antes do próximo batch...`);
        await sleep(BATCH_CONFIG.DELAY_ENTRE_BATCHES_MS);
      }
    }

    // AUDITORIA DETALHADA
    await logAudit(c, 'IMPORT_CERTIFICACOES_BATCH', 'historico_certificacoes_v2', batchId, undefined, {
      total_linhas: totalLinhas,
      linhas_processadas: totalLinhasProcessadas,
      importadas_com_sucesso: totalCriados,
      funcionarios_criados: totalFuncionariosCriados,
      treinamentos_criados: totalTreinamentosCriados,
      duplicatas_detectadas: totalDuplicatas,
      total_batches: totalBatches,
      total_tentativas: totalTentativas,
      pausas_aplicadas: totalPausas,
      erros_count: todosErros.length,
      batches_detalhes: batchesLogs
    });

    const processingTime = Date.now() - startTime;
    console.log(`\n🎯 === IMPORTAÇÃO FINALIZADA ===`);
    console.log(`✅ Processadas: ${totalLinhasProcessadas}/${totalLinhas} linhas`);
    console.log(`✅ Importadas: ${totalCriados} certificações`);
    console.log(`✅ Batches: ${totalBatches}, Tentativas: ${totalTentativas}, Pausas: ${totalPausas}`);
    console.log(`✅ Tempo total: ${processingTime}ms`);
    console.log(`✅ Erros: ${todosErros.length}`);

    // ✅ RESPOSTA FINAL DETALHADA CONFORME SOLICITADO
    return c.json({
      success: true,
      batch_id: batchId,
      processing_time_ms: processingTime,
      
      // ✅ CAMPOS SOLICITADOS PELO USUÁRIO
      total_rows: totalLinhas,
      linhas_processadas: totalLinhasProcessadas,
      importadas_com_sucesso: totalCriados,
      erros_por_lote: todosErros.length,
      total_batches: totalBatches,
      linhas_reprocessadas: totalTentativas - totalBatches, // Linhas que precisaram de retry
      pausas_aplicadas: totalPausas,
      rate_limits_detectados: totalPausas, // Pausas indicam rate limits detectados
      
      // Detalhes de entidades
      funcionarios_criados: totalFuncionariosCriados,
      treinamentos_criados: totalTreinamentosCriados,
      duplicatas_detectadas: totalDuplicatas,
      
      // Arrays de resultados
      errors: todosErros.slice(0, 50).map((erro) => ({ // Limitar a 50 primeiros erros
        row: 0,
        field: 'processamento',
        message: erro,
        error_type: 'PROCESSING' as const,
        severity: 'MEDIUM' as const
      })),
      warnings: totalDuplicatas > 0 ? [{
        row: 0,
        field: 'duplicatas',
        message: `${totalDuplicatas} certificações duplicadas foram ignoradas`,
        warning_type: 'DUPLICATE'
      }] : [],
      
      // ✅ AUDITORIA DETALHADA POR BATCH CONFORME SOLICITADO
      batches_auditoria: batchesLogs,
      
      // Configuração utilizada
      batch_config: {
        linhas_por_batch: BATCH_CONFIG.LINHAS_POR_BATCH,
        delay_entre_batches_ms: BATCH_CONFIG.DELAY_ENTRE_BATCHES_MS,
        max_retries_por_batch: BATCH_CONFIG.MAX_RETRIES,
        backoff_inicial_ms: BATCH_CONFIG.BACKOFF_INICIAL_MS
      },
      
      // ✅ LIMITE SEGURO RECOMENDADO CONFORME SOLICITADO
      limite_seguro_recomendado: BATCH_CONFIG.LINHAS_POR_BATCH,
      recomendacao_uso: `Para arquivos grandes (>200 linhas), este endpoint processa automaticamente em batches de ${BATCH_CONFIG.LINHAS_POR_BATCH} linhas com controle de rate limit e retry automático.`,
      
      summary: `✅ Importação completa: ${totalCriados}/${totalLinhas} certificações importadas com sucesso em ${totalBatches} batches. ${totalFuncionariosCriados} funcionários encontrados, ${totalTreinamentosCriados} treinamentos criados. ${totalPausas} pausas aplicadas para controle de quota.`
    });

  } catch (error) {
    console.error('💥 ERRO CRÍTICO NA IMPORTAÇÃO:', error);
    return c.json({
      success: false,
      batch_id: batchId,
      processing_time_ms: Date.now() - startTime,
      total_rows: 0,
      linhas_processadas: 0,
      importadas_com_sucesso: 0,
      erros_por_lote: 1,
      total_batches: 0,
      linhas_reprocessadas: 0,
      pausas_aplicadas: 0,
      rate_limits_detectados: 0,
      errors: [{
        row: 0,
        field: 'system',
        message: error instanceof Error ? error.message : 'Erro interno do servidor',
        error_type: 'SYSTEM' as const,
        severity: 'CRITICAL' as const
      }],
      warnings: [],
      batches_auditoria: [],
      limite_seguro_recomendado: BATCH_CONFIG.LINHAS_POR_BATCH,
      summary: 'Falha crítica no sistema'
    }, 500);
  }
});

export default app;
