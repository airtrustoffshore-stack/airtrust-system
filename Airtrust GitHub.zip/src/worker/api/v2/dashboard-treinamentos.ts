import { Hono } from 'hono';
import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();

// Aplicar middleware de autenticação
app.use('*', authMiddleware);

// GET /api/v2/dashboard/treinamentos-certificacoes - Métricas completas do dashboard
app.get('/treinamentos-certificacoes', requirePermission('treinamentos', 'READ'), async (c) => {
  const startTime = Date.now();
  
  try {
    console.log('📊 [DASHBOARD] Gerando métricas do dashboard...');
    const db = c.env.DB;
    
    // 1. MÉTRICAS DE FUNCIONÁRIOS
    const funcionarios = await db.prepare(`
      SELECT 
        COUNT(*) as total_funcionarios,
        COUNT(CASE WHEN status = 'ATIVO' THEN 1 END) as funcionarios_ativos,
        COUNT(CASE WHEN status = 'INATIVO' THEN 1 END) as funcionarios_inativos
      FROM funcionarios 
      WHERE deleted_at IS NULL
    `).first();
    
    // 2. MÉTRICAS DE TREINAMENTOS
    const treinamentos = await db.prepare(`
      SELECT 
        COUNT(*) as total_treinamentos,
        COUNT(CASE WHEN ativo = 1 THEN 1 END) as treinamentos_ativos,
        COUNT(CASE WHEN ativo = 0 THEN 1 END) as treinamentos_inativos,
        COUNT(DISTINCT categoria) as total_categorias
      FROM catalogo_treinamentos_v2 
      WHERE deleted_at IS NULL
    `).first();
    
    // 3. MÉTRICAS DE CERTIFICAÇÕES (V3)
    const certificacoesV3 = await db.prepare(`
      SELECT 
        COUNT(*) as total_certificacoes,
        COUNT(CASE WHEN compliance_status = 'VALIDO' THEN 1 END) as certificacoes_validas,
        COUNT(CASE WHEN compliance_status = 'VENCIDO' THEN 1 END) as certificacoes_vencidas,
        COUNT(CASE WHEN compliance_status = 'VENCENDO' THEN 1 END) as certificacoes_vencendo
      FROM certificacoes_v3 
      WHERE status = 'ATIVO'
    `).first();
    
    // 4. MÉTRICAS DE CERTIFICAÇÕES (V2 - HISTÓRICO)
    const certificacoesV2 = await db.prepare(`
      SELECT 
        COUNT(*) as total_certificacoes_v2,
        COUNT(CASE WHEN data_vencimento IS NULL OR data_vencimento > date('now') THEN 1 END) as certificacoes_v2_validas,
        COUNT(CASE WHEN data_vencimento IS NOT NULL AND data_vencimento <= date('now') THEN 1 END) as certificacoes_v2_vencidas,
        COUNT(CASE WHEN data_vencimento IS NOT NULL AND 
                    data_vencimento BETWEEN date('now') AND date('now', '+30 days') THEN 1 END) as certificacoes_v2_vencendo
      FROM historico_certificacoes_v2 
      WHERE deleted_at IS NULL
    `).first();
    
    // Consolidar certificações (V2 + V3)
    const certificacoes = {
      total_certificacoes: (certificacoesV3?.total_certificacoes as number || 0) + (certificacoesV2?.total_certificacoes_v2 as number || 0),
      certificacoes_validas: (certificacoesV3?.certificacoes_validas as number || 0) + (certificacoesV2?.certificacoes_v2_validas as number || 0),
      certificacoes_vencidas: (certificacoesV3?.certificacoes_vencidas as number || 0) + (certificacoesV2?.certificacoes_v2_vencidas as number || 0),
      certificacoes_vencendo: (certificacoesV3?.certificacoes_vencendo as number || 0) + (certificacoesV2?.certificacoes_v2_vencendo as number || 0)
    };
    
    // 5. ANÁLISE DE COMPLIANCE POR FUNCIONÁRIO
    const complianceAnalysis = await db.prepare(`
      SELECT 
        f.id as funcionario_id,
        f.nome as funcionario_nome,
        f.matricula,
        f.status as funcionario_status,
        -- Certificações V3
        COUNT(cv3.id) as certificacoes_v3,
        COUNT(CASE WHEN cv3.compliance_status = 'VALIDO' THEN 1 END) as certificacoes_v3_ok,
        COUNT(CASE WHEN cv3.compliance_status = 'VENCIDO' THEN 1 END) as certificacoes_v3_vencidas,
        -- Certificações V2
        COUNT(hv2.id) as certificacoes_v2,
        COUNT(CASE WHEN hv2.data_vencimento IS NULL OR hv2.data_vencimento > date('now') THEN 1 END) as certificacoes_v2_ok,
        COUNT(CASE WHEN hv2.data_vencimento IS NOT NULL AND hv2.data_vencimento <= date('now') THEN 1 END) as certificacoes_v2_vencidas
      FROM funcionarios f
      LEFT JOIN certificacoes_v3 cv3 ON f.matricula = cv3.funcionario_matricula AND cv3.status = 'ATIVO'
      LEFT JOIN historico_certificacoes_v2 hv2 ON f.id = hv2.funcionario_id AND hv2.deleted_at IS NULL
      WHERE f.deleted_at IS NULL AND f.status = 'ATIVO'
      GROUP BY f.id
    `).all();
    
    // Calcular compliance geral
    const funcionariosComCompliance = complianceAnalysis.results || [];
    const funcionariosCompletos = funcionariosComCompliance.filter((f: any) => {
      const totalCertificacoes = (f.certificacoes_v3 as number || 0) + (f.certificacoes_v2 as number || 0);
      const totalVencidas = (f.certificacoes_v3_vencidas as number || 0) + (f.certificacoes_v2_vencidas as number || 0);
      return totalCertificacoes > 0 && totalVencidas === 0;
    });
    const funcionariosPendentes = funcionariosComCompliance.filter((f: any) => {
      const totalCertificacoes = (f.certificacoes_v3 as number || 0) + (f.certificacoes_v2 as number || 0);
      const totalVencidas = (f.certificacoes_v3_vencidas as number || 0) + (f.certificacoes_v2_vencidas as number || 0);
      return totalCertificacoes === 0 || totalVencidas > 0;
    });
    
    const percentualCompliance = funcionariosComCompliance.length > 0 ? 
      Math.round((funcionariosCompletos.length / funcionariosComCompliance.length) * 100) : 0;
    
    // 6. TREINAMENTOS MAIS REALIZADOS (V2 + V3)
    const treinamentosMaisRealizados = await db.prepare(`
      SELECT 
        t.nome as treinamento_nome,
        t.codigo as treinamento_codigo,
        t.categoria,
        (
          SELECT COUNT(*) FROM historico_certificacoes_v2 h2 
          WHERE h2.treinamento_id = t.id AND h2.deleted_at IS NULL
        ) + (
          SELECT COUNT(*) FROM certificacoes_v3 c3 
          WHERE c3.treinamento_codigo = t.codigo AND c3.status = 'ATIVO'
        ) as total_certificacoes
      FROM catalogo_treinamentos_v2 t
      WHERE t.deleted_at IS NULL
      ORDER BY total_certificacoes DESC
      LIMIT 5
    `).all();
    
    // 7. CERTIFICAÇÕES POR MÊS (últimos 6 meses) - V2 + V3
    const certificacoesPorMesV2 = await db.prepare(`
      SELECT 
        strftime('%Y-%m', created_at) as mes,
        COUNT(*) as total_v2
      FROM historico_certificacoes_v2 
      WHERE deleted_at IS NULL 
        AND created_at >= datetime('now', '-6 months')
      GROUP BY strftime('%Y-%m', created_at)
    `).all();
    
    const certificacoesPorMesV3 = await db.prepare(`
      SELECT 
        strftime('%Y-%m', created_at) as mes,
        COUNT(*) as total_v3
      FROM certificacoes_v3 
      WHERE status = 'ATIVO'
        AND created_at >= datetime('now', '-6 months')
      GROUP BY strftime('%Y-%m', created_at)
    `).all();
    
    // Consolidar evolução mensal
    const mesesMap = new Map();
    (certificacoesPorMesV2.results || []).forEach(item => {
      mesesMap.set(item.mes, { mes: item.mes, total_v2: item.total_v2, total_v3: 0 });
    });
    (certificacoesPorMesV3.results || []).forEach(item => {
      const existing = mesesMap.get(item.mes) || { mes: item.mes, total_v2: 0, total_v3: 0 };
      existing.total_v3 = item.total_v3;
      mesesMap.set(item.mes, existing);
    });
    
    const evolucaoMensal = Array.from(mesesMap.values()).map(item => ({
      mes: item.mes,
      total: (item.total_v2 || 0) + (item.total_v3 || 0),
      total_v2: item.total_v2 || 0,
      total_v3: item.total_v3 || 0
    })).sort((a, b) => a.mes.localeCompare(b.mes));
    
    // 8. FUNCIONÁRIOS CRÍTICOS (com mais certificações vencidas)
    const funcionariosCriticos = funcionariosComCompliance
      .filter((f: any) => {
        const totalVencidas = (f.certificacoes_v3_vencidas as number || 0) + (f.certificacoes_v2_vencidas as number || 0);
        return totalVencidas > 0;
      })
      .map((f: any) => ({
        funcionario_nome: f.funcionario_nome,
        matricula: f.matricula,
        total_certificacoes: (f.certificacoes_v3 as number || 0) + (f.certificacoes_v2 as number || 0),
        certificacoes_vencidas: (f.certificacoes_v3_vencidas as number || 0) + (f.certificacoes_v2_vencidas as number || 0),
        certificacoes_ok: (f.certificacoes_v3_ok as number || 0) + (f.certificacoes_v2_ok as number || 0)
      }))
      .sort((a, b) => b.certificacoes_vencidas - a.certificacoes_vencidas)
      .slice(0, 10);
    
    // 9. ALERTAS E NOTIFICAÇÕES
    const funcionariosSemCertificacao = funcionariosComCompliance.filter((f: any) => {
      const totalCertificacoes = (f.certificacoes_v3 as number || 0) + (f.certificacoes_v2 as number || 0);
      return totalCertificacoes === 0;
    });
    
    const alertas = {
      certificacoes_vencendo: certificacoes.certificacoes_vencendo,
      certificacoes_vencidas: certificacoes.certificacoes_vencidas,
      funcionarios_sem_certificacao: funcionariosSemCertificacao.length,
      treinamentos_inativos: treinamentos?.treinamentos_inativos || 0,
      funcionarios_criticos: funcionariosCriticos.length
    };
    
    // 10. CONSOLIDAR TODAS AS MÉTRICAS
    const processingTime = Date.now() - startTime;
    const metricas = {
      // Visão Geral
      resumo: {
        total_funcionarios: funcionarios?.total_funcionarios || 0,
        funcionarios_ativos: funcionarios?.funcionarios_ativos || 0,
        funcionarios_inativos: funcionarios?.funcionarios_inativos || 0,
        total_treinamentos: treinamentos?.total_treinamentos || 0,
        treinamentos_ativos: treinamentos?.treinamentos_ativos || 0,
        treinamentos_inativos: treinamentos?.treinamentos_inativos || 0,
        total_categorias: treinamentos?.total_categorias || 0,
        total_certificacoes: certificacoes.total_certificacoes,
        certificacoes_validas: certificacoes.certificacoes_validas,
        certificacoes_vencidas: certificacoes.certificacoes_vencidas,
        certificacoes_vencendo: certificacoes.certificacoes_vencendo
      },
      
      // Compliance
      compliance: {
        percentual: percentualCompliance,
        funcionarios_ok: funcionariosCompletos.length,
        funcionarios_pendentes: funcionariosPendentes.length,
        funcionarios_sem_certificacao: funcionariosSemCertificacao.length,
        funcionarios_total: funcionariosComCompliance.length
      },
      
      // Status das Certificações (detalhado)
      certificacoes_status: {
        validas: certificacoes.certificacoes_validas,
        vencidas: certificacoes.certificacoes_vencidas,
        vencendo_30_dias: certificacoes.certificacoes_vencendo,
        total: certificacoes.total_certificacoes,
        detalhamento: {
          v2_total: certificacoesV2?.total_certificacoes_v2 || 0,
          v2_validas: certificacoesV2?.certificacoes_v2_validas || 0,
          v2_vencidas: certificacoesV2?.certificacoes_v2_vencidas || 0,
          v3_total: certificacoesV3?.total_certificacoes || 0,
          v3_validas: certificacoesV3?.certificacoes_validas || 0,
          v3_vencidas: certificacoesV3?.certificacoes_vencidas || 0
        }
      },
      
      // Top Treinamentos
      top_treinamentos: treinamentosMaisRealizados.results || [],
      
      // Evolução Temporal
      evolucao_mensal: evolucaoMensal,
      
      // Funcionários Críticos
      funcionarios_criticos: funcionariosCriticos,
      
      // Alertas
      alertas: alertas,
      
      // Metadados
      metadata: {
        ultima_atualizacao: new Date().toISOString(),
        processing_time_ms: processingTime,
        fontes_dados: ['funcionarios', 'catalogo_treinamentos_v2', 'historico_certificacoes_v2', 'certificacoes_v3'],
        versao_dashboard: '2.0'
      }
    };
    
    console.log(`✅ [DASHBOARD] Métricas geradas em ${processingTime}ms:`, {
      funcionarios: metricas.resumo.total_funcionarios,
      treinamentos: metricas.resumo.total_treinamentos,
      certificacoes: metricas.resumo.total_certificacoes,
      compliance: `${metricas.compliance.percentual}%`
    });
    
    // Registrar auditoria
    await logAudit(c, 'READ', 'dashboard_metrics', 'treinamentos_certificacoes', undefined, {
      processing_time_ms: processingTime,
      total_funcionarios: metricas.resumo.total_funcionarios,
      total_certificacoes: metricas.resumo.total_certificacoes,
      compliance_percentual: metricas.compliance.percentual
    });
    
    return c.json({
      success: true,
      data: metricas
    });
    
  } catch (error) {
    console.error('❌ [DASHBOARD] Erro ao gerar métricas:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno do servidor',
      processing_time_ms: Date.now() - startTime
    }, 500);
  }
});

// GET /api/v2/dashboard/treinamentos-certificacoes/quick - Métricas rápidas (cache-friendly)
app.get('/treinamentos-certificacoes/quick', requirePermission('treinamentos', 'READ'), async (c) => {
  try {
    const db = c.env.DB;
    
    // Consulta otimizada apenas com contadores principais
    const metricas = await db.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL AND status = 'ATIVO') as funcionarios_ativos,
        (SELECT COUNT(*) FROM catalogo_treinamentos_v2 WHERE deleted_at IS NULL AND ativo = 1) as treinamentos_ativos,
        (SELECT COUNT(*) FROM historico_certificacoes_v2 WHERE deleted_at IS NULL) as certificacoes_v2,
        (SELECT COUNT(*) FROM certificacoes_v3 WHERE status = 'ATIVO') as certificacoes_v3,
        (SELECT COUNT(*) FROM certificacoes_v3 WHERE status = 'ATIVO' AND compliance_status = 'VENCIDO') as vencidas_v3,
        (SELECT COUNT(*) FROM historico_certificacoes_v2 WHERE deleted_at IS NULL AND data_vencimento <= date('now')) as vencidas_v2
    `).first();
    
    const resumo = {
      funcionarios_ativos: metricas?.funcionarios_ativos as number || 0,
      treinamentos_ativos: metricas?.treinamentos_ativos as number || 0,
      total_certificacoes: (metricas?.certificacoes_v2 as number || 0) + (metricas?.certificacoes_v3 as number || 0),
      certificacoes_vencidas: (metricas?.vencidas_v2 as number || 0) + (metricas?.vencidas_v3 as number || 0),
      ultima_atualizacao: new Date().toISOString()
    };
    
    return c.json({
      success: true,
      data: resumo
    });
    
  } catch (error) {
    console.error('❌ [DASHBOARD QUICK] Erro:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno do servidor'
    }, 500);
  }
});

export default app;
