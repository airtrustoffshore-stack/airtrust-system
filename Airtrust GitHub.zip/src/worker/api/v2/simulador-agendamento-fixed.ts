import { Hono } from 'hono';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

// 🚨 SEM AUTH MIDDLEWARE - ENDPOINT PÚBLICO PARA AGENDAMENTO
// POST /api/v2/simulador/agendamento
app.post('/', async (c) => {
  try {
    const db = c.env.DB;
    const dados = await c.req.json();
    
    console.log('📅 ENDPOINT REAL - Agendando sessão:', JSON.stringify(dados, null, 2));
    
    // Validação básica
    if (!dados.dados_gerais) {
      return c.json({
        success: false, 
        error: 'dados_gerais obrigatório'
      }, 400);
    }
    
    const dg = dados.dados_gerais;
    
    if (!dg.simulador_id) {
      return c.json({success: false, error: 'simulador_id obrigatório'}, 400);
    }
    
    if (!dg.instrutor_id) {
      return c.json({success: false, error: 'instrutor_id obrigatório'}, 400);
    }
    
    if (!dg.data_inicio) {
      return c.json({success: false, error: 'data_inicio obrigatória'}, 400);
    }
    
    // Gerar UUID único para o agendamento
    const sessaoUuid = `SESS-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    console.log('🔑 UUID gerado:', sessaoUuid);
    
    // Criar agendamento no banco - TABELA agendamento_slots
    const dataInicio = dg.data_inicio.includes('T') ? dg.data_inicio : `${dg.data_inicio}T08:00:00`;
    const dataFim = dg.data_fim ? (dg.data_fim.includes('T') ? dg.data_fim : `${dg.data_fim}T10:00:00`) : 
      new Date(new Date(dataInicio).getTime() + 2*60*60*1000).toISOString();
    
    console.log('📅 Salvando slot no banco:', {
      simulador_id: dg.simulador_id,
      instrutor_id: dg.instrutor_id,
      data_inicio: dataInicio,
      data_fim: dataFim
    });
    
    const slotResult = await db.prepare(`
      INSERT INTO agendamento_slots (
        simulador_id, colaborador_id_instrutor, colaborador_id_checador,
        data_inicio, data_fim, status_slot, 
        created_at, updated_at, created_by
      ) VALUES (?, ?, ?, ?, ?, 'AGENDADO', datetime('now'), datetime('now'), 'SISTEMA_AGENDAMENTO')
    `).bind(
      dg.simulador_id,
      dg.instrutor_id,
      null, // checador opcional
      dataInicio,
      dataFim
    ).run();
    
    const agendamentoSlotId = slotResult.meta?.last_row_id;
    console.log('✅ Slot criado com ID:', agendamentoSlotId);
    
    // Criar ficha de avaliação - TABELA fichas_sessao
    const fichaUuid = `FICHA-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    const fichaResult = await db.prepare(`
      INSERT INTO fichas_sessao (
        ficha_uuid, agendamento_slot_id, colaborador_id_aluno, 
        funcao_na_sessao, sessao_template_id, ciclo_executado,
        status_workflow, observacoes_instrutor,
        created_at, updated_at, created_by
      ) VALUES (?, ?, ?, 'PIC', ?, 1, 'RASCUNHO', ?, datetime('now'), datetime('now'), 'SISTEMA_AGENDAMENTO')
    `).bind(
      fichaUuid,
      agendamentoSlotId,
      dg.instrutor_id, // Por agora, instrutor também é o aluno (pode ser ajustado)
      dg.template_id || null,
      dg.observacoes || ''
    ).run();
    
    const fichaId = fichaResult.meta?.last_row_id;
    console.log('✅ Ficha criada com ID:', fichaId, 'UUID:', fichaUuid);
    
    // Criar entrada na tabela de sessões (backup)
    const sessaoResult = await db.prepare(`
      INSERT INTO simulador_sessoes_v2 (
        uuid, simulador_id, template_id, instrutor_id,
        data_inicio, data_fim, status, observacoes,
        created_at, created_by, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'AGENDADO', ?, datetime('now'), 'SISTEMA_AGENDAMENTO', datetime('now'))
    `).bind(
      sessaoUuid,
      dg.simulador_id,
      dg.template_id || null,
      dg.instrutor_id,
      dataInicio,
      dataFim,
      dg.observacoes || ''
    ).run();
    
    const sessaoId = sessaoResult.meta?.last_row_id;
    console.log('✅ Sessão backup criada com ID:', sessaoId);
    
    // Registrar auditoria
    await db.prepare(`
      INSERT INTO auditoria_simulador (
        ficha_uuid, usuario_id, acao, detalhes_acao, 
        ip_origem, timestamp_acao
      ) VALUES (?, ?, ?, ?, ?, datetime('now'))
    `).bind(
      fichaUuid,
      dg.instrutor_id,
      'AGENDAMENTO_CRIADO',
      JSON.stringify({
        simulador_id: dg.simulador_id,
        template_id: dg.template_id,
        data_inicio: dataInicio,
        data_fim: dataFim,
        sessao_uuid: sessaoUuid
      }),
      c.req.header('CF-Connecting-IP') || 'sistema'
    ).run();
    
    const agendamentoCompleto = {
      // IDs principais
      id: agendamentoSlotId,
      uuid: sessaoUuid,
      ficha_uuid: fichaUuid,
      ficha_id: fichaId,
      
      // Dados originais
      simulador_id: dg.simulador_id,
      instrutor_id: dg.instrutor_id,
      template_id: dg.template_id,
      data_inicio: dataInicio,
      data_fim: dataFim,
      observacoes: dg.observacoes,
      
      // Status e controle
      status: 'AGENDADO',
      status_workflow: 'RASCUNHO',
      created_at: new Date().toISOString(),
      
      // Participantes (para compatibilidade)
      participantes: dados.participantes || []
    };
    
    console.log('🎉 AGENDAMENTO SALVO COM SUCESSO:', {
      slot_id: agendamentoSlotId,
      sessao_uuid: sessaoUuid,
      ficha_uuid: fichaUuid,
      instrutor: dg.instrutor_id,
      simulador: dg.simulador_id
    });
    
    return c.json({
      success: true,
      agendamento: agendamentoCompleto,
      message: 'Sessão agendada e salva no banco de dados com sucesso!',
      debug: {
        endpoint: 'REAL_ENDPOINT_FIXED',
        tables_created: ['agendamento_slots', 'fichas_sessao', 'simulador_sessoes_v2'],
        uuid_generated: sessaoUuid,
        ficha_uuid: fichaUuid,
        saved_to_database: true
      }
    });
    
  } catch (error) {
    console.error('❌ ERRO CRÍTICO ao salvar agendamento:', error);
    return c.json({
      success: false, 
      error: 'Erro interno do servidor ao salvar agendamento',
      details: (error as Error).message,
      stack: (error as Error).stack,
      endpoint: 'REAL_ENDPOINT_FIXED'
    }, 500);
  }
});

// GET - Listar agendamentos
app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    console.log('📋 Listando agendamentos do banco...');
    
    const agendamentos = await db.prepare(`
      SELECT 
        slot.id,
        slot.simulador_id,
        slot.colaborador_id_instrutor,
        slot.data_inicio,
        slot.data_fim,
        slot.status_slot,
        slot.created_at,
        sim.nome as simulador_nome,
        inst.nome as instrutor_nome,
        fs.ficha_uuid,
        fs.status_workflow,
        COUNT(fs.id) as total_fichas
      FROM agendamento_slots slot
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      LEFT JOIN fichas_sessao fs ON slot.id = fs.agendamento_slot_id AND fs.deleted_at IS NULL
      WHERE slot.data_inicio >= date('now', '-7 days')
      GROUP BY slot.id
      ORDER BY slot.data_inicio DESC
      LIMIT 50
    `).all();
    
    console.log(`✅ ${agendamentos.results.length} agendamentos encontrados no banco`);
    
    return c.json({
      success: true,
      data: agendamentos.results,
      total: agendamentos.results.length,
      source: 'DATABASE_REAL'
    });
    
  } catch (error) {
    console.error('❌ Erro ao listar agendamentos:', error);
    return c.json({
      success: false,
      error: 'Erro ao carregar agendamentos',
      details: (error as Error).message
    }, 500);
  }
});

// GET - Buscar agendamento específico
app.get('/:uuid', async (c) => {
  try {
    const db = c.env.DB;
    const uuid = c.req.param('uuid');
    
    console.log(`🔍 Buscando agendamento: ${uuid}`);
    
    const agendamento = await db.prepare(`
      SELECT 
        slot.*,
        fs.ficha_uuid, fs.status_workflow, fs.observacoes_instrutor,
        sim.nome as simulador_nome,
        inst.nome as instrutor_nome
      FROM agendamento_slots slot
      LEFT JOIN fichas_sessao fs ON slot.id = fs.agendamento_slot_id
      LEFT JOIN simuladores sim ON slot.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON slot.colaborador_id_instrutor = inst.id
      WHERE fs.ficha_uuid = ? AND fs.deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!agendamento) {
      return c.json({
        success: false,
        error: 'Agendamento não encontrado'
      }, 404);
    }
    
    return c.json({
      success: true,
      data: agendamento,
      source: 'DATABASE_REAL'
    });
    
  } catch (error) {
    console.error(`❌ Erro ao buscar agendamento ${c.req.param('uuid')}:`, error);
    return c.json({
      success: false,
      error: 'Erro ao carregar agendamento',
      details: (error as Error).message
    }, 500);
  }
});

export default app;
