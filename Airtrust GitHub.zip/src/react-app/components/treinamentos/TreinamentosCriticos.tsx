import { AlertTriangle, TrendingDown, Calendar } from 'lucide-react';
import Card, { CardContent, CardHeader } from '@/react-app/components/Card';
import Badge from '@/react-app/components/Badge';
import { useApi } from '@/react-app/hooks/useApi';

interface TreinamentoCritico {
  treinamento_id: number;
  treinamento_nome: string;
  codigo: string;
  total_funcionarios: number;
  funcionarios_em_dia: number;
  funcionarios_vencendo: number;
  funcionarios_vencidos: number;
  compliance_percentage: number;
  prioridade: 'CRITICA' | 'ALTA' | 'MEDIA';
}

export default function TreinamentosCriticos() {
  const { data: treinamentos, loading, error } = useApi<TreinamentoCritico[]>('/api/v2/dashboard/treinamentos-criticos');

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <h3 className="text-lg font-medium text-gray-900">Treinamentos Críticos</h3>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-200 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <h3 className="text-lg font-medium text-gray-900">Treinamentos Críticos</h3>
        </CardHeader>
        <CardContent>
          <p className="text-red-600 text-sm">Erro ao carregar dados: {error}</p>
        </CardContent>
      </Card>
    );
  }

  // Use dados reais da API ou lista vazia se não houver dados
  const treinamentosList = treinamentos && treinamentos.length > 0 ? treinamentos : [];

  const getPrioridadeBadge = (prioridade: string) => {
    switch (prioridade) {
      case 'CRITICA': return { variant: 'danger' as const, label: 'CRÍTICA' };
      case 'ALTA': return { variant: 'warning' as const, label: 'ALTA' };
      case 'MEDIA': return { variant: 'info' as const, label: 'MÉDIA' };
      default: return { variant: 'neutral' as const, label: 'BAIXA' };
    }
  };

  const getComplianceColor = (percentage: number) => {
    if (percentage >= 80) return 'from-green-500 to-emerald-500';
    if (percentage >= 60) return 'from-yellow-500 to-orange-500';
    if (percentage >= 40) return 'from-orange-500 to-red-500';
    return 'from-red-500 to-red-600';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-medium bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Treinamentos Críticos
            </h3>
            <p className="text-sm text-gray-600">Monitoramento de compliance por treinamento</p>
          </div>
          <AlertTriangle className="w-6 h-6 text-orange-500" />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {treinamentosList.map((treinamento) => {
          const prioridadeBadge = getPrioridadeBadge(treinamento.prioridade);
          const complianceColor = getComplianceColor(treinamento.compliance_percentage);
          
          return (
            <div key={treinamento.treinamento_id} className="p-4 rounded-lg border border-gray-200 hover:shadow-md transition-all duration-200">
              {/* Header do Treinamento */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-gray-900">{treinamento.treinamento_nome}</h4>
                    <Badge variant={prioridadeBadge.variant} size="sm">
                      {prioridadeBadge.label}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {treinamento.codigo}
                    </span>
                    <span>{treinamento.total_funcionarios} funcionários</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-gray-900">{treinamento.compliance_percentage}%</div>
                  <div className="text-xs text-gray-500">compliance</div>
                </div>
              </div>

              {/* Barra de Progresso */}
              <div className="mb-3">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`bg-gradient-to-r ${complianceColor} h-2 rounded-full transition-all duration-300`}
                    style={{ width: `${treinamento.compliance_percentage}%` }}
                  ></div>
                </div>
              </div>

              {/* Detalhamento */}
              <div className="flex justify-between text-sm">
                <div className="flex items-center gap-1 text-green-600">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  Em dia: {treinamento.funcionarios_em_dia}
                </div>
                <div className="flex items-center gap-1 text-yellow-600">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  Vencendo: {treinamento.funcionarios_vencendo}
                </div>
                <div className="flex items-center gap-1 text-red-600">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  Vencidos: {treinamento.funcionarios_vencidos}
                </div>
              </div>

              {/* Indicador de Tendência */}
              {treinamento.compliance_percentage < 50 && (
                <div className="mt-2 flex items-center gap-1 text-xs text-red-600 bg-red-50 px-2 py-1 rounded">
                  <TrendingDown className="w-3 h-3" />
                  Atenção: Compliance abaixo do esperado
                </div>
              )}
            </div>
          );
        })}

        {treinamentosList.length === 0 && (
          <div className="text-center py-8">
            <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Nenhum treinamento crítico identificado</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
