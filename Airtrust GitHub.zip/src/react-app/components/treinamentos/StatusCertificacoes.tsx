import { CheckCircle, Clock, AlertTriangle, XCircle } from 'lucide-react';
import Card, { CardContent, CardHeader } from '@/react-app/components/Card';
import { useApi } from '@/react-app/hooks/useApi';

interface StatusCertificacoes {
  validos: number;
  proximo_vencimento: number;
  criticos: number;
  vencidos: number;
}

export default function StatusCertificacoes() {
  const { data: status, loading, error } = useApi<StatusCertificacoes>('/api/v2/dashboard/status-certificacoes');

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <h3 className="text-lg font-medium text-gray-900">Status de Certificações</h3>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-12 bg-gray-200 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <h3 className="text-lg font-medium text-gray-900">Status de Certificações</h3>
        </CardHeader>
        <CardContent>
          <p className="text-red-600 text-sm">Erro ao carregar dados: {error}</p>
        </CardContent>
      </Card>
    );
  }

  const statusItems = [
    {
      label: 'Válidos',
      value: status?.validos || 0,
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      label: 'Próx. Vencimento',
      value: status?.proximo_vencimento || 0,
      icon: Clock,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100'
    },
    {
      label: 'Críticos',
      value: status?.criticos || 0,
      icon: AlertTriangle,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    },
    {
      label: 'Vencidos',
      value: status?.vencidos || 0,
      icon: XCircle,
      color: 'text-red-600',
      bgColor: 'bg-red-100'
    }
  ];

  return (
    <Card>
      <CardHeader>
        <h3 className="text-lg font-medium bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          Status de Certificações
        </h3>
        <p className="text-sm text-gray-600">Distribuição por status de validade</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {statusItems.map((item) => (
          <div key={item.label} className="flex items-center justify-between p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
            <div className="flex items-center">
              <div className={`w-10 h-10 rounded-full ${item.bgColor} flex items-center justify-center mr-3`}>
                <item.icon className={`w-5 h-5 ${item.color}`} />
              </div>
              <span className="font-medium text-gray-900">{item.label}</span>
            </div>
            <span className="text-2xl font-bold text-gray-900">{item.value}</span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
