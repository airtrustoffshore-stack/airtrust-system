import { FileCheck, FileX, BarChart3 } from 'lucide-react';
import Card, { CardContent, CardHeader } from '@/react-app/components/Card';
import { useApi } from '@/react-app/hooks/useApi';

interface RastreabilidadeDocumental {
  certificados_anexados: number;
  sem_comprovante: number;
  total_certificacoes: number;
}

export default function RastreabilidadeDocumental() {
  const { data: rastreabilidade, loading, error } = useApi<RastreabilidadeDocumental>('/api/v2/dashboard/rastreabilidade');

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <h3 className="text-lg font-medium text-gray-900">Rastreabilidade de Documentos</h3>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-16 bg-gray-200 rounded"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <h3 className="text-lg font-medium text-gray-900">Rastreabilidade de Documentos</h3>
        </CardHeader>
        <CardContent>
          <p className="text-red-600 text-sm">Erro ao carregar dados: {error}</p>
        </CardContent>
      </Card>
    );
  }

  const total = rastreabilidade?.total_certificacoes || 0;
  const anexados = rastreabilidade?.certificados_anexados || 0;
  const semComprovante = rastreabilidade?.sem_comprovante || 0;
  const percentualAnexados = total > 0 ? Math.round((anexados / total) * 100) : 0;

  return (
    <Card>
      <CardHeader>
        <h3 className="text-lg font-medium bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          Rastreabilidade de Documentos
        </h3>
        <p className="text-sm text-gray-600">Certificados anexados vs. sem comprovante</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Total de Certificações */}
        <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
              <BarChart3 className="w-5 h-5 text-blue-600" />
            </div>
            <span className="font-medium text-gray-900">Total de Certificações</span>
          </div>
          <span className="text-2xl font-bold text-blue-600">{total}</span>
        </div>

        {/* Certificados Anexados */}
        <div className="flex items-center justify-between p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
              <FileCheck className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <span className="font-medium text-gray-900">Certificados Anexados</span>
              <div className="text-xs text-gray-500">Com comprovante</div>
            </div>
          </div>
          <div className="text-right">
            <span className="text-2xl font-bold text-green-600">{anexados}</span>
            <div className="text-xs text-gray-500">{percentualAnexados}% do total</div>
          </div>
        </div>

        {/* Sem Comprovante */}
        <div className="flex items-center justify-between p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center mr-3">
              <FileX className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <span className="font-medium text-gray-900">Sem Comprovante</span>
              <div className="text-xs text-gray-500">Requer anexo</div>
            </div>
          </div>
          <div className="text-right">
            <span className="text-2xl font-bold text-red-600">{semComprovante}</span>
            <div className="text-xs text-gray-500">{100 - percentualAnexados}% do total</div>
          </div>
        </div>

        {/* Barra de Progresso */}
        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Progresso de Documentação</span>
            <span>{percentualAnexados}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-green-500 to-emerald-500 h-3 rounded-full transition-all duration-300"
              style={{ width: `${percentualAnexados}%` }}
            ></div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
