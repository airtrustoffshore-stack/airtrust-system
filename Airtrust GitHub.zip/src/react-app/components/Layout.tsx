import { Outlet } from 'react-router';
import MainSidebar from './MainSidebar';

export default function Layout() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Skip to main content link for accessibility */}
      <a 
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-blue-600 text-white px-4 py-2 rounded-md z-50"
        tabIndex={0}
      >
        Pular para conteúdo principal
      </a>

      {/* Main Sidebar */}
      <MainSidebar />

      {/* Main Content */}
      <main 
        id="main-content"
        className="ml-64 p-8"
        role="main"
        tabIndex={-1}
      >
        <Outlet />
      </main>
    </div>
  );
}
