import React, { useState } from 'react';
import { Shield, Lock, CheckCircle, AlertTriangle } from 'lucide-react';
import Button from '../Button';
import Modal from '../Modal';
import Card from '../Card';

interface AssinaturaDigitalModalProps {
  isOpen: boolean;
  onClose: () => void;
  fichaUuid: string;
  tipoAssinatura: 'INSTRUTOR' | 'ALUNO' | 'CHECADOR';
  dadosFicha: {
    colaborador_nome: string;
    matricula: string;
    sessao_nome: string;
    conceito_final: string;
  };
  onAssinaturaConcluida?: () => void;
}

const AssinaturaDigitalModal: React.FC<AssinaturaDigitalModalProps> = ({
  isOpen,
  onClose,
  fichaUuid,
  tipoAssinatura,
  dadosFicha,
  onAssinaturaConcluida
}) => {
  const [step, setStep] = useState<'verificacao' | 'assinando' | 'concluida'>('verificacao');
  const [assinaturaData, setAssinaturaData] = useState<any>(null);

  const handleIniciarAssinatura = async () => {
    setStep('assinando');

    try {
      // Simular processo de assinatura digital A1/A3
      await new Promise(resolve => setTimeout(resolve, 3000));

      const response = await fetch(`/api/v2/simulador/ficha/${fichaUuid}/assinar`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tipo_assinatura: tipoAssinatura,
          certificado_digital: 'A1_SIMULATED', // Em produção seria o certificado real
          dados_assinatura: {
            timestamp: new Date().toISOString(),
            ip_origem: 'auto-detect',
            user_agent: navigator.userAgent,
            hash_documento: generateDocumentHash()
          }
        })
      });

      const data = await response.json();
      
      if (data.success) {
        setAssinaturaData(data.data);
        setStep('concluida');
        onAssinaturaConcluida?.();
      } else {
        alert('Erro ao processar assinatura: ' + data.error);
        setStep('verificacao');
      }
    } catch (error) {
      console.error('Erro na assinatura:', error);
      alert('Erro ao conectar com o servidor');
      setStep('verificacao');
    }
  };

  const generateDocumentHash = (): string => {
    // Gerar hash baseado nos dados da ficha para integridade
    const dados = `${fichaUuid}-${dadosFicha.matricula}-${Date.now()}`;
    let hash = 0;
    for (let i = 0; i < dados.length; i++) {
      const char = dados.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(16, '0');
  };

  const getTipoAssinaturaLabel = () => {
    switch (tipoAssinatura) {
      case 'INSTRUTOR': return 'Instrutor Responsável';
      case 'ALUNO': return 'Aluno/Tripulante';
      case 'CHECADOR': return 'Checador';
      default: return tipoAssinatura;
    }
  };

  const renderVerificacao = () => (
    <div className="space-y-6">
      <div className="text-center">
        <Shield className="w-16 h-16 mx-auto text-blue-600 mb-4" />
        <h3 className="text-xl font-bold text-gray-900 mb-2">
          Assinatura Digital - {getTipoAssinaturaLabel()}
        </h3>
        <p className="text-gray-600">
          Confirme os dados abaixo antes de assinar digitalmente o documento
        </p>
      </div>

      <Card className="p-4 bg-blue-50 border-blue-200">
        <h4 className="font-semibold text-blue-900 mb-3">Dados da Avaliação</h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Tripulante:</span>
            <span className="font-medium">{dadosFicha.colaborador_nome}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Matrícula:</span>
            <span className="font-medium">{dadosFicha.matricula}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Sessão:</span>
            <span className="font-medium">{dadosFicha.sessao_nome}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Conceito Final:</span>
            <span className={`font-bold ${
              dadosFicha.conceito_final === 'APROVADO' ? 'text-green-600' : 'text-red-600'
            }`}>
              {dadosFicha.conceito_final}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">UUID:</span>
            <span className="font-mono text-xs">{fichaUuid}</span>
          </div>
        </div>
      </Card>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
          <div className="text-sm">
            <p className="font-medium text-yellow-800">Importante:</p>
            <p className="text-yellow-700 mt-1">
              Sua assinatura digital terá validade legal conforme MP 2.200-2/01 e Lei 14.063/20.
              O documento será auditado e rastreável permanentemente.
            </p>
          </div>
        </div>
      </div>

      <div className="flex justify-end space-x-3">
        <Button variant="secondary" onClick={onClose}>
          Cancelar
        </Button>
        <Button onClick={handleIniciarAssinatura}>
          <Lock className="w-4 h-4 mr-2" />
          Assinar Digitalmente
        </Button>
      </div>
    </div>
  );

  const renderAssinando = () => (
    <div className="text-center py-8">
      <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
      <h3 className="text-xl font-bold text-gray-900 mb-2">Processando Assinatura</h3>
      <div className="space-y-2 text-sm text-gray-600">
        <p>🔐 Validando certificado digital...</p>
        <p>⏱️ Gerando hash de integridade...</p>
        <p>📝 Registrando auditoria...</p>
        <p>✅ Finalizando assinatura...</p>
      </div>
      <p className="text-xs text-gray-500 mt-4">
        Aguarde, este processo pode demorar alguns segundos
      </p>
    </div>
  );

  const renderConcluida = () => (
    <div className="space-y-6">
      <div className="text-center">
        <CheckCircle className="w-16 h-16 mx-auto text-green-600 mb-4" />
        <h3 className="text-xl font-bold text-gray-900 mb-2">
          Assinatura Realizada com Sucesso!
        </h3>
        <p className="text-gray-600">
          O documento foi assinado digitalmente e possui validade legal
        </p>
      </div>

      {assinaturaData && (
        <Card className="p-4 bg-green-50 border-green-200">
          <h4 className="font-semibold text-green-900 mb-3">Detalhes da Assinatura</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Timestamp:</span>
              <span className="font-mono text-xs">
                {new Date(assinaturaData.timestamp).toLocaleString('pt-BR')}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Hash de Integridade:</span>
              <span className="font-mono text-xs">{assinaturaData.hash_auditoria}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Status:</span>
              <span className="text-green-600 font-medium">{assinaturaData.status}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Protocolo:</span>
              <span className="font-mono text-xs">{assinaturaData.protocolo}</span>
            </div>
          </div>
        </Card>
      )}

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
          <div className="text-sm">
            <p className="font-medium text-blue-800">Certificação ANAC</p>
            <p className="text-blue-700 mt-1">
              Este documento atende aos requisitos RBAC-61 e IS 61-004 para registros de treinamento.
              A assinatura é auditável e pode ser verificada a qualquer momento.
            </p>
          </div>
        </div>
      </div>

      <div className="flex justify-center">
        <Button onClick={onClose}>
          <CheckCircle className="w-4 h-4 mr-2" />
          Concluído
        </Button>
      </div>
    </div>
  );

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={step === 'concluida' ? 'Assinatura Concluída' : 'Assinatura Digital'}
    >
      <div className="min-h-[400px]">
        {step === 'verificacao' && renderVerificacao()}
        {step === 'assinando' && renderAssinando()}
        {step === 'concluida' && renderConcluida()}
      </div>
    </Modal>
  );
};

export default AssinaturaDigitalModal;
