import React, { useState } from 'react';
import { Save, Copy, FileText, CheckCircle } from 'lucide-react';
import Button from '../Button';
import Modal from '../Modal';

interface Manobra {
  id: number;
  manobra_id_codigo: string;
  nome_manobra: string;
  categoria: string;
  pontuacao_minima: number;
  ativo: boolean;
}

interface SessaoTemplate {
  id: number;
  treinamento_codigo: string;
  numero_sessao: number;
  nome_sessao: string;
  descricao?: string;
}

interface MatrizConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessao: SessaoTemplate | null;
  manobras: Manobra[];
  manobrasSelecionadas: Manobra[];
  onToggleManobra: (manobraId: number) => void;
  onSalvar: () => void;
  loading: boolean;
}

const MatrizConfigModal: React.FC<MatrizConfigModalProps> = ({
  isOpen,
  onClose,
  sessao,
  manobras,
  manobrasSelecionadas,
  onToggleManobra,
  onSalvar,
  loading
}) => {
  const [filterCategoria, setFilterCategoria] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [showDuplicateModal, setShowDuplicateModal] = useState(false);
  const [duplicateData, setDuplicateData] = useState({
    novo_nome: '',
    novo_codigo: ''
  });

  // Categorias únicas
  const categorias = Array.from(new Set(manobras.map(m => m.categoria))).sort();

  // Filtrar manobras
  const manobrasFiltradas = manobras.filter(manobra => {
    const matchCategoria = !filterCategoria || manobra.categoria === filterCategoria;
    const matchSearch = !searchTerm || 
      manobra.nome_manobra.toLowerCase().includes(searchTerm.toLowerCase()) ||
      manobra.manobra_id_codigo.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchCategoria && matchSearch;
  });

  // Agrupar por categoria
  const manobrasPorCategoria = manobrasFiltradas.reduce((acc, manobra) => {
    if (!acc[manobra.categoria]) {
      acc[manobra.categoria] = [];
    }
    acc[manobra.categoria].push(manobra);
    return acc;
  }, {} as Record<string, Manobra[]>);

  const handleDuplicateSessao = async () => {
    if (!sessao || !duplicateData.novo_nome || !duplicateData.novo_codigo) {
      return;
    }

    try {
      const response = await fetch('/api/v2/matriz-sessoes-manobras-enhanced/duplicar-sessao', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          sessao_origem_id: sessao.id,
          novo_nome: duplicateData.novo_nome,
          novo_codigo: duplicateData.novo_codigo
        })
      });

      if (response.ok) {
        const result = await response.json();
        alert(`Sessão duplicada com sucesso! ${result.data.manobras_copiadas} manobras copiadas.`);
        setShowDuplicateModal(false);
        setDuplicateData({ novo_nome: '', novo_codigo: '' });
      } else {
        const error = await response.json();
        alert(`Erro ao duplicar sessão: ${error.error}`);
      }
    } catch (error) {
      console.error('Erro ao duplicar sessão:', error);
      alert('Erro ao duplicar sessão');
    }
  };

  const selectAllInCategory = (categoria: string) => {
    const manobrasCategoria = manobrasPorCategoria[categoria] || [];
    manobrasCategoria.forEach(manobra => {
      const isSelected = manobrasSelecionadas.some(m => m.id === manobra.id);
      if (!isSelected && manobra.ativo) {
        onToggleManobra(manobra.id);
      }
    });
  };

  const deselectAllInCategory = (categoria: string) => {
    const manobrasCategoria = manobrasPorCategoria[categoria] || [];
    manobrasCategoria.forEach(manobra => {
      const isSelected = manobrasSelecionadas.some(m => m.id === manobra.id);
      if (isSelected) {
        onToggleManobra(manobra.id);
      }
    });
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title={`Configurar Manobras - ${sessao?.nome_sessao}`}
        
      >
        <div className="space-y-6">
          {/* Header com stats e ações */}
          <div className="flex justify-between items-center border-b pb-4">
            <div className="flex items-center space-x-4">
              <div className="text-sm">
                <span className="font-medium">{manobrasSelecionadas.length}</span>
                <span className="text-gray-600 ml-1">manobra(s) selecionada(s)</span>
              </div>
              <div className="text-sm text-gray-600">
                de {manobras.filter(m => m.ativo).length} disponíveis
              </div>
            </div>
            
            <div className="flex space-x-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setShowDuplicateModal(true)}
              >
                <Copy className="w-4 h-4 mr-2" />
                Duplicar Sessão
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  // Gerar relatório das manobras selecionadas
                  const relatorio = manobrasSelecionadas.map(m => 
                    `${m.manobra_id_codigo} - ${m.nome_manobra} (${m.categoria})`
                  ).join('\n');
                  
                  const blob = new Blob([relatorio], { type: 'text/plain' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `manobras_${sessao?.treinamento_codigo}_${sessao?.nome_sessao}.txt`;
                  a.click();
                  URL.revokeObjectURL(url);
                }}
              >
                <FileText className="w-4 h-4 mr-2" />
                Exportar Lista
              </Button>
            </div>
          </div>

          {/* Filtros */}
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Filtrar por Categoria
              </label>
              <select
                value={filterCategoria}
                onChange={(e) => setFilterCategoria(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="">Todas as categorias</option>
                {categorias.map(categoria => (
                  <option key={categoria} value={categoria}>{categoria}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Buscar Manobra
              </label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Nome ou código da manobra..."
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
            </div>
          </div>

          {/* Lista de manobras por categoria */}
          <div className="max-h-96 overflow-y-auto space-y-6">
            {Object.entries(manobrasPorCategoria).map(([categoria, manobrasCategoria]) => {
              const totalSelecionadas = manobrasCategoria.filter(m => 
                manobrasSelecionadas.some(ms => ms.id === m.id)
              ).length;
              
              return (
                <div key={categoria} className="border rounded-lg p-4">
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="font-medium text-gray-900 text-lg">
                      {categoria}
                      <span className="ml-2 text-sm text-gray-600">
                        ({totalSelecionadas}/{manobrasCategoria.filter(m => m.ativo).length})
                      </span>
                    </h4>
                    
                    <div className="flex space-x-2">
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => selectAllInCategory(categoria)}
                      >
                        Selecionar Todas
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => deselectAllInCategory(categoria)}
                      >
                        Desmarcar Todas
                      </Button>
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-3">
                    {manobrasCategoria.map(manobra => {
                      const isSelected = manobrasSelecionadas.some(m => m.id === manobra.id);
                      
                      return (
                        <label
                          key={manobra.id}
                          className={`flex items-start space-x-3 p-3 rounded-lg cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-blue-50 border-2 border-blue-200 shadow-sm'
                              : 'bg-gray-50 hover:bg-gray-100 border-2 border-gray-200'
                          } ${!manobra.ativo ? 'opacity-50' : ''}`}
                        >
                          <div className="flex items-center h-5">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => onToggleManobra(manobra.id)}
                              disabled={!manobra.ativo}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="font-medium text-sm text-blue-700">
                                {manobra.manobra_id_codigo}
                              </span>
                              {isSelected && (
                                <CheckCircle className="w-4 h-4 text-green-500" />
                              )}
                              {!manobra.ativo && (
                                <span className="text-xs text-red-600 bg-red-100 px-2 py-1 rounded">
                                  Inativa
                                </span>
                              )}
                            </div>
                            
                            <p className="text-gray-900 text-sm font-medium">
                              {manobra.nome_manobra}
                            </p>
                            
                            <p className="text-xs text-gray-500">
                              Pontuação mínima: {manobra.pontuacao_minima}
                            </p>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {Object.keys(manobrasPorCategoria).length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <p>Nenhuma manobra encontrada com os filtros aplicados.</p>
            </div>
          )}

          {/* Footer com ações */}
          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button onClick={onSalvar} disabled={loading}>
              <Save className="w-4 h-4 mr-2" />
              {loading ? 'Salvando...' : 'Salvar Configuração'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Modal de Duplicação */}
      <Modal
        isOpen={showDuplicateModal}
        onClose={() => setShowDuplicateModal(false)}
        title="Duplicar Sessão"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Crie uma nova sessão baseada na configuração atual de manobras.
          </p>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Código da Nova Sessão
            </label>
            <input
              type="text"
              value={duplicateData.novo_codigo}
              onChange={(e) => setDuplicateData(prev => ({ ...prev, novo_codigo: e.target.value }))}
              placeholder="Ex: S102"
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nome da Nova Sessão
            </label>
            <input
              type="text"
              value={duplicateData.novo_nome}
              onChange={(e) => setDuplicateData(prev => ({ ...prev, novo_nome: e.target.value }))}
              placeholder="Ex: Treinamento Avançado de IFR"
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>
          
          <div className="bg-blue-50 p-3 rounded">
            <p className="text-sm text-blue-700">
              Serão copiadas <strong>{manobrasSelecionadas.length} manobras</strong> da sessão atual.
            </p>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button 
              variant="secondary" 
              onClick={() => setShowDuplicateModal(false)}
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleDuplicateSessao}
              disabled={!duplicateData.novo_nome || !duplicateData.novo_codigo}
            >
              <Copy className="w-4 h-4 mr-2" />
              Duplicar Sessão
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default MatrizConfigModal;
