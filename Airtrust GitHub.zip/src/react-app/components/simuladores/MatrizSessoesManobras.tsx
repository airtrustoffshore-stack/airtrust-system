import React, { useState, useEffect } from 'react';
import { Download, Upload, AlertTriangle, CheckCircle } from 'lucide-react';
import Button from '../Button';
import Modal from '../Modal';
import Card from '../Card';

const LazyMatrizConfigModal = React.lazy(() => import('./MatrizConfigModal'));

interface SessaoTemplate {
  id: number;
  treinamento_codigo: string;
  numero_sessao: number;
  nome_sessao: string;
  descricao?: string;
  total_manobras: number;
}

interface Manobra {
  id: number;
  manobra_id_codigo: string;
  nome_manobra: string;
  categoria: string;
  pontuacao_minima: number;
  ativo: boolean;
}



const MatrizSessoesManobras: React.FC = () => {
  const [sessoes, setSessoes] = useState<SessaoTemplate[]>([]);
  const [manobras, setManobras] = useState<Manobra[]>([]);
  const [selectedSessao, setSelectedSessao] = useState<SessaoTemplate | null>(null);
  const [manobrasSessao, setManobrasSessao] = useState<Manobra[]>([]);
  const [showMatrizModal, setShowMatrizModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [changes, setChanges] = useState<Set<number>>(new Set());
  const [importResults, setImportResults] = useState<any>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Carregar sessões template
      const sessoesResponse = await fetch('/api/v2/simuladores/sessoes-template/listar');
      const sessoesData = await sessoesResponse.json();
      setSessoes(sessoesData.data || []);

      // Carregar todas as manobras
      const manobrasResponse = await fetch('/api/v2/simuladores/manobras/listar');
      const manobrasData = await manobrasResponse.json();
      setManobras(manobrasData.data || []);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadManobrasSessao = async (sessaoId: number) => {
    try {
      const response = await fetch(`/api/v2/matriz-sessoes-manobras-enhanced/sessao/${sessaoId}`);
      const data = await response.json();
      setManobrasSessao(data.data || []);
    } catch (error) {
      console.error('Erro ao carregar manobras da sessão:', error);
    }
  };

  const handleEditarMatriz = async (sessao: SessaoTemplate) => {
    setSelectedSessao(sessao);
    await loadManobrasSessao(sessao.id);
    setShowMatrizModal(true);
  };

  const toggleManobra = (manobraId: number) => {
    const isSelected = manobrasSessao.some(m => m.id === manobraId);
    
    if (isSelected) {
      setManobrasSessao(prev => prev.filter(m => m.id !== manobraId));
    } else {
      const manobra = manobras.find(m => m.id === manobraId);
      if (manobra) {
        setManobrasSessao(prev => [...prev, manobra]);
      }
    }
    
    if (selectedSessao) {
      setChanges(prev => new Set([...prev, selectedSessao.id]));
    }
  };

  const handleSalvarMatriz = async () => {
    if (!selectedSessao) return;

    setLoading(true);
    try {
      const response = await fetch('/api/v2/matriz-sessoes-manobras-enhanced/bulk-update', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          sessao_template_id: selectedSessao.id,
          manobras_ids: manobrasSessao.map(m => m.id)
        })
      });

      if (response.ok) {
        setChanges(prev => {
          const newChanges = new Set(prev);
          newChanges.delete(selectedSessao.id);
          return newChanges;
        });
        setShowMatrizModal(false);
        await loadData();
        alert('Matriz atualizada com sucesso!');
      } else {
        alert('Erro ao salvar matriz');
      }
    } catch (error) {
      console.error('Erro ao salvar matriz:', error);
      alert('Erro ao salvar matriz');
    } finally {
      setLoading(false);
    }
  };

  const handleImportCSV = async (file: File) => {
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/v2/matriz-sessoes-manobras-enhanced/import-csv', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();
      
      if (response.ok) {
        setImportResults(data.data);
        await loadData();
      } else {
        alert(`Erro na importação: ${data.error}`);
      }
    } catch (error) {
      console.error('Erro na importação:', error);
      alert('Erro na importação');
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = async () => {
    try {
      const response = await fetch('/api/v2/matriz-sessoes-manobras-enhanced/export-csv');
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'matriz_sessoes_manobras.csv';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } else {
        alert('Erro ao exportar CSV');
      }
    } catch (error) {
      console.error('Erro ao exportar:', error);
      alert('Erro ao exportar CSV');
    }
  };

  

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Matriz Sessões × Manobras</h2>
          <p className="text-gray-600">Configure quais manobras fazem parte de cada sessão de treinamento</p>
        </div>
        
        <div className="flex space-x-3">
          <Button variant="secondary" onClick={handleExportCSV}>
            <Download className="w-4 h-4 mr-2" />
            Exportar CSV
          </Button>
          <Button variant="secondary" onClick={() => setShowImportModal(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Importar CSV
          </Button>
        </div>
      </div>

      {/* Lista de Sessões */}
      <div className="grid gap-4">
        {sessoes.map(sessao => (
          <Card key={sessao.id} className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-lg">{sessao.nome_sessao}</h3>
                <p className="text-gray-600">Código: {sessao.treinamento_codigo} | Sessão {sessao.numero_sessao}</p>
                <p className="text-sm text-gray-500">
                  {sessao.total_manobras} manobra(s) configurada(s)
                </p>
                {sessao.descricao && (
                  <p className="text-gray-600 mt-1">{sessao.descricao}</p>
                )}
              </div>
              <div className="flex items-center space-x-2">
                {changes.has(sessao.id) && (
                  <span className="text-amber-600 text-sm">
                    <AlertTriangle className="w-4 h-4 inline mr-1" />
                    Alterações não salvas
                  </span>
                )}
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => handleEditarMatriz(sessao)}
                >
                  Configurar Manobras
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Modal de Configuração da Matriz - Lazy Loaded */}
      {showMatrizModal && (
        <React.Suspense fallback={<div>Carregando...</div>}>
          <LazyMatrizConfigModal
            isOpen={showMatrizModal}
            onClose={() => setShowMatrizModal(false)}
            sessao={selectedSessao}
            manobras={manobras}
            manobrasSelecionadas={manobrasSessao}
            onToggleManobra={toggleManobra}
            onSalvar={handleSalvarMatriz}
            loading={loading}
          />
        </React.Suspense>
      )}

      {/* Modal de Importação CSV */}
      <Modal
        isOpen={showImportModal}
        onClose={() => {
          setShowImportModal(false);
          setImportResults(null);
        }}
        title="Importar Matriz via CSV"
      >
        <div className="space-y-6">
          {!importResults ? (
            <>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Formato do CSV</h4>
                  <div className="bg-gray-50 p-3 rounded text-sm font-mono">
                    sessao_codigo,nome_sessao,manobra_codigos<br />
                    S101,"Treinamento CRM","M-101,M-204,M-300"<br />
                    S102,"Treinamento IFR","M-201,M-204"
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600 mb-3">
                    • <strong>sessao_codigo</strong>: Código identificador da sessão<br />
                    • <strong>nome_sessao</strong>: Nome da sessão (será criada se não existir)<br />
                    • <strong>manobra_codigos</strong>: Códigos das manobras separados por vírgula
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Selecionar arquivo CSV
                </label>
                <input
                  type="file"
                  accept=".csv"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      handleImportCSV(file);
                    }
                  }}
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                />
              </div>
            </>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-green-600">
                <CheckCircle className="w-5 h-5" />
                <h4 className="font-medium">Importação Concluída</h4>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-blue-50 p-3 rounded">
                  <p className="font-medium">Total de linhas: {importResults.total_linhas}</p>
                </div>
                <div className="bg-green-50 p-3 rounded">
                  <p className="font-medium">Processadas: {importResults.processadas}</p>
                </div>
                <div className="bg-purple-50 p-3 rounded">
                  <p className="font-medium">Sessões criadas: {importResults.sessoes_criadas}</p>
                </div>
                <div className="bg-indigo-50 p-3 rounded">
                  <p className="font-medium">Relações criadas: {importResults.relacoes_criadas}</p>
                </div>
              </div>

              {importResults.codigos_nao_encontrados.length > 0 && (
                <div className="bg-yellow-50 p-3 rounded">
                  <p className="font-medium text-yellow-800 mb-2">Códigos não encontrados:</p>
                  <p className="text-sm text-yellow-700">
                    {importResults.codigos_nao_encontrados.join(', ')}
                  </p>
                </div>
              )}

              {importResults.erros.length > 0 && (
                <div className="bg-red-50 p-3 rounded max-h-32 overflow-y-auto">
                  <p className="font-medium text-red-800 mb-2">Erros encontrados:</p>
                  {importResults.erros.map((erro: any, index: number) => (
                    <p key={index} className="text-sm text-red-700">
                      Linha {erro.linha}: {erro.erro}
                    </p>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end">
            <Button onClick={() => {
              setShowImportModal(false);
              setImportResults(null);
            }}>
              Fechar
            </Button>
          </div>
        </div>
      </Modal>

      {loading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg">
            <p>Carregando...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default MatrizSessoesManobras;
