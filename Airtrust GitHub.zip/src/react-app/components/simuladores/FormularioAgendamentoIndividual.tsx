import React, { useState, useEffect } from 'react';
import { InputDataBrasil, InputHoraBrasil, DateTimeBrasil } from '../../utils/InputsBrasileiros';
import Button from '../Button';

/**
 * ⚠️ PADRÃO BRASILEIRO OBRIGATÓRIO - AIRTRUST ⚠️
 * 
 * Formulário de Agendamento com Controle Individual de Treinamentos por Tripulante
 * 
 * Características obrigatórias:
 * ✅ Datas: SEMPRE dd/mm/aaaa (nunca mm/dd/yyyy ou yyyy-mm-dd)
 * ✅ Placeholders: SEMPRE "dd/mm/aaaa"
 * ✅ Máscaras: SEMPRE dd/mm/aaaa
 * ✅ Validação: SEMPRE formato brasileiro
 * ✅ Cultura: SEMPRE pt-BR
 */

interface DadosGerais {
  data_inicio: string;
  hora_inicio: string;
  data_fim: string;
  hora_fim: string;
  simulador_id: string;
  instrutor_id: string;
  observacoes: string;
}

interface Participante {
  id: number;
  colaborador_id: string;
  treinamento_id: string;
  template_sessao_id: string;
  funcao_na_sessao: 'PIC' | 'SIC' | 'DUAL';
  sessao_numero: number;
  total_sessoes_treinamento: number;
}

interface Simulador {
  id: number;
  nome: string;
  codigo_identificacao: string;
  status: string;
}

interface Funcionario {
  id: number;
  nome: string;
  matricula: string;
  is_instrutor: boolean;
  is_checador: boolean;
}

interface Treinamento {
  id: number;
  codigo: string;
  nome: string;
  total_sessoes: number;
}

interface Template {
  id: number;
  codigo?: string;
  nome_sessao: string;
  treinamento_codigo: string;
}

interface Props {
  onSalvar: (dadosCompletos: { dados_gerais: DadosGerais; participantes: Participante[] }) => void;
  onCancelar: () => void;
}

const FormularioAgendamentoIndividual: React.FC<Props> = ({
  onSalvar,
  onCancelar
}) => {
  const [dadosGerais, setDadosGerais] = useState<DadosGerais>({
    data_inicio: '',
    hora_inicio: '',
    data_fim: '',
    hora_fim: '',
    simulador_id: '',
    instrutor_id: '',
    observacoes: ''
  });
  
  const [participantes, setParticipantes] = useState<Participante[]>([
    {
      id: 1,
      colaborador_id: '',
      treinamento_id: '',
      template_sessao_id: '',
      funcao_na_sessao: 'PIC',
      sessao_numero: 1,
      total_sessoes_treinamento: 0
    },
    {
      id: 2,
      colaborador_id: '',
      treinamento_id: '',
      template_sessao_id: '',
      funcao_na_sessao: 'SIC',
      sessao_numero: 1,
      total_sessoes_treinamento: 0
    }
  ]);
  
  const [autoCalculado, setAutoCalculado] = useState(false);
  
  // Estados para dados carregados dos endpoints
  const [simuladores, setSimuladores] = useState<Simulador[]>([]);
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [treinamentos, setTreinamentos] = useState<Treinamento[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [carregando, setCarregando] = useState(true);
  
  // Carregar dados dos endpoints
  useEffect(() => {
    const carregarDados = async () => {
      try {
        const [simResponse, funcResponse, treinResponse, templatesResponse] = await Promise.all([
          fetch('/api/v2/simuladores'),
          fetch('/api/v2/funcionarios'),
          fetch('/api/v2/treinamentos'),
          fetch('/api/v2/simuladores/sessoes-template')
        ]);
        
        const [simData, funcData, treinData, templatesData] = await Promise.all([
          simResponse.json(),
          funcResponse.json(),
          treinResponse.json(),
          templatesResponse.json()
        ]);
        
        setSimuladores(simData.data || []);
        setFuncionarios(funcData.data || []);
        setTreinamentos(treinData.data || []);
        setTemplates(templatesData.data || []);
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
      } finally {
        setCarregando(false);
      }
    };
    
    carregarDados();
  }, []);
  
  // Auto-calcular horário de fim
  useEffect(() => {
    const { data_inicio, hora_inicio } = dadosGerais;
    
    if (data_inicio && hora_inicio && data_inicio.length === 10 && hora_inicio.length === 5) {
      const { data_fim, hora_fim } = calcularHorarioFim(data_inicio, hora_inicio);
      
      if (data_fim && hora_fim) {
        setDadosGerais(prev => ({
          ...prev,
          data_fim,
          hora_fim
        }));
        setAutoCalculado(true);
      }
    }
  }, [dadosGerais.data_inicio, dadosGerais.hora_inicio]);
  
  const calcularHorarioFim = (dataBrasil: string, horaInicio: string) => {
    if (!dataBrasil || !horaInicio) return { data_fim: '', hora_fim: '' };
    
    try {
      const dataHoraInicio = DateTimeBrasil.converterDataHoraBrasil(dataBrasil, horaInicio);
      if (!dataHoraInicio) return { data_fim: '', hora_fim: '' };
      
      const dataHoraFim = new Date(dataHoraInicio);
      dataHoraFim.setHours(dataHoraFim.getHours() + 2);
      
      const dataFimBrasil = DateTimeBrasil.formatarDataBrasil(dataHoraFim);
      const horaFim = dataHoraFim.toTimeString().substring(0, 5);
      
      return { data_fim: dataFimBrasil, hora_fim: horaFim };
    } catch (error) {
      console.error('Erro ao calcular horário fim:', error);
      return { data_fim: '', hora_fim: '' };
    }
  };
  
  const handleDadosGeraisChange = (campo: keyof DadosGerais, valor: string) => {
    setDadosGerais(prev => ({
      ...prev,
      [campo]: valor
    }));
    
    if (campo === 'data_fim' || campo === 'hora_fim') {
      setAutoCalculado(false);
    }
  };
  
  const handleParticipanteChange = (participanteId: number, campo: keyof Participante, valor: any) => {
    setParticipantes(prev =>
      prev.map(p => {
        if (p.id === participanteId) {
          const updated = { ...p, [campo]: valor };
          
          // Se mudou o treinamento, buscar informações do treinamento
          if (campo === 'treinamento_id' && valor) {
            const treinamento = treinamentos.find(t => t.id.toString() === valor);
            if (treinamento) {
              updated.total_sessoes_treinamento = treinamento.total_sessoes || 3;
            }
          }
          
          return updated;
        }
        return p;
      })
    );
  };
  
  const validarFormulario = () => {
    const erros: string[] = [];
    
    // Validar dados gerais
    if (!dadosGerais.simulador_id) erros.push('Simulador é obrigatório');
    if (!dadosGerais.instrutor_id) erros.push('Instrutor é obrigatório');
    if (!dadosGerais.data_inicio) erros.push('Data de início é obrigatória');
    if (!dadosGerais.hora_inicio) erros.push('Hora de início é obrigatória');
    
    // Validar formato brasileiro das datas
    if (dadosGerais.data_inicio && !DateTimeBrasil.validarDataBrasil(dadosGerais.data_inicio)) {
      erros.push('Data de início deve estar no formato brasileiro dd/mm/aaaa');
    }
    
    if (dadosGerais.data_fim && !DateTimeBrasil.validarDataBrasil(dadosGerais.data_fim)) {
      erros.push('Data de fim deve estar no formato brasileiro dd/mm/aaaa');
    }
    
    // Validar participantes
    participantes.forEach((p, index) => {
      if (!p.colaborador_id) erros.push(`Tripulante ${index + 1} é obrigatório`);
      if (!p.treinamento_id) erros.push(`Treinamento do Tripulante ${index + 1} é obrigatório`);
      if (!p.template_sessao_id) erros.push(`Template do Tripulante ${index + 1} é obrigatório`);
    });
    
    // Verificar se não tem tripulantes duplicados
    const colaboradorIds = participantes.map(p => p.colaborador_id).filter(Boolean);
    if (new Set(colaboradorIds).size !== colaboradorIds.length) {
      erros.push('Não pode ter o mesmo tripulante duas vezes na sessão');
    }
    
    return erros;
  };
  
  const handleSalvar = () => {
    const erros = validarFormulario();
    
    if (erros.length > 0) {
      alert('Corrija os seguintes erros:\n' + erros.join('\n'));
      return;
    }
    
    const dadosCompletos = {
      dados_gerais: dadosGerais,
      participantes: participantes
    };
    
    onSalvar(dadosCompletos);
  };
  
  // Filtrar funcionários instrutores
  const instrutores = funcionarios.filter(f => f.is_instrutor);
  
  // Filtrar templates por treinamento
  const getTemplatesPorTreinamento = (treinamentoId: string) => {
    const treinamento = treinamentos.find(t => t.id.toString() === treinamentoId);
    if (!treinamento) return [];
    return templates.filter(t => t.treinamento_codigo === treinamento.codigo);
  };
  
  // Mostrar carregamento se ainda estiver carregando dados
  if (carregando) {
    return (
      <div className="formulario-agendamento-individual space-y-6 max-w-4xl mx-auto">
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-gray-600 mt-2">Carregando dados do formulário...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="formulario-agendamento-individual space-y-6 max-w-4xl mx-auto">
      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-gray-900">📅 Agendar Sessão Dupla com Controle Individual</h3>
        <p className="text-gray-600 mt-2">🇧🇷 Cada tripulante pode estar em treinamentos diferentes</p>
      </div>
      
      {/* Dados Gerais da Sessão */}
      <section className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border-l-4 border-blue-500">
        <h4 className="text-lg font-semibold mb-4 text-blue-900">📍 Dados Gerais da Sessão</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">🎮 Simulador *</label>
            <select
              value={dadosGerais.simulador_id}
              onChange={(e) => handleDadosGeraisChange('simulador_id', e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Selecione o simulador...</option>
              {simuladores.map(sim => (
                <option key={sim.id} value={sim.id}>
                  {sim.nome} ({sim.codigo_identificacao})
                </option>
              ))}
            </select>
          </div>
          
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">👨‍🏫 Instrutor *</label>
            <select
              value={dadosGerais.instrutor_id}
              onChange={(e) => handleDadosGeraisChange('instrutor_id', e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Selecione o instrutor...</option>
              {instrutores.map(inst => (
                <option key={inst.id} value={inst.id}>
                  {inst.nome} ({inst.matricula})
                </option>
              ))}
            </select>
          </div>
          
          {/* 🇧🇷 Data de Início - PADRÃO BRASILEIRO */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">📅 Data de Início *</label>
            <InputDataBrasil
              value={dadosGerais.data_inicio}
              onChange={(valor) => handleDadosGeraisChange('data_inicio', valor)}
              placeholder="dd/mm/aaaa" // 🇧🇷 OBRIGATÓRIO
              required
            />
            <small className="text-xs text-blue-600">📅 Formato brasileiro: dd/mm/aaaa</small>
          </div>
          
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">🕒 Hora de Início *</label>
            <InputHoraBrasil
              value={dadosGerais.hora_inicio}
              onChange={(valor) => handleDadosGeraisChange('hora_inicio', valor)}
              placeholder="HH:mm"
              required
            />
          </div>
          
          {/* 🇧🇷 Data de Fim - PADRÃO BRASILEIRO */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              📅 Data de Fim *
              {autoCalculado && <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 text-xs rounded">🤖 Auto</span>}
            </label>
            <InputDataBrasil
              value={dadosGerais.data_fim}
              onChange={(valor) => handleDadosGeraisChange('data_fim', valor)}
              placeholder="dd/mm/aaaa" // 🇧🇷 OBRIGATÓRIO
              required
            />
          </div>
          
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              🕒 Hora de Fim *
              {autoCalculado && <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 text-xs rounded">🤖 +2h</span>}
            </label>
            <InputHoraBrasil
              value={dadosGerais.hora_fim}
              onChange={(valor) => handleDadosGeraisChange('hora_fim', valor)}
              placeholder="HH:mm"
              required
            />
          </div>
        </div>
      </section>
      
      {/* Participantes Individuais */}
      <section className="space-y-4">
        <h4 className="text-lg font-semibold text-gray-900">👥 Participantes da Sessão (Controle Individual)</h4>
        
        {participantes.map((participante, index) => (
          <div key={participante.id} className="bg-white border-2 border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
            <h5 className="text-md font-semibold mb-4 text-gray-800 border-b pb-2">
              🧑‍✈️ Tripulante {index + 1} - {participante.funcao_na_sessao}
            </h5>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Tripulante *</label>
                <select
                  value={participante.colaborador_id}
                  onChange={(e) => handleParticipanteChange(participante.id, 'colaborador_id', e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Selecione o tripulante...</option>
                  {funcionarios.map(func => (
                    <option key={func.id} value={func.id}>
                      {func.nome} ({func.matricula})
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">🎯 Treinamento que está Fazendo *</label>
                <select
                  value={participante.treinamento_id}
                  onChange={(e) => handleParticipanteChange(participante.id, 'treinamento_id', e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Selecione o treinamento...</option>
                  {treinamentos.map(trein => (
                    <option key={trein.id} value={trein.id}>
                      {trein.codigo} - {trein.nome}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">📋 Template desta Sessão *</label>
                <select
                  value={participante.template_sessao_id}
                  onChange={(e) => handleParticipanteChange(participante.id, 'template_sessao_id', e.target.value)}
                  required
                  disabled={!participante.treinamento_id}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100"
                >
                  <option value="">Selecione o template...</option>
                  {getTemplatesPorTreinamento(participante.treinamento_id).map(template => (
                    <option key={template.id} value={template.id}>
                      {template.nome_sessao}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">⚡ Função na Sessão *</label>
                <select
                  value={participante.funcao_na_sessao}
                  onChange={(e) => handleParticipanteChange(participante.id, 'funcao_na_sessao', e.target.value as 'PIC' | 'SIC' | 'DUAL')}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="PIC">PIC - Pilot in Command</option>
                  <option value="SIC">SIC - Second in Command</option>
                  <option value="DUAL">DUAL - Dual Control</option>
                </select>
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">📊 Sessão Nº do Treinamento</label>
                <input
                  type="number"
                  min="1"
                  max={participante.total_sessoes_treinamento || 10}
                  value={participante.sessao_numero}
                  onChange={(e) => handleParticipanteChange(participante.id, 'sessao_numero', parseInt(e.target.value) || 1)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                {participante.total_sessoes_treinamento > 0 && (
                  <small className="text-xs text-gray-600">
                    Total de sessões do treinamento: {participante.total_sessoes_treinamento}
                  </small>
                )}
              </div>
            </div>
            
            {/* Progresso Visual do Treinamento */}
            {participante.total_sessoes_treinamento > 0 && (
              <div className="mt-4 p-3 bg-blue-50 rounded-md">
                <label className="block text-sm font-medium text-blue-900 mb-2">📈 Progresso no Treinamento:</label>
                <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ 
                      width: `${(participante.sessao_numero / participante.total_sessoes_treinamento) * 100}%` 
                    }}
                  />
                </div>
                <div className="text-sm text-blue-800">
                  Sessão {participante.sessao_numero} de {participante.total_sessoes_treinamento}
                  {participante.sessao_numero === participante.total_sessoes_treinamento && 
                    <span className="ml-2 px-2 py-1 bg-red-100 text-red-800 text-xs rounded font-medium">
                      🎯 SESSÃO FINAL - Gerará certificação se aprovado!
                    </span>
                  }
                </div>
              </div>
            )}
          </div>
        ))}
      </section>
      
      {/* Observações Gerais */}
      <section className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">📝 Observações da Sessão</label>
        <textarea
          value={dadosGerais.observacoes}
          onChange={(e) => handleDadosGeraisChange('observacoes', e.target.value)}
          placeholder="Observações gerais sobre a sessão..."
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </section>
      
      {/* Informativo sobre controle individual */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-lg p-4">
        <h4 className="text-md font-semibold text-green-900 mb-2">ℹ️ Controle Individual de Treinamentos</h4>
        <div className="text-sm text-green-800 space-y-1">
          <p>✅ Cada tripulante tem progresso independente no seu treinamento</p>
          <p>✅ A avaliação e certificação é individual por tripulante</p>
          <p>✅ Tripulantes podem estar em treinamentos e etapas diferentes</p>
          <p>✅ Sistema rastreia automaticamente o progresso de cada um</p>
        </div>
      </div>
      
      {/* Botões de Ação */}
      <div className="flex justify-end space-x-4 pt-6 border-t">
        <Button variant="secondary" onClick={onCancelar}>
          ❌ Cancelar
        </Button>
        
        <Button onClick={handleSalvar} className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700">
          💾 Agendar Sessão com Controle Individual
        </Button>
      </div>
    </div>
  );
};

export default FormularioAgendamentoIndividual;
