import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { InputDataBrasil, useDateBrasil } from '../common/InputDataBrasil';

interface DadosAgendamento {
  data_inicio: string; // Formato brasileiro dd/mm/aaaa
  hora_inicio: string;
  data_fim: string; // Formato brasileiro dd/mm/aaaa
  hora_fim: string;
  simulador_id: string;
  instrutor_id: string;
  colaborador_aluno_id: string;
  template_sessao_id: string;
  funcao_na_sessao: 'PIC' | 'SIC' | 'DUAL';
  observacoes: string;
}

interface Simulador {
  id: number;
  nome: string;
  codigo_identificacao: string;
}

interface Funcionario {
  id: number;
  nome: string;
  matricula: string;
}

interface Template {
  id: number;
  nome: string;
  total_manobras: number;
}

interface Props {
  onSalvar?: (dados: DadosAgendamento) => void;
  onCancelar?: () => void;
  templateSelecionado?: any;
}

const FormularioAgendamento: React.FC<Props> = ({ onSalvar, onCancelar, templateSelecionado }) => {
  // 🇧🇷 Hooks para datas brasileiras
  const dataInicio = useDateBrasil();
  const dataFim = useDateBrasil();
  
  const [dadosAgendamento, setDadosAgendamento] = useState<DadosAgendamento>({
    data_inicio: '',
    hora_inicio: '',
    data_fim: '',
    hora_fim: '',
    simulador_id: '',
    instrutor_id: '',
    colaborador_aluno_id: '',
    template_sessao_id: templateSelecionado?.id?.toString() || '',
    funcao_na_sessao: 'PIC',
    observacoes: ''
  });
  
  const [simuladores, setSimuladores] = useState<Simulador[]>([]);
  const [instrutores, setInstrutores] = useState<Funcionario[]>([]);
  const [colaboradores, setColaboradores] = useState<Funcionario[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [autoCalculado, setAutoCalculado] = useState(false);
  const [salvando, setSalvando] = useState(false);
  const navigate = useNavigate();
  
  useEffect(() => {
    carregarDadosFormulario();
  }, []);
  
  const carregarDadosFormulario = async () => {
    try {
      const [simResponse, funcResponse, templatesResponse] = await Promise.all([
        fetch('/api/v2/simuladores'),
        fetch('/api/v2/funcionarios'),
        fetch('/api/v2/simuladores/sessoes-template')
      ]);
      
      const [simData, funcData, templatesData] = await Promise.all([
        simResponse.json(),
        funcResponse.json(),
        templatesResponse.json()
      ]);
      
      setSimuladores(simData.data || []);
      
      // Separar instrutores e tripulantes
      const funcionarios = funcData.data || [];
      setInstrutores(funcionarios.filter((f: Funcionario & { is_instrutor?: boolean }) => f.is_instrutor));
      setColaboradores(funcionarios);
      
      setTemplates(templatesData.data || []);
    } catch (error) {
      console.error('Erro ao carregar dados do formulário:', error);
    }
  };
  
  // 🇧🇷 Auto-calcular hora fim quando início muda (formato brasileiro)
  useEffect(() => {
    if (dataInicio.dataBrasil && dadosAgendamento.hora_inicio) {
      const dataFimCalculada = dataInicio.dataBrasil; // Mesmo dia
      const [hora, minuto] = dadosAgendamento.hora_inicio.split(':');
      const novaHora = (parseInt(hora) + 2) % 24; // +2 horas
      const horaFimCalculada = `${novaHora.toString().padStart(2, '0')}:${minuto}`;
      
      dataFim.setDataBrasil(dataFimCalculada);
      setDadosAgendamento(prev => ({
        ...prev,
        data_inicio: dataInicio.dataBrasil,
        data_fim: dataFimCalculada,
        hora_fim: horaFimCalculada
      }));
      setAutoCalculado(true);
    }
  }, [dataInicio.dataBrasil, dadosAgendamento.hora_inicio]);
  
  const handleInputChange = (campo: keyof DadosAgendamento, valor: string) => {
    setDadosAgendamento(prev => ({
      ...prev,
      [campo]: valor
    }));
    
    if (campo === 'data_fim' || campo === 'hora_fim') {
      setAutoCalculado(false);
    }
  };
  
  const handleSalvar = async () => {
    setSalvando(true);
    
    try {
      // 🇧🇷 Montar payload com datas brasileiras
      const payloadCompleto = {
        ...dadosAgendamento,
        data_inicio: dataInicio.dataBrasil,
        data_fim: dataFim.dataBrasil
      };
      
      if (onSalvar) {
        onSalvar(payloadCompleto);
      } else {
        const response = await fetch('/api/v2/simulador/agendamento', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payloadCompleto)
        });
        
        if (response.ok) {
          const data = await response.json();
          alert(`✅ Sessão agendada com sucesso!\nFicha criada: ${data.agendamento.ficha_uuid}`);
          navigate('/simulador');
        } else {
          const error = await response.json();
          alert(`❌ Erro ao agendar: ${error.error}`);
        }
      }
    } catch (error) {
      console.error('Erro ao salvar agendamento:', error);
      alert('❌ Erro de conexão ao salvar agendamento');
    } finally {
      setSalvando(false);
    }
  };
  
  const handleCancelar = () => {
    if (onCancelar) {
      onCancelar();
    } else {
      navigate('/simulador');
    }
  };
  
  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            📅 Agendar Nova Sessão
          </h1>
          <p className="text-gray-600">
            Agende uma nova sessão de simulador com preenchimento automático de horários
          </p>
        </div>
        
        <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
          {/* Data e Horários - 🇧🇷 Formato Brasileiro */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <InputDataBrasil
                label="📅 Data de Início"
                value={dataInicio.dataBrasil}
                onChange={dataInicio.setDataBrasil}
                required
                minDate={dataInicio.hoje}
                placeholder="dd/mm/aaaa"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                🕒 Hora de Início *
              </label>
              <input
                type="time"
                value={dadosAgendamento.hora_inicio}
                onChange={(e) => handleInputChange('hora_inicio', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            
            <div>
              <InputDataBrasil
                label={`📅 Data de Fim${autoCalculado ? ' (🤖 Auto)' : ''}`}
                value={dataFim.dataBrasil}
                onChange={(valor) => {
                  dataFim.setDataBrasil(valor);
                  setDadosAgendamento(prev => ({ ...prev, data_fim: valor }));
                  setAutoCalculado(false);
                }}
                required
                minDate={dataInicio.dataBrasil || dataInicio.hoje}
                placeholder="dd/mm/aaaa"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                🕒 Hora de Fim * {autoCalculado && <span className="text-green-600 text-xs">(+2h)</span>}
              </label>
              <input
                type="time"
                value={dadosAgendamento.hora_fim}
                onChange={(e) => handleInputChange('hora_fim', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
          </div>
          
          {/* Dados da Sessão */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                🎮 Simulador *
              </label>
              <select
                value={dadosAgendamento.simulador_id}
                onChange={(e) => handleInputChange('simulador_id', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Selecione o simulador...</option>
                {simuladores.map(sim => (
                  <option key={sim.id} value={sim.id}>
                    {sim.nome} ({sim.codigo_identificacao})
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                👨‍🏫 Instrutor *
              </label>
              <select
                value={dadosAgendamento.instrutor_id}
                onChange={(e) => handleInputChange('instrutor_id', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Selecione o instrutor...</option>
                {instrutores.map(inst => (
                  <option key={inst.id} value={inst.id}>
                    {inst.nome}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                👨‍✈️ Tripulante/Aluno *
              </label>
              <select
                value={dadosAgendamento.colaborador_aluno_id}
                onChange={(e) => handleInputChange('colaborador_aluno_id', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Selecione o tripulante...</option>
                {colaboradores.map(col => (
                  <option key={col.id} value={col.id}>
                    {col.nome} ({col.matricula})
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                📋 Template de Sessão
              </label>
              <select
                value={dadosAgendamento.template_sessao_id}
                onChange={(e) => handleInputChange('template_sessao_id', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Selecione o template...</option>
                {templates.map(temp => (
                  <option key={temp.id} value={temp.id}>
                    {temp.nome} ({temp.total_manobras} manobras)
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                ⚡ Função na Sessão *
              </label>
              <select
                value={dadosAgendamento.funcao_na_sessao}
                onChange={(e) => handleInputChange('funcao_na_sessao', e.target.value as 'PIC' | 'SIC' | 'DUAL')}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="PIC">PIC - Pilot in Command</option>
                <option value="SIC">SIC - Second in Command</option>
                <option value="DUAL">DUAL - Dual Control</option>
              </select>
            </div>
          </div>
          
          {/* Observações */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              📝 Observações
            </label>
            <textarea
              value={dadosAgendamento.observacoes}
              onChange={(e) => handleInputChange('observacoes', e.target.value)}
              placeholder="Observações sobre a sessão..."
              rows={3}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          {/* Botões */}
          <div className="flex gap-4 pt-6">
            <button
              type="button"
              onClick={handleCancelar}
              className="flex-1 bg-gray-300 text-gray-700 py-3 px-6 rounded-lg hover:bg-gray-400 font-medium"
            >
              ❌ Cancelar
            </button>
            <button
              type="button"
              onClick={handleSalvar}
              disabled={salvando}
              className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 font-medium disabled:bg-blue-400 flex items-center justify-center gap-2"
            >
              {salvando ? '⏳ Salvando...' : '💾 Agendar Sessão'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FormularioAgendamento;
