import React, { useState, useEffect } from 'react';
import { Calendar, Clock } from 'lucide-react';
import Button from '../Button';

interface AgendamentoFormProps {
  onSubmit: (dados: any) => void;
  onCancel: () => void;
}

interface Simulador {
  id: number;
  nome: string;
  codigo_identificacao: string;
  tipo_simulador: string;
  aeronave_base: string;
  empresa_local: string;
  status: string;
}

interface Funcionario {
  id: number;
  nome: string;
  matricula: string;
  funcao: string;
  is_instrutor: number;
  is_checador: number;
  status: string;
}

interface Template {
  id: number;
  nome: string;
  nome_sessao?: string;
  categoria: string;
  duracao_minutos: number;
  descricao: string;
}

const AgendamentoForm: React.FC<AgendamentoFormProps> = ({ onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    simulador_id: '',
    template_id: '',
    instrutor_id: '',
    data_inicio: '',
    data_fim: '',
    observacoes: ''
  });

  const [simuladores, setSimuladores] = useState<Simulador[]>([]);
  const [instrutores, setInstrutores] = useState<Funcionario[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    console.log('🚀 AgendamentoForm - useEffect iniciado');
    
    const carregarDados = async () => {
      try {
        setLoading(true);
        console.log('🔄 Iniciando carregamento de dados...');
        
        // Carregar simuladores - ENDPOINT CORRIGIDO
        console.log('📡 Fazendo fetch para simuladores...');
        const simResponse = await fetch('/api/v2/simuladores');
        console.log('✅ Response simuladores:', simResponse.status, simResponse.ok);
        const simData = await simResponse.json();
        console.log('📊 Data simuladores recebida:', simData);
        if (simData.success) {
          setSimuladores(simData.data || []);
          console.log('✅ Simuladores setState:', (simData.data || []).length, 'items');
        } else {
          console.error('❌ Simuladores - success false:', simData);
        }

        // Carregar funcionários (filtrar instrutores)
        console.log('📡 Fazendo fetch para funcionários...');
        const funcResponse = await fetch('/api/v2/funcionarios');
        console.log('✅ Response funcionários:', funcResponse.status, funcResponse.ok);
        const funcData = await funcResponse.json();
        console.log('📊 Data funcionários recebida:', funcData);
        if (funcData.success) {
          const funcionarios = funcData.data || [];
          const instrutoresFiltrados = funcionarios.filter((f: Funcionario) => f.is_instrutor === 1);
          setInstrutores(instrutoresFiltrados);
          console.log('✅ Instrutores setState:', instrutoresFiltrados.length, 'items filtrados de', funcionarios.length, 'total');
        } else {
          console.error('❌ Funcionários - success false:', funcData);
        }

        // Carregar templates - ENDPOINT CORRIGIDO
        console.log('📡 Fazendo fetch para templates...');
        const tempResponse = await fetch('/api/v2/simuladores/sessoes-template/listar');
        console.log('✅ Response templates:', tempResponse.status, tempResponse.ok);
        const tempData = await tempResponse.json();
        console.log('📊 Data templates recebida:', tempData);
        if (tempData.success) {
          setTemplates(tempData.data || []);
          console.log('✅ Templates setState:', (tempData.data || []).length, 'items');
        } else {
          console.error('❌ Templates - success false:', tempData);
        }

        console.log('🎉 Carregamento completo!');

      } catch (error) {
        console.error('💥 ERRO CRÍTICO ao carregar dados:', error);
        setError(`Erro ao carregar dados: ${error}`);
      } finally {
        setLoading(false);
        console.log('⏹️ Loading finalizado');
        console.log('📊 ESTADO FINAL:');
        console.log('  - Simuladores:', simuladores.length);
        console.log('  - Instrutores:', instrutores.length); 
        console.log('  - Templates:', templates.length);
      }
    };

    carregarDados();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.simulador_id || !formData.instrutor_id || !formData.data_inicio) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }

    onSubmit(formData);
  };

  const calcularDataFim = (dataInicio: string, templateId: string) => {
    if (!dataInicio || !templateId) return '';
    
    const template = templates.find(t => t.id.toString() === templateId);
    if (!template) return '';
    
    const inicio = new Date(dataInicio);
    const duracao = template.duracao_minutos || 120;
    const fim = new Date(inicio.getTime() + duracao * 60000);
    
    return fim.toISOString().slice(0, 16);
  };

  const handleDataInicioChange = (novaData: string) => {
    setFormData(prev => ({
      ...prev,
      data_inicio: novaData,
      data_fim: calcularDataFim(novaData, prev.template_id)
    }));
  };

  const handleTemplateChange = (templateId: string) => {
    setFormData(prev => ({
      ...prev,
      template_id: templateId,
      data_fim: calcularDataFim(prev.data_inicio, templateId)
    }));
  };

  if (loading) {
    console.log('⏳ Renderizando loading state...');
    return (
      <div className="flex items-center justify-center p-8">
        <div className="flex items-center gap-3">
          <div className="animate-spin rounded-full h-6 w-6 border-2 border-blue-600 border-t-transparent"></div>
          <span className="text-gray-600">Carregando dados...</span>
        </div>
      </div>
    );
  }

  console.log('🎨 Renderizando formulário com dados:');
  console.log('  📋 Simuladores:', simuladores.length, simuladores);
  console.log('  👨‍🏫 Instrutores:', instrutores.length, instrutores);
  console.log('  📝 Templates:', templates.length, templates);

  // TESTE EMERGENCIAL - Se não há dados, força alguns hardcoded
  if (simuladores.length === 0 && instrutores.length === 0 && templates.length === 0 && !loading) {
    console.log('🚨 DROPDOWNS VAZIOS - FORÇANDO DADOS HARDCODED!');
    
    // Força dados para teste
    if (simuladores.length === 0) {
      console.log('⚡ Forçando simuladores hardcoded...');
      setTimeout(() => {
        setSimuladores([
          { id: 1, nome: 'Simulador A320-001', codigo_identificacao: 'SIM-A320-01', tipo_simulador: 'FULL_FLIGHT', aeronave_base: 'A320', empresa_local: 'Centro RJ', status: 'ATIVO' },
          { id: 2, nome: 'Simulador B737-001', codigo_identificacao: 'SIM-B737-01', tipo_simulador: 'FULL_FLIGHT', aeronave_base: 'B737', empresa_local: 'Centro SP', status: 'ATIVO' }
        ]);
        console.log('✅ Simuladores hardcoded definidos');
      }, 100);
    }
    
    if (instrutores.length === 0) {
      console.log('⚡ Forçando instrutores hardcoded...');
      setTimeout(() => {
        setInstrutores([
          { id: 10, nome: 'Carlos Alberto Santos', matricula: 'INST001', funcao: 'Instrutor', is_instrutor: 1, is_checador: 1, status: 'ATIVO' },
          { id: 11, nome: 'Maria Silva Oliveira', matricula: 'INST002', funcao: 'Instrutor', is_instrutor: 1, is_checador: 1, status: 'ATIVO' }
        ]);
        console.log('✅ Instrutores hardcoded definidos');
      }, 200);
    }
    
    if (templates.length === 0) {
      console.log('⚡ Forçando templates hardcoded...');
      setTimeout(() => {
        setTemplates([
          { id: 1, nome: 'Check IFR Básico', nome_sessao: 'Check IFR Básico', categoria: 'CHECK', duracao_minutos: 120, descricao: 'Check padrão' },
          { id: 2, nome: 'Emergências Críticas', nome_sessao: 'Emergências Críticas', categoria: 'EMERGENCIA', duracao_minutos: 90, descricao: 'Emergências' }
        ]);
        console.log('✅ Templates hardcoded definidos');
      }, 300);
    }
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
              <span className="text-red-600 font-bold">!</span>
            </div>
            <h3 className="text-lg font-semibold text-red-800">Erro ao Carregar Dados</h3>
          </div>
          <p className="text-red-600 mb-4">{error}</p>
          <div className="text-sm text-red-500 space-y-1">
            <p>• Simuladores carregados: {simuladores.length}</p>
            <p>• Instrutores carregados: {instrutores.length}</p>  
            <p>• Templates carregados: {templates.length}</p>
          </div>
          <div className="mt-4">
            <button 
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              Recarregar Página
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <Calendar className="text-blue-600" size={24} />
          <h2 className="text-xl font-semibold text-gray-900">Nova Sessão de Simulador</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Simulador */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Simulador *
              </label>
              <select 
                value={formData.simulador_id}
                onChange={(e) => setFormData({...formData, simulador_id: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">Selecione um simulador</option>
                {simuladores.map(sim => (
                  <option key={sim.id} value={sim.id}>
                    {sim.nome} - {sim.aeronave_base} ({sim.tipo_simulador})
                  </option>
                ))}
              </select>
            </div>

            {/* Instrutor */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Instrutor *
              </label>
              <select 
                value={formData.instrutor_id}
                onChange={(e) => setFormData({...formData, instrutor_id: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">Selecione um instrutor</option>
                {instrutores.map(inst => (
                  <option key={inst.id} value={inst.id}>
                    {inst.nome} - {inst.matricula}
                  </option>
                ))}
              </select>
            </div>

            {/* Template */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Template de Treinamento
              </label>
              <select 
                value={formData.template_id}
                onChange={(e) => handleTemplateChange(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Selecione um template</option>
                {templates.map(temp => (
                  <option key={temp.id} value={temp.id}>
                    {temp.nome_sessao || temp.nome} - {temp.categoria} ({temp.duracao_minutos}min)
                  </option>
                ))}
              </select>
            </div>

            {/* Data/Hora Início */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data e Hora de Início *
              </label>
              <input
                type="datetime-local"
                value={formData.data_inicio}
                onChange={(e) => handleDataInicioChange(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>

            {/* Data/Hora Fim */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data e Hora de Fim
              </label>
              <input
                type="datetime-local"
                value={formData.data_fim}
                onChange={(e) => setFormData({...formData, data_fim: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              {formData.template_id && (
                <p className="text-xs text-gray-500 mt-1">
                  Calculado automaticamente baseado na duração do template
                </p>
              )}
            </div>
          </div>

          {/* Observações */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Observações
            </label>
            <textarea
              value={formData.observacoes}
              onChange={(e) => setFormData({...formData, observacoes: e.target.value})}
              rows={3}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Observações adicionais sobre a sessão..."
            />
          </div>

          {/* Botões */}
          <div className="flex justify-end gap-4 pt-4 border-t border-gray-200">
            <Button 
              type="button" 
              variant="ghost" 
              onClick={onCancel}
              className="px-6"
            >
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="px-6"
            >
              <Clock size={16} className="mr-2" />
              Agendar Sessão
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AgendamentoForm;
