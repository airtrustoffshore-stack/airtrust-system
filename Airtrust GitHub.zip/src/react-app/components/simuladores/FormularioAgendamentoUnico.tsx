import React, { useState, useEffect } from 'react';
import { Plus, X, Calendar, Users } from 'lucide-react';
import Button from '../Button';
import Card from '../Card';

interface DadosGerais {
  simulador_id: number;
  instrutor_id: number;
  checador_id?: number;
  data_inicio: string;
  hora_inicio: string;
  data_fim?: string;
  hora_fim?: string;
  observacoes?: string;
}

interface Participante {
  id: number;
  tripulante_id: number;
  tripulante_nome: string;
  tripulante_matricula: string;
  funcao_na_sessao: string;
  template_id?: number;
  template_nome?: string;
}

interface Simulador {
  id: number;
  nome: string;
  codigo_identificacao: string;
  status: string;
}

interface Funcionario {
  id: number;
  nome: string;
  matricula: string;
  is_instrutor: boolean;
  is_checador: boolean;
}

interface Template {
  id: number;
  nome: string;
  categoria: string;
  duracao_minutos: number;
}

interface Props {
  onSalvar: (dados: any) => void;
  onCancelar: () => void;
}

const FormularioAgendamentoUnico: React.FC<Props> = ({ onSalvar, onCancelar }) => {
  // Estados principais
  const [dadosGerais, setDadosGerais] = useState<DadosGerais>({
    simulador_id: 0,
    instrutor_id: 0,
    data_inicio: '',
    hora_inicio: '08:00',
    hora_fim: '10:00',
    observacoes: ''
  });

  const [participantes, setParticipantes] = useState<Participante[]>([]);
  
  // Estados para dropdowns
  const [simuladores, setSimuladores] = useState<Simulador[]>([]);
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  
  // Estados de controle
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    carregarDadosFormulario();
  }, []);

  const carregarDadosFormulario = async () => {
    setLoadingData(true);
    try {
      console.log('📊 Carregando dados para formulário de agendamento...');
      
      const [simuladoresRes, funcionariosRes, templatesRes] = await Promise.all([
        fetch('/api/v2/simuladores/listar'),
        fetch('/api/v2/funcionarios/listar'),
        fetch('/api/v2/simulador/templates/listar')
      ]);

      const [simuladoresData, funcionariosData, templatesData] = await Promise.all([
        simuladoresRes.json(),
        funcionariosRes.json(),
        templatesRes.json()
      ]);

      console.log('✅ Dados carregados:', {
        simuladores: simuladoresData.data?.length || 0,
        funcionarios: funcionariosData.data?.length || 0,
        templates: templatesData.data?.length || 0
      });

      setSimuladores(simuladoresData.data || []);
      setFuncionarios(funcionariosData.data || []);
      setTemplates(templatesData.data || []);
      
    } catch (error) {
      console.error('❌ Erro ao carregar dados:', error);
      alert('Erro ao carregar dados do formulário');
    } finally {
      setLoadingData(false);
    }
  };

  const handleDadosGeraisChange = (field: keyof DadosGerais, value: any) => {
    setDadosGerais(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const adicionarParticipante = () => {
    const novoParticipante: Participante = {
      id: Date.now(),
      tripulante_id: 0,
      tripulante_nome: '',
      tripulante_matricula: '',
      funcao_na_sessao: 'PIC',
      template_id: 0,
      template_nome: ''
    };
    
    setParticipantes(prev => [...prev, novoParticipante]);
  };

  const removerParticipante = (id: number) => {
    setParticipantes(prev => prev.filter(p => p.id !== id));
  };

  const handleParticipanteChange = (id: number, field: keyof Participante, value: any) => {
    setParticipantes(prev => prev.map(p => 
      p.id === id ? { ...p, [field]: value } : p
    ));
    
    // Se mudou o funcionário, atualizar nome e matrícula automaticamente
    if (field === 'tripulante_id') {
      const funcionario = funcionarios.find(f => f.id === parseInt(value));
      if (funcionario) {
        setParticipantes(prev => prev.map(p => 
          p.id === id ? {
            ...p,
            tripulante_nome: funcionario.nome,
            tripulante_matricula: funcionario.matricula
          } : p
        ));
      }
    }
    
    // Se mudou o template, atualizar nome do template
    if (field === 'template_id') {
      const template = templates.find(t => t.id === parseInt(value));
      if (template) {
        setParticipantes(prev => prev.map(p => 
          p.id === id ? {
            ...p,
            template_nome: template.nome
          } : p
        ));
      }
    }
  };

  const validarFormulario = (): string[] => {
    const erros: string[] = [];
    
    if (!dadosGerais.simulador_id) erros.push('Simulador é obrigatório');
    if (!dadosGerais.instrutor_id) erros.push('Instrutor é obrigatório');
    if (!dadosGerais.data_inicio) erros.push('Data de início é obrigatória');
    if (!dadosGerais.hora_inicio) erros.push('Hora de início é obrigatória');
    
    if (participantes.length === 0) {
      erros.push('Adicione pelo menos um participante');
    } else {
      participantes.forEach((p, index) => {
        if (!p.tripulante_id) erros.push(`Participante ${index + 1}: Selecione o funcionário`);
        if (!p.funcao_na_sessao) erros.push(`Participante ${index + 1}: Selecione a função na sessão`);
      });
    }
    
    return erros;
  };

  const handleSalvar = async () => {
    const erros = validarFormulario();
    if (erros.length > 0) {
      alert('Erros encontrados:\n' + erros.join('\n'));
      return;
    }

    setLoading(true);
    try {
      console.log('💾 Enviando dados do agendamento...');
      
      const dadosCompletos = {
        dados_gerais: {
          ...dadosGerais,
          data_fim: dadosGerais.data_fim || dadosGerais.data_inicio
        },
        participantes: participantes.map(p => ({
          colaborador_aluno_id: p.tripulante_id,
          tripulante_id: p.tripulante_id,
          tripulante_nome: p.tripulante_nome,
          tripulante_matricula: p.tripulante_matricula,
          funcao_na_sessao: p.funcao_na_sessao,
          template_id: p.template_id || 1,
          template_nome: p.template_nome || 'Template Padrão'
        }))
      };
      
      console.log('📤 Dados formatados:', dadosCompletos);
      
      await onSalvar(dadosCompletos);
      
    } catch (error) {
      console.error('❌ Erro ao salvar:', error);
      alert('Erro ao salvar agendamento');
    } finally {
      setLoading(false);
    }
  };

  if (loadingData) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando formulário...</p>
        </div>
      </div>
    );
  }

  const instrutores = funcionarios.filter(f => f.is_instrutor);
  const checadores = funcionarios.filter(f => f.is_checador);
  const todosFuncionarios = funcionarios.filter(f => f.is_instrutor || !f.is_checador);

  return (
    <div className="space-y-6 max-h-[80vh] overflow-y-auto">
      {/* Dados Gerais */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Calendar className="w-5 h-5 mr-2" />
          Dados Gerais da Sessão
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Simulador *
            </label>
            <select
              value={dadosGerais.simulador_id}
              onChange={(e) => handleDadosGeraisChange('simulador_id', parseInt(e.target.value))}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value={0}>Selecione um simulador</option>
              {simuladores.map(sim => (
                <option key={sim.id} value={sim.id}>
                  {sim.nome} ({sim.codigo_identificacao})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Instrutor *
            </label>
            <select
              value={dadosGerais.instrutor_id}
              onChange={(e) => handleDadosGeraisChange('instrutor_id', parseInt(e.target.value))}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value={0}>Selecione um instrutor</option>
              {instrutores.map(inst => (
                <option key={inst.id} value={inst.id}>
                  {inst.nome} ({inst.matricula})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Checador (Opcional)
            </label>
            <select
              value={dadosGerais.checador_id || 0}
              onChange={(e) => handleDadosGeraisChange('checador_id', e.target.value ? parseInt(e.target.value) : undefined)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value={0}>Sem checador</option>
              {checadores.map(check => (
                <option key={check.id} value={check.id}>
                  {check.nome} ({check.matricula})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Data da Sessão *
            </label>
            <input
              type="date"
              value={dadosGerais.data_inicio}
              onChange={(e) => handleDadosGeraisChange('data_inicio', e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Hora de Início *
            </label>
            <input
              type="time"
              value={dadosGerais.hora_inicio}
              onChange={(e) => handleDadosGeraisChange('hora_inicio', e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Hora de Término
            </label>
            <input
              type="time"
              value={dadosGerais.hora_fim}
              onChange={(e) => handleDadosGeraisChange('hora_fim', e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Observações
          </label>
          <textarea
            value={dadosGerais.observacoes}
            onChange={(e) => handleDadosGeraisChange('observacoes', e.target.value)}
            rows={3}
            className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Observações sobre a sessão..."
          />
        </div>
      </Card>

      {/* Participantes */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold flex items-center">
            <Users className="w-5 h-5 mr-2" />
            Participantes da Sessão
          </h3>
          <Button onClick={adicionarParticipante} size="sm">
            <Plus className="w-4 h-4 mr-1" />
            Adicionar Participante
          </Button>
        </div>

        {participantes.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Users className="w-12 h-12 mx-auto mb-3 text-gray-400" />
            <p>Nenhum participante adicionado</p>
            <p className="text-sm">Clique em "Adicionar Participante" para começar</p>
          </div>
        ) : (
          <div className="space-y-4">
            {participantes.map((participante, index) => (
              <div key={participante.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">Participante {index + 1}</h4>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => removerParticipante(participante.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Funcionário *
                    </label>
                    <select
                      value={participante.tripulante_id}
                      onChange={(e) => handleParticipanteChange(participante.id, 'tripulante_id', parseInt(e.target.value))}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value={0}>Selecione um funcionário</option>
                      {todosFuncionarios.map(func => (
                        <option key={func.id} value={func.id}>
                          {func.nome} ({func.matricula})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Função na Sessão *
                    </label>
                    <select
                      value={participante.funcao_na_sessao}
                      onChange={(e) => handleParticipanteChange(participante.id, 'funcao_na_sessao', e.target.value)}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Selecione a função</option>
                      <option value="PIC">PIC (Piloto em Comando)</option>
                      <option value="SIC">SIC (Segundo em Comando)</option>
                      <option value="DUAL">DUAL (Instrução Duplo Comando)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Template de Treinamento
                    </label>
                    <select
                      value={participante.template_id || 0}
                      onChange={(e) => handleParticipanteChange(participante.id, 'template_id', parseInt(e.target.value))}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value={0}>Template Padrão</option>
                      {templates.map(template => (
                        <option key={template.id} value={template.id}>
                          {template.nome} ({template.categoria})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {participante.tripulante_nome && (
                  <div className="mt-3 text-sm text-gray-600">
                    <strong>Funcionário selecionado:</strong> {participante.tripulante_nome} 
                    {participante.tripulante_matricula && ` (${participante.tripulante_matricula})`}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Botões de Ação */}
      <div className="flex justify-end space-x-3">
        <Button variant="secondary" onClick={onCancelar} disabled={loading}>
          Cancelar
        </Button>
        <Button onClick={handleSalvar} disabled={loading}>
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Salvando...
            </>
          ) : (
            <>
              <Calendar className="w-4 h-4 mr-2" />
              Agendar Sessão
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default FormularioAgendamentoUnico;
