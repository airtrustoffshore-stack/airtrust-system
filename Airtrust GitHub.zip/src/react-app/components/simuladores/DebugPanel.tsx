/**
 * ⚠️ PADRÃO BRASILEIRO OBRIGATÓRIO - AIRTRUST ⚠️
 * 
 * Painel de Debug Integrado para Módulo Simulador
 * 
 * ✅ Datas: SEMPRE dd/mm/aaaa (nunca mm/dd/yyyy ou yyyy-mm-dd)
 * ✅ Componentes de debug unificados
 * ✅ Testes de endpoints e conformidade brasileira
 */

import React, { useState } from 'react';
import { Settings, Bug, Calendar } from 'lucide-react';
import Card from '../Card';
import Button from '../Button';
import DebugSimulador from '../shared/DebugSimulador';
import DataBrasilTestComponent from '../shared/DataBrasilTestComponent';

export const DebugPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'simulador' | 'brasil'>('simulador');

  return (
    <Card className="p-6">
      <div className="flex items-center gap-3 mb-6">
        <Bug className="h-6 w-6 text-orange-600" />
        <h2 className="text-xl font-semibold text-gray-800">
          🔧 Ferramentas de Debug - Simulador AirTrust
        </h2>
      </div>
      
      <div className="flex gap-2 mb-6 p-1 bg-gray-100 rounded-lg">
        <Button
          variant={activeTab === 'simulador' ? 'primary' : 'ghost'}
          size="sm"
          onClick={() => setActiveTab('simulador')}
          className="flex items-center gap-2"
        >
          <Settings className="h-4 w-4" />
          Debug Simulador
        </Button>
        
        <Button
          variant={activeTab === 'brasil' ? 'primary' : 'ghost'}
          size="sm"
          onClick={() => setActiveTab('brasil')}
          className="flex items-center gap-2"
        >
          <Calendar className="h-4 w-4" />
          Testes Brasil
        </Button>
      </div>
      
      <div className="mt-6">
        {activeTab === 'simulador' && <DebugSimulador />}
        {activeTab === 'brasil' && <DataBrasilTestComponent />}
      </div>
    </Card>
  );
};

export default DebugPanel;
