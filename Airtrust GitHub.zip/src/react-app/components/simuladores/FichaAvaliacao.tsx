import React, { useState, useEffect } from 'react';
import { ClipboardCheck, AlertTriangle, Save, CheckCircle, X } from 'lucide-react';
import Button from '../Button';
import Card from '../Card';

interface FichaAvaliacaoProps {
  fichaUuid: string;
  onSalvar: (avaliacao: any) => void;
  onCancelar: () => void;
  readonly?: boolean;
}

const FichaAvaliacao: React.FC<FichaAvaliacaoProps> = ({
  fichaUuid,
  onSalvar,
  onCancelar,
  readonly = false
}) => {
  const [ficha, setFicha] = useState<any>(null);
  const [manobras, setManobras] = useState<any[]>([]);
  const [observacoesGerais, setObservacoesGerais] = useState('');
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    carregarFicha();
  }, [fichaUuid]);

  const carregarFicha = async () => {
    try {
      const response = await fetch(`/api/v2/simuladores/fichas/${fichaUuid}`);
      const data = await response.json();
      
      if (data.success) {
        setFicha(data.data);
        setManobras(data.data.manobras || []);
        setObservacoesGerais(data.data.observacoes_gerais || '');
      } else {
        console.error('Erro ao carregar ficha:', data.error);
      }
    } catch (error) {
      console.error('Erro ao carregar ficha:', error);
    } finally {
      setLoading(false);
    }
  };

  const atualizarManobra = (manobraId: number, campo: string, valor: any) => {
    setManobras(prev => prev.map(manobra => 
      manobra.manobra_id === manobraId || manobra.id === manobraId
        ? { ...manobra, [campo]: valor }
        : manobra
    ));
  };

  const calcularNotaFinal = () => {
    const manobrasAvaliadas = manobras.filter(m => m.pontuacao !== null && m.pontuacao !== undefined);
    if (manobrasAvaliadas.length === 0) return 0;
    
    const somaNotas = manobrasAvaliadas.reduce((acc, m) => acc + parseFloat(m.pontuacao || 0), 0);
    return Math.round((somaNotas / manobrasAvaliadas.length) * 10) / 10;
  };

  const determinarStatus = () => {
    const notaFinal = calcularNotaFinal();
    const notaMinima = 7.0; // Configurável por template
    
    if (manobras.every(m => m.pontuacao !== null && m.pontuacao !== undefined)) {
      return notaFinal >= notaMinima ? 'APROVADO' : 'REPROVADO';
    }
    return 'EM_ANDAMENTO';
  };

  const handleSalvar = async () => {
    setSalvando(true);
    try {
      const avaliacao = {
        status: determinarStatus(),
        nota_final: calcularNotaFinal(),
        observacoes_gerais: observacoesGerais,
        avaliado_por: 1, // TODO: pegar do contexto do usuário
        manobras: manobras.map(m => ({
          manobra_id: m.manobra_id || m.id,
          pontuacao: m.pontuacao,
          status: m.pontuacao !== null ? 'EXECUTADO' : 'PENDENTE',
          observacoes: m.observacoes || ''
        }))
      };
      
      await onSalvar(avaliacao);
    } catch (error) {
      console.error('Erro ao salvar avaliação:', error);
    } finally {
      setSalvando(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'APROVADO': return 'text-green-600 bg-green-100';
      case 'REPROVADO': return 'text-red-600 bg-red-100';
      case 'EM_ANDAMENTO': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getPontuacaoColor = (pontuacao: number, minima: number) => {
    if (pontuacao >= minima) return 'text-green-600';
    if (pontuacao >= minima * 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  const renderNotaInput = (manobra: any) => {
    if (readonly) {
      return (
        <span className={`font-medium ${manobra.pontuacao !== null ? getPontuacaoColor(manobra.pontuacao, manobra.pontuacao_minima || 5) : 'text-gray-400'}`}>
          {manobra.pontuacao !== null ? manobra.pontuacao.toFixed(1) : 'N/A'}
        </span>
      );
    }

    return (
      <input
        type="number"
        min="0"
        max="10"
        step="0.1"
        value={manobra.pontuacao || ''}
        onChange={(e) => atualizarManobra(manobra.manobra_id || manobra.id, 'pontuacao', parseFloat(e.target.value) || null)}
        className="w-20 px-2 py-1 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        placeholder="0.0"
      />
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-gray-600">Carregando ficha...</div>
      </div>
    );
  }

  if (!ficha) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-red-600">Ficha não encontrada</div>
      </div>
    );
  }

  const notaFinal = calcularNotaFinal();
  const statusFinal = determinarStatus();

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header da Ficha */}
      <Card className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-blue-100 rounded-lg">
              <ClipboardCheck className="w-8 h-8 text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Ficha de Avaliação</h1>
              <p className="text-gray-600">{ficha.ficha_uuid || fichaUuid}</p>
            </div>
          </div>
          
          <div className="text-right">
            <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(statusFinal)}`}>
              {statusFinal === 'APROVADO' && <CheckCircle className="w-4 h-4 mr-1" />}
              {statusFinal === 'REPROVADO' && <X className="w-4 h-4 mr-1" />}
              {statusFinal === 'EM_ANDAMENTO' && <AlertTriangle className="w-4 h-4 mr-1" />}
              {statusFinal}
            </div>
            {notaFinal > 0 && (
              <div className="mt-1 text-lg font-bold text-gray-900">
                Nota: <span className={getPontuacaoColor(notaFinal, 7.0)}>{notaFinal.toFixed(1)}</span>
              </div>
            )}
          </div>
        </div>

        {/* Informações da Sessão */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t">
          <div>
            <label className="text-sm font-medium text-gray-500">Funcionário</label>
            <p className="mt-1 text-sm text-gray-900">{ficha.funcionario_nome}</p>
            <p className="text-xs text-gray-500">{ficha.funcionario_matricula}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-500">Template</label>
            <p className="mt-1 text-sm text-gray-900">{ficha.template_nome}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-500">Simulador</label>
            <p className="mt-1 text-sm text-gray-900">{ficha.simulador_nome}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-500">Instrutor</label>
            <p className="mt-1 text-sm text-gray-900">{ficha.instrutor_nome}</p>
          </div>
        </div>
      </Card>

      {/* Lista de Manobras */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Avaliação por Manobra</h2>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-900">Manobra</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Categoria</th>
                <th className="text-center py-3 px-4 font-medium text-gray-900">Mín.</th>
                <th className="text-center py-3 px-4 font-medium text-gray-900">Nota</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Observações</th>
              </tr>
            </thead>
            <tbody>
              {manobras.map((manobra, index) => (
                <tr key={manobra.id || manobra.manobra_id || index} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div>
                      <p className="font-medium text-gray-900">{manobra.manobra_nome || manobra.nome}</p>
                      <p className="text-sm text-gray-500">{manobra.manobra_codigo || manobra.codigo}</p>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {manobra.manobra_categoria || manobra.categoria}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center text-sm text-gray-600">
                    {manobra.pontuacao_minima || 5}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {renderNotaInput(manobra)}
                  </td>
                  <td className="py-3 px-4">
                    {readonly ? (
                      <span className="text-sm text-gray-600">{manobra.observacoes || '-'}</span>
                    ) : (
                      <input
                        type="text"
                        value={manobra.observacoes || ''}
                        onChange={(e) => atualizarManobra(manobra.manobra_id || manobra.id, 'observacoes', e.target.value)}
                        className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Observações..."
                      />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Observações Gerais */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Observações Gerais</h2>
        {readonly ? (
          <div className="text-gray-700 whitespace-pre-wrap">
            {observacoesGerais || 'Nenhuma observação registrada.'}
          </div>
        ) : (
          <textarea
            value={observacoesGerais}
            onChange={(e) => setObservacoesGerais(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            rows={4}
            placeholder="Observações gerais sobre a sessão e desempenho do aluno..."
          />
        )}
      </Card>

      {/* Botões de Ação */}
      {!readonly && (
        <div className="flex justify-end space-x-3">
          <Button
            variant="secondary"
            onClick={onCancelar}
            disabled={salvando}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSalvar}
            disabled={salvando}
            className="bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
          >
            <Save className="w-4 h-4 mr-2" />
            {salvando ? 'Salvando...' : 'Salvar Avaliação'}
          </Button>
        </div>
      )}
    </div>
  );
};

export default FichaAvaliacao;
