import React from 'react';
import { useNavigate } from 'react-router';

interface FichaSimulador {
  id: number;
  uuid: string;
  status_workflow: string;
  funcao_na_sessao: string;
  conceito_final?: string;
  nota_final?: number;
  created_at: string;
  colaborador: {
    nome: string;
    matricula: string;
  };
  simulador: {
    nome: string;
    codigo?: string;
  };
  instrutor: {
    nome: string;
  };
  sessao_template?: {
    nome: string;
    numero?: string;
  };
}

interface AcoesFichaProps {
  ficha: FichaSimulador;
}

const AcoesFicha: React.FC<AcoesFichaProps> = ({ ficha }) => {
  const navigate = useNavigate();
  
  const handleVisualizar = async (fichaUuid: string) => {
    try {
      console.log(`👁 Visualizando ficha: ${fichaUuid}`);
      
      const response = await fetch(`/api/v2/simulador/ficha/${fichaUuid}`);
      
      if (response.ok) {
        const data = await response.json();
        
        // Navegar para página de visualização
        navigate(`/simulador/ficha/${fichaUuid}/visualizar`, {
          state: { ficha: data.ficha }
        });
      } else {
        const errorData = await response.json();
        alert(`❌ Erro ao carregar ficha: ${errorData.error}`);
      }
    } catch (error) {
      console.error('❌ Erro ao visualizar ficha:', error);
      alert('❌ Erro de conexão ao carregar ficha');
    }
  };
  
  const handleEditar = async (fichaUuid: string) => {
    try {
      console.log(`✏️ Editando ficha: ${fichaUuid}`);
      
      // Verificar se pode editar
      if (!podeEditar(ficha)) {
        alert('❌ Esta ficha não pode ser editada no status atual');
        return;
      }
      
      const response = await fetch(`/api/v2/simulador/ficha/${fichaUuid}`);
      
      if (response.ok) {
        const data = await response.json();
        
        // Navegar para página de edição
        navigate(`/simulador/ficha/${fichaUuid}/editar`, {
          state: { ficha: data.ficha }
        });
      } else {
        const errorData = await response.json();
        alert(`❌ Erro ao carregar ficha: ${errorData.error}`);
      }
    } catch (error) {
      console.error('❌ Erro ao editar ficha:', error);
      alert('❌ Erro de conexão ao carregar ficha');
    }
  };
  
  const handleAvaliar = async (fichaUuid: string) => {
    try {
      console.log(`📝 Avaliando ficha: ${fichaUuid}`);
      
      // Verificar se pode avaliar
      if (!podeAvaliar(ficha)) {
        alert('❌ Esta ficha não pode ser avaliada no status atual');
        return;
      }
      
      const response = await fetch(`/api/v2/simulador/ficha/${fichaUuid}/avaliacao`);
      
      if (response.ok) {
        const data = await response.json();
        
        // Navegar para página de avaliação
        navigate(`/simulador/ficha/${fichaUuid}/avaliar`, {
          state: { avaliacao: data.avaliacao }
        });
      } else {
        const errorData = await response.json();
        alert(`❌ Erro ao carregar avaliação: ${errorData.error}`);
      }
    } catch (error) {
      console.error('❌ Erro ao avaliar ficha:', error);
      alert('❌ Erro de conexão ao carregar avaliação');
    }
  };
  
  const podeEditar = (ficha: FichaSimulador) => {
    const statusEditaveis = ['RASCUNHO', 'PENDENTE_ALUNO'];
    return statusEditaveis.includes(ficha.status_workflow);
  };
  
  const podeAvaliar = (ficha: FichaSimulador) => {
    const statusAvaliaveis = ['PENDENTE_ALUNO', 'PENDENTE_INSTRUTOR_FINAL', 'RASCUNHO'];
    return statusAvaliaveis.includes(ficha.status_workflow);
  };
  
  return (
    <div className="flex gap-2">
      {/* Botão Visualizar - SEMPRE DISPONÍVEL */}
      <button
        onClick={() => handleVisualizar(ficha.uuid)}
        className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors flex items-center gap-1"
        title="Visualizar ficha"
      >
        👁 <span className="hidden sm:inline">Ver</span>
      </button>
      
      {/* Botão Editar - CONDICIONAL */}
      <button
        onClick={() => handleEditar(ficha.uuid)}
        disabled={!podeEditar(ficha)}
        className={`p-2 rounded-lg transition-colors flex items-center gap-1 ${
          podeEditar(ficha)
            ? 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
            : 'text-gray-300 cursor-not-allowed'
        }`}
        title={podeEditar(ficha) ? 'Editar ficha' : 'Não pode ser editada neste status'}
      >
        ✏️ <span className="hidden sm:inline">Editar</span>
      </button>
      
      {/* Botão Avaliar - CONDICIONAL */}
      <button
        onClick={() => handleAvaliar(ficha.uuid)}
        disabled={!podeAvaliar(ficha)}
        className={`p-2 rounded-lg transition-colors flex items-center gap-1 ${
          podeAvaliar(ficha)
            ? 'text-gray-600 hover:text-green-600 hover:bg-green-50'
            : 'text-gray-300 cursor-not-allowed'
        }`}
        title={podeAvaliar(ficha) ? 'Avaliar ficha' : 'Não pode ser avaliada neste status'}
      >
        📝 <span className="hidden sm:inline">Avaliar</span>
      </button>
    </div>
  );
};

export default AcoesFicha;
