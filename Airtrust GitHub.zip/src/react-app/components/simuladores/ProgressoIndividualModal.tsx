import React, { useState, useEffect } from 'react';
import { X, User, BookOpen, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import Button from '../Button';

/**
 * ⚠️ PADRÃO BRASILEIRO OBRIGATÓRIO - AIRTRUST ⚠️
 * 
 * Modal para visualizar progresso individual de treinamentos por tripulante
 * 
 * Características obrigatórias:
 * ✅ Datas: SEMPRE dd/mm/aaaa (nunca mm/dd/yyyy ou yyyy-mm-dd)
 * ✅ Progresso visual claro
 * ✅ Status individual por treinamento
 * ✅ Histórico completo de sessões
 */

interface ProgressoTreinamento {
  id: number;
  colaborador_id: number;
  treinamento_id: number;
  treinamento_codigo: string;
  treinamento_nome: string;
  sessoes_concluidas: number;
  total_sessoes_necessarias: number;
  status_treinamento: string;
  percentual_conclusao: number;
  data_inicio: string;
  data_conclusao?: string;
  certificacao_gerada_id?: number;
  colaborador_nome: string;
  colaborador_matricula: string;
}

interface SessaoParticipante {
  id: number;
  sessao_numero: number;
  funcao_na_sessao: string;
  status_individual: string;
  conceito_individual?: string;
  data_conclusao_individual?: string;
  template_nome?: string;
  simulador_nome?: string;
  data_inicio: string;
  sessao_uuid: string;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  colaboradorId: number;
  colaboradorNome?: string;
}

const ProgressoIndividualModal: React.FC<Props> = ({
  isOpen,
  onClose,
  colaboradorId,
  colaboradorNome
}) => {
  const [progressos, setProgressos] = useState<ProgressoTreinamento[]>([]);
  const [sessoes, setSessoes] = useState<Record<number, SessaoParticipante[]>>({});
  const [loading, setLoading] = useState(false);
  const [expandedTreinamento, setExpandedTreinamento] = useState<number | null>(null);

  useEffect(() => {
    if (isOpen && colaboradorId) {
      loadProgressoIndividual();
    }
  }, [isOpen, colaboradorId]);

  const loadProgressoIndividual = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/v2/simulador/progresso-individual/${colaboradorId}`);
      const data = await response.json();

      if (data.success) {
        setProgressos(data.data || []);
        
        // Carregar sessões para cada treinamento
        for (const progresso of data.data || []) {
          await loadSessoesParticipante(progresso.treinamento_id);
        }
      } else {
        console.error('Erro ao carregar progresso:', data.error);
      }
    } catch (error) {
      console.error('Erro ao carregar progresso individual:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadSessoesParticipante = async (treinamentoId: number) => {
    try {
      const response = await fetch(`/api/v2/simulador/sessoes-participante/${colaboradorId}/${treinamentoId}`);
      const data = await response.json();

      if (data.success) {
        setSessoes(prev => ({
          ...prev,
          [treinamentoId]: data.data || []
        }));
      }
    } catch (error) {
      console.error('Erro ao carregar sessões do participante:', error);
    }
  };

  const formatarDataBrasil = (dataISO: string): string => {
    try {
      const data = new Date(dataISO);
      return data.toLocaleDateString('pt-BR');
    } catch {
      return dataISO;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'CONCLUIDO': return 'text-green-600 bg-green-100';
      case 'EM_ANDAMENTO': return 'text-blue-600 bg-blue-100';
      case 'REPROVADO': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIndividualColor = (status: string) => {
    switch (status) {
      case 'APROVADO': return 'text-green-600 bg-green-100';
      case 'REPROVADO': return 'text-red-600 bg-red-100';
      case 'PENDENTE': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'CONCLUIDO': return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'EM_ANDAMENTO': return <Clock className="w-5 h-5 text-blue-600" />;
      case 'REPROVADO': return <AlertCircle className="w-5 h-5 text-red-600" />;
      default: return <Clock className="w-5 h-5 text-gray-600" />;
    }
  };

  const toggleExpandTreinamento = (treinamentoId: number) => {
    setExpandedTreinamento(expandedTreinamento === treinamentoId ? null : treinamentoId);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex items-center space-x-3">
            <User className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-bold text-gray-900">
                Progresso Individual de Treinamentos
              </h2>
              <p className="text-sm text-gray-600">
                {colaboradorNome && `${colaboradorNome} - `}ID: {colaboradorId}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Carregando progresso individual...</p>
            </div>
          ) : progressos.length === 0 ? (
            <div className="text-center py-8">
              <BookOpen className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-600">Nenhum treinamento individual encontrado</p>
            </div>
          ) : (
            <div className="space-y-4">
              {progressos.map(progresso => (
                <div key={progresso.id} className="border rounded-lg p-4 bg-gray-50">
                  {/* Header do Treinamento */}
                  <div 
                    className="flex items-center justify-between cursor-pointer"
                    onClick={() => toggleExpandTreinamento(progresso.treinamento_id)}
                  >
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(progresso.status_treinamento)}
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {progresso.treinamento_codigo} - {progresso.treinamento_nome}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {progresso.sessoes_concluidas} de {progresso.total_sessoes_necessarias} sessões concluídas
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(progresso.status_treinamento)}`}>
                        {progresso.status_treinamento}
                      </span>
                      <div className="text-xs text-gray-500 mt-1">
                        {progresso.percentual_conclusao}% concluído
                      </div>
                    </div>
                  </div>

                  {/* Barra de Progresso */}
                  <div className="mt-3">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progresso.percentual_conclusao}%` }}
                      />
                    </div>
                  </div>

                  {/* Detalhes expandidos */}
                  {expandedTreinamento === progresso.treinamento_id && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="text-sm">
                          <span className="font-medium text-gray-700">Data de Início:</span>
                          <span className="ml-2 text-gray-600">{formatarDataBrasil(progresso.data_inicio)}</span>
                        </div>
                        {progresso.data_conclusao && (
                          <div className="text-sm">
                            <span className="font-medium text-gray-700">Data de Conclusão:</span>
                            <span className="ml-2 text-gray-600">{formatarDataBrasil(progresso.data_conclusao)}</span>
                          </div>
                        )}
                      </div>

                      {/* Sessões do Treinamento */}
                      {sessoes[progresso.treinamento_id] && (
                        <div>
                          <h4 className="font-medium text-gray-900 mb-3">📋 Histórico de Sessões:</h4>
                          <div className="space-y-2">
                            {sessoes[progresso.treinamento_id].map(sessao => (
                              <div key={sessao.id} className="bg-white border rounded p-3">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <div className="font-medium text-sm">
                                      Sessão {sessao.sessao_numero} - {sessao.funcao_na_sessao}
                                    </div>
                                    <div className="text-xs text-gray-600">
                                      {sessao.template_nome} | {sessao.simulador_nome}
                                    </div>
                                    <div className="text-xs text-gray-500">
                                      {formatarDataBrasil(sessao.data_inicio)} | {sessao.sessao_uuid}
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusIndividualColor(sessao.status_individual)}`}>
                                      {sessao.status_individual}
                                    </span>
                                    {sessao.conceito_individual && (
                                      <div className="text-xs text-gray-500 mt-1">
                                        {sessao.conceito_individual}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end p-6 border-t bg-gray-50">
          <Button variant="secondary" onClick={onClose}>
            Fechar
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProgressoIndividualModal;
