import React, { useState, useEffect } from 'react';

interface DadosTemplate {
  treinamento_id: string;
  numero_sessao: string;
  nome_sessao: string;
  descricao: string;
  duracao_estimada: number;
  nivel_dificuldade: string;
  manobras_selecionadas: any[];
}

interface Treinamento {
  id: number;
  codigo: string;
  nome: string;
  tipo_treinamento: string;
  total_sessoes_necessarias: number;
  validade_meses: number;
}

interface Manobra {
  id: number;
  codigo: string;
  nome: string;
}

interface Props {
  onClose: () => void;
  onSuccess?: (template: any) => void;
}

const FormularioCriarTemplate: React.FC<Props> = ({ onClose, onSuccess }) => {
  const [dadosTemplate, setDadosTemplate] = useState<DadosTemplate>({
    treinamento_id: '',
    numero_sessao: '',
    nome_sessao: '',
    descricao: '',
    duracao_estimada: 2.0,
    nivel_dificuldade: 'BASICO',
    manobras_selecionadas: []
  });
  
  const [treinamentos, setTreinamentos] = useState<Treinamento[]>([]);
  const [, setManobrasDisponiveis] = useState<Manobra[]>([]);
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);
  
  // Carregar treinamentos e manobras
  useEffect(() => {
    carregarDadosFormulario();
  }, []);
  
  const carregarDadosFormulario = async () => {
    try {
      const [treinamentosResponse, manobrasResponse] = await Promise.all([
        fetch('/api/v2/treinamentos/listar'),
        fetch('/api/v2/simulador/manobras')
      ]);
      
      const treinamentosData = treinamentosResponse.ok ? await treinamentosResponse.json() : { treinamentos: [] };
      const manobrasData = manobrasResponse.ok ? await manobrasResponse.json() : { manobras: [] };
      
      setTreinamentos(treinamentosData.treinamentos || []);
      setManobrasDisponiveis(manobrasData.manobras || []);
      
      console.log(`📚 Carregados ${treinamentosData.treinamentos?.length || 0} treinamentos`);
      console.log(`🎯 Carregadas ${manobrasData.manobras?.length || 0} manobras`);
      
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleInputChange = (campo: keyof DadosTemplate, valor: any) => {
    setDadosTemplate(prev => ({
      ...prev,
      [campo]: valor
    }));
  };
  
  const handleSalvar = async () => {
    if (!dadosTemplate.treinamento_id || !dadosTemplate.numero_sessao || !dadosTemplate.nome_sessao) {
      alert('❌ Preencha os campos obrigatórios: Treinamento, Número da Sessão e Nome da Sessão');
      return;
    }
    
    setSalvando(true);
    
    try {
      const payload = {
        treinamento_id: parseInt(dadosTemplate.treinamento_id),
        numero_sessao: parseInt(dadosTemplate.numero_sessao),
        nome: dadosTemplate.nome_sessao,
        descricao: dadosTemplate.descricao,
        duracao_estimada: parseFloat(dadosTemplate.duracao_estimada.toString()),
        nivel_dificuldade: dadosTemplate.nivel_dificuldade,
        manobras: dadosTemplate.manobras_selecionadas.map((m: any) => ({
          manobra_id: m.id,
          ordem_execucao: m.ordem || 1,
          obrigatoria: m.obrigatoria || true
        }))
      };
      
      console.log('📤 Salvando template:', payload);
      
      const response = await fetch('/api/v2/simulador/templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      if (response.ok) {
        const data = await response.json();
        alert(`✅ Template criado com sucesso!\nID: ${data.template.id}`);
        onSuccess && onSuccess(data.template);
        onClose();
      } else {
        const error = await response.json();
        alert(`❌ Erro: ${error.error}`);
      }
    } catch (error) {
      console.error('❌ Erro ao salvar template:', error);
      alert('❌ Erro de conexão');
    } finally {
      setSalvando(false);
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-900">📋 Criar Sessão Template</h2>
          <button 
            onClick={onClose} 
            className="text-gray-500 hover:text-gray-700 text-2xl"
            disabled={salvando}
          >
            ❌
          </button>
        </div>
        
        <div className="p-6">
          <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
            {/* Dropdown de Treinamentos - CORREÇÃO PRINCIPAL */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                🎯 Treinamento *
              </label>
              <select
                value={dadosTemplate.treinamento_id}
                onChange={(e) => handleInputChange('treinamento_id', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
                disabled={loading || salvando}
              >
                <option value="">
                  {loading ? 'Carregando treinamentos...' : 'Selecione o treinamento...'}
                </option>
                {treinamentos.map(treinamento => (
                  <option key={treinamento.id} value={treinamento.id}>
                    {treinamento.codigo} - {treinamento.nome} ({treinamento.tipo_treinamento})
                  </option>
                ))}
              </select>
              
              {treinamentos.length === 0 && !loading && (
                <p className="text-sm text-red-600 mt-1">
                  ⚠️ Nenhum treinamento disponível. Cadastre treinamentos primeiro.
                </p>
              )}
            </div>
            
            {/* Número da Sessão */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                📊 Número da Sessão *
              </label>
              <input
                type="number"
                value={dadosTemplate.numero_sessao}
                onChange={(e) => handleInputChange('numero_sessao', e.target.value)}
                placeholder="Número sequencial da sessão"
                min="1"
                max="50"
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
                disabled={salvando}
              />
            </div>
            
            {/* Nome da Sessão */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                📝 Nome da Sessão *
              </label>
              <input
                type="text"
                value={dadosTemplate.nome_sessao}
                onChange={(e) => handleInputChange('nome_sessao', e.target.value)}
                placeholder="Nome descritivo da sessão"
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
                disabled={salvando}
              />
            </div>
            
            {/* Descrição */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                📄 Descrição
              </label>
              <textarea
                value={dadosTemplate.descricao}
                onChange={(e) => handleInputChange('descricao', e.target.value)}
                placeholder="Descrição detalhada da sessão"
                rows={3}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                disabled={salvando}
              />
            </div>
            
            {/* Configurações Adicionais */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  ⏱️ Duração Estimada (horas)
                </label>
                <input
                  type="number"
                  value={dadosTemplate.duracao_estimada}
                  onChange={(e) => handleInputChange('duracao_estimada', parseFloat(e.target.value))}
                  step="0.5"
                  min="0.5"
                  max="8"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  disabled={salvando}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  📈 Nível de Dificuldade
                </label>
                <select
                  value={dadosTemplate.nivel_dificuldade}
                  onChange={(e) => handleInputChange('nivel_dificuldade', e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  disabled={salvando}
                >
                  <option value="BASICO">🟢 Básico</option>
                  <option value="INTERMEDIARIO">🟡 Intermediário</option>
                  <option value="AVANCADO">🔴 Avançado</option>
                </select>
              </div>
            </div>
            
            {/* Informações do Treinamento Selecionado */}
            {dadosTemplate.treinamento_id && (
              <div className="bg-blue-50 rounded-lg p-4">
                {(() => {
                  const treinamento = treinamentos.find(t => t.id.toString() === dadosTemplate.treinamento_id);
                  return treinamento ? (
                    <div className="text-sm text-blue-800">
                      <h3 className="font-semibold mb-2">📚 Informações do Treinamento Selecionado:</h3>
                      <p><strong>Nome:</strong> {treinamento.nome}</p>
                      <p><strong>Tipo:</strong> {treinamento.tipo_treinamento}</p>
                      <p><strong>Total de Sessões:</strong> {treinamento.total_sessoes_necessarias}</p>
                      <p><strong>Validade:</strong> {treinamento.validade_meses} meses</p>
                    </div>
                  ) : null;
                })()}
              </div>
            )}
          </form>
        </div>
        
        <div className="flex justify-end gap-4 p-6 border-t">
          <button
            type="button"
            onClick={onClose}
            className="bg-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-400 font-medium"
            disabled={salvando}
          >
            Cancelar
          </button>
          
          <button
            type="button"
            onClick={handleSalvar}
            disabled={salvando || loading}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 font-medium disabled:bg-blue-400 flex items-center gap-2"
          >
            {salvando ? '⏳ Salvando...' : '💾 Criar Template'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default FormularioCriarTemplate;
