import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { InputDataBrasil, useDateBrasil } from '../common/InputDataBrasil';

interface DadosAgendamento {
  data_inicio: string;
  hora_inicio: string;
  data_fim: string;
  hora_fim: string;
  simulador_id: string;
  instrutor_id: string;
  observacoes: string;
  eh_sessao_check: boolean;
  tipo_checador: string;
  checador_interno_id: string;
  checador_anac_nome: string;
  checador_anac_credencial: string;
}

interface Participante {
  id: number;
  colaborador_id: string;
  treinamento_id: string;
  template_sessao_id: string;
  funcao_na_sessao: 'PIC' | 'SIC' | 'DUAL';
  sessao_numero: number;
}

interface DropdownData {
  simuladores: any[];
  instrutores: any[];
  tripulantes: any[];
  checadores: any[];
  treinamentos: any[];
  templatesPorTreinamento: { [key: string]: any[] };
}

const FormularioAgendamentoAvancado: React.FC = () => {
  const navigate = useNavigate();
  
  // 🇧🇷 Hooks para datas brasileiras
  const dataInicio = useDateBrasil();
  const dataFim = useDateBrasil();
  
  const [dadosAgendamento, setDadosAgendamento] = useState<DadosAgendamento>({
    data_inicio: '',
    hora_inicio: '',
    data_fim: '',
    hora_fim: '',
    simulador_id: '',
    instrutor_id: '',
    observacoes: '',
    eh_sessao_check: false,
    tipo_checador: '',
    checador_interno_id: '',
    checador_anac_nome: '',
    checador_anac_credencial: ''
  });
  
  // ✅ SEMPRE 2 PARTICIPANTES FIXOS - NÃO ALTERAR
  const [participantes, setParticipantes] = useState<Participante[]>([
    {
      id: 1,
      colaborador_id: '',
      treinamento_id: '',
      template_sessao_id: '',
      funcao_na_sessao: 'PIC',
      sessao_numero: 1
    },
    {
      id: 2,
      colaborador_id: '',
      treinamento_id: '',
      template_sessao_id: '',
      funcao_na_sessao: 'SIC',
      sessao_numero: 1
    }
  ]);
  
  const [dropdownData, setDropdownData] = useState<DropdownData>({
    simuladores: [],
    instrutores: [],
    tripulantes: [],
    checadores: [],
    treinamentos: [],
    templatesPorTreinamento: {}
  });
  
  const [loading, setLoading] = useState({
    simuladores: true,
    funcionarios: true,
    treinamentos: true
  });
  
  const [autoCalculado, setAutoCalculado] = useState(false);
  const [salvando, setSalvando] = useState(false);
  
  // Carregar dados iniciais
  useEffect(() => {
    carregarTodosDados();
  }, []);
  
  // Auto-calcular hora fim
  useEffect(() => {
    if (dataInicio.dataBrasil && dadosAgendamento.hora_inicio) {
      const dataFimCalculada = dataInicio.dataBrasil;
      const [hora, minuto] = dadosAgendamento.hora_inicio.split(':');
      const novaHora = (parseInt(hora) + 2) % 24;
      const horaFimCalculada = `${novaHora.toString().padStart(2, '0')}:${minuto}`;
      
      dataFim.setDataBrasil(dataFimCalculada);
      setDadosAgendamento(prev => ({
        ...prev,
        data_inicio: dataInicio.dataBrasil,
        data_fim: dataFimCalculada,
        hora_fim: horaFimCalculada
      }));
      setAutoCalculado(true);
    }
  }, [dataInicio.dataBrasil, dadosAgendamento.hora_inicio]);
  
  const carregarTodosDados = async () => {
    try {
      console.log('🔄 Carregando todos os dados do formulário...');
      
      const [simResponse, funcResponse, treinamentosResponse] = await Promise.all([
        fetch('/api/v2/simuladores'),
        fetch('/api/v2/funcionarios'),
        fetch('/api/v2/treinamentos/listar')
      ]);
      
      const simData = simResponse.ok ? await simResponse.json() : { data: [] };
      const funcData = funcResponse.ok ? await funcResponse.json() : { data: [] };
      const treinamentosData = treinamentosResponse.ok ? await treinamentosResponse.json() : { treinamentos: [] };
      
      const funcionarios = funcData.data || [];
      
      console.log('📊 Dados carregados:', {
        simuladores: simData.data?.length || 0,
        instrutores: funcionarios.filter((f: any) => f.is_instrutor === 1).length,
        tripulantes: funcionarios.length,
        checadores: funcionarios.filter((f: any) => f.is_checador === 1).length,
        treinamentos: treinamentosData.treinamentos?.length || 0
      });
      
      setDropdownData({
        simuladores: simData.data || [],
        instrutores: funcionarios.filter((f: any) => f.is_instrutor === 1),
        tripulantes: funcionarios,
        checadores: funcionarios.filter((f: any) => f.is_checador === 1),
        treinamentos: treinamentosData.treinamentos || [],
        templatesPorTreinamento: {}
      });
      
      setLoading({
        simuladores: false,
        funcionarios: false,
        treinamentos: false
      });
      
    } catch (error) {
      console.error('❌ Erro ao carregar dados gerais:', error);
      setLoading({
        simuladores: false,
        funcionarios: false,
        treinamentos: false
      });
    }
  };
  
  // Carregar templates quando treinamento for selecionado
  const carregarTemplatesDoTreinamento = async (treinamentoId: string) => {
    if (!treinamentoId) {
      console.log('❌ Treinamento ID inválido:', treinamentoId);
      return;
    }
    
    try {
      console.log(`📋 Carregando templates para treinamento ${treinamentoId}...`);
      
      const response = await fetch(`/api/v2/simulador/templates/treinamento/${treinamentoId}`);
      
      if (response.ok) {
        const data = await response.json();
        
        console.log(`✅ Templates recebidos para treinamento ${treinamentoId}:`, data.templates);
        
        // Armazenar no cache
        setDropdownData(prev => ({
          ...prev,
          templatesPorTreinamento: {
            ...prev.templatesPorTreinamento,
            [treinamentoId]: data.templates || []
          }
        }));
        
      } else {
        console.error(`❌ Erro HTTP ${response.status} ao carregar templates`);
        const errorData = await response.json();
        console.error('Detalhes do erro:', errorData);
        
        setDropdownData(prev => ({
          ...prev,
          templatesPorTreinamento: {
            ...prev.templatesPorTreinamento,
            [treinamentoId]: []
          }
        }));
      }
    } catch (error) {
      console.error(`❌ Erro de conexão ao carregar templates:`, error);
      setDropdownData(prev => ({
        ...prev,
        templatesPorTreinamento: {
          ...prev.templatesPorTreinamento,
          [treinamentoId]: []
        }
      }));
    }
  };
  
  const handleAgendamentoChange = (campo: keyof DadosAgendamento, valor: string | boolean) => {
    setDadosAgendamento(prev => ({
      ...prev,
      [campo]: valor
    }));
    
    if (campo === 'data_fim' || campo === 'hora_fim') {
      setAutoCalculado(false);
    }
  };
  
  // Função para alterar dados do participante
  const handleParticipanteChange = (participanteId: number, campo: keyof Participante, valor: any) => {
    console.log(`🔄 Alterando participante ${participanteId}: ${campo} = ${valor}`);
    
    setParticipantes(prev =>
      prev.map(p => {
        if (p.id === participanteId) {
          const updated = { ...p, [campo]: valor };
          
          // Se mudou o treinamento, limpar template e carregar novos templates
          if (campo === 'treinamento_id') {
            console.log(`🎯 Treinamento alterado para: ${valor}`);
            updated.template_sessao_id = ''; // Limpar template selecionado
            
            // Carregar templates do novo treinamento
            if (valor) {
              setTimeout(() => {
                carregarTemplatesDoTreinamento(valor);
              }, 100);
            }
          }
          
          return updated;
        }
        return p;
      })
    );
  };
  
  // Obter templates disponíveis para um participante
  const obterTemplatesDisponiveis = (participante: Participante) => {
    if (!participante.treinamento_id) {
      return [];
    }
    
    const templates = dropdownData.templatesPorTreinamento[participante.treinamento_id] || [];
    console.log(`📋 Templates disponíveis para treinamento ${participante.treinamento_id}:`, templates.length);
    
    return templates;
  };
  
  const validarFormulario = () => {
    // Validar dados gerais
    if (!dadosAgendamento.simulador_id) {
      alert('❌ Selecione um simulador');
      return false;
    }
    
    if (!dadosAgendamento.instrutor_id) {
      alert('❌ Selecione um instrutor');
      return false;
    }
    
    // Validar sistema de check
    if (dadosAgendamento.eh_sessao_check) {
      if (!dadosAgendamento.tipo_checador) {
        alert('❌ Selecione o tipo de checador para sessão de check');
        return false;
      }
      
      if (dadosAgendamento.tipo_checador === 'INTERNO' && !dadosAgendamento.checador_interno_id) {
        alert('❌ Selecione o checador interno');
        return false;
      }
      
      if (dadosAgendamento.tipo_checador === 'ANAC') {
        if (!dadosAgendamento.checador_anac_nome || !dadosAgendamento.checador_anac_credencial) {
          alert('❌ Preencha nome e credencial do checador ANAC');
          return false;
        }
      }
    }
    
    // Validar cada participante
    for (const participante of participantes) {
      if (!participante.colaborador_id) {
        alert(`❌ Selecione um tripulante para o Participante ${participante.id}`);
        return false;
      }
      
      if (!participante.treinamento_id) {
        alert(`❌ Selecione um treinamento para o Participante ${participante.id}`);
        return false;
      }
      
      if (!participante.template_sessao_id) {
        alert(`❌ Selecione um template para o Participante ${participante.id}`);
        return false;
      }
    }
    
    return true;
  };
  
  const handleSalvar = async () => {
    if (!validarFormulario()) {
      return;
    }
    
    setSalvando(true);
    
    try {
      const payload = {
        dados_gerais: {
          ...dadosAgendamento,
          data_inicio: dataInicio.dataBrasil,
          data_fim: dataFim.dataBrasil
        },
        participantes: participantes,
        eh_check: dadosAgendamento.eh_sessao_check
      };
      
      console.log('📤 Enviando agendamento:', payload);
      
      const response = await fetch('/api/v2/simulador/agendamento', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      if (response.ok) {
        const data = await response.json();
        alert(`✅ Sessão agendada com sucesso!\nUUID: ${data.agendamento?.ficha_uuid || data.slot_id}`);
        navigate('/simuladores');
      } else {
        const error = await response.json();
        alert(`❌ Erro ao agendar: ${error.error}`);
      }
    } catch (error) {
      console.error('❌ Erro ao salvar agendamento:', error);
      alert('❌ Erro de conexão ao salvar agendamento');
    } finally {
      setSalvando(false);
    }
  };
  
  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            📅 Agendar Sessão de Simulador
          </h1>
          <p className="text-gray-600">
            Agende uma nova sessão com 2 participantes e controle individual por treinamento
          </p>
        </div>
        
        {/* Dados Gerais da Sessão */}
        <section className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 mb-4 border-b-2 border-blue-500 pb-2">
            📍 Dados Gerais da Sessão
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div>
              <InputDataBrasil
                label="📅 Data de Início"
                value={dataInicio.dataBrasil}
                onChange={dataInicio.setDataBrasil}
                required
                minDate={dataInicio.hoje}
                placeholder="dd/mm/aaaa"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                🕒 Hora de Início *
              </label>
              <input
                type="time"
                value={dadosAgendamento.hora_inicio}
                onChange={(e) => handleAgendamentoChange('hora_inicio', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            
            <div>
              <InputDataBrasil
                label={`📅 Data de Fim${autoCalculado ? ' (🤖 Auto)' : ''}`}
                value={dataFim.dataBrasil}
                onChange={(valor) => {
                  dataFim.setDataBrasil(valor);
                  setDadosAgendamento(prev => ({ ...prev, data_fim: valor }));
                  setAutoCalculado(false);
                }}
                required
                minDate={dataInicio.dataBrasil || dataInicio.hoje}
                placeholder="dd/mm/aaaa"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                🕒 Hora de Fim * {autoCalculado && <span className="text-green-600 text-xs">(+2h)</span>}
              </label>
              <input
                type="time"
                value={dadosAgendamento.hora_fim}
                onChange={(e) => handleAgendamentoChange('hora_fim', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                🎮 Simulador * {loading.simuladores && '🔄'}
              </label>
              <select
                value={dadosAgendamento.simulador_id}
                onChange={(e) => handleAgendamentoChange('simulador_id', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
                disabled={loading.simuladores}
              >
                <option value="">
                  {loading.simuladores ? 'Carregando...' : 'Selecione o simulador...'}
                </option>
                {dropdownData.simuladores.map(sim => (
                  <option key={sim.id} value={sim.id}>
                    {sim.nome} ({sim.codigo_identificacao})
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                👨‍🏫 Instrutor * {loading.funcionarios && '🔄'}
              </label>
              <select
                value={dadosAgendamento.instrutor_id}
                onChange={(e) => handleAgendamentoChange('instrutor_id', e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
                disabled={loading.funcionarios}
              >
                <option value="">
                  {loading.funcionarios ? 'Carregando...' : 'Selecione o instrutor...'}
                </option>
                {dropdownData.instrutores.map(inst => (
                  <option key={inst.id} value={inst.id}>
                    {inst.nome} ({inst.matricula})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </section>
        
        {/* Sistema de Check */}
        <section className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 mb-4 border-b-2 border-purple-500 pb-2">
            ✅ Sistema de Check
          </h2>
          
          <div className="bg-purple-50 p-4 rounded-lg">
            <div className="flex items-center mb-4">
              <input
                type="checkbox"
                id="eh_sessao_check"
                checked={dadosAgendamento.eh_sessao_check}
                onChange={(e) => handleAgendamentoChange('eh_sessao_check', e.target.checked)}
                className="mr-3 h-4 w-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
              />
              <label htmlFor="eh_sessao_check" className="text-lg font-medium text-gray-900">
                🏅 Esta é uma sessão de Check (Avaliação de Proficiência)
              </label>
            </div>
            
            {dadosAgendamento.eh_sessao_check && (
              <div className="ml-7 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    👤 Tipo de Checador *
                  </label>
                  <select
                    value={dadosAgendamento.tipo_checador}
                    onChange={(e) => handleAgendamentoChange('tipo_checador', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                    required
                  >
                    <option value="">Selecione o tipo de checador...</option>
                    <option value="INTERNO">🏢 Checador Interno da Empresa</option>
                    <option value="ANAC">🛫 Checador da ANAC</option>
                  </select>
                </div>
                
                {dadosAgendamento.tipo_checador === 'INTERNO' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      👨‍✈️ Checador Interno *
                    </label>
                    <select
                      value={dadosAgendamento.checador_interno_id}
                      onChange={(e) => handleAgendamentoChange('checador_interno_id', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                      required
                    >
                      <option value="">Selecione o checador...</option>
                      {dropdownData.checadores.map(check => (
                        <option key={check.id} value={check.id}>
                          {check.nome} ({check.matricula}) - {check.funcao}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
                
                {dadosAgendamento.tipo_checador === 'ANAC' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        🛫 Nome do Checador ANAC *
                      </label>
                      <input
                        type="text"
                        value={dadosAgendamento.checador_anac_nome}
                        onChange={(e) => handleAgendamentoChange('checador_anac_nome', e.target.value)}
                        placeholder="Nome completo do checador"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        🆔 Credencial/CHT ANAC *
                      </label>
                      <input
                        type="text"
                        value={dadosAgendamento.checador_anac_credencial}
                        onChange={(e) => handleAgendamentoChange('checador_anac_credencial', e.target.value)}
                        placeholder="Número da credencial"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                        required
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
        
        {/* PARTICIPANTES - SEMPRE 2 FIXOS */}
        <section className="mb-8">
          <h2 className="text-xl font-bold text-gray-800 mb-4 border-b-2 border-green-500 pb-2">
            👥 Participantes da Sessão (Sempre 2 Participantes)
          </h2>
          
          {/* NÃO TEM BOTÃO ADICIONAR PARTICIPANTE */}
          
          {participantes.map((participante, index) => (
            <div key={participante.id} className="bg-gray-50 rounded-lg p-6 mb-4 border-l-4 border-blue-500">
              <div className="mb-4">
                <h3 className="text-lg font-semibold text-gray-800">
                  🧑‍✈️ Participante {index + 1} - {participante.funcao_na_sessao}
                </h3>
              </div>
              
              {/* LAYOUT CORRETO: 4 CAMPOS EM LINHA */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                
                {/* 1º CAMPO: Tripulante */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    👨‍✈️ Tripulante *
                  </label>
                  <select
                    value={participante.colaborador_id}
                    onChange={(e) => handleParticipanteChange(participante.id, 'colaborador_id', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                    disabled={salvando}
                  >
                    <option value="">Selecione o tripulante...</option>
                    {dropdownData.tripulantes.map(trip => (
                      <option key={trip.id} value={trip.id}>
                        {trip.nome} ({trip.matricula})
                      </option>
                    ))}
                  </select>
                </div>
                
                {/* 2º CAMPO: TREINAMENTO - OBRIGATÓRIO QUE ESTAVA FALTANDO */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    🎯 Treinamento que está Fazendo *
                  </label>
                  <select
                    value={participante.treinamento_id || ''}
                    onChange={(e) => handleParticipanteChange(participante.id, 'treinamento_id', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                    disabled={loading.treinamentos || salvando}
                  >
                    <option value="">
                      {loading.treinamentos ? 'Carregando treinamentos...' : 'Selecione o treinamento...'}
                    </option>
                    {dropdownData.treinamentos.map(treinamento => (
                      <option key={treinamento.id} value={treinamento.id}>
                        {treinamento.codigo} - {treinamento.nome}
                      </option>
                    ))}
                  </select>
                  
                  {dropdownData.treinamentos.length === 0 && !loading.treinamentos && (
                    <p className="text-sm text-red-600 mt-1">
                      ⚠️ Nenhum treinamento disponível. Cadastre treinamentos primeiro.
                    </p>
                  )}
                </div>
                
                {/* 3º CAMPO: Template desta Sessão - DEPENDENTE DO TREINAMENTO */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    📋 Template desta Sessão *
                    {participante.treinamento_id && obterTemplatesDisponiveis(participante).length === 0 && ' 🔄'}
                  </label>
                  <select
                    value={participante.template_sessao_id || ''}
                    onChange={(e) => handleParticipanteChange(participante.id, 'template_sessao_id', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                    disabled={!participante.treinamento_id || salvando}
                  >
                    <option value="">
                      {!participante.treinamento_id 
                        ? '⚠️ Primeiro selecione o treinamento acima'
                        : obterTemplatesDisponiveis(participante).length === 0
                        ? 'Carregando templates deste treinamento...'
                        : 'Selecione o template...'
                      }
                    </option>
                    
                    {obterTemplatesDisponiveis(participante).map(template => (
                      <option key={template.id} value={template.id}>
                        Sessão {template.numero_sessao} - {template.nome} 
                        ({template.total_manobras || 0} manobras)
                      </option>
                    ))}
                  </select>
                  
                  {participante.treinamento_id && obterTemplatesDisponiveis(participante).length === 0 && (
                    <div className="text-sm text-orange-600 mt-1">
                      ⚠️ Este treinamento não possui templates cadastrados.
                      <br />
                      <button 
                        type="button"
                        onClick={() => carregarTemplatesDoTreinamento(participante.treinamento_id)}
                        className="text-blue-600 underline"
                      >
                        🔄 Tentar carregar novamente
                      </button>
                    </div>
                  )}
                </div>
                
                {/* 4º CAMPO: Função na Sessão */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    ⚡ Função na Sessão *
                  </label>
                  <select
                    value={participante.funcao_na_sessao}
                    onChange={(e) => handleParticipanteChange(participante.id, 'funcao_na_sessao', e.target.value as 'PIC' | 'SIC' | 'DUAL')}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                    disabled={salvando}
                  >
                    <option value="PIC">PIC - Pilot in Command</option>
                    <option value="SIC">SIC - Second in Command</option>
                    <option value="DUAL">DUAL - Dual Control</option>
                  </select>
                </div>
              </div>
              
              {/* Informações do Treinamento Selecionado */}
              {participante.treinamento_id && (
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  {(() => {
                    const treinamento = dropdownData.treinamentos.find(t => t.id.toString() === participante.treinamento_id);
                    return treinamento ? (
                      <div className="text-sm text-blue-800">
                        📚 <strong>Treinamento:</strong> {treinamento.nome} <br/>
                        🎯 <strong>Tipo:</strong> {treinamento.tipo_treinamento || 'N/A'} <br/>
                        📊 <strong>Total de Sessões:</strong> {treinamento.total_sessoes_necessarias || 'N/A'} <br/>
                        ⏱️ <strong>Validade:</strong> {treinamento.validade_meses || 'N/A'} meses
                      </div>
                    ) : null;
                  })()}
                </div>
              )}
            </div>
          ))}
        </section>
        
        {/* Observações */}
        <section className="mb-8">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              📝 Observações da Sessão
            </label>
            <textarea
              value={dadosAgendamento.observacoes}
              onChange={(e) => handleAgendamentoChange('observacoes', e.target.value)}
              placeholder="Observações gerais sobre a sessão..."
              rows={3}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              disabled={salvando}
            />
          </div>
        </section>
        
        {/* Botões de Ação */}
        <div className="flex gap-4 pt-6 border-t">
          <button
            type="button"
            onClick={() => navigate('/simuladores')}
            className="flex-1 bg-gray-300 text-gray-700 py-3 px-6 rounded-lg hover:bg-gray-400 font-medium"
            disabled={salvando}
          >
            ❌ Cancelar
          </button>
          <button
            type="button"
            onClick={handleSalvar}
            disabled={salvando}
            className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 font-medium disabled:bg-blue-400 flex items-center justify-center gap-2"
          >
            {salvando ? '⏳ Agendando...' : '💾 Agendar Sessão de Simulador'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default FormularioAgendamentoAvancado;
