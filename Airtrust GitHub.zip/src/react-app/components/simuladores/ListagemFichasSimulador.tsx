import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import AcoesFicha from './AcoesFicha';

// ✅ VALIDAÇÃO DEFENSIVA NO FRONTEND
const renderizarColaborador = (colaborador: any) => {
  // ✅ VERIFICAÇÃO ANTES DE ACESSAR PROPRIEDADES
  if (!colaborador) {
    console.warn('⚠️ Colaborador undefined, usando dados padrão');
    return {
      nome: 'Nome não informado',
      matricula: 'N/A'
    };
  }
  
  return {
    nome: colaborador.nome || colaborador.aluno_nome || 'Nome não informado',
    matricula: colaborador.matricula || colaborador.aluno_matricula || 'N/A'
  };
};

interface FichaSimulador {
  id: number;
  uuid: string;
  status_workflow: string;
  funcao_na_sessao: string;
  conceito_final?: string;
  nota_final?: number;
  created_at: string;
  colaborador: {
    nome: string;
    matricula: string;
  };
  simulador: {
    nome: string;
    codigo?: string;
  };
  instrutor: {
    nome: string;
  };
  sessao_template?: {
    nome: string;
    numero?: string;
  };
}

const ListagemFichasSimulador: React.FC = () => {
  const [fichas, setFichas] = useState<FichaSimulador[]>([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    carregarFichas();
  }, []);
  
  const carregarFichas = async () => {
    setLoading(true);
    setErro(null);
    
    try {
      const response = await fetch('/api/v2/simulador/fichas');
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      setFichas(data.fichas || []);
    } catch (error) {
      console.error('Erro ao carregar fichas:', error);
      setErro(`Erro ao carregar fichas: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    } finally {
      setLoading(false);
    }
  };
  
  
  
  
  
  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      'RASCUNHO': 'bg-gray-100 text-gray-800',
      'PENDENTE_ALUNO': 'bg-yellow-100 text-yellow-800',
      'PENDENTE_INSTRUTOR_FINAL': 'bg-blue-100 text-blue-800',
      'PENDENTE_CHECK': 'bg-purple-100 text-purple-800',
      'CONCLUIDA': 'bg-green-100 text-green-800',
      'REPROVADA': 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <span className="ml-3">Carregando fichas...</span>
      </div>
    );
  }
  
  if (erro) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 m-4">
        <div className="flex items-center">
          <div className="text-red-400 text-xl">❌</div>
          <div className="ml-3">
            <h3 className="text-red-800 font-medium">Erro ao carregar dados</h3>
            <p className="text-red-700 text-sm mt-1">{erro}</p>
          </div>
        </div>
        <button 
          onClick={carregarFichas}
          className="mt-3 bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
        >
          🔄 Tentar Novamente
        </button>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900">
          📋 Fichas de Simulador
        </h1>
        <button 
          onClick={() => navigate('/simulador/agendar')}
          className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 flex items-center gap-2"
        >
          ➕ Nova Sessão
        </button>
      </div>
      
      {fichas.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <div className="text-6xl mb-4">📝</div>
          <h3 className="text-xl font-medium text-gray-900 mb-2">
            Nenhuma ficha encontrada
          </h3>
          <p className="text-gray-600 mb-6">
            Crie uma nova sessão para começar a usar o simulador
          </p>
          <button 
            onClick={() => navigate('/simulador/agendar')}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
          >
            🚀 Agendar Primeira Sessão
          </button>
        </div>
      ) : (
        <div className="grid gap-4">
          {fichas.map(ficha => (
            <div key={ficha.id} className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">
                      {ficha.uuid}
                    </h3>
                    <span className={`inline-block px-3 py-1 text-sm font-medium rounded-full ${getStatusColor(ficha.status_workflow)}`}>
                      {ficha.status_workflow}
                    </span>
                  </div>
                  <div className="text-right text-sm text-gray-500">
                    📅 {ficha.created_at}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-blue-600">👨‍✈️</span>
                    <div>
                      <div className="font-medium">{renderizarColaborador(ficha.colaborador || ficha).nome}</div>
                      <div className="text-sm text-gray-500">
                        ({renderizarColaborador(ficha.colaborador || ficha).matricula})
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-green-600">🎮</span>
                    <div>
                      <div className="font-medium">{ficha.simulador?.nome || 'N/A'}</div>
                      <div className="text-sm text-gray-500">Simulador</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-purple-600">👨‍🏫</span>
                    <div>
                      <div className="font-medium">{ficha.instrutor?.nome || 'N/A'}</div>
                      <div className="text-sm text-gray-500">Instrutor</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-orange-600">⚡</span>
                    <div>
                      <div className="font-medium">{ficha.funcao_na_sessao}</div>
                      <div className="text-sm text-gray-500">Função</div>
                    </div>
                  </div>
                </div>
                
                {ficha.conceito_final && (
                  <div className="mb-4">
                    <span className={`inline-block px-3 py-1 text-sm font-bold rounded-full ${
                      ficha.conceito_final === 'APROVADO' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      🎯 {ficha.conceito_final}
                    </span>
                  </div>
                )}
                
                <div className="flex justify-between items-center">
                  <div className="text-sm text-gray-500">
                    {ficha.sessao_template?.nome || 'Template não definido'}
                  </div>
                  <AcoesFicha ficha={ficha} />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ListagemFichasSimulador;
