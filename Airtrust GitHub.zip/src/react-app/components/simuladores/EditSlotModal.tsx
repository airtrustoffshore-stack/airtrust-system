import React, { useState, useEffect } from 'react';
import { Trash2, AlertTriangle } from 'lucide-react';
import Modal from '../Modal';
import Button from '../Button';
import DateInputFixed from '../shared/DateInputFixed';

interface EditSlotModalProps {
  isOpen: boolean;
  onClose: () => void;
  slot: any;
  simuladores: any[];
  funcionarios: any[];
  onSlotUpdated: () => void;
}

const EditSlotModal: React.FC<EditSlotModalProps> = ({
  isOpen,
  onClose,
  slot,
  simuladores,
  funcionarios,
  onSlotUpdated
}) => {
  const [formData, setFormData] = useState({
    simulador_id: '',
    instrutor_id: '',
    checador_id: '',
    data_inicio: '',
    data_fim: '',
    hora_inicio: '',
    hora_fim: '',
    status_slot: 'AGENDADO'
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (slot && isOpen) {
      // Separar data e hora
      let dataInicio = '';
      let horaInicio = '';
      let dataFim = '';
      let horaFim = '';

      if (slot.data_inicio) {
        const dtInicio = new Date(slot.data_inicio);
        dataInicio = dtInicio.toISOString().split('T')[0];
        horaInicio = dtInicio.toTimeString().slice(0, 5);
      }

      if (slot.data_fim) {
        const dtFim = new Date(slot.data_fim);
        dataFim = dtFim.toISOString().split('T')[0];
        horaFim = dtFim.toTimeString().slice(0, 5);
      }

      setFormData({
        simulador_id: slot.simulador_id?.toString() || '',
        instrutor_id: slot.colaborador_id_instrutor?.toString() || '',
        checador_id: slot.colaborador_id_checador?.toString() || '',
        data_inicio: dataInicio,
        data_fim: dataFim,
        hora_inicio: horaInicio,
        hora_fim: horaFim,
        status_slot: slot.status_slot || 'AGENDADO'
      });
      setError('');
    }
  }, [slot, isOpen]);

  const handleSave = async () => {
    setLoading(true);
    setError('');

    try {
      // Validation
      if (!formData.simulador_id || !formData.instrutor_id || !formData.data_inicio || !formData.data_fim || !formData.hora_inicio || !formData.hora_fim) {
        throw new Error('Preencha todos os campos obrigatórios');
      }

      // Combinar data e hora para criar datetime completo
      const dataHoraInicio = new Date(`${formData.data_inicio}T${formData.hora_inicio}:00`);
      const dataHoraFim = new Date(`${formData.data_fim}T${formData.hora_fim}:00`);

      if (dataHoraInicio >= dataHoraFim) {
        throw new Error('Data/hora de início deve ser anterior à data/hora de fim');
      }

      const payload = {
        simulador_id: parseInt(formData.simulador_id),
        instrutor_id: parseInt(formData.instrutor_id),
        checador_id: formData.checador_id ? parseInt(formData.checador_id) : undefined,
        data_inicio: dataHoraInicio.toISOString(),
        data_fim: dataHoraFim.toISOString(),
        status_slot: formData.status_slot
      };

      const response = await fetch(`/api/v2/simulador/agendamento/${slot.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro ao atualizar slot');
      }

      onSlotUpdated();
      onClose();
    } catch (error) {
      console.error('Erro ao salvar:', error);
      setError(error instanceof Error ? error.message : 'Erro ao salvar');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (forceDelete = false) => {
    setLoading(true);
    setError('');

    try {
      const url = `/api/v2/simulador/agendamento/${slot.id}${forceDelete ? '?force=true' : ''}`;
      
      const response = await fetch(url, {
        method: 'DELETE'
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro ao excluir slot');
      }

      onSlotUpdated();
      onClose();
      setShowDeleteConfirm(false);
    } catch (error) {
      console.error('Erro ao excluir:', error);
      setError(error instanceof Error ? error.message : 'Erro ao excluir');
    } finally {
      setLoading(false);
    }
  };

  const canEdit = slot?.status_slot !== 'CONCLUIDO';
  const canDelete = slot?.status_slot !== 'EM_ANDAMENTO' && slot?.status_slot !== 'CONCLUIDO';
  const hasFichas = slot?.fichas?.length > 0;

  if (showDeleteConfirm) {
    return (
      <Modal isOpen={isOpen} onClose={() => setShowDeleteConfirm(false)} title="Confirmar Exclusão">
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="w-6 h-6 text-red-500 mt-1" />
            <div>
              <h3 className="font-medium text-gray-900">Excluir agendamento?</h3>
              <p className="text-gray-600 mt-1">
                Esta ação não pode ser desfeita. {hasFichas && `${slot.fichas.length} ficha(s) será(ão) afetada(s).`}
              </p>
            </div>
          </div>

          {hasFichas && (
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h4 className="font-medium text-yellow-800 mb-2">Opções de exclusão:</h4>
              <div className="space-y-3">
                <Button 
                  variant="secondary" 
                  onClick={() => handleDelete(false)}
                  disabled={loading}
                  className="w-full"
                >
                  Cancelar agendamento (soft delete)
                </Button>
                <Button 
                  variant="danger" 
                  onClick={() => handleDelete(true)}
                  disabled={loading}
                  className="w-full"
                >
                  Excluir permanentemente (hard delete)
                </Button>
              </div>
            </div>
          )}

          {!hasFichas && (
            <Button 
              variant="danger" 
              onClick={() => handleDelete(false)}
              disabled={loading}
              className="w-full"
            >
              {loading ? 'Excluindo...' : 'Confirmar Exclusão'}
            </Button>
          )}

          <Button 
            variant="secondary" 
            onClick={() => setShowDeleteConfirm(false)}
            disabled={loading}
            className="w-full"
          >
            Cancelar
          </Button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Editar Agendamento" className="max-w-2xl">
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-800 text-sm">{error}</p>
        </div>
      )}

      <div className="space-y-6">
        {/* Informações do slot */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-medium text-gray-900 mb-2">Slot #{slot?.id}</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-500">Status atual:</span>
              <span className={`ml-2 px-2 py-1 rounded text-xs ${
                slot?.status_slot === 'AGENDADO' ? 'bg-blue-100 text-blue-800' :
                slot?.status_slot === 'EM_ANDAMENTO' ? 'bg-yellow-100 text-yellow-800' :
                slot?.status_slot === 'CONCLUIDO' ? 'bg-green-100 text-green-800' :
                'bg-red-100 text-red-800'
              }`}>
                {slot?.status_slot}
              </span>
            </div>
            <div>
              <span className="text-gray-500">Fichas associadas:</span>
              <span className="ml-2 font-medium">{slot?.fichas?.length || 0}</span>
            </div>
          </div>
        </div>

        {!canEdit && (
          <div className="bg-yellow-50 p-4 rounded-lg">
            <p className="text-yellow-800 text-sm">
              ⚠️ Este agendamento não pode ser editado pois já foi concluído.
            </p>
          </div>
        )}

        {/* Formulário */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Simulador *
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              value={formData.simulador_id}
              onChange={(e) => setFormData({ ...formData, simulador_id: e.target.value })}
              disabled={!canEdit || loading}
            >
              <option value="">Selecione...</option>
              {simuladores.filter(s => s.status === 'ATIVO').map(sim => (
                <option key={sim.id} value={sim.id}>{sim.nome}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Instrutor *
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              value={formData.instrutor_id}
              onChange={(e) => setFormData({ ...formData, instrutor_id: e.target.value })}
              disabled={!canEdit || loading}
            >
              <option value="">Selecione...</option>
              {funcionarios.filter(f => f.is_instrutor).map(func => (
                <option key={func.id} value={func.id}>{func.nome}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Checador
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              value={formData.checador_id}
              onChange={(e) => setFormData({ ...formData, checador_id: e.target.value })}
              disabled={!canEdit || loading}
            >
              <option value="">Nenhum</option>
              {funcionarios.filter(f => f.is_checador).map(func => (
                <option key={func.id} value={func.id}>{func.nome}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Status
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              value={formData.status_slot}
              onChange={(e) => setFormData({ ...formData, status_slot: e.target.value })}
              disabled={!canEdit || loading}
            >
              <option value="AGENDADO">Agendado</option>
              <option value="EM_ANDAMENTO">Em Andamento</option>
              <option value="CONCLUIDO">Concluído</option>
              <option value="CANCELADO">Cancelado</option>
            </select>
          </div>

          <div>
            <DateInputFixed
              label="Data de Início *"
              value={formData.data_inicio}
              onChange={(value) => setFormData({ ...formData, data_inicio: value })}
              disabled={!canEdit || loading}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Hora de Início *
            </label>
            <input
              type="time"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              value={formData.hora_inicio}
              onChange={(e) => setFormData({ ...formData, hora_inicio: e.target.value })}
              disabled={!canEdit || loading}
            />
          </div>

          <div>
            <DateInputFixed
              label="Data de Fim *"
              value={formData.data_fim}
              onChange={(value) => setFormData({ ...formData, data_fim: value })}
              disabled={!canEdit || loading}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Hora de Fim *
            </label>
            <input
              type="time"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              value={formData.hora_fim}
              onChange={(e) => setFormData({ ...formData, hora_fim: e.target.value })}
              disabled={!canEdit || loading}
            />
          </div>
        </div>

        {/* Fichas associadas */}
        {hasFichas && (
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Fichas Associadas</h4>
            <div className="space-y-2">
              {slot.fichas.map((ficha: any) => (
                <div key={ficha.id} className="bg-gray-50 p-3 rounded">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-medium">{ficha.aluno_nome}</span>
                      <span className="text-gray-500 ml-2">({ficha.funcao_na_sessao})</span>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs ${
                      ficha.status_workflow === 'CONCLUIDA' ? 'bg-green-100 text-green-800' :
                      ficha.status_workflow === 'REPROVADA' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {ficha.status_workflow}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Botões */}
      <div className="flex justify-between pt-6 border-t border-gray-200 mt-6">
        <div>
          {canDelete && (
            <Button 
              variant="danger" 
              onClick={() => setShowDeleteConfirm(true)}
              disabled={loading}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Excluir
            </Button>
          )}
        </div>
        
        <div className="flex space-x-3">
          <Button variant="secondary" onClick={onClose} disabled={loading}>
            Cancelar
          </Button>
          {canEdit && (
            <Button onClick={handleSave} disabled={loading}>
              {loading ? 'Salvando...' : 'Salvar Alterações'}
            </Button>
          )}
        </div>
      </div>
    </Modal>
  );
};

export default EditSlotModal;
