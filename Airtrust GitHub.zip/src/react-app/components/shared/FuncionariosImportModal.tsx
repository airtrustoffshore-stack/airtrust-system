import React, { useState, useRef, useCallback } from 'react';
import { X, Upload, Download, CheckCircle, AlertTriangle, XCircle, FileText, Clock, AlertCircle } from 'lucide-react';
import Papa from 'papaparse';
import Button from '@/react-app/components/Button';
import Modal from '@/react-app/components/Modal';

interface ImportError {
  linha: number;
  erro: string;
  dados?: any;
}

interface ImportResult {
  success: boolean;
  linhas_processadas: number;
  criados?: number;
  atualizados?: number;
  importadas_com_sucesso?: number;
  erros: number;
  detalhes_erros: ImportError[];
  duracao_ms?: number;
  resumo?: string;
  error?: string;
}

interface PreviewData {
  headers: string[];
  rows: string[][];
}

interface FuncionariosImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const EXPECTED_FORMAT = {
  headers: ['nome', 'função', 'anv', 'cpf', 'data de nasc.', 'licença', 'canac', 'sispat', 'prestserv', 'email', 'telefone', 'admissão', 'matrícula'],
  example: `Nome,Função,ANV,CPF,Data de Nasc.,Licença,CANAC,Sispat,Prestserv,Email,Telefone,Admissão,Matrícula
Nome Completo,PILOTO,12345,12345678901,1985-05-01,LIC001,123456,98765,3001,email@empresa.com,11999999999,2023-01-15,MAT001
Outro Nome,COMISSARIO,67890,98765432109,1990-03-15,LIC002,654321,56789,3002,email2@empresa.com,11888888888,2023-02-20,MAT002`,
  requiredFields: ['nome', 'matrícula']
};

export default function FuncionariosImportModal({ 
  isOpen, 
  onClose, 
  onSuccess 
}: FuncionariosImportModalProps) {
  const [step, setStep] = useState<'upload' | 'preview' | 'processing' | 'result'>('upload');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewData, setPreviewData] = useState<PreviewData | null>(null);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [csvText, setCsvText] = useState('');
  const [inputMode, setInputMode] = useState<'file' | 'text'>('file');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const resetModal = useCallback(() => {
    setStep('upload');
    setSelectedFile(null);
    setPreviewData(null);
    setValidationErrors([]);
    setResult(null);
    setIsDragOver(false);
    setCsvText('');
    setInputMode('file');
  }, []);

  const handleClose = useCallback(() => {
    resetModal();
    onClose();
  }, [resetModal, onClose]);

  const validateHeaders = useCallback((headers: string[]): string[] => {
    const errors: string[] = [];
    const normalizedHeaders = headers.map(h => h.trim().toLowerCase());
    
    // Verificar campos obrigatórios
    for (const required of EXPECTED_FORMAT.requiredFields) {
      if (!normalizedHeaders.includes(required.toLowerCase())) {
        errors.push(`Campo obrigatório '${required}' não encontrado`);
      }
    }
    
    return errors;
  }, []);

  const parseCSVFile = useCallback((file: File) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      preview: 5,
      transformHeader: (header: string) => header.trim().toLowerCase().replace(/\s+/g, '_'),
      complete: (results) => {
        const headers = results.meta.fields || [];
        const rows = results.data.map((row: any) => 
          headers.map(header => row[header] || '')
        );

        setPreviewData({ headers, rows });
        
        const headerErrors = validateHeaders(headers);
        setValidationErrors(headerErrors);
        
        setStep('preview');
      },
      error: (error) => {
        console.error('Erro ao fazer parse do CSV:', error);
        setValidationErrors(['Erro ao processar arquivo CSV: ' + error.message]);
        setStep('preview');
      }
    });
  }, [validateHeaders]);

  const parseCSVText = useCallback((csvContent: string) => {
    Papa.parse(csvContent, {
      header: true,
      skipEmptyLines: true,
      preview: 5,
      transformHeader: (header: string) => header.trim().toLowerCase().replace(/\s+/g, '_'),
      complete: (results) => {
        const headers = results.meta.fields || [];
        const rows = results.data.map((row: any) => 
          headers.map(header => row[header] || '')
        );

        setPreviewData({ headers, rows });
        
        const headerErrors = validateHeaders(headers);
        setValidationErrors(headerErrors);
        
        setStep('preview');
      },
      error: (error: any) => {
        console.error('Erro ao fazer parse do CSV:', error);
        setValidationErrors(['Erro ao processar texto CSV: ' + error.message]);
        setStep('preview');
      }
    });
  }, [validateHeaders]);

  const handleFileSelect = useCallback((file: File) => {
    if (file.size > 10 * 1024 * 1024) {
      alert('Arquivo muito grande. Máximo 10MB permitido.');
      return;
    }

    if (!file.name.toLowerCase().endsWith('.csv')) {
      alert('Por favor, selecione um arquivo CSV.');
      return;
    }

    setSelectedFile(file);
    parseCSVFile(file);
  }, [parseCSVFile]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  const processImport = useCallback(async () => {
    if (!selectedFile && !csvText) return;

    setStep('processing');

    try {
      let csvContent = '';
      if (selectedFile) {
        csvContent = await selectedFile.text();
      } else {
        csvContent = csvText;
      }
      
      console.log('🚀 Iniciando importação de funcionários...');
      
      const response = await fetch('/api/v2/funcionarios-batch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ csv_data: csvContent }),
      });
      
      console.log('📡 Response status:', response.status);
      console.log('📡 Response headers:', Object.fromEntries(response.headers.entries()));
      
      let responseData;
      try {
        const responseText = await response.text();
        console.log('📡 Response text length:', responseText.length);
        console.log('📡 Response text preview:', responseText.substring(0, 200));
        
        responseData = JSON.parse(responseText);
        console.log('✅ JSON parsing successful:', responseData);
      } catch (parseError) {
        console.error('❌ JSON parse error:', parseError);
        console.error('❌ Response content that failed to parse:', await response.text());
        
        responseData = {
          success: false,
          error: 'Erro de comunicação com o servidor - resposta inválida',
          linhas_processadas: 0,
          erros: 1,
          detalhes_erros: [{ linha: 0, erro: 'Servidor retornou conteúdo HTML ao invés de JSON' }],
          resumo: 'Falha na comunicação'
        };
      }
      
      setResult(responseData);
      setStep('result');
      
      if (responseData.success && (responseData.criados > 0 || responseData.atualizados > 0)) {
        setTimeout(() => {
          onSuccess();
        }, 3000);
      }
      
    } catch (error) {
      console.error('Erro na importação:', error);
      setResult({
        success: false,
        error: 'Erro de comunicação com o servidor',
        linhas_processadas: 0,
        erros: 1,
        detalhes_erros: [{ linha: 0, erro: 'Falha na comunicação' }],
        resumo: 'Falha na comunicação'
      });
      setStep('result');
    }
  }, [selectedFile, csvText, onSuccess]);

  const downloadTemplate = useCallback(() => {
    const csvContent = EXPECTED_FORMAT.example;
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'template_funcionarios.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, []);

  const renderUploadStep = () => (
    <div className="space-y-6 w-full">
      {/* Modo de Input */}
      <div className="flex bg-gray-100 rounded-lg p-1">
        <button
          onClick={() => setInputMode('file')}
          className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            inputMode === 'file'
              ? 'bg-white text-gray-900 shadow-sm'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          📁 Upload de Arquivo
        </button>
        <button
          onClick={() => setInputMode('text')}
          className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            inputMode === 'text'
              ? 'bg-white text-gray-900 shadow-sm'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          📄 Colar CSV
        </button>
      </div>

      {inputMode === 'file' ? (
        /* Drag & Drop Area */
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
          }`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-lg font-medium text-gray-700 mb-2">
            Arraste e solte seu arquivo CSV aqui
          </p>
          <p className="text-sm text-gray-500 mb-4">
            ou clique para selecionar um arquivo
          </p>
          <Button
            variant="primary"
            onClick={() => fileInputRef.current?.click()}
            className="mb-4"
          >
            Selecionar Arquivo CSV
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv"
            onChange={handleFileInputChange}
            className="hidden"
          />
          <p className="text-xs text-gray-400">
            Máximo 10MB • Formato CSV apenas
          </p>
        </div>
      ) : (
        /* Área de Texto */
        <div className="space-y-4 w-full">
          <div className="w-full">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cole seu conteúdo CSV aqui:
            </label>
            <textarea
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder={`Exemplo:\n${EXPECTED_FORMAT.headers.join(',')}\n${EXPECTED_FORMAT.example.split('\n').slice(1, 3).join('\n')}`}
              className="w-full h-40 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm resize-none"
            />
          </div>
          <Button
            variant="primary"
            onClick={() => parseCSVText(csvText)}
            disabled={!csvText.trim()}
            className="w-full"
          >
            Processar CSV
          </Button>
        </div>
      )}

      {/* Template Download */}
      <div className="bg-blue-50 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium text-blue-900">Precisa de um template?</h4>
            <p className="text-sm text-blue-700">Baixe nosso modelo CSV para começar</p>
          </div>
          <Button variant="secondary" size="sm" onClick={downloadTemplate}>
            <Download className="w-4 h-4 mr-2" />
            Baixar Template
          </Button>
        </div>
      </div>

      {/* Formato Esperado */}
      <div className="bg-gray-50 rounded-lg p-4 w-full">
        <h4 className="font-medium text-gray-900 mb-3">📋 Formato CSV Esperado</h4>
        
        <div className="bg-white rounded-lg border overflow-hidden w-full">
          {/* Header */}
          <div className="bg-blue-50 px-4 py-2 border-b">
            <p className="text-sm font-medium text-blue-900">
              Campos obrigatórios: <span className="text-blue-600">{EXPECTED_FORMAT.requiredFields.join(', ')}</span>
            </p>
          </div>
          
          {/* Formato Completo Estilizado */}
          <div className="p-4 w-full">
            <p className="font-medium text-gray-800 mb-3">Formato CSV esperado:</p>
            <pre className="bg-gray-100 p-3 rounded-md overflow-x-auto text-sm border w-full">
              <code className="text-gray-700 font-mono whitespace-pre block">
{EXPECTED_FORMAT.example}
              </code>
            </pre>
            
            {/* Descrição dos Campos */}
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-gray-600">
              <div className="bg-green-50 border border-green-200 rounded p-3">
                <p className="font-medium mb-2 text-green-800">✅ OBRIGATÓRIOS:</p>
                <ul className="space-y-1 list-disc list-inside text-green-700">
                  <li><strong>Nome:</strong> Nome completo</li>
                  <li><strong>Matrícula:</strong> Código único</li>
                </ul>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded p-3">
                <p className="font-medium mb-2 text-blue-800">ℹ️ OPCIONAIS:</p>
                <ul className="space-y-1 list-disc list-inside text-blue-700">
                  <li><strong>Função:</strong> PILOTO, COMISSARIO, etc.</li>
                  <li><strong>ANV:</strong> Aeronaves habilitadas</li>
                  <li><strong>CPF:</strong> Documento</li>
                  <li><strong>Licença:</strong> Licença aeronáutica</li>
                  <li><strong>Códigos:</strong> CANAC, Sispat, Prestserv</li>
                  <li><strong>Contatos:</strong> Email, Telefone</li>
                  <li><strong>Datas:</strong> Nascimento, Admissão</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderPreviewStep = () => (
    <div className="space-y-6">
      {/* File Info */}
      <div className="bg-blue-50 rounded-lg p-4">
        <div className="flex items-center">
          <FileText className="w-5 h-5 text-blue-600 mr-3" />
          <div>
            <p className="font-medium text-blue-900">
              {selectedFile?.name || 'Dados colados via texto'}
            </p>
            <p className="text-sm text-blue-700">
              {selectedFile 
                ? `${Math.round((selectedFile?.size || 0) / 1024)} KB • ${previewData?.rows.length || 0} linha(s) de preview`
                : `${previewData?.rows.length || 0} linha(s) de preview`
              }
            </p>
          </div>
        </div>
      </div>

      {/* Validation Errors */}
      {validationErrors.length > 0 && (
        <div className="bg-red-50 rounded-lg p-4">
          <div className="flex items-center mb-2">
            <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
            <h4 className="font-medium text-red-900">Erros de Validação</h4>
          </div>
          <ul className="text-sm text-red-700 space-y-1">
            {validationErrors.map((error, index) => (
              <li key={index} className="flex items-start">
                <span className="w-1 h-1 bg-red-600 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                {error}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Preview Table */}
      {previewData && (
        <div className="border rounded-lg overflow-hidden w-full">
          <div className="bg-gray-50 px-4 py-2 border-b">
            <h4 className="font-medium text-gray-900">Preview dos dados (primeiras 5 linhas)</h4>
          </div>
          
          <div className="overflow-x-auto max-h-80">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 sticky top-0">
                <tr>
                  {previewData.headers.map((header, index) => (
                    <th key={index} className="px-4 py-3 text-left font-medium text-gray-700 border-r last:border-r-0 min-w-[140px] whitespace-nowrap">
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {previewData.rows.map((row, rowIndex) => (
                  <tr key={rowIndex} className="border-t hover:bg-gray-50">
                    {row.map((cell, cellIndex) => (
                      <td key={cellIndex} className="px-4 py-2 text-gray-600 border-r last:border-r-0 max-w-[200px] truncate" title={cell}>
                        {cell || <span className="text-gray-400 italic">vazio</span>}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Header Mapping Info */}
      <div className="bg-green-50 rounded-lg p-4">
        <div className="flex items-center mb-2">
          <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
          <h4 className="font-medium text-green-900">Mapeamento de Campos</h4>
        </div>
        <div className="text-sm text-green-700">
          <p>Headers detectados: <span className="font-mono">{previewData?.headers.join(', ')}</span></p>
          <p className="mt-1">Status: {validationErrors.length === 0 ? 'Válido ✓' : `${validationErrors.length} erro(s) encontrado(s) ✗`}</p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex justify-between">
        <Button variant="secondary" onClick={() => setStep('upload')}>
          Voltar
        </Button>
        <Button 
          variant="primary" 
          onClick={processImport}
          disabled={validationErrors.length > 0}
        >
          {validationErrors.length > 0 ? 'Corrigir Erros Primeiro' : 'Iniciar Importação'}
        </Button>
      </div>
    </div>
  );

  const renderProcessingStep = () => (
    <div className="text-center py-12">
      <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-6">
        <Clock className="w-8 h-8 text-blue-600 animate-spin" />
      </div>
      <h3 className="text-lg font-medium text-gray-900 mb-2">
        Processando importação...
      </h3>
      <p className="text-gray-600">
        Validando dados e executando importação em lote
      </p>
      <div className="mt-4 text-sm text-gray-500">
        <p>• Validando integridade referencial</p>
        <p>• Aplicando regras de negócio</p>
        <p>• Gerando relatório detalhado</p>
      </div>
    </div>
  );

  const renderResultStep = () => {
    if (!result) return null;

    const isPartialSuccess = result.success && result.erros > 0 && 
      ((result.criados && result.criados > 0) || 
       (result.atualizados && result.atualizados > 0));

    const getStatusIcon = () => {
      if (!result.success) return <XCircle className="w-8 h-8 text-red-600" />;
      if (isPartialSuccess) return <AlertTriangle className="w-8 h-8 text-yellow-600" />;
      return <CheckCircle className="w-8 h-8 text-green-600" />;
    };

    const getStatusColor = () => {
      if (!result.success) return 'red';
      if (isPartialSuccess) return 'yellow';
      return 'green';
    };

    const statusColor = getStatusColor();

    return (
      <div className="space-y-6">
        {/* Status Header */}
        <div className={`bg-${statusColor}-50 rounded-lg p-6 text-center`}>
          <div className="flex justify-center mb-4">
            {getStatusIcon()}
          </div>
          <h3 className={`text-lg font-medium text-${statusColor}-900 mb-2`}>
            {!result.success 
              ? 'Importação Falhada!' 
              : isPartialSuccess 
                ? 'Importação Parcial'
                : 'Importação Concluída!'}
          </h3>
          <p className={`text-${statusColor}-700`}>
            {result.error || result.resumo || 'Processamento finalizado'}
          </p>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-gray-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-gray-900">{result.linhas_processadas}</p>
            <p className="text-sm text-gray-600">Processadas</p>
          </div>
          
          <div className="bg-green-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-green-600">{result.criados || 0}</p>
            <p className="text-sm text-green-700">Criados</p>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-blue-600">{result.atualizados || 0}</p>
            <p className="text-sm text-blue-700">Atualizados</p>
          </div>
          
          <div className="bg-red-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-red-600">{result.erros}</p>
            <p className="text-sm text-red-700">Erros</p>
          </div>
        </div>

        {/* Performance */}
        {result.duracao_ms && (
          <div className="bg-blue-50 rounded-lg p-3 text-center">
            <p className="text-lg font-bold text-blue-600">{result.duracao_ms}ms</p>
            <p className="text-sm text-blue-700">Tempo de Processamento</p>
          </div>
        )}

        {/* Errors Detail */}
        {result.detalhes_erros && result.detalhes_erros.length > 0 && (
          <div className="bg-red-50 rounded-lg p-4">
            <h4 className="font-medium text-red-900 mb-3">
              Detalhes dos Erros ({result.detalhes_erros.length})
            </h4>
            <div className="max-h-40 overflow-y-auto space-y-2">
              {result.detalhes_erros.map((erro, index) => (
                <div key={index} className="text-sm border-l-2 border-red-300 pl-3">
                  <span className="font-medium text-red-700">Linha {erro.linha}:</span>
                  <span className="text-red-600 ml-2">{erro.erro}</span>
                  {erro.dados && (
                    <div className="text-red-500 text-xs mt-1 font-mono">
                      {JSON.stringify(erro.dados, null, 2).substring(0, 100)}...
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-between">
          <Button variant="secondary" onClick={resetModal}>
            Nova Importação
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Fechar
          </Button>
        </div>
      </div>
    );
  };

  const renderStepContent = () => {
    switch (step) {
      case 'upload': return renderUploadStep();
      case 'preview': return renderPreviewStep();
      case 'processing': return renderProcessingStep();
      case 'result': return renderResultStep();
      default: return renderUploadStep();
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} className="max-w-6xl max-h-[90vh] overflow-y-auto m-4">
      <div className="w-full p-6 max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex-1 min-w-0 pr-4">
            <h2 className="text-xl font-semibold text-gray-900 truncate">Importar Funcionários via CSV</h2>
            <p className="text-sm text-gray-600 mt-1 break-words">Importe dados de funcionários usando arquivo CSV com validação avançada</p>
          </div>
          <button onClick={handleClose} className="text-gray-400 hover:text-gray-600 flex-shrink-0">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Step Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-sm">
            <span className={step === 'upload' ? 'font-medium text-blue-600' : 'text-gray-500'}>
              1. Upload
            </span>
            <span className={step === 'preview' ? 'font-medium text-blue-600' : 'text-gray-500'}>
              2. Preview
            </span>
            <span className={step === 'processing' ? 'font-medium text-blue-600' : 'text-gray-500'}>
              3. Processamento
            </span>
            <span className={step === 'result' ? 'font-medium text-blue-600' : 'text-gray-500'}>
              4. Resultado
            </span>
          </div>
          <div className="mt-2 bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 rounded-full h-2 transition-all duration-300"
              style={{ 
                width: step === 'upload' ? '25%' : 
                       step === 'preview' ? '50%' : 
                       step === 'processing' ? '75%' : '100%' 
              }}
            />
          </div>
        </div>

        <div className="max-h-[80vh] overflow-y-auto w-full">
          <div className="w-full">
            {renderStepContent()}
          </div>
        </div>
      </div>
    </Modal>
  );
}
