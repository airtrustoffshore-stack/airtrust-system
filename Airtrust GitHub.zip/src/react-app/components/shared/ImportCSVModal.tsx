import React, { useState, useRef, useCallback } from 'react';
import { X, Upload, Download, CheckCircle, AlertTriangle, XCircle, Eye, FileText, Clock } from 'lucide-react';
import Button from '@/react-app/components/Button';
import Modal from '@/react-app/components/Modal';

interface CSVError {
  row: number;
  field: string;
  message: string;
  error_type: 'VALIDATION' | 'DUPLICATE' | 'FOREIGN_KEY' | 'SYSTEM';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  raw_value?: string;
}

interface CSVWarning {
  row: number;
  field: string;
  message: string;
  warning_type: 'FORMAT' | 'SUGGESTION' | 'PERFORMANCE';
  raw_value?: string;
}

interface CSVImportResult {
  success: boolean;
  batch_id: string;
  processing_time_ms: number;
  rows_total: number;
  rows_processed: number;
  rows_failed: number;
  rows_skipped: number;
  new_catalogs_created?: number;
  duplicates_detected: number;
  errors: CSVError[];
  warnings: CSVWarning[];
  summary: string;
}

interface ImportCSVModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  endpoint: string; // '/api/v2/treinamentos/catalogo-treinamentos/batch-import' or '/api/v2/treinamentos/historico-certificacoes/batch-import'
  title: string;
  description: string;
  formatoExemplo: string[];
}

export default function ImportCSVModal({ 
  isOpen, 
  onClose, 
  onSuccess, 
  endpoint, 
  title, 
  description, 
  formatoExemplo 
}: ImportCSVModalProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [csvContent, setCsvContent] = useState<string>('');
  const [previewData, setPreviewData] = useState<{ headers: string[]; rows: string[][] } | null>(null);
  const [, setIsProcessing] = useState(false);
  const [result, setResult] = useState<CSVImportResult | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [step, setStep] = useState<'upload' | 'preview' | 'processing' | 'result'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const resetModal = useCallback(() => {
    setSelectedFile(null);
    setCsvContent('');
    setPreviewData(null);
    setResult(null);
    setStep('upload');
    setShowPreview(false);
    setIsProcessing(false);
    setIsDragOver(false);
  }, []);

  const handleClose = useCallback(() => {
    resetModal();
    onClose();
  }, [resetModal, onClose]);

  const handleFileSelect = useCallback((file: File) => {
    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      alert('Arquivo muito grande. Máximo 10MB permitido.');
      return;
    }

    if (!file.name.toLowerCase().endsWith('.csv')) {
      alert('Por favor, selecione um arquivo CSV.');
      return;
    }

    setSelectedFile(file);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setCsvContent(content);
      
      // Parse preview data
      try {
        const lines = content.trim().split('\n');
        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        const rows = lines.slice(1, 6).map(line => { // Only first 5 rows for preview (UI only)
          const result = [];
          let current = '';
          let inQuotes = false;
          
          for (let i = 0; i < line.length; i++) {
            const char = line[i];
            if (char === '"') {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              result.push(current.trim().replace(/"/g, ''));
              current = '';
            } else {
              current += char;
            }
          }
          result.push(current.trim().replace(/"/g, ''));
          return result;
        });
        
        setPreviewData({ headers, rows });
        setStep('preview');
      } catch (error) {
        alert('Erro ao ler o arquivo CSV. Verifique o formato.');
      }
    };
    
    reader.readAsText(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  const processImport = useCallback(async () => {
    if (!csvContent) return;
    
    setIsProcessing(true);
    setStep('processing');
    
    try {
      // ✅ ENVIAR ARQUIVO COMPLETO (nunca apenas preview)
      console.log('📊 [IMPORT] Enviando arquivo completo para backend');
      const formData = new FormData();
      const blob = new Blob([csvContent], { type: 'text/csv' });
      formData.append('file', blob, 'import.csv');
      
      const response = await fetch(endpoint, {
        method: 'POST',
        body: formData,
      });
      
      const data = await response.json();
      setResult(data);
      setStep('result');
      
      if (data.success && data.rows_processed > 0) {
        setTimeout(() => {
          onSuccess();
        }, 2000);
      }
    } catch (error) {
      console.error('Import error:', error);
      setResult({
        success: false,
        batch_id: `error_${Date.now()}`,
        processing_time_ms: 0,
        rows_total: 0,
        rows_processed: 0,
        rows_failed: 0,
        rows_skipped: 0,
        duplicates_detected: 0,
        errors: [{
          row: 0,
          field: 'system',
          message: 'Erro de comunicação com o servidor',
          error_type: 'SYSTEM',
          severity: 'CRITICAL'
        }],
        warnings: [],
        summary: 'Falha na comunicação'
      });
      setStep('result');
    } finally {
      setIsProcessing(false);
    }
  }, [csvContent, endpoint, onSuccess]);

  const renderUploadStep = () => (
    <div className="space-y-6">
      {/* Drag & Drop Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
          isDragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
        }`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
      >
        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <p className="text-lg font-medium text-gray-700 mb-2">
          Arraste e solte seu arquivo CSV aqui
        </p>
        <p className="text-sm text-gray-500 mb-4">
          ou clique para selecionar um arquivo
        </p>
        <Button
          variant="primary"
          onClick={() => fileInputRef.current?.click()}
          className="mb-4"
        >
          Selecionar Arquivo
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          onChange={handleFileInputChange}
          className="hidden"
        />
        <p className="text-xs text-gray-400">
          Máximo 10MB • Formato CSV apenas
        </p>
      </div>

      {/* Template Download */}
      <div className="bg-blue-50 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium text-blue-900">Precisa de um template?</h4>
            <p className="text-sm text-blue-700">Baixe nosso modelo totalmente editável (sem proteção)</p>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="secondary" 
              size="sm"
              onClick={() => window.open('/api/v2/templates-airtrust/certificacoes/csv', '_blank')}
            >
              <Download className="w-4 h-4 mr-2" />
              CSV
            </Button>
            <Button 
              variant="secondary" 
              size="sm"
              onClick={() => window.open('/api/v2/templates-airtrust/certificacoes/xlsx', '_blank')}
            >
              <Download className="w-4 h-4 mr-2" />
              Excel
            </Button>
          </div>
        </div>
        <p className="text-xs text-blue-600 mt-2">
          ✅ Templates totalmente editáveis - sem senha, sem proteção, sem restrições
        </p>
      </div>

      {/* Formato Exemplo */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-medium text-gray-900 mb-2">Formato esperado:</h4>
        <div className="text-sm text-gray-600 font-mono bg-white p-3 rounded border">
          {formatoExemplo.join('\n')}
        </div>
      </div>
    </div>
  );

  const renderPreviewStep = () => (
    <div className="space-y-6">
      {/* File Info */}
      <div className="bg-blue-50 rounded-lg p-4">
        <div className="flex items-center">
          <FileText className="w-5 h-5 text-blue-600 mr-3" />
          <div>
            <p className="font-medium text-blue-900">{selectedFile?.name}</p>
            <p className="text-sm text-blue-700">
              {Math.round((selectedFile?.size || 0) / 1024)} KB • {previewData?.rows.length || 0} linha(s) de dados
            </p>
          </div>
        </div>
      </div>

      {/* Preview Table */}
      <div className="border rounded-lg overflow-hidden">
        <div className="bg-gray-50 px-4 py-2 border-b">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-gray-900">Preview dos dados (primeiras 5 linhas)</h4>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowPreview(!showPreview)}
            >
              <Eye className="w-4 h-4 mr-2" />
              {showPreview ? 'Ocultar' : 'Mostrar'} Preview
            </Button>
          </div>
        </div>
        
        {showPreview && previewData && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100">
                <tr>
                  {previewData.headers.map((header, index) => (
                    <th key={index} className="px-3 py-2 text-left font-medium text-gray-700 border-r last:border-r-0">
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {previewData.rows.map((row, rowIndex) => (
                  <tr key={rowIndex} className="border-t">
                    {row.map((cell, cellIndex) => (
                      <td key={cellIndex} className="px-3 py-2 text-gray-600 border-r last:border-r-0">
                        {cell || <span className="text-gray-400 italic">vazio</span>}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex justify-between">
        <Button variant="secondary" onClick={() => setStep('upload')}>
          Voltar
        </Button>
        <Button variant="primary" onClick={processImport}>
          Iniciar Importação
        </Button>
      </div>
    </div>
  );

  const renderProcessingStep = () => (
    <div className="text-center py-12">
      <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-6">
        <Clock className="w-8 h-8 text-blue-600 animate-spin" />
      </div>
      <h3 className="text-lg font-medium text-gray-900 mb-2">
        Processando importação...
      </h3>
      <p className="text-gray-600">
        Validando dados e executando importação em lote
      </p>
    </div>
  );

  const renderResultStep = () => {
    if (!result) return null;

    const getStatusIcon = () => {
      if (result.success && result.rows_processed > 0) {
        return <CheckCircle className="w-8 h-8 text-green-600" />;
      } else if (result.rows_processed > 0 && result.rows_failed > 0) {
        return <AlertTriangle className="w-8 h-8 text-yellow-600" />;
      } else {
        return <XCircle className="w-8 h-8 text-red-600" />;
      }
    };

    const getStatusColor = () => {
      if (result.success && result.rows_processed > 0) return 'green';
      if (result.rows_processed > 0 && result.rows_failed > 0) return 'yellow';
      return 'red';
    };

    const statusColor = getStatusColor();

    return (
      <div className="space-y-6">
        {/* Status Header */}
        <div className={`bg-${statusColor}-50 rounded-lg p-6 text-center`}>
          <div className="flex justify-center mb-4">
            {getStatusIcon()}
          </div>
          <h3 className={`text-lg font-medium text-${statusColor}-900 mb-2`}>
            {result.success && result.rows_processed > 0 
              ? 'Importação Concluída!' 
              : result.rows_processed > 0 
                ? 'Importação Parcial' 
                : 'Importação Falhada'
            }
          </h3>
          <p className={`text-${statusColor}-700`}>
            {result.summary}
          </p>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-gray-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-gray-900">{result.rows_total}</p>
            <p className="text-sm text-gray-600">Total</p>
          </div>
          <div className="bg-green-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-green-600">{result.rows_processed}</p>
            <p className="text-sm text-green-700">Processados</p>
          </div>
          <div className="bg-red-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-red-600">{result.rows_failed}</p>
            <p className="text-sm text-red-700">Falharam</p>
          </div>
          <div className="bg-blue-50 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold text-blue-600">{result.processing_time_ms}ms</p>
            <p className="text-sm text-blue-700">Tempo</p>
          </div>
        </div>

        {/* Additional Metrics */}
        {(result.duplicates_detected > 0 || (result.new_catalogs_created !== undefined && result.new_catalogs_created > 0)) && (
          <div className="grid grid-cols-2 gap-4">
            {result.duplicates_detected > 0 && (
              <div className="bg-yellow-50 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-yellow-600">{result.duplicates_detected}</p>
                <p className="text-sm text-yellow-700">Duplicatas</p>
              </div>
            )}
            {result.new_catalogs_created !== undefined && result.new_catalogs_created > 0 && (
              <div className="bg-purple-50 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-purple-600">{result.new_catalogs_created}</p>
                <p className="text-sm text-purple-700">Auto-criados</p>
              </div>
            )}
          </div>
        )}

        {/* Errors */}
        {result.errors.length > 0 && (
          <div className="bg-red-50 rounded-lg p-4">
            <h4 className="font-medium text-red-900 mb-3">
              Erros ({result.errors.length})
            </h4>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {result.errors.slice(0, 10).map((error, index) => (
                <div key={index} className="text-sm">
                  <span className="font-medium text-red-700">Linha {error.row}:</span>
                  <span className="text-red-600 ml-2">{error.message}</span>
                  {error.raw_value && (
                    <span className="text-red-500 ml-2 font-mono text-xs">({error.raw_value})</span>
                  )}
                </div>
              ))}
              {result.errors.length > 10 && (
                <p className="text-sm text-red-600 italic">
                  ... e mais {result.errors.length - 10} erro(s)
                </p>
              )}
            </div>
          </div>
        )}

        {/* Warnings */}
        {result.warnings.length > 0 && (
          <div className="bg-yellow-50 rounded-lg p-4">
            <h4 className="font-medium text-yellow-900 mb-3">
              Avisos ({result.warnings.length})
            </h4>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {result.warnings.slice(0, 5).map((warning, index) => (
                <div key={index} className="text-sm">
                  <span className="font-medium text-yellow-700">Linha {warning.row}:</span>
                  <span className="text-yellow-600 ml-2">{warning.message}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-between">
          <Button variant="secondary" onClick={resetModal}>
            Nova Importação
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Fechar
          </Button>
        </div>
      </div>
    );
  };

  const renderStepContent = () => {
    switch (step) {
      case 'upload': return renderUploadStep();
      case 'preview': return renderPreviewStep();
      case 'processing': return renderProcessingStep();
      case 'result': return renderResultStep();
      default: return renderUploadStep();
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">{title}</h2>
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        </div>
        <button onClick={handleClose} className="text-gray-400 hover:text-gray-600">
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Step Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between text-sm">
          <span className={step === 'upload' ? 'font-medium text-blue-600' : 'text-gray-500'}>
            1. Upload
          </span>
          <span className={step === 'preview' ? 'font-medium text-blue-600' : 'text-gray-500'}>
            2. Preview
          </span>
          <span className={step === 'processing' ? 'font-medium text-blue-600' : 'text-gray-500'}>
            3. Processando
          </span>
          <span className={step === 'result' ? 'font-medium text-blue-600' : 'text-gray-500'}>
            4. Resultado
          </span>
        </div>
        <div className="mt-2 bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 rounded-full h-2 transition-all duration-300"
            style={{ 
              width: step === 'upload' ? '25%' : 
                     step === 'preview' ? '50%' : 
                     step === 'processing' ? '75%' : '100%' 
            }}
          />
        </div>
      </div>

      {renderStepContent()}
    </Modal>
  );
}
