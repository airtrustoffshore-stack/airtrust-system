/**
 * ⚠️ PADRÃO BRASILEIRO OBRIGATÓRIO - AIRTRUST ⚠️
 * 
 * Componente de Debug para Módulo Simulador
 * 
 * ✅ Datas: SEMPRE dd/mm/aaaa (nunca mm/dd/yyyy ou yyyy-mm-dd)
 * ✅ Testa endpoints corrigidos
 * ✅ Valida conceitos e notas
 * ✅ Monitora erros 500
 */

import React, { useState } from 'react';
import { Activity, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import Button from '../Button';
import Card from '../Card';

interface FichaTeste {
  uuid: string;
  status_workflow: string;
  colaborador?: {
    nome: string;
    matricula: string;
  };
  conceito_final?: string | null;
  manobras?: any[];
  pode_editar?: boolean;
}

interface ResultadoTeste {
  endpoint: string;
  sucesso: boolean;
  status: number;
  dados?: any;
  erro?: string;
  tempo_resposta?: number;
}

export const DebugSimulador: React.FC = () => {
  const [fichas, setFichas] = useState<FichaTeste[]>([]);
  const [resultados, setResultados] = useState<ResultadoTeste[]>([]);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  const adicionarResultado = (resultado: ResultadoTeste) => {
    setResultados(prev => [...prev, resultado]);
  };

  const formatarDataBrasil = (dataISO: string): string => {
    try {
      const data = new Date(dataISO);
      const dia = data.getDate().toString().padStart(2, '0');
      const mes = (data.getMonth() + 1).toString().padStart(2, '0');
      const ano = data.getFullYear().toString();
      return `${dia}/${mes}/${ano}`;
    } catch {
      return 'Data inválida';
    }
  };

  const testarEndpoint = async (url: string, metodo: string = 'GET', dados?: any): Promise<ResultadoTeste> => {
    const inicioTempo = Date.now();
    
    try {
      const opcoes: RequestInit = {
        method: metodo,
        headers: {
          'Content-Type': 'application/json',
        },
      };
      
      if (dados && metodo !== 'GET') {
        opcoes.body = JSON.stringify(dados);
      }
      
      const response = await fetch(url, opcoes);
      const tempoResposta = Date.now() - inicioTempo;
      
      let dadosResposta;
      try {
        dadosResposta = await response.json();
      } catch {
        dadosResposta = { texto: 'Resposta não é JSON válido' };
      }
      
      return {
        endpoint: url,
        sucesso: response.ok,
        status: response.status,
        dados: dadosResposta,
        tempo_resposta: tempoResposta
      };
    } catch (error) {
      const tempoResposta = Date.now() - inicioTempo;
      return {
        endpoint: url,
        sucesso: false,
        status: 0,
        erro: error instanceof Error ? error.message : 'Erro desconhecido',
        tempo_resposta: tempoResposta
      };
    }
  };

  const testarTodosEndpoints = async () => {
    setLoading(true);
    setErro(null);
    setResultados([]);
    setFichas([]);
    
    try {
      console.log('🧪 Iniciando testes dos endpoints do simulador...');
      
      // Teste 1: Listar fichas (endpoint original)
      console.log('📋 Testando listagem de fichas (endpoint original)...');
      const resultadoLista = await testarEndpoint('/api/v2/simulador/fichas-lista');
      adicionarResultado(resultadoLista);
      
      if (resultadoLista.sucesso && resultadoLista.dados?.data) {
        setFichas(resultadoLista.dados.data);
        console.log(`✅ Encontradas ${resultadoLista.dados.data.length} fichas`);
      }
      
      // Teste 2: Para cada ficha, testar carregamento com endpoint corrigido
      if (resultadoLista.dados?.data?.length > 0) {
        console.log('🔍 Testando carregamento individual de fichas...');
        
        for (const ficha of resultadoLista.dados.data) {
          // Testar endpoint corrigido
          const resultadoFicha = await testarEndpoint(`/api/v2/simulador/ficha/${ficha.uuid}/corrigida`);
          adicionarResultado(resultadoFicha);
          
          if (resultadoFicha.sucesso) {
            console.log(`✅ Ficha ${ficha.uuid} carregada com sucesso`);
            
            // Se a ficha pode ser editada, testar salvamento
            if (resultadoFicha.dados?.data?.pode_editar && resultadoFicha.dados?.data?.manobras?.length > 0) {
              console.log(`🧪 Testando salvamento de notas para ficha ${ficha.uuid}...`);
              
              // Criar notas de teste
              const manobrasTeste = resultadoFicha.dados.data.manobras.map((m: any) => ({
                manobra_id: m.manobra_id,
                nota: '8', // Nota boa para teste
                observacoes: 'Teste automático do sistema de debug'
              }));
              
              const resultadoSalvar = await testarEndpoint(
                `/api/v2/simulador/ficha/${ficha.uuid}/notas-corrigidas`,
                'PATCH',
                {
                  manobras: manobrasTeste,
                  observacoes_instrutor: 'Teste automático do sistema - Debug AirTrust'
                }
              );
              
              adicionarResultado(resultadoSalvar);
              
              if (resultadoSalvar.sucesso) {
                console.log(`✅ Notas salvas com sucesso para ficha ${ficha.uuid}`);
                console.log(`📊 Conceito calculado: ${resultadoSalvar.dados?.data?.conceito}`);
              } else {
                console.error(`❌ Erro ao salvar notas da ficha ${ficha.uuid}:`, resultadoSalvar.erro);
              }
            }
          } else {
            console.error(`❌ Erro ao carregar ficha ${ficha.uuid}:`, resultadoFicha.erro);
          }
        }
      }
      
      // Teste 3: Testar endpoints de avaliação de manobras
      console.log('⚡ Testando endpoint de avaliação de manobras...');
      if (fichas.length > 0) {
        const primeiraFicha = fichas[0];
        const resultadoAvaliacao = await testarEndpoint(`/api/v2/simulador/ficha/${primeiraFicha.uuid}/avaliacao`);
        adicionarResultado(resultadoAvaliacao);
        
        if (resultadoAvaliacao.sucesso) {
          console.log(`✅ Endpoint de avaliação funcionando para ficha ${primeiraFicha.uuid}`);
        }
      }
      
      console.log('🎉 Todos os testes concluídos!');
      
    } catch (error) {
      console.error('❌ Erro geral nos testes:', error);
      setErro(error instanceof Error ? error.message : 'Erro desconhecido');
    } finally {
      setLoading(false);
    }
  };

  const limparResultados = () => {
    setResultados([]);
    setFichas([]);
    setErro(null);
  };

  const exportarRelatorio = () => {
    const relatorio = {
      timestamp: new Date().toISOString(),
      data_brasil: formatarDataBrasil(new Date().toISOString()),
      total_testes: resultados.length,
      testes_sucesso: resultados.filter(r => r.sucesso).length,
      testes_erro: resultados.filter(r => !r.sucesso).length,
      fichas_encontradas: fichas.length,
      detalhes: resultados,
      fichas_testadas: fichas
    };
    
    const blob = new Blob([JSON.stringify(relatorio, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `debug-simulador-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="debug-simulador p-6 space-y-6">
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <Activity className="h-6 w-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-800">
            🔧 Debug - Módulo Simulador AirTrust
          </h2>
        </div>
        
        <div className="text-sm text-gray-600 mb-4">
          <p>✅ Testa endpoints corrigidos com padrão brasileiro (dd/mm/aaaa)</p>
          <p>✅ Valida cálculo de conceitos e carregamento de fichas</p>
          <p>✅ Monitora erros 500 e problemas de integração</p>
        </div>
        
        <div className="flex gap-3">
          <Button onClick={testarTodosEndpoints} disabled={loading} className="flex items-center gap-2">
            {loading ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Activity className="h-4 w-4" />
            )}
            {loading ? 'Testando...' : '🧪 Executar Todos os Testes'}
          </Button>
          
          <Button variant="secondary" onClick={limparResultados} disabled={loading}>
            🗑️ Limpar Resultados
          </Button>
          
          {resultados.length > 0 && (
            <Button variant="secondary" onClick={exportarRelatorio}>
              📄 Exportar Relatório
            </Button>
          )}
        </div>
      </Card>

      {erro && (
        <Card className="p-4 border-red-200 bg-red-50">
          <div className="flex items-center gap-2">
            <XCircle className="h-5 w-5 text-red-600" />
            <h3 className="font-medium text-red-800">❌ Erro Encontrado:</h3>
          </div>
          <pre className="mt-2 text-sm text-red-700 bg-red-100 p-2 rounded overflow-auto">
            {erro}
          </pre>
        </Card>
      )}

      {fichas.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            📋 Fichas Encontradas ({fichas.length})
          </h3>
          <div className="grid gap-3">
            {fichas.map(ficha => (
              <div key={ficha.uuid} className="p-3 border rounded-lg bg-gray-50">
                <div className="flex justify-between items-start">
                  <div>
                    <strong className="text-sm font-mono">{ficha.uuid}</strong>
                    <p className="text-sm text-gray-600">
                      Status: <span className="font-medium">{ficha.status_workflow}</span>
                    </p>
                    {ficha.colaborador && (
                      <p className="text-sm text-gray-600">
                        Tripulante: {ficha.colaborador.nome} ({ficha.colaborador.matricula})
                      </p>
                    )}
                  </div>
                  <div className="text-right">
                    {ficha.conceito_final && (
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        ficha.conceito_final === 'APROVADO' 
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {ficha.conceito_final}
                      </span>
                    )}
                    {ficha.pode_editar && (
                      <p className="text-xs text-blue-600 mt-1">✏️ Editável</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {resultados.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
            <Activity className="h-5 w-5 text-blue-600" />
            📊 Resultados dos Testes ({resultados.length})
          </h3>
          
          <div className="grid gap-3 max-h-96 overflow-y-auto">
            {resultados.map((resultado, index) => (
              <div key={index} className={`p-3 border rounded-lg ${
                resultado.sucesso ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
              }`}>
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    {resultado.sucesso ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-600" />
                    )}
                    <span className="font-mono text-sm">{resultado.endpoint}</span>
                  </div>
                  <div className="text-right text-xs">
                    <span className={`px-2 py-1 rounded ${
                      resultado.status === 200 ? 'bg-green-100 text-green-800' : 
                      resultado.status >= 400 ? 'bg-red-100 text-red-800' : 
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {resultado.status}
                    </span>
                    {resultado.tempo_resposta && (
                      <p className="text-gray-500 mt-1">
                        {resultado.tempo_resposta}ms
                      </p>
                    )}
                  </div>
                </div>
                
                {resultado.erro && (
                  <p className="text-sm text-red-700 mb-2">❌ {resultado.erro}</p>
                )}
                
                {resultado.dados && resultado.sucesso && (
                  <div className="text-xs text-gray-600">
                    {resultado.dados.message && (
                      <p>✅ {resultado.dados.message}</p>
                    )}
                    {resultado.dados.data?.conceito && (
                      <p>📊 Conceito: <strong>{resultado.dados.data.conceito}</strong></p>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default DebugSimulador;
