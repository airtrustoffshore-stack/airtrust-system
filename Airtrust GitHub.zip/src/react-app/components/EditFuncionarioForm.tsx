import { useState, useEffect } from 'react';
import { useApi, useApiMutation } from '@/react-app/hooks/useApi';
import Button from './Button';
import AeronaveSelect from './AeronaveSelect';
import { User, Mail, Building, Shield } from 'lucide-react';

interface FuncionarioEditData {
  nome: string;
  matricula: string;
  cpf: string;
  codigo_anac: string;
  funcao: string;
  base: string;
  contrato: string;
  telefone: string;
  email: string;
  status: string;
  is_instrutor: boolean;
  is_checador: boolean;
  aeronave_principal: string;
}

interface EditFuncionarioFormProps {
  funcionarioId: number;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function EditFuncionarioForm({ funcionarioId, onSuccess, onCancel }: EditFuncionarioFormProps) {
  const { data: funcionario, loading: loadingFuncionario } = useApi<any>(`/api/v2/funcionarios/${funcionarioId}`);
  const { data: funcoes } = useApi<any[]>('/api/v2/funcoes');
  const { mutate, loading, error } = useApiMutation();

  const [formData, setFormData] = useState<FuncionarioEditData>({
    nome: '',
    matricula: '',
    cpf: '',
    codigo_anac: '',
    funcao: '',
    base: '',
    contrato: '',
    telefone: '',
    email: '',
    status: 'ATIVO',
    is_instrutor: false,
    is_checador: false,
    aeronave_principal: ''
  });

  useEffect(() => {
    if (funcionario) {
      setFormData({
        nome: funcionario.nome || '',
        matricula: funcionario.matricula || '',
        cpf: funcionario.cpf || '',
        codigo_anac: funcionario.codigo_anac || '',
        funcao: funcionario.funcao || '',
        base: funcionario.base || '',
        contrato: funcionario.contrato || '',
        telefone: funcionario.telefone || '',
        email: funcionario.email || '',
        status: funcionario.status || 'ATIVO',
        is_instrutor: funcionario.is_instrutor === 1,
        is_checador: funcionario.is_checador === 1,
        aeronave_principal: funcionario.aeronave_principal || ''
      });
    }
  }, [funcionario]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const submitData = {
        ...formData,
        is_instrutor: formData.is_instrutor ? 1 : 0,
        is_checador: formData.is_checador ? 1 : 0,
        // Remove campos vazios para não sobrescrever dados existentes
        matricula: formData.matricula || undefined,
        cpf: formData.cpf || undefined,
        codigo_anac: formData.codigo_anac || undefined,
        base: formData.base || undefined,
        contrato: formData.contrato || undefined,
        telefone: formData.telefone || undefined,
        email: formData.email || undefined,
        aeronave_principal: formData.aeronave_principal || undefined,
      };

      await mutate(`/api/v2/funcionarios/${funcionarioId}`, {
        method: 'PUT',
        body: JSON.stringify(submitData)
      });

      onSuccess();
    } catch (err) {
      console.error('Erro ao atualizar funcionário:', err);
    }
  };

  if (loadingFuncionario) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="h-10 bg-gray-200 rounded"></div>
          <div className="h-10 bg-gray-200 rounded"></div>
          <div className="h-10 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="p-6 space-y-6">
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}

      {/* Informações Básicas */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <User className="w-5 h-5 mr-2 text-blue-600" />
          Informações Básicas
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nome Completo *
            </label>
            <input
              type="text"
              name="nome"
              value={formData.nome}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Digite o nome completo"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Matrícula
            </label>
            <input
              type="text"
              name="matricula"
              value={formData.matricula}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Digite a matrícula"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              CPF
            </label>
            <input
              type="text"
              name="cpf"
              value={formData.cpf}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="000.000.000-00"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Código ANAC
            </label>
            <input
              type="text"
              name="codigo_anac"
              value={formData.codigo_anac}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Digite o código ANAC"
            />
          </div>
        </div>
      </div>

      {/* Função e Status */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <Building className="w-5 h-5 mr-2 text-indigo-600" />
          Função e Status
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Função *
            </label>
            <select
              name="funcao"
              value={formData.funcao}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Selecione uma função</option>
              {funcoes?.map((funcao) => (
                <option key={funcao.id} value={funcao.nome}>
                  {funcao.nome}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Status
            </label>
            <select
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="ATIVO">ATIVO</option>
              <option value="INATIVO">INATIVO</option>
              <option value="LICENCA">LICENÇA</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Base
            </label>
            <input
              type="text"
              name="base"
              value={formData.base}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Base de operação"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Contrato
            </label>
            <input
              type="text"
              name="contrato"
              value={formData.contrato}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Tipo de contrato"
            />
          </div>
        </div>
      </div>

      {/* Contato */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <Mail className="w-5 h-5 mr-2 text-green-600" />
          Informações de Contato
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="email@exemplo.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Telefone
            </label>
            <input
              type="tel"
              name="telefone"
              value={formData.telefone}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="(11) 99999-9999"
            />
          </div>
        </div>
      </div>

      {/* Certificações */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <Shield className="w-5 h-5 mr-2 text-purple-600" />
          Certificações e Especializações
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Aeronave Principal
            </label>
            <AeronaveSelect
              value={formData.aeronave_principal}
              onChange={(value) => setFormData(prev => ({ ...prev, aeronave_principal: value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="is_instrutor"
              name="is_instrutor"
              checked={formData.is_instrutor}
              onChange={handleChange}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="is_instrutor" className="ml-2 text-sm text-gray-700">
              É Instrutor
            </label>
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="is_checador"
              name="is_checador"
              checked={formData.is_checador}
              onChange={handleChange}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="is_checador" className="ml-2 text-sm text-gray-700">
              É Checador
            </label>
          </div>
        </div>
      </div>

      {/* Ações */}
      <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
        <Button 
          type="button" 
          variant="secondary" 
          onClick={onCancel}
          disabled={loading}
        >
          Cancelar
        </Button>
        <Button 
          type="submit" 
          variant="primary"
          loading={loading}
          disabled={!formData.nome || !formData.funcao}
        >
          Salvar Alterações
        </Button>
      </div>
    </form>
  );
}
