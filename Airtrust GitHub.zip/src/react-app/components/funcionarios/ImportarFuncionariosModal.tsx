import { useState } from 'react';
import { Upload, CheckCircle, AlertCircle, Users, Download } from 'lucide-react';
import Button from '@/react-app/components/Button';
import Modal from '@/react-app/components/Modal';

interface ImportarFuncionariosModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface ImportResult {
  success: boolean;
  linhas_processadas: number;
  criados: number;
  atualizados: number;
  erros: number;
  detalhes_erros?: string[];
  error?: string;
}

export default function ImportarFuncionariosModal({ isOpen, onClose, onSuccess }: ImportarFuncionariosModalProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);

  const handleImportSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    const formData = new FormData(e.currentTarget);
    const file = formData.get('file') as File;
    
    if (!file) {
      alert('Por favor, selecione o arquivo da planilha');
      return;
    }

    setIsUploading(true);
    setImportResult(null);

    try {
      const csvText = await file.text();
      const response = await fetch('/api/v2/funcionarios-batch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ csv_data: csvText }),
      });

      const result = await response.json() as ImportResult;
      setImportResult(result);
      
      if (result.success && (result.criados > 0 || result.atualizados > 0)) {
        onSuccess(); // Refresh da lista
      }
    } catch (error) {
      setImportResult({
        success: false,
        error: 'Erro de comunicação com o servidor',
        linhas_processadas: 0,
        criados: 0,
        atualizados: 0,
        erros: 1,
        detalhes_erros: [error instanceof Error ? error.message : 'Erro desconhecido']
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleClose = () => {
    setImportResult(null);
    onClose();
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={handleClose} 
      title="Importar Funcionários da Planilha"
      className="max-w-4xl max-h-[90vh] overflow-y-auto"
    >
      <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
        {/* Formato Esperado */}
        <div className="bg-blue-50 rounded-lg p-4">
          <h4 className="font-medium text-blue-900 mb-3 flex items-center">
            <Download className="w-4 h-4 mr-2" />
            Formato Esperado da Planilha
          </h4>
          
          {/* Destaque importante sobre nomes */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg p-4 mb-4">
            <h5 className="font-semibold text-green-800 mb-2 flex items-center">
              ✅ IMPORTANTE: Como incluir os nomes dos funcionários
            </h5>
            <ul className="text-sm text-green-700 space-y-1">
              <li>• <strong>1ª COLUNA = NOME COMPLETO</strong> (ex: "Nome do Funcionário")</li>
              <li>• <strong>Última COLUNA = MATRÍCULA</strong> (ex: "300", "303", "74")</li>
              <li>• O sistema irá usar exatamente o nome escrito na planilha</li>
              <li>• Não precisa extrair do email - digite o nome completo</li>
            </ul>
          </div>

          <div className="bg-white rounded border overflow-hidden">
            <div className="p-3">
              <p className="font-medium text-gray-800 mb-2">🎯 Template CSV Padrão AirTrust:</p>
              <pre className="bg-white p-3 rounded text-xs overflow-x-auto">
                <code className="text-gray-700 font-mono whitespace-pre block">
{`Nome,Função,ANV,CPF,Data de Nasc.,Licença,CANAC,Sispat,Prestserv,Email,Telefone,Admissão,Matrícula
Nome Funcionário,PILOTO,12345,12345678901,1985-05-01,XYZ,123456,98765,3001,funcionario@exemplo.com,11999999999,2023-01-15,10001`}
                </code>
              </pre>
            </div>
          </div>
          
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-50 border border-green-200 rounded p-3">
              <h6 className="font-medium text-green-800 mb-2">✅ CAMPOS OBRIGATÓRIOS</h6>
              <ul className="text-xs text-green-700 space-y-1">
                <li>• <strong>Nome:</strong> Nome completo do funcionário</li>
                <li>• <strong>Matrícula:</strong> Código único de identificação</li>
              </ul>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded p-3">
              <h6 className="font-medium text-blue-800 mb-2">ℹ️ CAMPOS OPCIONAIS</h6>
              <ul className="text-xs text-blue-700 space-y-1">
                <li>• <strong>Função:</strong> PILOTO, COMISSARIO, MECANICO, etc.</li>
                <li>• <strong>ANV:</strong> Aeronaves habilitadas</li>
                <li>• <strong>CPF:</strong> Documento de identificação</li>
                <li>• <strong>Licença:</strong> Licença aeronáutica</li>
                <li>• <strong>CANAC/Sispat/Prestserv:</strong> Códigos internos</li>
                <li>• <strong>Email/Telefone:</strong> Contatos</li>
                <li>• <strong>Data de Nasc./Admissão:</strong> Datas importantes</li>
              </ul>
            </div>
          </div>
          
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded">
            <p className="text-red-800 text-xs font-medium">
              ⚠️ IMPORTANTE: Apenas Nome e Matrícula são obrigatórios. Todos os demais campos são opcionais e podem estar em branco.
            </p>
            <p className="text-red-700 text-xs mt-1">
              • Linhas só serão rejeitadas se Nome ou Matrícula estiverem vazios/ausentes
            </p>
          </div>
        </div>

        {/* Upload */}
        <form onSubmit={handleImportSubmit} className="space-y-4">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
            <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <input
              type="file"
              name="file"
              accept=".csv,.xlsx,.xls"
              required
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
            />
            <p className="text-xs text-gray-500 mt-2">Arquivos CSV, XLS ou XLSX (máx. 10MB)</p>
          </div>

          <div className="flex justify-end space-x-3">
            <Button type="button" variant="secondary" onClick={handleClose} disabled={isUploading}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary" loading={isUploading}>
              {isUploading ? 'Importando...' : 'Importar Funcionários'}
            </Button>
          </div>
        </form>

        {/* Resultado */}
        {importResult && (
          <div className={`rounded-lg p-4 ${importResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
            <div className="flex items-center mb-3">
              {importResult.success ? (
                <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-600 mr-2" />
              )}
              <h4 className={`font-medium ${importResult.success ? 'text-green-900' : 'text-red-900'}`}>
                {importResult.success ? 'Importação Concluída!' : 'Erro na Importação'}
              </h4>
            </div>
            
            {importResult.success && (
              <div className="grid grid-cols-3 gap-4 mt-3">
                <div className="text-center p-3 bg-white rounded border">
                  <div className="flex items-center justify-center mb-2">
                    <Users className="h-4 w-4 text-green-600 mr-1" />
                    <div className="text-2xl font-bold text-green-600">{importResult.criados}</div>
                  </div>
                  <div className="text-sm text-green-700">Criados</div>
                </div>
                <div className="text-center p-3 bg-white rounded border">
                  <div className="flex items-center justify-center mb-2">
                    <CheckCircle className="h-4 w-4 text-blue-600 mr-1" />
                    <div className="text-2xl font-bold text-blue-600">{importResult.atualizados}</div>
                  </div>
                  <div className="text-sm text-blue-700">Atualizados</div>
                </div>
                <div className="text-center p-3 bg-white rounded border">
                  <div className="flex items-center justify-center mb-2">
                    <AlertCircle className="h-4 w-4 text-red-600 mr-1" />
                    <div className="text-2xl font-bold text-red-600">{importResult.erros}</div>
                  </div>
                  <div className="text-sm text-red-700">Erros</div>
                </div>
              </div>
            )}

            {importResult.error && (
              <div className="mt-3 p-3 bg-red-100 rounded border border-red-200">
                <p className="text-sm text-red-800">{importResult.error}</p>
              </div>
            )}

            {importResult.detalhes_erros && importResult.detalhes_erros.length > 0 && (
              <div className="mt-3 max-h-32 overflow-y-auto">
                <p className="text-sm font-medium text-red-700 mb-2">Detalhes dos erros:</p>
                <div className="bg-white rounded border border-red-200 p-2">
                  {importResult.detalhes_erros.map((erro, i) => (
                    <p key={i} className="text-xs text-red-600 mb-1">• {erro}</p>
                  ))}
                  {importResult.erros > importResult.detalhes_erros.length && (
                    <p className="text-xs text-red-500 italic">
                      ... e mais {importResult.erros - importResult.detalhes_erros.length} erros
                    </p>
                  )}
                </div>
              </div>
            )}

            {importResult.success && (importResult.criados > 0 || importResult.atualizados > 0) && (
              <div className="mt-4 p-3 bg-green-100 rounded border border-green-200">
                <p className="text-sm text-green-800">
                  ✅ Importação finalizada! {importResult.linhas_processadas} linhas processadas.
                  Os funcionários já estão disponíveis para relacionamentos no sistema.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </Modal>
  );
}
