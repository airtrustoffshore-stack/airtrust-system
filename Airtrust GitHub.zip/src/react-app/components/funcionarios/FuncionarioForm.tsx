import React, { useState, useEffect } from 'react';
import Button from '../Button';

interface FuncionarioFormData {
  nome: string;
  matricula: string;
  cpf?: string;
  email?: string;
  telefone?: string;
  funcao: string;
  status: string;
  codigo_anac?: string;
  base?: string;
  contrato?: string;
}

interface Funcionario {
  id?: number;
  nome: string;
  matricula: string;
  cpf?: string;
  email?: string;
  telefone?: string;
  funcao: string;
  status: string;
  codigo_anac?: string;
  base?: string;
  contrato?: string;
}

interface FuncionarioFormProps {
  funcionario?: Funcionario;
  onSubmit: (data: FuncionarioFormData) => void;
  onCancel: () => void;
}

const FuncionarioForm: React.FC<FuncionarioFormProps> = ({ funcionario, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState<FuncionarioFormData>({
    nome: funcionario?.nome || '',
    matricula: funcionario?.matricula || '',
    cpf: funcionario?.cpf || '',
    email: funcionario?.email || '',
    telefone: funcionario?.telefone || '',
    funcao: funcionario?.funcao || '',
    status: funcionario?.status || 'ATIVO',
    codigo_anac: funcionario?.codigo_anac || '',
    base: funcionario?.base || '',
    contrato: funcionario?.contrato || ''
  });

  const [funcoes, setFuncoes] = useState<{ nome: string }[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    carregarFuncoes();
  }, []);

  const carregarFuncoes = async () => {
    try {
      const response = await fetch('/api/v2/funcoes');
      const data = await response.json();
      if (data.success) {
        setFuncoes(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar funções:', error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nome.trim() || !formData.matricula.trim() || !formData.funcao.trim()) {
      alert('Por favor, preencha os campos obrigatórios.');
      return;
    }

    setLoading(true);
    try {
      await onSubmit(formData);
    } catch (error) {
      console.error('Erro ao salvar funcionário:', error);
      alert('Erro ao salvar funcionário. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Nome - CAMPO OBRIGATÓRIO */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nome Completo *
            </label>
            <input
              type="text"
              name="nome"
              value={formData.nome}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Ex: Nome do Funcionário"
            />
          </div>

          {/* Matrícula */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Matrícula *
            </label>
            <input
              type="text"
              name="matricula"
              value={formData.matricula}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Ex: 300"
            />
          </div>

          {/* CPF */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              CPF
            </label>
            <input
              type="text"
              name="cpf"
              value={formData.cpf}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="000.000.000-00"
            />
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="funcionario@empresa.com"
            />
          </div>

          {/* Telefone */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Telefone
            </label>
            <input
              type="tel"
              name="telefone"
              value={formData.telefone}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="(11) 99999-9999"
            />
          </div>

          {/* Função */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Função *
            </label>
            <select
              name="funcao"
              value={formData.funcao}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Selecione uma função</option>
              {funcoes.map((funcao) => (
                <option key={funcao.nome} value={funcao.nome}>
                  {funcao.nome}
                </option>
              ))}
            </select>
          </div>

          

          {/* Base */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Base
            </label>
            <input
              type="text"
              name="base"
              value={formData.base}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Ex: Rio de Janeiro"
            />
          </div>

          {/* Contrato */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Contrato
            </label>
            <input
              type="text"
              name="contrato"
              value={formData.contrato}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Ex: CLT"
            />
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Status
            </label>
            <select
              name="status"
              value={formData.status}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="ATIVO">Ativo</option>
              <option value="INATIVO">Inativo</option>
            </select>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
        <Button 
          type="button" 
          variant="ghost" 
          onClick={onCancel}
          disabled={loading}
        >
          Cancelar
        </Button>
        <Button 
          type="submit" 
          variant="primary"
          disabled={loading}
        >
          {loading ? 'Salvando...' : funcionario ? 'Atualizar' : 'Criar'}
        </Button>
      </div>
    </form>
  );
};

export default FuncionarioForm;
