import React, { useState, useEffect } from 'react';
import Button from '../Button';
import AeronaveMultiSelect from '../AeronaveMultiSelect';
import { User, Mail, Building, FileText, Shield } from 'lucide-react';

interface FuncionarioFormData {
  nome: string;
  matricula: string;
  guerra?: string;
  cpf?: string;
  email?: string;
  telefone?: string;
  funcao: string;
  status: string;
  codigo_anac?: string;
  codigo_canac?: string;
  codigo_sispat?: string;
  codigo_prestserv?: string;
  licenca_aeronautica?: string;
  base?: string;
  contrato?: string;
  data_nascimento?: string;
  data_admissao?: string;
  aeronaves_qualificadas?: number[];
  cma_numero?: string;
  cma_data_vencimento?: string;
  aso_data_vencimento?: string;
  nivel_icao?: string;
  nivel_icao_data_vencimento?: string;
}

interface Funcionario {
  id?: number;
  nome: string;
  matricula: string;
  guerra?: string;
  cpf?: string;
  email?: string;
  telefone?: string;
  funcao: string;
  status: string;
  codigo_anac?: string;
  codigo_canac?: string;
  codigo_sispat?: string;
  codigo_prestserv?: string;
  licenca_aeronautica?: string;
  base?: string;
  contrato?: string;
  data_nascimento?: string;
  data_admissao?: string;
  aeronaves_qualificadas?: number[];
  cma_numero?: string;
  cma_data_vencimento?: string;
  aso_data_vencimento?: string;
  nivel_icao?: string;
  nivel_icao_data_vencimento?: string;
}

interface FuncionarioFormUnifiedProps {
  funcionario?: Funcionario;
  onSubmit: (data: FuncionarioFormData) => void;
  onCancel: () => void;
  loading?: boolean;
}

const FuncionarioFormUnified: React.FC<FuncionarioFormUnifiedProps> = ({ 
  funcionario, 
  onSubmit, 
  onCancel,
  loading = false
}) => {
  const [formData, setFormData] = useState<FuncionarioFormData>({
    nome: '',
    matricula: '',
    guerra: '',
    cpf: '',
    email: '',
    telefone: '',
    funcao: '',
    status: 'ATIVO',
    codigo_anac: '',
    codigo_canac: '',
    codigo_sispat: '',
    codigo_prestserv: '',
    licenca_aeronautica: '',
    base: '',
    contrato: '',
    data_nascimento: '',
    data_admissao: '',
    aeronaves_qualificadas: [],
    cma_numero: '',
    cma_data_vencimento: '',
    aso_data_vencimento: '',
    nivel_icao: '',
    nivel_icao_data_vencimento: ''
  });

  const [_funcionarioCompleto, setFuncionarioCompleto] = useState<any>(null);

  const [funcoes, setFuncoes] = useState<{ nome: string }[]>([]);

  useEffect(() => {
    carregarFuncoes();
    if (funcionario?.id) {
      carregarDadosCompletos(funcionario.id);
    }
  }, [funcionario]);

  const carregarDadosCompletos = async (id: number) => {
    try {
      const response = await fetch(`/api/v2/funcionarios/${id}`);
      const data = await response.json();
      if (data.success) {
        const func = data.data;
        setFuncionarioCompleto(func);
        setFormData({
          nome: func.nome || '',
          matricula: func.matricula || '',
          guerra: func.guerra || '',
          cpf: func.cpf || '',
          email: func.email || '',
          telefone: func.telefone || '',
          funcao: func.funcao || '',
          status: func.status || 'ATIVO',
          codigo_anac: func.codigo_anac || '',
          codigo_canac: func.codigo_canac || '',
          codigo_sispat: func.codigo_sispat || '',
          codigo_prestserv: func.codigo_prestserv || '',
          licenca_aeronautica: func.licenca_aeronautica || '',
          base: func.base || '',
          contrato: func.contrato || '',
          data_nascimento: func.data_nascimento || '',
          data_admissao: func.data_admissao || '',
          aeronaves_qualificadas: [],
          cma_numero: func.cma_numero || '',
          cma_data_vencimento: func.cma_data_vencimento || '',
          aso_data_vencimento: func.aso_data_vencimento || '',
          nivel_icao: func.nivel_icao || '',
          nivel_icao_data_vencimento: func.nivel_icao_data_vencimento || ''
        });
      }
    } catch (error) {
      console.error('Erro ao carregar dados do funcionário:', error);
    }
  };

  const carregarFuncoes = async () => {
    try {
      const response = await fetch('/api/v2/funcoes');
      const data = await response.json();
      if (data.success) {
        setFuncoes(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar funções:', error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nome.trim() || !formData.matricula.trim()) {
      alert('Por favor, preencha os campos obrigatórios (Nome e Matrícula).');
      return;
    }

    try {
      await onSubmit(formData);
    } catch (error) {
      console.error('Erro ao salvar funcionário:', error);
      alert('Erro ao salvar funcionário. Tente novamente.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="p-6">
        {/* Seção 1: Informações Pessoais */}
        <div className="space-y-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center border-b border-gray-200 pb-2">
            <User className="w-5 h-5 mr-2 text-blue-600" />
            Informações Pessoais
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome Completo *
              </label>
              <input
                type="text"
                name="nome"
                value={formData.nome}
                onChange={handleInputChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: Nome do Funcionário"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome de Guerra
              </label>
              <input
                type="text"
                name="guerra"
                value={formData.guerra}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: Nome Funcionário"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Matrícula *
              </label>
              <input
                type="text"
                name="matricula"
                value={formData.matricula}
                onChange={handleInputChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: 300"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                CPF
              </label>
              <input
                type="text"
                name="cpf"
                value={formData.cpf}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="000.000.000-00"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data de Nascimento
                <span className="text-xs text-gray-500 ml-1">(DD/MM/AAAA)</span>
              </label>
              <input
                type="text"
                name="data_nascimento"
                value={formData.data_nascimento}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="dd/mm/aaaa"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data de Admissão
                <span className="text-xs text-gray-500 ml-1">(DD/MM/AAAA)</span>
              </label>
              <input
                type="text"
                name="data_admissao"
                value={formData.data_admissao}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="dd/mm/aaaa"
              />
            </div>
          </div>
        </div>

        {/* Seção 2: Contato */}
        <div className="space-y-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center border-b border-gray-200 pb-2">
            <Mail className="w-5 h-5 mr-2 text-green-600" />
            Informações de Contato
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="funcionario@empresa.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Telefone
              </label>
              <input
                type="tel"
                name="telefone"
                value={formData.telefone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="(11) 99999-9999"
              />
            </div>
          </div>
        </div>

        {/* Seção 3: Função e Status */}
        <div className="space-y-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center border-b border-gray-200 pb-2">
            <Building className="w-5 h-5 mr-2 text-indigo-600" />
            Função e Status Profissional
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Função
              </label>
              <select
                name="funcao"
                value={formData.funcao}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Selecione uma função</option>
                {funcoes.map((funcao) => (
                  <option key={funcao.nome} value={funcao.nome}>
                    {funcao.nome}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Base
              </label>
              <input
                type="text"
                name="base"
                value={formData.base}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: SBSP"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Contrato
              </label>
              <input
                type="text"
                name="contrato"
                value={formData.contrato}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: CLT"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="ATIVO">Ativo</option>
                <option value="INATIVO">Inativo</option>
                <option value="LICENCA">Licença</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="max-w-sm">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Aeronaves Qualificadas
              </label>
              <AeronaveMultiSelect
                value={formData.aeronaves_qualificadas || []}
                onChange={(value) => setFormData(prev => ({ ...prev, aeronaves_qualificadas: value }))}
                className="w-full"
                placeholder="Selecione aeronaves qualificadas"
              />
            </div>
          </div>
        </div>

        {/* Seção 4: Certificações e Códigos */}
        <div className="space-y-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center border-b border-gray-200 pb-2">
            <FileText className="w-5 h-5 mr-2 text-purple-600" />
            Certificações e Códigos Regulamentares
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Código ANAC
              </label>
              <input
                type="text"
                name="codigo_canac"
                value={formData.codigo_canac}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: 951681"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Código SISPAT
              </label>
              <input
                type="text"
                name="codigo_sispat"
                value={formData.codigo_sispat}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: 47700622"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Código PRESTSERV
              </label>
              <input
                type="text"
                name="codigo_prestserv"
                value={formData.codigo_prestserv}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: 4600669316"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Licença Aeronáutica
              </label>
              <input
                type="text"
                name="licenca_aeronautica"
                value={formData.licenca_aeronautica}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: PCH 01671"
              />
            </div>
          </div>
        </div>

        {/* Seção 5: Exames Médicos */}
        <div className="space-y-6">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center border-b border-gray-200 pb-2">
            <Shield className="w-5 h-5 mr-2 text-red-600" />
            Exames Médicos e Certificações de Saúde
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Número CMA
              </label>
              <input
                type="text"
                name="cma_numero"
                value={formData.cma_numero}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: CMA123456"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Vencimento CMA
                <span className="text-xs text-gray-500 ml-1">(DD/MM/AAAA)</span>
              </label>
              <input
                type="text"
                name="cma_data_vencimento"
                value={formData.cma_data_vencimento}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="dd/mm/aaaa"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Vencimento ASO
                <span className="text-xs text-gray-500 ml-1">(DD/MM/AAAA)</span>
              </label>
              <input
                type="text"
                name="aso_data_vencimento"
                value={formData.aso_data_vencimento}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="dd/mm/aaaa"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nível ICAO
              </label>
              <input
                type="text"
                name="nivel_icao"
                value={formData.nivel_icao}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: Nível 4"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Vencimento ICAO
                <span className="text-xs text-gray-500 ml-1">(DD/MM/AAAA)</span>
              </label>
              <input
                type="text"
                name="nivel_icao_data_vencimento"
                value={formData.nivel_icao_data_vencimento}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="dd/mm/aaaa"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Footer com Ações */}
      <div className="px-6 py-4 border-t border-gray-200 flex justify-end space-x-3 bg-gray-50">
        <Button 
          type="button" 
          variant="ghost" 
          onClick={onCancel}
          disabled={loading}
        >
          Cancelar
        </Button>
        <Button 
          type="submit" 
          variant="primary"
          disabled={loading}
        >
          {loading ? 'Salvando...' : funcionario ? 'Atualizar Funcionário' : 'Criar Funcionário'}
        </Button>
      </div>
    </form>
  );
};

export default FuncionarioFormUnified;
