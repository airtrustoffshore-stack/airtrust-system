// Estrutura hierárquica da navegação - Fonte única da verdade
export interface NavigationStructure {
  main_menu: MainMenuItem[];
  settings_menu: SettingsMenuItem[];
}

export interface MainMenuItem {
  id: string;
  label: string;
  icon: string;
  path?: string;
  expandable: boolean;
  children?: SubMenuItem[];
  badge?: string;
}

export interface SubMenuItem {
  id: string;
  label: string;
  path: string;
  badge?: string;
}

export interface SettingsMenuItem {
  category: string;
  items: SettingsItem[];
}

export interface SettingsItem {
  id: string;
  label: string;
  path: string;
  component: string;
  description: string;
  permissions_required?: string[];
}

// Configuração da nova IA (baseada nas imagens de referência)
export const NAVIGATION_CONFIG: NavigationStructure = {
  main_menu: [
    { 
      id: 'dashboard', 
      label: 'Dashboard', 
      icon: 'BarChart3', 
      path: '/', 
      expandable: false 
    },
    { 
      id: 'treinamentos', 
      label: 'Treinamentos', 
      icon: 'BookOpen', 
      path: '/treinamentos', 
      expandable: false 
    },
    {
      id: 'pessoas',
      label: 'Pessoas',
      icon: 'Users',
      expandable: true,
      children: [
        { 
          id: 'funcionarios', 
          label: 'Funcionários', 
          path: '/funcionarios' 
        },
        { 
          id: 'pasta-virtual', 
          label: 'Pasta Virtual', 
          path: '/pasta-virtual' 
        }
      ]
    },
    {
      id: 'escalas',
      label: 'Escalas e FRMS',
      icon: 'Calendar',
      expandable: true,
      children: [
        { 
          id: 'escalas', 
          label: 'Planejamento de Escala', 
          path: '/escalas', 
          badge: 'EM BREVE' 
        },
        { 
          id: 'frms', 
          label: 'FRMS', 
          path: '/frms', 
          badge: 'EM BREVE' 
        }
      ]
    },
    { 
      id: 'simuladores', 
      label: 'Simuladores', 
      icon: 'Calendar', 
      path: '/simuladores', 
      expandable: false 
    },
    { 
      id: 'minhas-assinaturas', 
      label: 'Minhas Assinaturas', 
      icon: 'CheckCircle', 
      path: '/minhas-assinaturas', 
      expandable: false 
    },
    { 
      id: 'hospedagem', 
      label: 'Hospedagem', 
      icon: 'Building', 
      path: '/hospedagem', 
      expandable: false, 
      badge: 'EM BREVE' 
    }
  ],
  settings_menu: [
    {
      category: 'Cadastros',
      items: [
        {
          id: 'funcoes',
          label: 'Gestão de Funções',
          path: '/configuracoes/funcoes',
          component: 'FuncoesManagement',
          description: 'Gerenciar cargos e funções da organização',
          permissions_required: ['admin']
        },
        {
          id: 'catalogo-treinamentos',
          label: 'Catálogo de Treinamentos',
          path: '/configuracoes/catalogo-treinamentos',
          component: 'CatalogoManagement',
          description: 'Gerenciar tipos de treinamento disponíveis',
          permissions_required: ['admin', 'manager']
        },
        {
          id: 'catalogo-aeronaves',
          label: 'Catálogo de Aeronaves',
          path: '/configuracoes/aeronaves',
          component: 'AeronavesCRUD',
          description: 'Gerenciar aeronaves da frota',
          permissions_required: ['admin']
        },
        
      ]
    },
    {
      category: 'Sistema',
      items: [
        {
          id: 'usuarios',
          label: 'Usuários e Permissões',
          path: '/configuracoes/usuarios',
          component: 'UserManagement',
          description: 'Gerenciar usuários e suas permissões',
          permissions_required: ['admin']
        },
        {
          id: 'auditoria',
          label: 'Logs de Auditoria',
          path: '/configuracoes/auditoria',
          component: 'AuditLogs',
          description: 'Visualizar logs de auditoria do sistema',
          permissions_required: ['admin']
        }
      ]
    }
  ]
};
