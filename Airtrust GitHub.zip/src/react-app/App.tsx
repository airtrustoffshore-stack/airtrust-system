import { BrowserRouter as Router, Routes, Route } from "react-router";
import Layout from "@/react-app/components/Layout";

// Import components directly for critical functionality (removing problematic lazy loading)
import Dashboard from "@/react-app/pages/Dashboard";
import Funcionarios from "@/react-app/pages/Funcionarios";
import Funcoes from "@/react-app/pages/Funcoes";
import Sistema from "@/react-app/pages/Sistema";
import PastaVirtual from "@/react-app/pages/PastaVirtual";
import PastaVirtualLanding from "@/react-app/pages/PastaVirtualLanding";
import DashboardTreinamentos from "@/react-app/pages/DashboardTreinamentos";
import CertificacoesList from "@/react-app/components/treinamentos/CertificacoesList";
import ComplianceMatrix from "@/react-app/components/compliance/ComplianceMatrix";
import Aeronaves from "@/react-app/pages/Aeronaves";
import ImportCSV from "@/react-app/pages/ImportCSV";
import ConfiguracoesLayout from "@/react-app/pages/ConfiguracoesLayout";
import Simuladores from "@/react-app/pages/Simuladores";
import SimuladoresAdmin from "@/react-app/pages/SimuladoresAdmin";
import AgendarSimulador from "@/react-app/pages/AgendarSimulador";
import MinhasAssinaturas from "@/react-app/pages/MinhasAssinaturas";
import SimuladoresTemplates from "@/react-app/pages/SimuladoresTemplates";
import VisualizarFichaSimulador from "@/react-app/pages/VisualizarFichaSimulador";
import AvaliarFichaSimulador from "@/react-app/pages/AvaliarFichaSimulador";
import EditarFichaSimulador from "@/react-app/pages/EditarFichaSimulador";
import Agendamento from "@/react-app/pages/Agendamento";
import AvaliarFicha from "@/react-app/pages/AvaliarFicha";
import Templates from "@/react-app/pages/simuladores/Templates";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="funcionarios" element={<Funcionarios />} />
          <Route path="funcionarios/:funcionarioId/pasta" element={<PastaVirtual />} />
          <Route path="pasta-virtual/:funcionarioId" element={<PastaVirtual />} />
          <Route path="pasta-virtual" element={<PastaVirtualLanding />} />
          <Route path="funcoes" element={<Funcoes />} />
          <Route path="sistema" element={<Sistema />} />
          <Route path="treinamentos" element={<DashboardTreinamentos />} />
          <Route path="treinamentos/certificacoes" element={<CertificacoesList />} />
          <Route path="treinamentos/matriz-compliance" element={<ComplianceMatrix />} />
          <Route path="aeronaves" element={<Aeronaves />} />
          <Route path="import-csv" element={<ImportCSV />} />
          <Route path="simuladores" element={<Simuladores />} />
          <Route path="simuladores/agendamento" element={<AgendarSimulador />} />
          <Route path="simuladores/templates" element={<Templates />} />
          <Route path="agendamento" element={<Agendamento />} />
          <Route path="simuladores-templates" element={<SimuladoresTemplates />} />
          <Route path="simuladores-agendamento-avancado" element={<AgendarSimulador />} />
          <Route path="simulador/agendar" element={<AgendarSimulador />} />
          <Route path="visualizar-ficha-simulador/:uuid" element={<VisualizarFichaSimulador />} />
          <Route path="editar-ficha-simulador/:uuid" element={<EditarFichaSimulador />} />
          <Route path="avaliar-ficha-simulador/:uuid" element={<AvaliarFichaSimulador />} />
          <Route path="simulador/ficha/:uuid/visualizar" element={<VisualizarFichaSimulador />} />
          <Route path="simulador/ficha/:uuid/avaliar" element={<AvaliarFichaSimulador />} />
          <Route path="simulador/ficha/:uuid/editar" element={<EditarFichaSimulador />} />
          <Route path="avaliar-ficha/:fichaUuid" element={<AvaliarFicha />} />
          <Route path="admin/simuladores" element={<SimuladoresAdmin />} />
          <Route path="minhas-assinaturas" element={<MinhasAssinaturas />} />
        </Route>
        <Route path="/configuracoes/*" element={<ConfiguracoesLayout />} />
      </Routes>
    </Router>
  );
}
