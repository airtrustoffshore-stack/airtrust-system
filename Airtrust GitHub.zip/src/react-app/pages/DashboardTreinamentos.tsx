import React, { useState } from 'react';
import { BarChart3, Users, CheckCircle, Grid3X3, Upload, Download } from 'lucide-react';
import Button from '../components/Button';
import CatalogoManagement from '../components/treinamentos/CatalogoManagement';
import CertificacoesList from '../components/treinamentos/CertificacoesList';
import ComplianceMatrix from '../components/compliance/ComplianceMatrix';
import StatusCertificacoes from '../components/treinamentos/StatusCertificacoes';
import TreinamentosCriticos from '../components/treinamentos/TreinamentosCriticos';
import RastreabilidadeDocumental from '../components/treinamentos/RastreabilidadeDocumental';
import ImportarCertificacoesModal from '../components/shared/CertificacoesImportModal';
import AdvancedImportModal from '../components/shared/AdvancedImportModal';
import BackupRestoreModal from '../components/shared/BackupRestoreModal';

const DashboardTreinamentos: React.FC = () => {
  // Verificar se há parâmetros de URL para definir aba ativa
  const urlParams = new URLSearchParams(window.location.search);
  const tabParam = urlParams.get('tab');
  const [activeTab, setActiveTab] = useState(tabParam || 'visao-geral');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isImportCertModalOpen, setIsImportCertModalOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [importMode, setImportMode] = useState<'catalog' | 'history'>('catalog');

  const tabs = [
    { id: 'visao-geral', label: 'Visão Geral', icon: BarChart3 },
    { id: 'treinamentos', label: 'Treinamentos', icon: Users },
    { id: 'certificacoes', label: 'Certificações', icon: CheckCircle },
    { id: 'matriz-compliance', label: 'Matriz de Compliance', icon: Grid3X3 }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'visao-geral':
        return (
          <div className="space-y-6">
            <StatusCertificacoes />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <TreinamentosCriticos />
              <RastreabilidadeDocumental />
            </div>
          </div>
        );
      case 'treinamentos':
        return <CatalogoManagement />;
      case 'certificacoes':
        console.log('🎯 Rendering CertificacoesList component');
        return (
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Lista de Certificações</h3>
            <CertificacoesList />
          </div>
        );
      case 'matriz-compliance':
        return <ComplianceMatrix />;
      default:
        return null;
    }
  };

  return (
    <div className="import-container">
      {/* Header Principal */}
      <div className="import-header">
        <div>
          <h1 className="import-title">
            Gestão de Treinamentos e Certificações
          </h1>
          <p className="text-gray-600 mt-2">
            Sistema completo de gestão de treinamentos, certificações e compliance
          </p>
        </div>
        
        {/* BOTÕES CENTRALIZADOS - ÚNICOS NO SISTEMA */}
        <div className="flex gap-3">
          <Button 
            variant="secondary" 
            className="text-sm"
            onClick={() => {
              setImportMode('catalog');
              setIsImportModalOpen(true);
            }}
          >
            <Upload className="w-4 h-4 mr-2" />
            Importar Treinamentos
          </Button>
          
          <Button 
            variant="secondary" 
            className="text-sm"
            onClick={() => setIsImportCertModalOpen(true)}
          >
            <Upload className="w-4 h-4 mr-2" />
            Importar Certificações
          </Button>
          
          <Button 
            variant="secondary" 
            className="text-sm"
            onClick={() => setIsBackupModalOpen(true)}
          >
            <Download className="w-4 h-4 mr-2" />
            Backup/Restore
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="list-section">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap flex items-center gap-2 ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Conteúdo das Abas */}
        <div className="p-6">
          {renderTabContent()}
        </div>
        
        {/* Debug: Mostrar aba ativa */}
        <div className="hidden">Debug: Active tab = {activeTab}</div>
      </div>

      {/* Modais */}
      <AdvancedImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onSuccess={() => setIsImportModalOpen(false)}
        mode={importMode}
        title={importMode === 'catalog' ? 'Importar Treinamentos via CSV' : 'Importar Certificações via CSV'}
        description="Importe dados usando arquivo CSV com validação avançada"
      />

      <ImportarCertificacoesModal
        isOpen={isImportCertModalOpen}
        onClose={() => setIsImportCertModalOpen(false)}
        onSuccess={() => {
          setIsImportCertModalOpen(false);
          // Refresh data if needed
        }}
      />

      <BackupRestoreModal
        isOpen={isBackupModalOpen}
        onClose={() => setIsBackupModalOpen(false)}
      />
    </div>
  );
};

export default DashboardTreinamentos;
