import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Calendar, List, Eye, Clock, Users, Settings, FileText, Edit, ClipboardCheck } from 'lucide-react';

import Button from '../components/Button';
import Modal from '../components/Modal';
import Card from '../components/Card';
import SimuladoresAdmin from './SimuladoresAdmin';
import EditSlotModal from '../components/simuladores/EditSlotModal';
import AvaliacaoManobras from '../components/simuladores/AvaliacaoManobras';
import FormularioAgendamentoUnico from '../components/simuladores/FormularioAgendamentoUnico';
import DebugPanel from '../components/simuladores/DebugPanel';

interface AgendamentoSlot {
  id: number;
  simulador_id: number;
  simulador_nome: string;
  colaborador_id_instrutor: number;
  instrutor_nome: string;
  colaborador_id_checador?: number;
  checador_nome?: string;
  data_inicio: string;
  data_fim: string;
  status_slot: string;
  fichas: FichaSessao[];
}

interface FichaSessao {
  id: number;
  ficha_uuid: string;
  colaborador_id_aluno: number;
  aluno_nome: string;
  aluno_matricula: string;
  funcao_na_sessao: string;
  template_nome: string;
  ciclo_executado: number;
  status_workflow: string;
}

interface Simulador {
  id: number;
  nome: string;
  codigo_identificacao: string;
  status: string;
}

interface Funcionario {
  id: number;
  nome: string;
  matricula: string;
  is_instrutor: boolean;
  is_checador: boolean;
}



interface UserProfile {
  perfil: 'ADMIN' | 'COMPLIANCE' | 'GESTOR' | 'FUNCIONARIO';
}

const Simuladores: React.FC = () => {
  const navigate = useNavigate();
  
  // Main tab state
  const [activeTab, setActiveTab] = useState<'agenda' | 'fichas' | 'cadastro'>('agenda');
  
  // Calendar view state
  const [activeView, setActiveView] = useState<'calendar' | 'list'>('calendar');
  const [slots, setSlots] = useState<AgendamentoSlot[]>([]);
  const [simuladores, setSimuladores] = useState<Simulador[]>([]);
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [modalAgendamentoUnico, setModalAgendamentoUnico] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<AgendamentoSlot | null>(null);
  const [showAvaliacaoModal, setShowAvaliacaoModal] = useState(false);
  const [selectedFichaUuid, setSelectedFichaUuid] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // User profile for RBAC
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  

  useEffect(() => {
    loadUserProfile();
  }, []);

  useEffect(() => {
    if (activeTab === 'agenda' && userProfile) {
      loadData();
    }
  }, [activeTab, userProfile]);

  const loadUserProfile = async () => {
    try {
      const response = await fetch('/api/v2/auth/profile');
      const data = await response.json();
      if (data.success) {
        setUserProfile(data.data);
      } else {
        // Default to ADMIN if profile fails to load for demo
        setUserProfile({ perfil: 'ADMIN' });
      }
    } catch (error) {
      console.error('Erro ao carregar perfil:', error);
      // Default to ADMIN if profile fails to load for demo
      setUserProfile({ perfil: 'ADMIN' });
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      console.log('🔄 Carregando dados do simulador...');
      
      const [slotsRes, simuladoresRes, funcionariosRes] = await Promise.all([
        fetch('/api/v2/simulador/slots'),
        fetch('/api/v2/simuladores/listar'),
        fetch('/api/v2/funcionarios')
      ]);

      console.log('📊 Status das respostas:', {
        slots: slotsRes.status,
        simuladores: simuladoresRes.status,
        funcionarios: funcionariosRes.status
      });

      const [slotsData, simuladoresData, funcionariosData] = await Promise.all([
        slotsRes.json(),
        simuladoresRes.json(),
        funcionariosRes.json()
      ]);

      console.log('✅ Dados carregados:', {
        slots: slotsData.slots?.length || 0,
        simuladores: simuladoresData.data?.length || 0,
        funcionarios: funcionariosData.funcionarios?.length || 0
      });

      setSlots(slotsData.slots || []);
      setSimuladores(simuladoresData.data || []);
      setFuncionarios(funcionariosData.funcionarios || funcionariosData.data || []);
      
      // ✅ LOG DETALHADO DOS SLOTS CARREGADOS
      console.log('📋 Slots carregados detalhados:', slotsData.slots?.map((s: any) => ({
        id: s.id,
        simulador: s.simulador_nome,
        instrutor: s.instrutor_nome,
        fichas_count: s.fichas?.length || 0,
        participantes: s.fichas?.map((f: any) => f.aluno_nome) || []
      })));
      
    } catch (error) {
      console.error('❌ Erro ao carregar dados:', error);
    } finally {
      console.log('🏁 Finalizando carregamento...');
      setLoading(false);
    }
  };

  

  // ✅ CORREÇÃO 5: REFRESH AUTOMÁTICO APÓS AGENDAR
  const handleSalvarAgendamentoUnico = async (dadosAgendamento: any) => {
    try {
      console.log('📤 Enviando agendamento:', dadosAgendamento);
      
      const response = await fetch('/api/v2/simulador/agendamento', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dadosAgendamento)
      });
      
      const resultado = await response.json();
      
      if (resultado.success) {
        console.log('✅ Agendamento criado:', resultado);
        
        // ✅ FORÇAR RECARREGAMENTO DA LISTA
        await loadData();
        
        // ✅ FECHAR MODAL E MOSTRAR SUCESSO
        setModalAgendamentoUnico(false);
        alert(`Sessão agendada com sucesso! ${resultado.participantes_count || 0} participantes`);
        
      } else {
        throw new Error(resultado.error || 'Erro desconhecido');
      }
      
    } catch (error) {
      console.error('❌ Erro ao agendar:', error);
      alert(`Erro ao agendar sessão: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    }
  };

  // ✅ CORREÇÃO 2: FUNÇÃO PARA EXCLUIR SESSÃO
  const handleExcluirSessao = async (slotId: number) => {
    if (!confirm('Tem certeza que deseja excluir esta sessão? Esta ação não pode ser desfeita.')) {
      return;
    }

    try {
      console.log('🗑️ Excluindo sessão:', slotId);
      
      const response = await fetch(`/api/v2/simulador/agendamento/${slotId}`, {
        method: 'DELETE'
      });
      
      const resultado = await response.json();
      
      if (resultado.success) {
        console.log('✅ Sessão excluída:', resultado);
        
        // ✅ RECARREGAR LISTA APÓS EXCLUSÃO
        await loadData();
        alert(resultado.message || 'Sessão excluída com sucesso!');
        
      } else {
        throw new Error(resultado.error || 'Erro ao excluir sessão');
      }
      
    } catch (error) {
      console.error('❌ Erro ao excluir:', error);
      alert(`Erro ao excluir sessão: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    }
  };

  const handleEditSlot = (slot: AgendamentoSlot) => {
    setSelectedSlot(slot);
    setShowEditModal(true);
  };

  const handleSlotUpdated = () => {
    loadData();
    setShowEditModal(false);
    setSelectedSlot(null);
  };

  // CORREÇÃO 3: FRONTEND - CORRIGIR NAVEGAÇÃO DOS BOTÕES
  const handleVisualizarFicha = (fichaUuid: string) => {
    console.log('👁️ Visualizar ficha:', fichaUuid);
    
    if (!fichaUuid || fichaUuid === 'undefined') {
      alert('UUID da ficha inválido');
      return;
    }
    
    // ✅ NAVEGAR PARA ROTA CORRETA
    navigate(`/visualizar-ficha-simulador/${fichaUuid}`);
  };

  const handleEditarFicha = (fichaUuid: string, statusWorkflow: string) => {
    console.log('✏️ Editar ficha:', fichaUuid, 'Status:', statusWorkflow);
    
    if (!fichaUuid || fichaUuid === 'undefined') {
      alert('UUID da ficha inválido');
      return;
    }
    
    // ✅ VALIDAR STATUS EDITÁVEL
    const statusEditaveis = ['RASCUNHO', 'PENDENTE_ALUNO', 'EM_ANDAMENTO'];
    if (!statusEditaveis.includes(statusWorkflow)) {
      alert(`Esta ficha não pode ser editada no status: ${statusWorkflow}`);
      return;
    }
    
    navigate(`/editar-ficha-simulador/${fichaUuid}`);
  };

  const handleAvaliarFicha = (fichaUuid: string) => {
    console.log('📋 Avaliar ficha:', fichaUuid);
    
    if (!fichaUuid || fichaUuid === 'undefined') {
      alert('UUID da ficha inválido');
      return;
    }
    
    navigate(`/avaliar-ficha-simulador/${fichaUuid}`);
  };

  const podeEditarFicha = (statusWorkflow: string) => {
    const statusEditaveis = ['RASCUNHO', 'PENDENTE_ALUNO'];
    return statusEditaveis.includes(statusWorkflow);
  };

  const handleAvaliacaoClose = () => {
    setShowAvaliacaoModal(false);
    setSelectedFichaUuid(null);
    loadData(); // Recarregar dados após avaliação
  };

  

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'AGENDADO': return 'bg-blue-100 text-blue-800';
      case 'EM_ANDAMENTO': return 'bg-yellow-100 text-yellow-800';
      case 'CONCLUIDO': return 'bg-green-100 text-green-800';
      case 'CANCELADO': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getWorkflowColor = (status: string) => {
    switch (status) {
      case 'RASCUNHO': return 'bg-gray-100 text-gray-800';
      case 'PENDENTE_ALUNO': return 'bg-yellow-100 text-yellow-800';
      case 'PENDENTE_INSTRUTOR_FINAL': return 'bg-orange-100 text-orange-800';
      case 'PENDENTE_CHECK': return 'bg-purple-100 text-purple-800';
      case 'CONCLUIDA': return 'bg-green-100 text-green-800';
      case 'REPROVADA': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Check if user can see admin tabs
  const canAccessAdmin = userProfile?.perfil === 'ADMIN';
  const canAccessManagement = userProfile?.perfil === 'ADMIN' || userProfile?.perfil === 'GESTOR';

  const renderCalendarView = () => {
    const groupedByDate = slots.reduce((acc, slot) => {
      const dateObj = slot.data_inicio ? new Date(slot.data_inicio) : new Date();
      const date = isNaN(dateObj.getTime()) ? new Date().toDateString() : dateObj.toDateString();
      if (!acc[date]) acc[date] = [];
      acc[date].push(slot);
      return acc;
    }, {} as Record<string, AgendamentoSlot[]>);

    return (
      <div className="space-y-6">
        {Object.entries(groupedByDate).map(([date, daySlots]) => (
          <Card key={date} className="p-6">
            <h3 className="text-lg font-semibold mb-4">
              {new Date(date).toLocaleDateString('pt-BR', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </h3>
            
            <div className="space-y-4">
              {daySlots.map(slot => (
                <div key={slot.id} className="border rounded-lg p-4 bg-gray-50">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="font-semibold">{slot.simulador_nome}</h4>
                      <p className="text-sm text-gray-600">
                        <Clock className="w-4 h-4 inline mr-1" />
                        {slot.data_inicio ? new Date(slot.data_inicio).toLocaleString('pt-BR', { 
                          day: '2-digit', 
                          month: '2-digit', 
                          year: 'numeric',
                          hour: '2-digit', 
                          minute: '2-digit' 
                        }) : 'Data não disponível'} - 
                        {slot.data_fim ? new Date(slot.data_fim).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : 'N/A'}
                      </p>
                      <p className="text-sm text-gray-600">
                        <Users className="w-4 h-4 inline mr-1" />
                        Instrutor: {slot.instrutor_nome}
                        {slot.checador_nome && ` | Checador: ${slot.checador_nome}`}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded text-sm ${getStatusColor(slot.status_slot)}`}>
                        {slot.status_slot}
                      </span>
                      {canAccessManagement && (
                        <div className="flex space-x-1">
                          <Button variant="secondary" size="sm" onClick={() => handleEditSlot(slot)} title="Editar sessão">
                            <Edit className="w-3 h-3" />
                          </Button>
                          {/* ✅ CORREÇÃO 2: BOTÃO DELETAR SESSÃO */}
                          <Button 
                            variant="secondary" 
                            size="sm" 
                            onClick={() => handleExcluirSessao(slot.id)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            title="Excluir sessão"
                          >
                            🗑️
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>

                  {slot.fichas.length > 0 && (
                    <div className="border-t pt-3">
                      <h5 className="font-medium mb-2">Participantes:</h5>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {slot.fichas.map(ficha => (
                          <div key={ficha.id} className="bg-white border rounded p-3">
                            <div className="flex justify-between items-start">
                              <div>
                                <p className="font-medium">{ficha.aluno_nome}</p>
                                <p className="text-sm text-gray-600">
                                  {ficha.funcao_na_sessao} | Ciclo {ficha.ciclo_executado}
                                </p>
                                <p className="text-sm text-gray-600">{ficha.template_nome}</p>
                              </div>
                              <div className="text-right">
                                <span className={`px-2 py-1 rounded text-xs ${getWorkflowColor(ficha.status_workflow)}`}>
                                  {ficha.status_workflow}
                                </span>
                                <p className="text-xs text-gray-500 mt-1">{ficha.ficha_uuid}</p>
                                <div className="mt-2 flex space-x-1">
                                  <Button size="sm" variant="secondary" onClick={() => handleVisualizarFicha(ficha.ficha_uuid)} title="Visualizar ficha">
                                    <Eye className="w-3 h-3" />
                                  </Button>
                                  {podeEditarFicha(ficha.status_workflow) && (
                                    <Button size="sm" onClick={() => handleEditarFicha(ficha.ficha_uuid, ficha.status_workflow)} title="Editar ficha">
                                      <Edit className="w-3 h-3" />
                                    </Button>
                                  )}
                                  <Button size="sm" variant="secondary" onClick={() => handleAvaliarFicha(ficha.ficha_uuid)} title="Avaliar manobras">
                                    <ClipboardCheck className="w-3 h-3" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Card>
        ))}
        
        {Object.keys(groupedByDate).length === 0 && (
          <Card className="p-8 text-center">
            <Calendar className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-600">Nenhuma sessão agendada</p>
          </Card>
        )}
      </div>
    );
  };

  const renderListView = () => {
    const allFichas = slots.flatMap(slot => 
      slot.fichas.map(ficha => ({
        ...ficha,
        slot_info: {
          simulador_nome: slot.simulador_nome,
          instrutor_nome: slot.instrutor_nome,
          data_inicio: slot.data_inicio,
          data_fim: slot.data_fim
        }
      }))
    );

    return (
      <div className="space-y-4">
        {allFichas.map(ficha => (
          <Card key={ficha.id} className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-semibold">{ficha.ficha_uuid}</h4>
                <p className="text-gray-900">{ficha.aluno_nome} ({ficha.aluno_matricula})</p>
                <p className="text-gray-600">
                  {ficha.slot_info.simulador_nome} | {ficha.funcao_na_sessao} | Ciclo {ficha.ciclo_executado}
                </p>
                <p className="text-gray-600">{ficha.template_nome}</p>
                <p className="text-sm text-gray-500">
                  {ficha.slot_info.data_inicio ? new Date(ficha.slot_info.data_inicio).toLocaleString('pt-BR', {
                    day: '2-digit',
                    month: '2-digit', 
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  }) : 'Data não disponível'}
                </p>
              </div>
              <div className="text-right">
                <span className={`px-2 py-1 rounded text-sm ${getWorkflowColor(ficha.status_workflow)}`}>
                  {ficha.status_workflow}
                </span>
                <div className="mt-2 flex space-x-2">
                  <Button variant="secondary" size="sm" onClick={() => handleVisualizarFicha(ficha.ficha_uuid)}>
                    <Eye className="w-4 h-4 mr-1" />
                    Visualizar
                  </Button>
                  {podeEditarFicha(ficha.status_workflow) && (
                    <Button size="sm" onClick={() => handleEditarFicha(ficha.ficha_uuid, ficha.status_workflow)}>
                      <Edit className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </Card>
        ))}
        
        {allFichas.length === 0 && (
          <Card className="p-8 text-center">
            <List className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-600">Nenhuma ficha encontrada</p>
          </Card>
        )}
      </div>
    );
  };

  const renderFichasTab = () => {
    const allFichas = slots.flatMap(slot => 
      slot.fichas.map(ficha => ({
        ...ficha,
        slot_info: {
          simulador_nome: slot.simulador_nome,
          instrutor_nome: slot.instrutor_nome,
          data_inicio: slot.data_inicio,
          data_fim: slot.data_fim
        }
      }))
    );

    const fichasByStatus = allFichas.reduce((acc, ficha) => {
      if (!acc[ficha.status_workflow]) acc[ficha.status_workflow] = [];
      acc[ficha.status_workflow].push(ficha);
      return acc;
    }, {} as Record<string, typeof allFichas>);

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(fichasByStatus).map(([status, fichas]) => (
            <Card key={status} className="p-4 text-center">
              <div className={`text-2xl font-bold ${getWorkflowColor(status).replace('bg-', 'text-').replace('-100', '-600')}`}>
                {fichas.length}
              </div>
              <p className="text-sm text-gray-600 mt-1">{status}</p>
            </Card>
          ))}
        </div>

        <div className="space-y-4">
          {allFichas.map(ficha => (
            <Card key={ficha.id} className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-semibold">{ficha.ficha_uuid}</h4>
                  <p className="text-gray-900">{ficha.aluno_nome} ({ficha.aluno_matricula})</p>
                  <p className="text-gray-600">
                    {ficha.slot_info.simulador_nome} | {ficha.funcao_na_sessao} | Ciclo {ficha.ciclo_executado}
                  </p>
                  <p className="text-gray-600">{ficha.template_nome}</p>
                  <p className="text-sm text-gray-500">
                    {new Date(ficha.slot_info.data_inicio).toLocaleString('pt-BR')}
                  </p>
                  <p className="text-sm text-gray-500">
                    Instrutor: {ficha.slot_info.instrutor_nome}
                  </p>
                </div>
                <div className="text-right">
                  <span className={`px-2 py-1 rounded text-sm ${getWorkflowColor(ficha.status_workflow)}`}>
                    {ficha.status_workflow}
                  </span>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Button variant="secondary" size="sm" onClick={() => handleVisualizarFicha(ficha.ficha_uuid)}>
                      <Eye className="w-4 h-4 mr-1" />
                      Visualizar
                    </Button>
                    {podeEditarFicha(ficha.status_workflow) && (
                      <Button size="sm" onClick={() => handleEditarFicha(ficha.ficha_uuid, ficha.status_workflow)}>
                        <Edit className="w-4 h-4 mr-1" />
                        Editar
                      </Button>
                    )}
                    <Button variant="secondary" size="sm" onClick={() => handleAvaliarFicha(ficha.ficha_uuid)}>
                      <ClipboardCheck className="w-4 h-4 mr-1" />
                      Avaliar
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {allFichas.length === 0 && (
          <Card className="p-8 text-center">
            <FileText className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-600">Nenhuma ficha de sessão encontrada</p>
          </Card>
        )}
      </div>
    );
  };

  const renderAgendaTab = () => (
    <div>
      {/* View toggles e botão agendar */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => setActiveView('calendar')}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              activeView === 'calendar'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Calendar className="w-4 h-4 inline mr-2" />
            Calendário
          </button>
          <button
            onClick={() => setActiveView('list')}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              activeView === 'list'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <List className="w-4 h-4 inline mr-2" />
            Lista
          </button>
        </div>

        {canAccessManagement && (
          <div className="flex space-x-2">
            <Button onClick={() => setModalAgendamentoUnico(true)} className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
              <Users className="w-4 h-4 mr-2" />
              Agendar Sessão de Simulador
            </Button>
          </div>
        )}
      </div>

      {/* Conteúdo */}
      {loading ? (
        <div className="text-center py-8">Carregando...</div>
      ) : (
        <>
          {activeView === 'calendar' ? renderCalendarView() : renderListView()}
        </>
      )}
    </div>
  );

  const renderMainTabs = () => {
    const tabs = [
      { key: 'agenda', label: 'Agenda / Calendário', icon: Calendar, visible: canAccessManagement },
      { key: 'fichas', label: 'Fichas de Sessão', icon: FileText, visible: canAccessManagement },
      { key: 'cadastro', label: 'Cadastro', icon: Settings, visible: canAccessAdmin }
    ].filter(tab => tab.visible);

    return (
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          {tabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.key
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>
      </div>
    );
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'agenda':
        return renderAgendaTab();
      case 'fichas':
        return renderFichasTab();
      case 'cadastro':
        return canAccessAdmin ? <SimuladoresAdmin /> : null;
      default:
        return renderAgendaTab();
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Simuladores</h1>
        <p className="text-gray-600 mt-2">
          {activeTab === 'agenda' && 'Gerencie agendamentos e sessões de simulador'}
          {activeTab === 'fichas' && 'Acompanhe o status das fichas de sessão'}
          {activeTab === 'cadastro' && 'Configure simuladores, manobras e templates'}
        </p>
      </div>

      {/* Main Tabs */}
      {renderMainTabs()}

      {/* Tab Content */}
      {renderTabContent()}

      {/* Painel de Debug - DESENVOLVIMENTO */}
      {activeTab === 'agenda' && (
        <div className="mt-8 border-t pt-6">
          <DebugPanel />
        </div>
      )}

      {/* Modal de Agendamento Único */}
      <Modal
        isOpen={modalAgendamentoUnico}
        onClose={() => setModalAgendamentoUnico(false)}
        title="Agendar Sessão de Simulador"
        size="2xl"
      >
        <FormularioAgendamentoUnico
          onSalvar={handleSalvarAgendamentoUnico}
          onCancelar={() => setModalAgendamentoUnico(false)}
        />
      </Modal>

      {/* Modal de Edição de Slot */}
      <EditSlotModal
        isOpen={showEditModal}
        onClose={() => {
          setShowEditModal(false);
          setSelectedSlot(null);
        }}
        slot={selectedSlot}
        simuladores={simuladores}
        funcionarios={funcionarios}
        onSlotUpdated={handleSlotUpdated}
      />

      {/* Modal de Avaliação de Manobras */}
      <Modal
        isOpen={showAvaliacaoModal}
        onClose={handleAvaliacaoClose}
        title="Avaliação de Manobras"
      >
        {selectedFichaUuid && (
          <AvaliacaoManobras 
            fichaUuid={selectedFichaUuid} 
            onClose={handleAvaliacaoClose}
          />
        )}
      </Modal>
    </div>
  );
};

export default Simuladores;
