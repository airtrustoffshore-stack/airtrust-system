import { useState } from 'react';
import FuncoesManagement from '../components/admin/FuncoesManagement';
import ComplianceMatrix from '../components/compliance/ComplianceMatrix';

export default function Funcoes() {
  const [showMatriz, setShowMatriz] = useState(false);

  const handleMatrizCompliance = () => {
    setShowMatriz(true);
  };

  const handleBackToFuncoes = () => {
    setShowMatriz(false);
  };

  return (
    <div className="space-y-6">
      {!showMatriz ? (
        <>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Gestão de Funções
            </h1>
            <p className="text-gray-600 mt-2">
              Configure as funções organizacionais e suas responsabilidades
            </p>
          </div>
          <FuncoesManagement onMatrizCompliance={handleMatrizCompliance} />
        </>
      ) : (
        <>
          <div>
            <button
              onClick={handleBackToFuncoes}
              className="text-blue-600 hover:text-blue-800 mb-4 flex items-center transition-colors"
            >
              ← Voltar para Funções
            </button>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Matriz de Compliance
            </h1>
            <p className="text-gray-600 mt-2">
              Configure quais treinamentos são obrigatórios para cada função
            </p>
          </div>
          <ComplianceMatrix onBack={handleBackToFuncoes} />
        </>
      )}
    </div>
  );
}
