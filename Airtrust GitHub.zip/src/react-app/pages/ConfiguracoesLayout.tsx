import { Routes, Route, Navigate } from 'react-router';
import MasterDetailLayout from '../components/layouts/MasterDetailLayout';
import FuncoesManagement from '../components/admin/FuncoesManagement';
import CatalogoManagement from '../components/treinamentos/CatalogoManagement';
import AeronavesCRUD from './Aeronaves';

// Placeholder components para as páginas que ainda não existem
const UserManagement = () => (
  <div className="text-center py-12">
    <h2 className="text-xl font-semibold text-gray-900 mb-4">Usuários e Permissões</h2>
    <p className="text-gray-600">Esta funcionalidade estará disponível em breve.</p>
  </div>
);

const AuditLogs = () => (
  <div className="text-center py-12">
    <h2 className="text-xl font-semibold text-gray-900 mb-4">Logs de Auditoria</h2>
    <p className="text-gray-600">Esta funcionalidade estará disponível em breve.</p>
  </div>
);

export default function ConfiguracoesLayout() {
  return (
    <div className="ml-64">
      <MasterDetailLayout>
        <Routes>
          <Route path="/" element={<Navigate to="/configuracoes/funcoes" replace />} />
          <Route path="/funcoes" element={<FuncoesManagement />} />
          <Route path="/catalogo-treinamentos" element={<CatalogoManagement />} />
          <Route path="/aeronaves" element={<AeronavesCRUD />} />
          <Route path="/usuarios" element={<UserManagement />} />
          <Route path="/auditoria" element={<AuditLogs />} />
        </Routes>
      </MasterDetailLayout>
    </div>
  );
}
