import React, { useState, useEffect } from 'react';
import { Plus, Calendar, List, Edit, Trash2, Eye, Grid, Upload } from 'lucide-react';

import Button from '../components/Button';
import Modal from '../components/Modal';
import Card from '../components/Card';
import MatrizSessoesManobras from '../components/simuladores/MatrizSessoesManobras';

interface Simulador {
  id: number;
  nome: string;
  codigo_identificacao: string;
  tipo_simulador: string;
  aeronave_base: string;
  empresa_local: string;
  status: string;
}

interface Ciclo {
  id: number;
  numero_ciclo: number;
  nome: string;
  descricao?: string;
}

interface Manobra {
  id: number;
  manobra_id_codigo: string;
  nome_manobra: string;
  categoria: string;
  criterios_aprovacao?: string;
  pontuacao_minima: number;
  ativo: boolean;
  ciclos?: number[];
}

interface SessaoTemplate {
  id: number;
  treinamento_codigo: string;
  numero_sessao: number;
  nome_sessao: string;
  descricao?: string;
  manobras?: number[];
}

const SimuladoresAdmin: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'simuladores' | 'ciclos' | 'manobras' | 'sessoes' | 'matriz'>('simuladores');
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [modalType, setModalType] = useState<'create' | 'edit' | 'import'>('create');

  // Estados para cada entidade
  const [simuladores, setSimuladores] = useState<Simulador[]>([]);
  const [ciclos, setCiclos] = useState<Ciclo[]>([]);
  const [manobras, setManobras] = useState<Manobra[]>([]);
  const [sessoes, setSessoes] = useState<SessaoTemplate[]>([]);

  // Estados do formulário
  const [formData, setFormData] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');

  useEffect(() => {
    loadData();
  }, [activeTab]);

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      let endpoint = '';
      switch (activeTab) {
        case 'simuladores':
          endpoint = '/api/v2/simuladores/listar';
          break;
        case 'ciclos':
          endpoint = '/api/v2/simuladores/ciclos/listar';
          break;
        case 'manobras':
          endpoint = '/api/v2/simuladores/manobras/listar';
          break;
        case 'sessoes':
          endpoint = '/api/v2/simuladores/sessoes-template/listar';
          break;
        case 'matriz':
          // Para matriz, não carregamos dados aqui
          setLoading(false);
          return;
      }

      const response = await fetch(endpoint);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro ao carregar dados');
      }

      switch (activeTab) {
        case 'simuladores':
          setSimuladores(data.data || []);
          break;
        case 'ciclos':
          setCiclos(data.data || []);
          break;
        case 'manobras':
          setManobras(data.data || []);
          break;
        case 'sessoes':
          setSessoes(data.data || []);
          break;
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      setError(error instanceof Error ? error.message : 'Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = () => {
    setEditingItem(null);
    setFormData({});
    setModalType('create');
    setError('');
    setSuccess('');
    setShowModal(true);
  };

  const handleEdit = (item: any) => {
    setEditingItem(item);
    setFormData({ ...item });
    setModalType('edit');
    setError('');
    setSuccess('');
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir este item?')) return;

    setLoading(true);
    try {
      const endpoint = getEndpoint();
      const response = await fetch(`${endpoint}/${id}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setSuccess('Item excluído com sucesso');
        await loadData();
      } else {
        throw new Error(data.error || 'Erro ao excluir item');
      }
    } catch (error) {
      console.error('Erro ao excluir:', error);
      setError(error instanceof Error ? error.message : 'Erro ao excluir item');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // Validação básica
      if (activeTab === 'simuladores') {
        if (!formData.nome || !formData.codigo_identificacao || !formData.tipo_simulador || !formData.aeronave_base || !formData.empresa_local) {
          throw new Error('Preencha todos os campos obrigatórios');
        }
      } else if (activeTab === 'ciclos') {
        if (!formData.numero_ciclo || !formData.nome) {
          throw new Error('Preencha todos os campos obrigatórios');
        }
      } else if (activeTab === 'manobras') {
        if (!formData.manobra_id_codigo || !formData.nome_manobra || !formData.categoria) {
          throw new Error('Preencha todos os campos obrigatórios');
        }
      } else if (activeTab === 'sessoes') {
        if (!formData.treinamento_codigo || !formData.numero_sessao || !formData.nome_sessao) {
          throw new Error('Preencha todos os campos obrigatórios');
        }
      }

      const endpoint = getEndpoint();
      
      const response = await fetch(
        modalType === 'create' ? endpoint : `${endpoint}/${editingItem.id}`,
        {
          method: modalType === 'create' ? 'POST' : 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(formData)
        }
      );
      
      const data = await response.json();
      
      if (response.ok) {
        setSuccess(modalType === 'create' ? 'Item criado com sucesso!' : 'Item atualizado com sucesso!');
        setTimeout(() => {
          setShowModal(false);
          loadData();
        }, 1500);
      } else {
        throw new Error(data.error || `Erro ao ${modalType === 'create' ? 'criar' : 'atualizar'} item`);
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      setError(error instanceof Error ? error.message : 'Erro ao salvar item');
    } finally {
      setLoading(false);
    }
  };

  const handleImportCSV = async (file: File) => {
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/v2/simuladores/manobras-catalogo/import-csv', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();
      
      if (response.ok) {
        setSuccess(`Importação concluída! ${data.data?.processadas || 0} itens processados.`);
        setShowModal(false);
        await loadData();
      } else {
        throw new Error(data.error || 'Erro na importação');
      }
    } catch (error) {
      console.error('Erro na importação:', error);
      setError(error instanceof Error ? error.message : 'Erro na importação');
    } finally {
      setLoading(false);
    }
  };

  const getEndpoint = () => {
    switch (activeTab) {
      case 'simuladores': return '/api/v2/simuladores';
      case 'ciclos': return '/api/v2/simuladores/ciclos';
      case 'manobras': return '/api/v2/simuladores/manobras-catalogo';
      case 'sessoes': return '/api/v2/simuladores/sessoes-template';
      default: return '';
    }
  };

  const renderTabContent = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Carregando...</span>
        </div>
      );
    }

    switch (activeTab) {
      case 'simuladores':
        return renderSimuladores();
      case 'ciclos':
        return renderCiclos();
      case 'manobras':
        return renderManobras();
      case 'sessoes':
        return renderSessoes();
      case 'matriz':
        return <MatrizSessoesManobras />;
      default:
        return null;
    }
  };

  const renderSimuladores = () => (
    <div className="space-y-4">
      {simuladores.length === 0 ? (
        <div className="text-center py-12">
          <Calendar className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-600 mb-4">Nenhum simulador cadastrado</p>
          <Button onClick={handleCreate}>
            <Plus className="w-4 h-4 mr-2" />
            Criar Primeiro Simulador
          </Button>
        </div>
      ) : (
        simuladores.map(sim => (
          <Card key={sim.id} className="hover:shadow-md transition-shadow">
            <div className="p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-3">
                    <h3 className="font-semibold text-lg text-gray-900">{sim.nome}</h3>
                    <span className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${
                      sim.status === 'ATIVO' ? 'bg-green-100 text-green-800' : 
                      sim.status === 'MANUTENCAO' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {sim.status}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Código:</span>
                      <span className="ml-2 font-medium">{sim.codigo_identificacao}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Tipo:</span>
                      <span className="ml-2 font-medium">{sim.tipo_simulador}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Aeronave:</span>
                      <span className="ml-2 font-medium">{sim.aeronave_base}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Local:</span>
                      <span className="ml-2 font-medium">{sim.empresa_local}</span>
                    </div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button variant="secondary" size="sm" onClick={() => handleEdit(sim)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => handleDelete(sim.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))
      )}
    </div>
  );

  const renderCiclos = () => (
    <div className="space-y-4">
      {ciclos.length === 0 ? (
        <div className="text-center py-12">
          <List className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-600 mb-4">Nenhum ciclo cadastrado</p>
          <Button onClick={handleCreate}>
            <Plus className="w-4 h-4 mr-2" />
            Criar Primeiro Ciclo
          </Button>
        </div>
      ) : (
        ciclos.map(ciclo => (
          <Card key={ciclo.id} className="hover:shadow-md transition-shadow">
            <div className="p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="font-semibold text-lg text-gray-900 mb-2">
                    Ciclo {ciclo.numero_ciclo}
                  </h3>
                  <p className="text-gray-900 font-medium mb-2">{ciclo.nome}</p>
                  {ciclo.descricao && (
                    <p className="text-gray-600 text-sm">{ciclo.descricao}</p>
                  )}
                </div>
                <div className="flex space-x-2">
                  <Button variant="secondary" size="sm" onClick={() => handleEdit(ciclo)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => handleDelete(ciclo.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))
      )}
    </div>
  );

  const renderManobras = () => (
    <div className="space-y-4">
      {manobras.length === 0 ? (
        <div className="text-center py-12">
          <Edit className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-600 mb-4">Nenhuma manobra cadastrada</p>
          <div className="flex justify-center space-x-3">
            <Button onClick={handleCreate}>
              <Plus className="w-4 h-4 mr-2" />
              Criar Primeira Manobra
            </Button>
            <Button variant="secondary" onClick={() => {
              setModalType('import');
              setShowModal(true);
            }}>
              <Upload className="w-4 h-4 mr-2" />
              Importar CSV
            </Button>
          </div>
        </div>
      ) : (
        manobras.map(manobra => (
          <Card key={manobra.id} className="hover:shadow-md transition-shadow">
            <div className="p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-3">
                    <h3 className="font-semibold text-lg text-gray-900">{manobra.manobra_id_codigo}</h3>
                    <span className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${
                      manobra.ativo ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {manobra.ativo ? 'Ativa' : 'Inativa'}
                    </span>
                  </div>
                  <p className="text-gray-900 font-medium mb-2">{manobra.nome_manobra}</p>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Categoria:</span>
                      <span className="ml-2 font-medium">{manobra.categoria}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Pontuação Mínima:</span>
                      <span className="ml-2 font-medium">{manobra.pontuacao_minima}</span>
                    </div>
                  </div>
                  {manobra.criterios_aprovacao && (
                    <p className="text-gray-600 text-sm mt-2">
                      <span className="text-gray-500">Critérios:</span> {manobra.criterios_aprovacao}
                    </p>
                  )}
                </div>
                <div className="flex space-x-2">
                  <Button variant="secondary" size="sm" onClick={() => handleEdit(manobra)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => handleDelete(manobra.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))
      )}
    </div>
  );

  const renderSessoes = () => (
    <div className="space-y-4">
      {sessoes.length === 0 ? (
        <div className="text-center py-12">
          <Eye className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-600 mb-4">Nenhuma sessão template cadastrada</p>
          <Button onClick={handleCreate}>
            <Plus className="w-4 h-4 mr-2" />
            Criar Primeira Sessão
          </Button>
        </div>
      ) : (
        sessoes.map(sessao => (
          <Card key={sessao.id} className="hover:shadow-md transition-shadow">
            <div className="p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="font-semibold text-lg text-gray-900 mb-2">
                    Sessão {sessao.numero_sessao}
                  </h3>
                  <p className="text-gray-900 font-medium mb-2">{sessao.nome_sessao}</p>
                  <div className="text-sm text-gray-600 space-y-1">
                    <div>
                      <span className="text-gray-500">Treinamento:</span>
                      <span className="ml-2 font-medium">{sessao.treinamento_codigo}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Manobras configuradas:</span>
                      <span className="ml-2 font-medium">{(sessao as any).total_manobras || 0}</span>
                    </div>
                  </div>
                  {sessao.descricao && (
                    <p className="text-gray-600 text-sm mt-2">{sessao.descricao}</p>
                  )}
                </div>
                <div className="flex space-x-2">
                  <Button variant="secondary" size="sm" onClick={() => handleEdit(sessao)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => handleDelete(sessao.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))
      )}
    </div>
  );

  const renderModal = () => {
    if (!showModal) return null;

    return (
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={modalType === 'import' ? `Importar ${activeTab}` : `${modalType === 'create' ? 'Criar' : 'Editar'} ${getModalTitle()}`}
        className="max-w-2xl"
      >
        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-800 text-sm">{error}</p>
          </div>
        )}
        
        {success && (
          <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-green-800 text-sm">{success}</p>
          </div>
        )}

        {modalType === 'import' ? renderImportForm() : renderFormFields()}
        
        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 mt-6">
          <Button variant="secondary" onClick={() => setShowModal(false)} disabled={loading}>
            Cancelar
          </Button>
          {modalType !== 'import' && (
            <Button onClick={handleSave} disabled={loading}>
              {loading ? 'Salvando...' : (modalType === 'create' ? 'Criar' : 'Salvar')}
            </Button>
          )}
        </div>
      </Modal>
    );
  };

  const getModalTitle = () => {
    switch (activeTab) {
      case 'simuladores': return 'Simulador';
      case 'ciclos': return 'Ciclo';
      case 'manobras': return 'Manobra';
      case 'sessoes': return 'Sessão Template';
      default: return '';
    }
  };

  const renderImportForm = () => (
    <div className="space-y-4">
      <div className="bg-blue-50 p-4 rounded-lg">
        <h4 className="font-medium text-blue-900 mb-2">Formato do CSV para Manobras</h4>
        <div className="text-sm text-blue-800 space-y-1">
          <p><strong>Cabeçalho:</strong> manobra_id_codigo,nome_manobra,categoria,pontuacao_minima</p>
          <p><strong>Exemplo:</strong> M-001,Decolagem Normal,DECOLAGEM,5</p>
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Selecionar arquivo CSV
        </label>
        <input
          type="file"
          accept=".csv"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) {
              handleImportCSV(file);
            }
          }}
          disabled={loading}
          className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 disabled:opacity-50"
        />
      </div>
    </div>
  );

  const renderFormFields = () => {
    switch (activeTab) {
      case 'simuladores':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome *
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.nome || ''}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="Nome do simulador"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Código de Identificação *
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.codigo_identificacao || ''}
                onChange={(e) => setFormData({ ...formData, codigo_identificacao: e.target.value })}
                placeholder="Código único do simulador"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tipo de Simulador *
              </label>
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.tipo_simulador || ''}
                onChange={(e) => setFormData({ ...formData, tipo_simulador: e.target.value })}
              >
                <option value="">Selecione o tipo...</option>
                <option value="FNPT-I">FNPT-I</option>
                <option value="FNPT-II">FNPT-II</option>
                <option value="FFS">FFS</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Aeronave Base *
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.aeronave_base || ''}
                onChange={(e) => setFormData({ ...formData, aeronave_base: e.target.value })}
                placeholder="Modelo da aeronave simulada"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Empresa/Local *
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.empresa_local || ''}
                onChange={(e) => setFormData({ ...formData, empresa_local: e.target.value })}
                placeholder="Empresa proprietária ou local de operação"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Certificação ANAC
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.certificacao_anac || ''}
                onChange={(e) => setFormData({ ...formData, certificacao_anac: e.target.value })}
                placeholder="Número da certificação ANAC"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.status || 'ATIVO'}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              >
                <option value="ATIVO">Ativo</option>
                <option value="MANUTENCAO">Manutenção</option>
                <option value="INATIVO">Inativo</option>
              </select>
            </div>
          </div>
        );

      case 'ciclos':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Número do Ciclo *
              </label>
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.numero_ciclo || ''}
                onChange={(e) => setFormData({ ...formData, numero_ciclo: parseInt(e.target.value) })}
              >
                <option value="">Selecione...</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome *
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.nome || ''}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="Nome do ciclo"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Descrição
              </label>
              <textarea
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={3}
                value={formData.descricao || ''}
                onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                placeholder="Descrição detalhada do ciclo"
              />
            </div>
          </div>
        );

      case 'manobras':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Código da Manobra *
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.manobra_id_codigo || ''}
                onChange={(e) => setFormData({ ...formData, manobra_id_codigo: e.target.value })}
                placeholder="Ex: M-001"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome da Manobra *
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.nome_manobra || ''}
                onChange={(e) => setFormData({ ...formData, nome_manobra: e.target.value })}
                placeholder="Nome descritivo da manobra"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Categoria *
              </label>
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.categoria || ''}
                onChange={(e) => setFormData({ ...formData, categoria: e.target.value })}
              >
                <option value="">Selecione a categoria...</option>
                <option value="DECOLAGEM">Decolagem</option>
                <option value="POUSO">Pouso</option>
                <option value="NAVEGACAO">Navegação</option>
                <option value="EMERGENCIA">Emergência</option>
                <option value="CRM">CRM</option>
                <option value="PROCEDIMENTO">Procedimento</option>
                <option value="OUTRO">Outro</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Pontuação Mínima
              </label>
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.pontuacao_minima || 5}
                onChange={(e) => setFormData({ ...formData, pontuacao_minima: parseInt(e.target.value) })}
              >
                {[1,2,3,4,5,6,7,8,9,10].map(n => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Critérios de Aprovação
              </label>
              <textarea
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={3}
                value={formData.criterios_aprovacao || ''}
                onChange={(e) => setFormData({ ...formData, criterios_aprovacao: e.target.value })}
                placeholder="Descreva os critérios de avaliação"
              />
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="ativo"
                checked={formData.ativo !== false}
                onChange={(e) => setFormData({ ...formData, ativo: e.target.checked })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="ativo" className="ml-2 block text-sm text-gray-700">
                Manobra ativa
              </label>
            </div>
          </div>
        );

      case 'sessoes':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Código do Treinamento *
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.treinamento_codigo || ''}
                onChange={(e) => setFormData({ ...formData, treinamento_codigo: e.target.value })}
                placeholder="Ex: TRM-001"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Número da Sessão *
              </label>
              <input
                type="number"
                min="1"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.numero_sessao || ''}
                onChange={(e) => setFormData({ ...formData, numero_sessao: parseInt(e.target.value) })}
                placeholder="Número sequencial da sessão"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome da Sessão *
              </label>
              <input
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.nome_sessao || ''}
                onChange={(e) => setFormData({ ...formData, nome_sessao: e.target.value })}
                placeholder="Nome descritivo da sessão"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Descrição
              </label>
              <textarea
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={3}
                value={formData.descricao || ''}
                onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                placeholder="Descrição detalhada da sessão"
              />
            </div>
          </div>
        );

      default:
        return <div className="text-center py-8 text-gray-500">Formulário em desenvolvimento...</div>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Gestão de Simuladores</h1>
        <p className="text-gray-600">Configure simuladores, ciclos, manobras e templates de sessão</p>
      </div>

      {/* Mensagens globais */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-800">{error}</p>
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-green-800">{success}</p>
        </div>
      )}

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          {[
            { key: 'simuladores', label: 'Simuladores', icon: Calendar },
            { key: 'ciclos', label: 'Ciclos', icon: List },
            { key: 'manobras', label: 'Manobras', icon: Edit },
            { key: 'sessoes', label: 'Templates de Sessão', icon: Eye },
            { key: 'matriz', label: 'Matriz Sessões × Manobras', icon: Grid }
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`flex items-center space-x-2 py-3 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === tab.key
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Header com botões */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">
          {activeTab === 'simuladores' && 'Simuladores'}
          {activeTab === 'ciclos' && 'Ciclos'}
          {activeTab === 'manobras' && 'Manobras'}
          {activeTab === 'sessoes' && 'Templates de Sessão'}
          {activeTab === 'matriz' && 'Matriz Sessões × Manobras'}
        </h2>
        
        <div className="flex space-x-3">
          {activeTab === 'manobras' && (
            <Button variant="secondary" onClick={() => {
              setModalType('import');
              setShowModal(true);
            }}>
              <Upload className="w-4 h-4 mr-2" />
              Importar CSV
            </Button>
          )}
          {activeTab !== 'matriz' && (
            <Button onClick={handleCreate}>
              <Plus className="w-4 h-4 mr-2" />
              Criar {getModalTitle()}
            </Button>
          )}
        </div>
      </div>

      {/* Conteúdo */}
      {renderTabContent()}

      {/* Modal */}
      {renderModal()}
    </div>
  );
};

export default SimuladoresAdmin;
