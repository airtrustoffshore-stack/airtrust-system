import { useApi } from '@/react-app/hooks/useApi';
import Card, { CardHeader, CardContent } from '@/react-app/components/Card';
import Badge from '@/react-app/components/Badge';
import { Users, Settings, Activity, Shield, CheckCircle, AlertTriangle } from 'lucide-react';

interface SystemHealth {
  status: string;
  checks: Array<{
    check?: string;
    module?: string;
    table?: string;
    status: string;
    details?: string;
    error?: string;
  }>;
  timestamp: string;
  environment: string;
}

interface SystemInfo {
  system: string;
  version: string;
  environment: string;
  timestamp: string;
  database_stats: Record<string, number | string>;
}

export default function Dashboard() {
  const { data: funcionarios } = useApi<any[]>('/api/v2/funcionarios');
  const { data: funcoes } = useApi<any[]>('/api/v2/funcoes');
  const { data: health } = useApi<SystemHealth>('/api/v2/system/health');
  const { data: systemInfo } = useApi<SystemInfo>('/api/v2/system/info');

  const stats = [
    {
      name: 'Total Funcionários',
      value: funcionarios?.length || 0,
      icon: Users,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'from-blue-50 to-blue-100'
    },
    {
      name: 'Funções Ativas',
      value: funcoes?.length || 0,
      icon: Settings,
      color: 'from-indigo-500 to-indigo-600',
      bgColor: 'from-indigo-50 to-indigo-100'
    },
    {
      name: 'Status Sistema',
      value: health?.status || 'CHECKING',
      icon: health?.status === 'HEALTHY' ? CheckCircle : AlertTriangle,
      color: health?.status === 'HEALTHY' ? 'from-green-500 to-green-600' : 'from-yellow-500 to-yellow-600',
      bgColor: health?.status === 'HEALTHY' ? 'from-green-50 to-green-100' : 'from-yellow-50 to-yellow-100'
    },
    {
      name: 'Ambiente',
      value: systemInfo?.environment || 'dev',
      icon: Shield,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'from-purple-50 to-purple-100'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          Dashboard AirTrust
        </h1>
        <p className="text-gray-600 mt-2">
          Sistema de Gestão de Segurança e Operações Aeronáuticas
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.name} gradient>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">
                    {typeof stat.value === 'string' ? stat.value.toUpperCase() : stat.value}
                  </p>
                </div>
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                  <stat.icon className={`w-6 h-6 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Funcionários Recentes */}
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <Users className="w-5 h-5 mr-2 text-blue-600" />
              Funcionários Recentes
            </h3>
          </CardHeader>
          <CardContent>
            {funcionarios && funcionarios.length > 0 ? (
              <div className="space-y-3">
                {funcionarios.slice(0, 5).map((funcionario) => (
                  <div key={funcionario.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">{funcionario.nome}</p>
                      <p className="text-sm text-gray-600">{funcionario.funcao}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant={funcionario.status === 'ATIVO' ? 'success' : 'neutral'}>
                        {funcionario.status}
                      </Badge>
                      <p className="text-xs text-gray-500 mt-1">{funcionario.base}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">Nenhum funcionário encontrado</p>
            )}
          </CardContent>
        </Card>

        {/* Health Check */}
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <Activity className="w-5 h-5 mr-2 text-green-600" />
              Status do Sistema
            </h3>
          </CardHeader>
          <CardContent>
            {health ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-medium">Status Geral:</span>
                  <Badge variant={health.status === 'HEALTHY' ? 'success' : 'warning'}>
                    {health.status}
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  {health.checks.slice(0, 5).map((check, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                      <span className="text-sm text-gray-700">
                        {check.check || check.table || check.module}
                      </span>
                      <Badge variant={check.status === 'OK' ? 'success' : check.status === 'FAIL' ? 'danger' : 'warning'}>
                        {check.status}
                      </Badge>
                    </div>
                  ))}
                </div>
                
                <p className="text-xs text-gray-500 mt-3">
                  Última verificação: {new Date(health.timestamp).toLocaleString()}
                </p>
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">Carregando status...</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Funções Overview */}
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Settings className="w-5 h-5 mr-2 text-indigo-600" />
            Funções por Categoria
          </h3>
        </CardHeader>
        <CardContent>
          {funcoes && funcoes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {funcoes.map((funcao) => (
                <div key={funcao.id} className="p-4 border border-gray-200 rounded-lg">
                  <h4 className="font-medium text-gray-900">{funcao.nome}</h4>
                  <p className="text-sm text-gray-600 mt-1">{funcao.descricao}</p>
                  <Badge variant="info" size="sm">
                    {funcao.categoria}
                  </Badge>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-4">Nenhuma função encontrada</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
