import React, { useState, useEffect } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router';

interface FichaDetalhes {
  id: number;
  uuid: string;
  data_sessao: string;
  status_workflow: string;
  conceito_final?: string;
  nota_final?: number;
  funcao_na_sessao: string;
  ciclo_executado: number;
  observacoes?: string;
  colaborador: {
    nome: string;
    matricula: string;
    funcao: string;
  };
  instrutor: {
    nome: string;
    matricula: string;
  };
  simulador: {
    nome: string;
    codigo_identificacao: string;
  };
  template: {
    nome: string;
    descricao?: string;
    numero_sessao: number;
  };
  manobras: Array<{
    id: number;
    codigo: string;
    nome: string;
    descricao?: string;
    categoria: string;
    nota?: number;
    observacoes?: string;
    executada: boolean;
    criterios_aprovacao?: string;
    pontuacao_minima: number;
  }>;
}

const VisualizarFichaSimulador: React.FC = () => {
  const { uuid } = useParams<{ uuid: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  
  const [ficha, setFicha] = useState<FichaDetalhes | null>(null);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    // Se temos dados no state, usar eles
    if (location.state?.ficha) {
      setFicha(location.state.ficha);
      setLoading(false);
      return;
    }

    // Caso contrário, buscar da API
    if (uuid) {
      carregarFicha(uuid);
    }
  }, [uuid, location.state]);

  // ✅ CORREÇÃO 3: VALIDAÇÃO DEFENSIVA COMPLETA
  const carregarFicha = async (fichaUuid: string) => {
    setLoading(true);
    setErro(null);

    try {
      // ✅ VALIDAR UUID ANTES DE FAZER REQUEST
      if (!fichaUuid || fichaUuid === 'undefined' || fichaUuid === 'null') {
        throw new Error('UUID da ficha inválido');
      }

      console.log('🔍 Carregando ficha:', fichaUuid);
      
      const response = await fetch(`/api/v2/simulador/ficha/${fichaUuid}`);
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Ficha não encontrada');
        }
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      // ✅ VALIDAÇÃO DEFENSIVA DOS DADOS RECEBIDOS
      if (!data.success) {
        throw new Error(data.error || 'Resposta inválida da API');
      }

      if (!data.ficha) {
        throw new Error('Dados da ficha não encontrados na resposta');
      }

      // ✅ LOG DETALHADO DOS DADOS
      console.log('✅ Dados da ficha recebidos:', {
        uuid: fichaUuid,
        tem_colaborador: !!data.ficha?.colaborador,
        colaborador_nome: data.ficha?.colaborador?.nome || data.ficha?.aluno_nome || 'Nome não informado',
        status: data.ficha?.status_workflow,
        tem_manobras: !!data.ficha?.manobras?.length,
        ficha_keys: Object.keys(data.ficha || {})
      });
      
      setFicha(data.ficha);
    } catch (error) {
      console.error('❌ Erro ao carregar ficha:', error);
      setErro(`Erro ao carregar ficha: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      'RASCUNHO': 'bg-gray-100 text-gray-800',
      'PENDENTE_ALUNO': 'bg-yellow-100 text-yellow-800',
      'PENDENTE_INSTRUTOR_FINAL': 'bg-blue-100 text-blue-800',
      'PENDENTE_CHECK': 'bg-purple-100 text-purple-800',
      'CONCLUIDA': 'bg-green-100 text-green-800',
      'REPROVADA': 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const getNotaColor = (nota?: number) => {
    if (!nota) return 'text-gray-400';
    if (nota >= 7) return 'text-green-600 font-semibold';
    if (nota >= 5) return 'text-yellow-600 font-medium';
    return 'text-red-600 font-semibold';
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <span className="ml-3">Carregando ficha...</span>
      </div>
    );
  }

  if (erro) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 m-4">
        <div className="flex items-center">
          <div className="text-red-400 text-xl">❌</div>
          <div className="ml-3">
            <h3 className="text-red-800 font-medium">Erro ao carregar dados</h3>
            <p className="text-red-700 text-sm mt-1">{erro}</p>
          </div>
        </div>
        <div className="mt-3 space-x-3">
          <button 
            onClick={() => uuid && carregarFicha(uuid)}
            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
          >
            🔄 Tentar Novamente
          </button>
          <button 
            onClick={() => navigate('/simulador/fichas')}
            className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700"
          >
            ← Voltar à Lista
          </button>
        </div>
      </div>
    );
  }

  if (!ficha) {
    return (
      <div className="text-center py-12">
        <div className="text-6xl mb-4">📋</div>
        <h3 className="text-xl font-medium text-gray-900 mb-2">Ficha não encontrada</h3>
        <p className="text-gray-600 mb-6">A ficha solicitada não foi encontrada</p>
        <button 
          onClick={() => navigate('/simulador/fichas')}
          className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
        >
          ← Voltar à Lista
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            📋 {ficha.uuid}
          </h1>
          <span className={`inline-block px-3 py-1 text-sm font-medium rounded-full mt-2 ${getStatusColor(ficha.status_workflow)}`}>
            {ficha.status_workflow}
          </span>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => navigate('/simulador/fichas')}
            className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200"
          >
            ← Voltar
          </button>
          {['RASCUNHO', 'PENDENTE_ALUNO'].includes(ficha.status_workflow) && (
            <button 
              onClick={() => navigate(`/simulador/ficha/${ficha.uuid}/editar`, { state: { ficha } })}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
            >
              ✏️ Editar
            </button>
          )}
          {['PENDENTE_ALUNO', 'PENDENTE_INSTRUTOR_FINAL', 'RASCUNHO'].includes(ficha.status_workflow) && (
            <button 
              onClick={() => navigate(`/simulador/ficha/${ficha.uuid}/avaliar`)}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
            >
              📝 Avaliar
            </button>
          )}
        </div>
      </div>

      {/* Informações da Sessão */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4 text-gray-900">
          ℹ️ Informações da Sessão
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-500 mb-1">Colaborador</label>
            {/* ✅ CORREÇÃO 3: FALLBACKS MÚLTIPLOS PARA DADOS DE COLABORADOR */}
            <div className="text-lg font-semibold">
              {ficha.colaborador?.nome || (ficha as any)?.aluno_nome || 'Nome não informado'}
            </div>
            <div className="text-sm text-gray-500">
              {ficha.colaborador?.matricula || (ficha as any)?.aluno_matricula || 'N/A'} • {ficha.colaborador?.funcao || 'Função não informada'}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-500 mb-1">Instrutor</label>
            <div className="text-lg font-semibold">{ficha.instrutor.nome}</div>
            <div className="text-sm text-gray-500">{ficha.instrutor.matricula}</div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-500 mb-1">Simulador</label>
            <div className="text-lg font-semibold">{ficha.simulador.nome}</div>
            <div className="text-sm text-gray-500">{ficha.simulador.codigo_identificacao}</div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-500 mb-1">Data da Sessão</label>
            <div className="text-lg font-semibold">{ficha.data_sessao}</div>
            <div className="text-sm text-gray-500">Função: {ficha.funcao_na_sessao}</div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-gray-200">
          <div>
            <label className="block text-sm font-medium text-gray-500 mb-1">Template de Sessão</label>
            <div className="text-lg font-semibold">{ficha.template.nome}</div>
            <div className="text-sm text-gray-500">
              Sessão {ficha.template.numero_sessao} • Ciclo {ficha.ciclo_executado}
            </div>
            {ficha.template.descricao && (
              <p className="text-sm text-gray-600 mt-2">{ficha.template.descricao}</p>
            )}
          </div>
        </div>

        {/* Resultado Final */}
        {ficha.conceito_final && (
          <div className="mt-6 pt-4 border-t border-gray-200">
            <label className="block text-sm font-medium text-gray-500 mb-2">Resultado Final</label>
            <div className="flex items-center gap-4">
              <span className={`px-4 py-2 rounded-full text-sm font-bold ${
                ficha.conceito_final === 'APROVADO' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                🎯 {ficha.conceito_final}
              </span>
              {ficha.nota_final && (
                <span className={`text-2xl font-bold ${getNotaColor(ficha.nota_final)}`}>
                  {ficha.nota_final.toFixed(1)}
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Manobras */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
        <h2 className="text-xl font-semibold mb-4 text-gray-900">
          🎮 Manobras do Template ({ficha.manobras.length})
        </h2>

        {ficha.manobras.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-4xl mb-2">🎮</div>
            <p className="text-gray-500">Nenhuma manobra definida para este template</p>
          </div>
        ) : (
          <div className="space-y-4">
            {ficha.manobras.map((manobra) => (
              <div key={manobra.id} className={`border rounded-lg p-4 ${
                manobra.executada ? 'border-blue-200 bg-blue-50' : 'border-gray-200'
              }`}>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {manobra.codigo} - {manobra.nome}
                    </h3>
                    <span className="inline-block px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded mt-1">
                      {manobra.categoria}
                    </span>
                  </div>
                  
                  <div className="text-right">
                    {manobra.executada ? (
                      <div>
                        {manobra.nota ? (
                          <span className={`text-2xl font-bold ${getNotaColor(manobra.nota)}`}>
                            {manobra.nota}
                          </span>
                        ) : (
                          <span className="text-gray-400 font-medium">NR</span>
                        )}
                      </div>
                    ) : (
                      <span className="text-gray-400 text-sm">Não executada</span>
                    )}
                  </div>
                </div>
                
                {manobra.descricao && (
                  <p className="text-sm text-gray-600 mb-2">{manobra.descricao}</p>
                )}
                
                {manobra.criterios_aprovacao && (
                  <div className="text-xs text-blue-600 mb-2">
                    📋 {manobra.criterios_aprovacao}
                  </div>
                )}
                
                <div className="text-xs text-gray-500">
                  Pontuação mínima: {manobra.pontuacao_minima}
                </div>
                
                {manobra.observacoes && (
                  <div className="mt-2 p-2 bg-yellow-50 border-l-2 border-yellow-200">
                    <p className="text-sm text-gray-700">
                      💭 <strong>Observações:</strong> {manobra.observacoes}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Observações Gerais */}
      {ficha.observacoes && (
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mt-6">
          <h2 className="text-xl font-semibold mb-4 text-gray-900">
            📝 Observações do Instrutor
          </h2>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-gray-700 whitespace-pre-wrap">{ficha.observacoes}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default VisualizarFichaSimulador;
