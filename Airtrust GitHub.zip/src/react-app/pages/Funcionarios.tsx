import { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';

import Button from '@/react-app/components/Button';
import Modal from '@/react-app/components/Modal';
// import FuncionarioForm from '@/react-app/components/FuncionarioForm'; // REMOVIDO - Usando formulário unificado
import FuncionarioKPIs from '@/react-app/components/funcionarios/FuncionarioKPIs';
import FuncionarioList from '@/react-app/components/funcionarios/FuncionarioList';
import FuncionarioFormUnified from '@/react-app/components/funcionarios/FuncionarioFormUnified';

import FuncionariosImportModal from '@/react-app/components/shared/FuncionariosImportModal';

// Interface de Dados Unificada OBRIGATÓRIA
interface FuncionarioUnificado {
  // Dados do Módulo 1 (funcionários)
  id: number;
  nome: string;
  matricula: string;
  funcao: string;
  email: string;
  telefone?: string;
  status: 'ATIVO' | 'INATIVO';

  // Dados do Módulo 2 (compliance)
  compliance_status: 'CONFORME' | 'VENCENDO' | 'VENCIDO' | 'PENDENTE';
  compliance_percentage: number; // 0-100
  dias_para_vencimento: number;
}

// Função de Merge OBRIGATÓRIA (CORRIGIDA)
const mergeData = (funcionarios: any[], compliance: any[]): FuncionarioUnificado[] => {
  return funcionarios.map(func => {
    // Encontrar TODOS os registros de compliance para este funcionário
    const funcionarioCompliance = compliance.filter(c => c.funcionario_id === func.id);
    
    if (funcionarioCompliance.length === 0) {
      return {
        id: func.id,
        nome: func.nome,
        matricula: func.matricula || '',
        funcao: func.funcao,
        email: func.email,
        telefone: func.telefone,
        status: func.status,
        compliance_status: 'PENDENTE' as const,
        compliance_percentage: 0,
        dias_para_vencimento: 0,
      };
    }

    // Calcular estatísticas de compliance
    const totalRegistros = funcionarioCompliance.length;
    const emDia = funcionarioCompliance.filter(c => c.status === 'EM_DIA').length;
    const vencendo = funcionarioCompliance.filter(c => c.status === 'VENCENDO').length;
    const vencido = funcionarioCompliance.filter(c => c.status === 'VENCIDO').length;
    const pendente = funcionarioCompliance.filter(c => c.status === 'PENDENTE').length;

    // Status geral (prioridade: VENCIDO > VENCENDO > PENDENTE > CONFORME)
    let compliance_status: 'CONFORME' | 'VENCENDO' | 'VENCIDO' | 'PENDENTE' = 'CONFORME';
    if (vencido > 0) {
      compliance_status = 'VENCIDO';
    } else if (vencendo > 0) {
      compliance_status = 'VENCENDO';
    } else if (pendente > 0) {
      compliance_status = 'PENDENTE';
    }

    // Percentual de compliance (EM_DIA / TOTAL)
    const compliance_percentage = Math.round((emDia / totalRegistros) * 100);

    // Menor número de dias para vencimento crítico
    const diasCriticos = funcionarioCompliance
      .filter(c => c.dias_para_vencimento !== null)
      .map(c => c.dias_para_vencimento)
      .sort((a, b) => a - b);
    const dias_para_vencimento = diasCriticos.length > 0 ? diasCriticos[0] : 0;

    return {
      id: func.id,
      nome: func.nome,
      matricula: func.matricula || '',
      funcao: func.funcao,
      email: func.email,
      telefone: func.telefone,
      status: func.status,
      compliance_status,
      compliance_percentage,
      dias_para_vencimento,
    };
  });
};

export default function Funcionarios() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  
  const [editingFuncionario, setEditingFuncionario] = useState<FuncionarioUnificado | null>(null);
  const [funcionariosUnificados, setFuncionariosUnificados] = useState<FuncionarioUnificado[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Buscar dados das duas APIs (M1 e M2) usando Promise.all
  const fetchUnifiedData = async () => {
    try {
      setLoading(true);
      setError(null);

      const [funcionariosResponse, complianceResponse] = await Promise.all([
        fetch('/api/v2/funcionarios'),
        fetch('/api/v2/compliance')
      ]);

      const funcionariosResult = await funcionariosResponse.json();
      const complianceResult = await complianceResponse.json();

      if (!funcionariosResult.success) {
        throw new Error(funcionariosResult.error || 'Erro ao buscar funcionários');
      }

      if (!complianceResult.success) {
        console.warn('Erro ao buscar compliance, usando dados padrão');
      }

      // Merge dos dados usando a função obrigatória
      const merged = mergeData(
        funcionariosResult.data || [],
        complianceResult.data || []
      );

      setFuncionariosUnificados(merged);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
      console.error('Erro ao buscar dados unificados:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUnifiedData();
  }, []);

  const handleCreateSuccess = async (data: any) => {
    try {
      const response = await fetch('/api/v2/funcionarios', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      
      if (!response.ok) throw new Error('Erro ao criar funcionário');
      
      setIsCreateModalOpen(false);
      fetchUnifiedData(); // Recarregar dados
    } catch (error) {
      console.error('Erro ao criar funcionário:', error);
      throw error;
    }
  };

  const handleImportSuccess = () => {
    setIsImportModalOpen(false);
    fetchUnifiedData(); // Recarregar dados após importação
  };

  

  const handleEditClick = (funcionario: FuncionarioUnificado) => {
    setEditingFuncionario(funcionario);
    setIsEditModalOpen(true);
  };

  const handleEditSuccess = async (data: any) => {
    if (!editingFuncionario) return;
    
    try {
      const response = await fetch(`/api/v2/funcionarios/${editingFuncionario.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      
      if (!response.ok) throw new Error('Erro ao atualizar funcionário');
      
      setIsEditModalOpen(false);
      setEditingFuncionario(null);
      fetchUnifiedData(); // Recarregar dados
    } catch (error) {
      console.error('Erro ao atualizar funcionário:', error);
      throw error;
    }
  };

  const handleEditCancel = () => {
    setIsEditModalOpen(false);
    setEditingFuncionario(null);
  };

  const handleDelete = async () => {
    // ✅ CORREÇÃO 1: Apenas atualizar lista silenciosamente 
    // (confirmação já foi feita no FuncionarioList)
    await fetchUnifiedData();
  };

  const handleViewFolder = (id: number) => {
    // Navegar para a página da pasta virtual
    window.location.href = `/funcionarios/${id}/pasta`;
  };

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600">Erro ao carregar dados: {error}</p>
        <Button 
          variant="primary" 
          onClick={fetchUnifiedData}
          className="mt-4"
        >
          Tentar Novamente
        </Button>
      </div>
    );
  }

  return (
    <div className="import-container">
      {/* Header */}
      <div className="import-header">
        <div>
          <h1 className="import-title">
            Dashboard de Funcionários
          </h1>
          <p className="text-gray-600 mt-2">
            Gestão unificada de tripulação e compliance
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => setIsImportModalOpen(true)}>
            Importar Funcionários
          </Button>
          <Button variant="primary" onClick={() => setIsCreateModalOpen(true)} className="import-button">
            <Plus className="w-4 h-4 mr-2" />
            Novo Funcionário
          </Button>
        </div>
      </div>

      {/* KPIs */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white p-6 rounded-lg shadow animate-pulse">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                <div className="ml-4">
                  <div className="h-4 bg-gray-200 rounded mb-2 w-20"></div>
                  <div className="h-6 bg-gray-200 rounded w-12"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <FuncionarioKPIs funcionariosUnificados={funcionariosUnificados} />
      )}

      {/* Lista de Funcionários */}
      {loading ? (
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200">
            <div className="animate-pulse">
              <div className="h-6 bg-gray-200 rounded mb-2 w-48"></div>
              <div className="h-4 bg-gray-200 rounded w-32"></div>
            </div>
          </div>
          <div className="p-6">
            <div className="animate-pulse space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <FuncionarioList
          funcionariosUnificados={funcionariosUnificados}
          onEdit={handleEditClick}
          onDelete={handleDelete}
          onViewFolder={handleViewFolder}
        />
      )}

      {/* Modal de Criação - FORMULÁRIO UNIFICADO */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Novo Funcionário"
        className="max-w-6xl max-h-[90vh] overflow-y-auto"
      >
        <FuncionarioFormUnified
          onSubmit={handleCreateSuccess}
          onCancel={() => setIsCreateModalOpen(false)}
        />
      </Modal>

      {/* Modal de Edição - FORMULÁRIO UNIFICADO CORRIGIDO */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={handleEditCancel}
        title="Editar Funcionário"
        className="max-w-6xl max-h-[90vh] overflow-y-auto"
      >
        {editingFuncionario && (
          <FuncionarioFormUnified
            funcionario={{
              ...editingFuncionario,
              // Buscar dados completos do funcionário via API
              id: editingFuncionario.id
            }}
            onSubmit={handleEditSuccess}
            onCancel={handleEditCancel}
          />
        )}
      </Modal>

      

      {/* Modal de Importação CSV */}
      <FuncionariosImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onSuccess={handleImportSuccess}
      />
    </div>
  );
}
