import React, { Suspense } from 'react';
import { useNavigate, useLocation } from 'react-router';
import FormularioAgendamento from '../components/simuladores/FormularioAgendamento';
import FormularioAgendamentoAvancado from '../components/simuladores/FormularioAgendamentoAvancado';

const AgendarSimulador: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Verificar se é agendamento avançado baseado na rota
  const isAvancado = location.pathname.includes('avancado');

  // Loading component para fallback
  const LoadingFallback = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Carregando formulário de agendamento...</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Suspense fallback={<LoadingFallback />}>
        {isAvancado ? (
          <FormularioAgendamentoAvancado />
        ) : (
          <FormularioAgendamento 
            onCancelar={() => navigate('/simuladores')}
            templateSelecionado={location.state?.templateSelecionado}
          />
        )}
      </Suspense>
    </div>
  );
};

export default AgendarSimulador;
