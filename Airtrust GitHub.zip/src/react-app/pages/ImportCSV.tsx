import { useState } from 'react';
import Card from '@/react-app/components/Card';
import Button from '@/react-app/components/Button';
import { Download, Upload, FileText, CheckCircle, AlertCircle, Info, BookOpen, Users } from 'lucide-react';
import AdvancedImportModal from '@/react-app/components/shared/AdvancedImportModal';
import FuncionariosImportModal from '@/react-app/components/shared/FuncionariosImportModal';
import CertificacoesImportModal from '@/react-app/components/shared/CertificacoesImportModal';

export const ImportCSVPage = () => {
  const [isCatalogoImportOpen, setIsCatalogoImportOpen] = useState(false);
  const [isFuncionariosImportOpen, setIsFuncionariosImportOpen] = useState(false);
  const [isCertificacoesImportOpen, setIsCertificacoesImportOpen] = useState(false);

  const downloadSample = (type: 'catalog' | 'history' | 'funcionarios') => {
    let csvContent = '';
    let filename = '';

    if (type === 'catalog') {
      csvContent = `codigo,nome,descricao,categoria,periodicidade_meses,nota_minima,carga_horaria,ativo
TRN-001,Nome do Treinamento,Descrição do treinamento,CATEGORIA,12,7.0,8,true`;
      filename = 'template_catalog.csv';
    } else if (type === 'funcionarios') {
      csvContent = `nome,matricula,funcao,email,telefone,cpf,codigo_anac,base,contrato,aeronave_principal
Funcionario Exemplo,FUNC001,PILOTO_COMANDANTE,funcionario@empresa.com,11999999999,00000000000,ABC123,BASE,CLT,AERONAVE`;
      filename = 'template_funcionarios.csv';
    } else {
      csvContent = `funcionario_matricula,treinamento_codigo,data_conclusao,data_vencimento,instrutor,nota_final,observacoes
FUNC001,TRN001,2024-01-15,2025-01-15,Nome Instrutor,8.5,Observações da certificação`;
      filename = 'template_certificacoes.csv';
    }

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          Sistema de Importação CSV
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Importe dados em lote para o sistema AirTrust usando arquivos CSV. 
          Sistema empresarial com validação avançada, tratamento de erros e auditoria completa.
        </p>
      </div>

      {/* Cards de Importação */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Importação de Catálogo de Treinamentos */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-blue-500/10 to-transparent rounded-full transform translate-x-16 -translate-y-16"></div>
          
          <div className="relative p-6 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-900">Catálogo de Treinamentos</h2>
                <p className="text-gray-600 text-sm">Importe tipos de treinamento</p>
              </div>
            </div>

            <div className="bg-blue-50 rounded-lg p-3 space-y-2">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-blue-800">
                  <p className="font-medium mb-1">O que este modo faz:</p>
                  <ul className="space-y-1 text-xs">
                    <li>• Cria ou atualiza treinamentos</li>
                    <li>• Configura periodicidade e notas</li>
                    <li>• Define categorias</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex space-x-2">
              <Button
                onClick={() => downloadSample('catalog')}
                variant="secondary"
                size="sm"
                className="flex-1 flex items-center justify-center gap-1"
              >
                <Download className="w-3 h-3" />
                Template
              </Button>
              <Button
                onClick={() => setIsCatalogoImportOpen(true)}
                variant="primary"
                size="sm"
                className="flex-1 flex items-center justify-center gap-1"
              >
                <Upload className="w-3 h-3" />
                Importar
              </Button>
            </div>
          </div>
        </Card>

        {/* Importação de Funcionários */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-green-500/10 to-transparent rounded-full transform translate-x-16 -translate-y-16"></div>
          
          <div className="relative p-6 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-900">Funcionários</h2>
                <p className="text-gray-600 text-sm">Importe dados da tripulação</p>
              </div>
            </div>

            <div className="bg-green-50 rounded-lg p-3 space-y-2">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-green-800">
                  <p className="font-medium mb-1">O que este modo faz:</p>
                  <ul className="space-y-1 text-xs">
                    <li>• Cria funcionários</li>
                    <li>• Define funções e matrículas</li>
                    <li>• Configura contatos</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex space-x-2">
              <Button
                onClick={() => downloadSample('funcionarios')}
                variant="secondary"
                size="sm"
                className="flex-1 flex items-center justify-center gap-1"
              >
                <Download className="w-3 h-3" />
                Template
              </Button>
              <Button
                onClick={() => setIsFuncionariosImportOpen(true)}
                variant="primary"
                size="sm"
                className="flex-1 flex items-center justify-center gap-1"
              >
                <Upload className="w-3 h-3" />
                Importar
              </Button>
            </div>
          </div>
        </Card>

        {/* Importação de Certificações */}
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-purple-500/10 to-transparent rounded-full transform translate-x-16 -translate-y-16"></div>
          
          <div className="relative p-6 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-900">Certificações</h2>
                <p className="text-gray-600 text-sm">Importe histórico de certificações</p>
              </div>
            </div>

            <div className="bg-purple-50 rounded-lg p-3 space-y-2">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-purple-800">
                  <p className="font-medium mb-1">O que este modo faz:</p>
                  <ul className="space-y-1 text-xs">
                    <li>• Registra certificações</li>
                    <li>• Auto-cria treinamentos</li>
                    <li>• Substitui certificações antigas</li>
                    <li>• Atualiza compliance</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex space-x-2">
              <Button
                onClick={() => downloadSample('history')}
                variant="secondary"
                size="sm"
                className="flex-1 flex items-center justify-center gap-1"
              >
                <Download className="w-3 h-3" />
                Template
              </Button>
              <Button
                onClick={() => setIsCertificacoesImportOpen(true)}
                variant="primary"
                size="sm"
                className="flex-1 flex items-center justify-center gap-1"
              >
                <Upload className="w-3 h-3" />
                Importar
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Recursos Avançados */}
      <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 border-purple-200">
        <div className="p-8 space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Sistema de Importação Empresarial</h2>
            <p className="text-gray-600">Recursos avançados para importação segura e confiável</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Validação Avançada */}
            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900">Validação Avançada</h3>
              <p className="text-sm text-gray-600">
                Validação automática de tipos de dados, formatos de data, 
                referências de chave estrangeira e regras de negócio.
              </p>
            </div>

            {/* Tratamento de Erros */}
            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mx-auto">
                <AlertCircle className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900">Relatórios Detalhados</h3>
              <p className="text-sm text-gray-600">
                Relatórios completos de erros com localização exata, 
                sugestões de correção e métricas de processamento.
              </p>
            </div>

            {/* Auditoria */}
            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900">Auditoria Completa</h3>
              <p className="text-sm text-gray-600">
                Backup automático antes da importação, logs de auditoria 
                e possibilidade de rollback em caso de problemas.
              </p>
            </div>
          </div>

          <div className="bg-white/50 backdrop-blur-sm rounded-lg p-4 border border-purple-200">
            <div className="flex items-center justify-center space-x-8 text-sm text-gray-600">
              <span className="flex items-center">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                Processamento em lotes
              </span>
              <span className="flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                Preview antes da importação
              </span>
              <span className="flex items-center">
                <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                Métricas de performance
              </span>
              <span className="flex items-center">
                <span className="w-2 h-2 bg-orange-500 rounded-full mr-2"></span>
                Backup automático
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* Dicas e Boas Práticas */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <div className="p-6 space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <FileText className="w-5 h-5 mr-2 text-blue-600" />
              Formato CSV - Boas Práticas
            </h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-start">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Use vírgula (,) como separador de campos
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Primeira linha deve conter os cabeçalhos
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Datas no formato YYYY-MM-DD (ex: 2024-12-01)
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Valores booleanos: true/false, 1/0
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Codificação UTF-8 para caracteres especiais
              </li>
            </ul>
          </div>
        </Card>

        <Card>
          <div className="p-6 space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <AlertCircle className="w-5 h-5 mr-2 text-orange-600" />
              Limitações e Cuidados
            </h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-start">
                <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Máximo 10MB por arquivo CSV
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Funcionários devem existir antes de importar certificações
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Campos obrigatórios não podem estar vazios
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Códigos duplicados serão atualizados, não criados
              </li>
              <li className="flex items-start">
                <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                Backup automático é criado antes da importação
              </li>
            </ul>
          </div>
        </Card>
      </div>

      {/* Modal de Importação Catálogo */}
      <AdvancedImportModal
        isOpen={isCatalogoImportOpen}
        onClose={() => setIsCatalogoImportOpen(false)}
        onSuccess={() => setIsCatalogoImportOpen(false)}
        mode="catalog"
        title="Importar Catálogo de Treinamentos"
        description="Importe ou atualize treinamentos no catálogo usando arquivo CSV com validação avançada"
      />

      {/* Modal de Importação Funcionários */}
      <FuncionariosImportModal
        isOpen={isFuncionariosImportOpen}
        onClose={() => setIsFuncionariosImportOpen(false)}
        onSuccess={() => setIsFuncionariosImportOpen(false)}
      />

      {/* Modal de Importação Certificações */}
      <CertificacoesImportModal
        isOpen={isCertificacoesImportOpen}
        onClose={() => setIsCertificacoesImportOpen(false)}
        onSuccess={() => setIsCertificacoesImportOpen(false)}
      />
    </div>
  );
};

export default ImportCSVPage;
