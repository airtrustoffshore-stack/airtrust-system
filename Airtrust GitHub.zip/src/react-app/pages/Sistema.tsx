import { useApi } from '@/react-app/hooks/useApi';
import Card, { CardHeader, CardContent } from '@/react-app/components/Card';
import Badge from '@/react-app/components/Badge';
import { 
  Shield, 
  Activity, 
  Database, 
  Server, 
  CheckCircle, 
  AlertTriangle, 
  XCircle,
  Clock,
  HardDrive
} from 'lucide-react';

interface SystemHealth {
  status: string;
  checks: Array<{
    check?: string;
    module?: string;
    table?: string;
    status: string;
    details?: string;
    error?: string;
  }>;
  timestamp: string;
  environment: string;
}

interface SystemInfo {
  system: string;
  version: string;
  environment: string;
  timestamp: string;
  database_stats: Record<string, number | string>;
}

export default function Sistema() {
  const { data: health, loading: healthLoading, error: healthError } = useApi<SystemHealth>('/api/v2/system/health');
  const { data: systemInfo, loading: infoLoading } = useApi<SystemInfo>('/api/v2/system/info');

  const getStatusIcon = (status: string) => {
    switch (status.toUpperCase()) {
      case 'OK':
      case 'HEALTHY':
        return CheckCircle;
      case 'FAIL':
      case 'DEGRADED':
        return XCircle;
      case 'SLOW':
      case 'WARNING':
        return AlertTriangle;
      default:
        return Activity;
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status.toUpperCase()) {
      case 'OK':
      case 'HEALTHY':
        return 'success';
      case 'FAIL':
      case 'DEGRADED':
        return 'danger';
      case 'SLOW':
      case 'WARNING':
        return 'warning';
      default:
        return 'neutral';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          Sistema
        </h1>
        <p className="text-gray-600 mt-2">
          Monitoramento e status da infraestrutura AirTrust
        </p>
      </div>

      {/* Sistema Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Status Geral */}
        <Card gradient>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Status Geral</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {healthLoading ? '...' : health?.status || 'UNKNOWN'}
                </p>
              </div>
              <div className={`w-12 h-12 bg-gradient-to-br ${
                health?.status === 'HEALTHY' ? 'from-green-50 to-green-100' : 'from-yellow-50 to-yellow-100'
              } rounded-lg flex items-center justify-center`}>
                <Shield className={`w-6 h-6 ${
                  health?.status === 'HEALTHY' ? 'text-green-600' : 'text-yellow-600'
                }`} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ambiente */}
        <Card gradient>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Ambiente</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {infoLoading ? '...' : systemInfo?.environment?.toUpperCase() || 'DEV'}
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg flex items-center justify-center">
                <Server className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Versão */}
        <Card gradient>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Versão</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {infoLoading ? '...' : systemInfo?.version || '1.0.0'}
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg flex items-center justify-center">
                <Activity className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Última Verificação */}
        <Card gradient>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Última Verificação</p>
                <p className="text-sm font-bold text-gray-900 mt-1">
                  {healthLoading ? '...' : health ? new Date(health.timestamp).toLocaleTimeString() : '--:--'}
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-indigo-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Health Checks */}
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Activity className="w-5 h-5 mr-2 text-green-600" />
            Verificações de Saúde
          </h3>
        </CardHeader>
        <CardContent>
          {healthLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="animate-pulse flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                  <div className="h-6 bg-gray-200 rounded w-16"></div>
                </div>
              ))}
            </div>
          ) : healthError ? (
            <div className="text-center py-8">
              <XCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <p className="text-red-600">Erro ao carregar status: {healthError}</p>
            </div>
          ) : health ? (
            <div className="space-y-3">
              {health.checks.map((check, index) => {
                const StatusIcon = getStatusIcon(check.status);
                return (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex items-center space-x-3">
                      <StatusIcon className={`w-5 h-5 ${
                        check.status === 'OK' ? 'text-green-600' : 
                        check.status === 'FAIL' ? 'text-red-600' : 'text-yellow-600'
                      }`} />
                      <div>
                        <p className="font-medium text-gray-900">
                          {check.check || check.table || check.module || 'Verificação'}
                        </p>
                        {check.details && (
                          <p className="text-sm text-gray-600">{check.details}</p>
                        )}
                        {check.error && (
                          <p className="text-sm text-red-600">{check.error}</p>
                        )}
                      </div>
                    </div>
                    <Badge variant={getStatusVariant(check.status)}>
                      {check.status}
                    </Badge>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">Nenhuma verificação disponível</p>
          )}
        </CardContent>
      </Card>

      {/* Database Statistics */}
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Database className="w-5 h-5 mr-2 text-blue-600" />
            Estatísticas do Banco de Dados
          </h3>
        </CardHeader>
        <CardContent>
          {infoLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="animate-pulse p-4 bg-gray-50 rounded-lg">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          ) : systemInfo?.database_stats ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {Object.entries(systemInfo.database_stats).map(([table, count]) => (
                <div key={table} className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-200/50">
                  <div className="flex items-center justify-between mb-2">
                    <HardDrive className="w-5 h-5 text-blue-600" />
                    <Badge variant="info" size="sm">
                      {typeof count === 'number' ? count : count.toString()}
                    </Badge>
                  </div>
                  <h4 className="font-medium text-gray-900 capitalize">
                    {table.replace(/_/g, ' ')}
                  </h4>
                  <p className="text-sm text-gray-600">registros</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">Estatísticas não disponíveis</p>
          )}
        </CardContent>
      </Card>

      {/* System Information */}
      {systemInfo && (
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <Shield className="w-5 h-5 mr-2 text-purple-600" />
              Informações do Sistema
            </h3>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="font-medium text-gray-600">Sistema:</span>
                  <span className="text-gray-900">{systemInfo.system}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-600">Versão:</span>
                  <span className="text-gray-900">{systemInfo.version}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-600">Ambiente:</span>
                  <Badge variant={systemInfo.environment === 'production' ? 'danger' : 'info'}>
                    {systemInfo.environment}
                  </Badge>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="font-medium text-gray-600">Última Atualização:</span>
                  <span className="text-gray-900 text-sm">
                    {new Date(systemInfo.timestamp).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-600">Status de Saúde:</span>
                  <Badge variant={getStatusVariant(health?.status || 'unknown')}>
                    {health?.status || 'UNKNOWN'}
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
