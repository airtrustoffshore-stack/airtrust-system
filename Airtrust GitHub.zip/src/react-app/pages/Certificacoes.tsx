import { useState, useEffect } from 'react';
import { Plus, FileText, Download, Upload } from 'lucide-react';
import Button from '@/react-app/components/Button';
import CertificacoesImportModal from '@/react-app/components/shared/CertificacoesImportModal';

interface CertificacaoStats {
  total: number;
  ativas: number;
  vencidas: number;
  vencendo: number;
}

interface Certificacao {
  id: number;
  funcionario_nome: string;
  funcionario_matricula: string;
  treinamento_nome: string;
  treinamento_codigo: string;
  data_conclusao: string;
  data_vencimento?: string;
  status: string;
  instrutor?: string;
  nota_final?: number;
}

export default function Certificacoes() {
  const [certificacoes, setCertificacoes] = useState<Certificacao[]>([]);
  const [stats, setStats] = useState<CertificacaoStats>({
    total: 0,
    ativas: 0,
    vencidas: 0,
    vencendo: 0
  });
  const [loading, setLoading] = useState(true);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  const fetchCertificacoes = async () => {
    try {
      setLoading(true);
      
      // Buscar certificações da API
      const response = await fetch('/api/v2/certificacoes-v3');
      const result = await response.json();
      
      if (result.success) {
        setCertificacoes(result.data || []);
        
        // Calcular estatísticas
        const total = result.data?.length || 0;
        const ativas = result.data?.filter((c: Certificacao) => c.status === 'ATIVO').length || 0;
        const vencidas = result.data?.filter((c: Certificacao) => c.status === 'VENCIDO').length || 0;
        const vencendo = result.data?.filter((c: Certificacao) => c.status === 'VENCENDO').length || 0;
        
        setStats({ total, ativas, vencidas, vencendo });
      }
    } catch (error) {
      console.error('Erro ao carregar certificações:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCertificacoes();
  }, []);

  const handleImportSuccess = () => {
    setIsImportModalOpen(false);
    fetchCertificacoes();
  };

  const handleDeleteCertificacao = async (certificacaoId: number) => {
    const cert = certificacoes.find(c => c.id === certificacaoId);
    const nomeDisplay = cert?.treinamento_nome || `Certificação ${certificacaoId}`;
    const funcionarioDisplay = cert?.funcionario_nome || 'Funcionário';
    
    const confirmacao = confirm(
      `Tem certeza que deseja excluir a certificação "${nomeDisplay}" do funcionário "${funcionarioDisplay}"?\n\n` +
      'Esta ação não pode ser desfeita.'
    );
    
    if (!confirmacao) return;

    try {
      const response = await fetch(`/api/v2/certificacoes-v3/${certificacaoId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || `Erro HTTP ${response.status}`);
      }

      if (!result.success) {
        throw new Error(result.error || 'Erro ao excluir certificação');
      }

      await fetchCertificacoes();
      console.log(`✅ Certificação "${nomeDisplay}" excluída com sucesso`);
      
    } catch (err) {
      console.error('Erro ao remover certificação:', err);
      alert(`Erro ao excluir certificação: ${err instanceof Error ? err.message : 'Erro desconhecido'}`);
    }
  };

  const downloadTemplate = () => {
    const csvContent = `funcionario_matricula,treinamento_codigo,data_conclusao,data_vencimento,instrutor,nota_final,observacoes
FUNC001,TRN-001,2024-01-15,2025-01-15,Nome Instrutor,8.5,Observações da certificação`;

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'template_certificacoes.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="import-container">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
          <div className="h-96 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="import-container">
      {/* Header */}
      <div className="import-header">
        <div>
          <h1 className="import-title">Gestão de Certificações</h1>
          <p className="text-gray-600 mt-2">
            Controle completo do histórico de certificações da tripulação
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={downloadTemplate}>
            <Download className="w-4 h-4 mr-2" />
            Template CSV
          </Button>
          <Button variant="primary" onClick={() => setIsImportModalOpen(true)} className="import-button">
            <Upload className="w-4 h-4 mr-2" />
            Importar Certificações
          </Button>
        </div>
      </div>

      {/* Stats KPIs */}
      <div className="import-stats">
        <div className="stat-card">
          <div className="flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full mx-auto mb-3">
            <FileText className="w-6 h-6 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
          <div className="text-sm text-gray-600">Total de Certificações</div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-center w-12 h-12 bg-green-100 rounded-full mx-auto mb-3">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          </div>
          <div className="text-2xl font-bold text-gray-900">{stats.ativas}</div>
          <div className="text-sm text-gray-600">Certificações Ativas</div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-center w-12 h-12 bg-yellow-100 rounded-full mx-auto mb-3">
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
          </div>
          <div className="text-2xl font-bold text-gray-900">{stats.vencendo}</div>
          <div className="text-sm text-gray-600">Vencendo em Breve</div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-center w-12 h-12 bg-red-100 rounded-full mx-auto mb-3">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          </div>
          <div className="text-2xl font-bold text-gray-900">{stats.vencidas}</div>
          <div className="text-sm text-gray-600">Certificações Vencidas</div>
        </div>
      </div>

      {/* Lista de Certificações */}
      <div className="list-section">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Histórico de Certificações</h2>
          <span className="text-sm text-gray-600">{certificacoes.length} registros</span>
        </div>

        {certificacoes.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <FileText className="w-12 h-12 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Nenhuma certificação encontrada
            </h3>
            <p className="text-gray-600 mb-4">
              Comece importando certificações ou registrando manualmente.
            </p>
            <Button variant="primary" onClick={() => setIsImportModalOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Importar Primeira Certificação
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Funcionário
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Treinamento
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Data Conclusão
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Data Vencimento
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Instrutor
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {certificacoes.map((cert) => (
                  <tr key={cert.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{cert.funcionario_nome}</div>
                        <div className="text-sm text-gray-500">{cert.funcionario_matricula}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{cert.treinamento_nome}</div>
                        <div className="text-sm text-gray-500">{cert.treinamento_codigo}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(cert.data_conclusao).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {cert.data_vencimento 
                        ? new Date(cert.data_vencimento).toLocaleDateString('pt-BR')
                        : '-'
                      }
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        cert.status === 'ATIVO' 
                          ? 'bg-green-100 text-green-800'
                          : cert.status === 'VENCIDO'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {cert.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {cert.instrutor || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <button
                        onClick={() => handleDeleteCertificacao(cert.id)}
                        className="text-red-600 hover:text-red-800 hover:bg-red-50 p-2 rounded-lg transition-colors"
                        title="Excluir certificação"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal de Importação */}
      <CertificacoesImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onSuccess={handleImportSuccess}
      />
    </div>
  );
}
