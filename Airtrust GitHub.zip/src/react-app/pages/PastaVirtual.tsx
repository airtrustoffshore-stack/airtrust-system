import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { ArrowLeft, Plus, FileText, User, Calendar, Award, Download, Folder, File, RefreshCw, AlertTriangle, Clock, Activity } from 'lucide-react';
import Button from '@/react-app/components/Button';
import Card, { CardHeader, CardContent } from '@/react-app/components/Card';
import Badge from '@/react-app/components/Badge';
import AddCertificacaoModal from '@/react-app/components/funcionarios/AddCertificacaoModal';

interface Funcionario {
  id: number;
  nome: string;
  matricula: string;
  funcao: string;
  email: string;
  telefone?: string;
  status: string;
  aeronave_principal?: string;
}

interface ArquivoPasta {
  sync_id: number;
  nome_arquivo: string;
  treinamento: {
    codigo: string;
    nome: string;
    categoria: string;
  };
  certificacao: {
    data_conclusao: string;
    data_vencimento?: string;
    nota_final?: number;
    instrutor?: string;
    status_validade: 'VALIDO' | 'VENCENDO' | 'VENCIDO';
  };
  arquivo: {
    tamanho_bytes: number;
    hash_md5: string;
    data_sincronizacao: string;
    url_download: string;
  };
}

interface SubPasta {
  nome: string;
  icone: string;
  descricao: string;
  arquivos: ArquivoPasta[];
}

interface EstruturaPastas {
  certificacoes: SubPasta;
  treinamentos: SubPasta;
  medicos: SubPasta;
  documentos_gerais: SubPasta;
  fichas_simulador: SubPasta;
}

interface PastaVirtualData {
  funcionario: {
    id: number;
    nome: string;
    matricula: string;
    funcao: string;
    status: string;
  };
  estrutura_pastas: EstruturaPastas;
  estatisticas: {
    total_arquivos: number;
    certificacoes: number;
    treinamentos: number;
    medicos: number;
    documentos_gerais: number;
    fichas_simulador: number;
    espaco_total_bytes: number;
    ultimo_sync?: string;
    arquivos_vencidos: number;
    arquivos_vencendo: number;
  };
}

interface CatalogoTreinamento {
  id: number;
  codigo: string;
  nome: string;
  descricao?: string;
  categoria: string;
  periodicidade_meses?: number;
  ativo: boolean;
}

export default function PastaVirtual() {
  const { funcionarioId } = useParams<{ funcionarioId: string }>();
  const navigate = useNavigate();
  
  const [funcionario, setFuncionario] = useState<Funcionario | null>(null);
  const [catalogoTreinamentos, setCatalogoTreinamentos] = useState<CatalogoTreinamento[]>([]);
  const [pastaVirtualData, setPastaVirtualData] = useState<PastaVirtualData | null>(null);
  const [activeTab, setActiveTab] = useState<string>('certificacoes');
  const [loading, setLoading] = useState(true);
  const [loadingSync, setLoadingSync] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Promise.all para buscar dados do funcionário, pasta virtual e catálogo
      const [funcionarioResponse, pastaVirtualResponse, catalogoResponse] = await Promise.all([
        fetch(`/api/v2/funcionarios/${funcionarioId}`).then(r => r.json()),
        fetch(`/api/v2/pasta-virtual-enhanced/listar/${funcionarioId}`).then(r => r.json()),
        fetch('/api/v2/treinamentos/catalogo-treinamentos').then(r => r.json())
      ]);

      if (!funcionarioResponse.success) {
        throw new Error(funcionarioResponse.error || 'Funcionário não encontrado');
      }

      setFuncionario(funcionarioResponse.data);
      setCatalogoTreinamentos(catalogoResponse.data || []);

      if (pastaVirtualResponse.success) {
        setPastaVirtualData(pastaVirtualResponse);
        
        // Definir aba ativa baseada no conteúdo disponível
        if (pastaVirtualResponse.estrutura_pastas.certificacoes.arquivos.length > 0) {
          setActiveTab('certificacoes');
        } else if (pastaVirtualResponse.estrutura_pastas.medicos.arquivos.length > 0) {
          setActiveTab('medicos');
        } else if (pastaVirtualResponse.estrutura_pastas.treinamentos.arquivos.length > 0) {
          setActiveTab('treinamentos');
        }
      }

      // Buscar certificações não é mais necessário para esta tela

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao carregar dados');
      console.error('Erro ao buscar dados da pasta virtual:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddSuccess = () => {
    setIsAddModalOpen(false);
    fetchData(); // Re-fetch para atualizar a lista
  };

  const sincronizarFuncionario = async () => {
    try {
      setLoadingSync(true);
      setError(null);

      const result = await fetch(`/api/v2/pasta-virtual-enhanced/sync/${funcionarioId}`, {
        method: 'POST'
      }).then(r => r.json());

      if (result.success) {
        // Recarregar dados após sincronização
        await fetchData();
      } else {
        throw new Error(result.error || 'Erro na sincronização');
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro na sincronização');
      console.error('💥 Erro na sincronização:', err);
    } finally {
      setLoadingSync(false);
    }
  };

  const downloadArquivo = (syncId: number, nomeArquivo: string) => {
    const url = `/api/v2/pasta-virtual-enhanced/download/${syncId}`;
    
    // Criar link temporário para download auditável
    const link = document.createElement('a');
    link.href = url;
    link.download = nomeArquivo;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'VALIDO': return 'success';
      case 'VENCENDO': return 'warning'; 
      case 'VENCIDO': return 'danger';
      case 'ATIVO': return 'success';
      case 'SUBSTITUIDO': return 'warning';
      case 'CANCELADO': return 'danger';
      default: return 'neutral';
    }
  };

  const getIconForSubPasta = (icone: string) => {
    switch (icone) {
      case 'certificate': return Award;
      case 'book': return FileText;
      case 'heart': return Activity;
      case 'file': return File;
      case 'monitor': return Activity;
      default: return FileText;
    }
  };

  useEffect(() => {
    if (funcionarioId) {
      fetchData();
    }
  }, [funcionarioId]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded mb-4 w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600 mb-4">Erro: {error}</p>
        <Button variant="primary" onClick={() => navigate('/funcionarios')}>
          Voltar para Funcionários
        </Button>
      </div>
    );
  }

  if (!funcionario) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600 mb-4">Funcionário não encontrado</p>
        <Button variant="primary" onClick={() => navigate('/funcionarios')}>
          Voltar para Funcionários
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/funcionarios')}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Pasta Virtual Enterprise
            </h1>
            <p className="text-gray-600 mt-1">
              Sistema de Gestão Documental e Auditoria Completa
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="secondary" 
            onClick={sincronizarFuncionario}
            disabled={loadingSync}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loadingSync ? 'animate-spin' : ''}`} />
            Sincronizar
          </Button>
          <Button variant="primary" onClick={() => setIsAddModalOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Adicionar Manual
          </Button>
        </div>
      </div>

      {/* Cabeçalho do Funcionário */}
      <Card gradient>
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
              {funcionario.nome.split(' ').map(n => n[0]).join('').substring(0, 2)}
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-gray-900">{funcionario.nome}</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3">
                <div className="flex items-center text-sm text-gray-600">
                  <User className="w-4 h-4 mr-2" />
                  {funcionario.matricula}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Award className="w-4 h-4 mr-2" />
                  {funcionario.funcao}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <FileText className="w-4 h-4 mr-2" />
                  {funcionario.aeronave_principal || 'N/A'}
                </div>
                <div>
                  <Badge variant={funcionario.status === 'ATIVO' ? 'success' : 'danger'}>
                    {funcionario.status}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estatísticas da Pasta Virtual */}
      {pastaVirtualData && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-gray-600">Total</p>
                  <p className="text-xl font-bold text-gray-900">{pastaVirtualData.estatisticas.total_arquivos}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Award className="w-5 h-5 text-green-600" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-gray-600">Certificações</p>
                  <p className="text-xl font-bold text-gray-900">{pastaVirtualData.estatisticas.certificacoes}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="p-2 bg-red-100 rounded-lg">
                  <Activity className="w-5 h-5 text-red-600" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-gray-600">Médicos</p>
                  <p className="text-xl font-bold text-gray-900">{pastaVirtualData.estatisticas.medicos}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <AlertTriangle className="w-5 h-5 text-purple-600" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-gray-600">Críticos</p>
                  <p className="text-xl font-bold text-gray-900">{pastaVirtualData.estatisticas.arquivos_vencidos + pastaVirtualData.estatisticas.arquivos_vencendo}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <Activity className="w-5 h-5 text-indigo-600" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-gray-600">Espaço</p>
                  <p className="text-xl font-bold text-gray-900">
                    {Math.round(pastaVirtualData.estatisticas.espaco_total_bytes / 1024)}KB
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Sistema de Subpastas com Tabs */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <Folder className="w-5 h-5 mr-2 text-blue-600" />
              Estrutura Hierárquica de Documentos
            </h3>
            {pastaVirtualData?.estatisticas.ultimo_sync && (
              <p className="text-sm text-gray-500">
                Última sync: {new Date(pastaVirtualData.estatisticas.ultimo_sync).toLocaleString('pt-BR')}
              </p>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {!pastaVirtualData ? (
            <div className="text-center py-8">
              <Folder className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 text-lg font-medium mb-2">Carregando Pasta Virtual...</p>
              <p className="text-sm text-gray-400">
                Aguarde enquanto estruturamos os documentos em subpastas
              </p>
            </div>
          ) : pastaVirtualData.estatisticas.total_arquivos === 0 ? (
            <div className="text-center py-8">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 text-lg font-medium mb-2">Pasta Virtual Vazia</p>
              <p className="text-sm text-gray-400 mb-4">
                Nenhum documento sincronizado encontrado. Clique em "Sincronizar" para popular a pasta virtual.
              </p>
              <Button variant="primary" onClick={sincronizarFuncionario} disabled={loadingSync}>
                <RefreshCw className={`w-4 h-4 mr-2 ${loadingSync ? 'animate-spin' : ''}`} />
                Sincronizar Agora
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Tabs Navigation */}
              <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
                {Object.entries(pastaVirtualData.estrutura_pastas).map(([key, pasta]) => {
                  const Icon = getIconForSubPasta(pasta.icone);
                  const isActive = activeTab === key;
                  const hasContent = pasta.arquivos.length > 0;
                  
                  return (
                    <button
                      key={key}
                      onClick={() => setActiveTab(key)}
                      disabled={!hasContent}
                      className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        isActive 
                          ? 'bg-white text-blue-600 shadow-sm' 
                          : hasContent
                          ? 'text-gray-700 hover:text-gray-900 hover:bg-gray-200' 
                          : 'text-gray-400 cursor-not-allowed'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{pasta.nome}</span>
                      <Badge size="sm" variant={hasContent ? 'neutral' : 'neutral'}>
                        {pasta.arquivos.length}
                      </Badge>
                    </button>
                  );
                })}
              </div>

              {/* Tab Content */}
              <div className="space-y-4">
                {pastaVirtualData.estrutura_pastas[activeTab as keyof EstruturaPastas] && (
                  <>
                    <div className="border-l-4 border-blue-500 pl-4">
                      <h4 className="font-medium text-gray-900">
                        {pastaVirtualData.estrutura_pastas[activeTab as keyof EstruturaPastas].nome}
                      </h4>
                      <p className="text-sm text-gray-600">
                        {pastaVirtualData.estrutura_pastas[activeTab as keyof EstruturaPastas].descricao}
                      </p>
                    </div>

                    {pastaVirtualData.estrutura_pastas[activeTab as keyof EstruturaPastas].arquivos.length === 0 ? (
                      <div className="text-center py-6">
                        <File className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-500">Nenhum arquivo encontrado nesta pasta</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {pastaVirtualData.estrutura_pastas[activeTab as keyof EstruturaPastas].arquivos.map((arquivo) => (
                          <div key={arquivo.sync_id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <div className="flex items-center space-x-3 mb-2">
                                  <File className="w-4 h-4 text-gray-600" />
                                  <h5 className="font-medium text-gray-900">
                                    {arquivo.treinamento.nome}
                                  </h5>
                                  <Badge 
                                    variant={getStatusBadgeVariant(arquivo.certificacao.status_validade)}
                                    size="sm"
                                  >
                                    {arquivo.certificacao.status_validade}
                                  </Badge>
                                  <Badge variant="neutral" size="sm">
                                    {arquivo.treinamento.codigo}
                                  </Badge>
                                </div>
                                
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-2">
                                  <div className="flex items-center">
                                    <Calendar className="w-3 h-3 mr-1" />
                                    Conclusão: {new Date(arquivo.certificacao.data_conclusao).toLocaleDateString('pt-BR')}
                                  </div>
                                  {arquivo.certificacao.data_vencimento && (
                                    <div className="flex items-center">
                                      <Clock className="w-3 h-3 mr-1" />
                                      Vence: {new Date(arquivo.certificacao.data_vencimento).toLocaleDateString('pt-BR')}
                                    </div>
                                  )}
                                  {arquivo.certificacao.instrutor && (
                                    <div className="flex items-center">
                                      <User className="w-3 h-3 mr-1" />
                                      {arquivo.certificacao.instrutor}
                                    </div>
                                  )}
                                  {arquivo.certificacao.nota_final && (
                                    <div className="flex items-center">
                                      <Award className="w-3 h-3 mr-1" />
                                      Nota: {arquivo.certificacao.nota_final.toFixed(1)}
                                    </div>
                                  )}
                                </div>

                                <div className="flex items-center space-x-4 text-xs text-gray-500">
                                  <span>📁 {arquivo.nome_arquivo}</span>
                                  <span>💾 {Math.round(arquivo.arquivo.tamanho_bytes / 1024)} KB</span>
                                  <span>🔐 {arquivo.arquivo.hash_md5.substring(0, 8)}...</span>
                                  <span>📅 {new Date(arquivo.arquivo.data_sincronizacao).toLocaleDateString('pt-BR')}</span>
                                </div>
                              </div>
                              
                              <div className="ml-4">
                                <Button
                                  size="sm"
                                  variant="primary"
                                  onClick={() => downloadArquivo(arquivo.sync_id, arquivo.nome_arquivo)}
                                  className="flex items-center space-x-2"
                                >
                                  <Download className="w-4 h-4" />
                                  <span>Baixar PDF</span>
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de Adicionar Certificação */}
      <AddCertificacaoModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSuccess={handleAddSuccess}
        funcionarioId={parseInt(funcionarioId!)}
        catalogoTreinamentos={catalogoTreinamentos}
      />
    </div>
  );
}
