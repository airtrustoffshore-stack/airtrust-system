import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import FormularioCriarTemplate from '../components/simuladores/FormularioCriarTemplate';

interface Template {
  id: number;
  codigo: string;
  nome: string;
  descricao?: string;
  duracao_estimada: number;
  nivel_treinamento: string;
  total_manobras: number;
  numero_sessao: number;
  treinamento_nome: string;
  created_at: string;
}

const SimuladoresTemplates: React.FC = () => {
  const navigate = useNavigate();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [filtroTreinamento, setFiltroTreinamento] = useState('');
  
  useEffect(() => {
    carregarTemplates();
  }, []);
  
  const carregarTemplates = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/v2/simulador/templates');
      
      if (response.ok) {
        const data = await response.json();
        setTemplates(data.templates || []);
        console.log(`✅ Carregados ${data.templates?.length || 0} templates`);
      } else {
        console.error('❌ Erro ao carregar templates:', response.status);
        setTemplates([]);
      }
    } catch (error) {
      console.error('❌ Erro na requisição:', error);
      setTemplates([]);
    } finally {
      setLoading(false);
    }
  };
  
  const handleCreateSuccess = (novoTemplate: any) => {
    console.log('✅ Template criado com sucesso:', novoTemplate);
    carregarTemplates(); // Recarregar lista
    setShowCreateModal(false);
  };
  
  const templatesFiltrados = templates.filter(template => 
    filtroTreinamento === '' || 
    template.treinamento_nome.toLowerCase().includes(filtroTreinamento.toLowerCase()) ||
    template.codigo.toLowerCase().includes(filtroTreinamento.toLowerCase())
  );
  
  const getNivelColor = (nivel: string) => {
    switch (nivel) {
      case 'BASICO': return 'text-green-600 bg-green-100';
      case 'INTERMEDIARIO': return 'text-yellow-600 bg-yellow-100';
      case 'AVANCADO': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };
  
  return (
    <div className="container mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg">
        {/* Header */}
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                📋 Templates de Sessões de Simulador
              </h1>
              <p className="text-gray-600 mt-1">
                Gerencie os templates de treinamento para sessões de simulador
              </p>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={() => navigate('/simuladores')}
                className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 font-medium"
              >
                ← Voltar
              </button>
              
              <button
                onClick={() => setShowCreateModal(true)}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 font-medium"
              >
                ➕ Criar Template
              </button>
            </div>
          </div>
        </div>
        
        {/* Filtros */}
        <div className="p-6 border-b bg-gray-50">
          <div className="flex gap-4 items-center">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                🔍 Filtrar por Treinamento
              </label>
              <input
                type="text"
                value={filtroTreinamento}
                onChange={(e) => setFiltroTreinamento(e.target.value)}
                placeholder="Digite o nome ou código do treinamento..."
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <div className="text-sm text-gray-500">
              {templatesFiltrados.length} de {templates.length} templates
            </div>
          </div>
        </div>
        
        {/* Lista de Templates */}
        <div className="p-6">
          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <p className="text-gray-600 mt-2">Carregando templates...</p>
            </div>
          ) : templates.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <div className="text-6xl mb-4">📋</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                Nenhum Template Encontrado
              </h3>
              <p className="text-gray-500 mb-6">
                Crie seu primeiro template de sessão para começar
              </p>
              <button
                onClick={() => setShowCreateModal(true)}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-medium"
              >
                ➕ Criar Primeiro Template
              </button>
            </div>
          ) : templatesFiltrados.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">
                Nenhum template encontrado com o filtro aplicado
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {templatesFiltrados.map(template => (
                <div key={template.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">
                        {template.nome}
                      </h3>
                      <p className="text-sm text-gray-500">
                        Sessão {template.numero_sessao} • {template.codigo}
                      </p>
                    </div>
                    
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getNivelColor(template.nivel_treinamento)}`}>
                      {template.nivel_treinamento}
                    </span>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">📚 Treinamento:</span>
                      <span className="font-medium">{template.treinamento_nome}</span>
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">🎯 Manobras:</span>
                      <span className="font-medium">{template.total_manobras} manobras</span>
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">⏱️ Duração:</span>
                      <span className="font-medium">{template.duracao_estimada}h</span>
                    </div>
                  </div>
                  
                  {template.descricao && (
                    <p className="text-sm text-gray-600 mb-4">
                      {template.descricao.length > 80 
                        ? `${template.descricao.substring(0, 80)}...` 
                        : template.descricao
                      }
                    </p>
                  )}
                  
                  <div className="flex gap-2">
                    <button
                      className="flex-1 bg-blue-50 text-blue-600 py-2 px-4 rounded hover:bg-blue-100 text-sm font-medium"
                      onClick={() => {
                        // TODO: Implementar visualização/edição
                        alert(`Ver detalhes do template ${template.id}`);
                      }}
                    >
                      👁️ Ver Detalhes
                    </button>
                    
                    <button
                      className="flex-1 bg-green-50 text-green-600 py-2 px-4 rounded hover:bg-green-100 text-sm font-medium"
                      onClick={() => {
                        // TODO: Implementar uso em agendamento
                        navigate('/simuladores/agendar', { 
                          state: { templateSelecionado: template } 
                        });
                      }}
                    >
                      📅 Usar em Agendamento
                    </button>
                  </div>
                  
                  <div className="mt-3 pt-3 border-t text-xs text-gray-400">
                    Criado em {new Date(template.created_at).toLocaleDateString('pt-BR')}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Modal de Criação */}
      {showCreateModal && (
        <FormularioCriarTemplate
          onClose={() => setShowCreateModal(false)}
          onSuccess={handleCreateSuccess}
        />
      )}
    </div>
  );
};

export default SimuladoresTemplates;
