import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';

interface Manobra {
  id: number;
  codigo: string;
  nome: string;
  categoria: string;
  criterios_aprovacao?: string;
  pontuacao_minima: number;
  nota_atual?: number;
  observacoes_atual?: string;
  executada: boolean;
}

interface FichaAvaliacao {
  ficha: {
    uuid: string;
    colaborador: string;
    matricula: string;
    simulador: string;
    template: string;
    data_sessao: string;
    status_workflow: string;
    funcao_na_sessao: string;
    ciclo_executado: number;
  };
  manobras: Manobra[];
  pode_avaliar: boolean;
}

const AvaliarFichaSimulador: React.FC = () => {
  const { uuid } = useParams<{ uuid: string }>();
  const navigate = useNavigate();
  
  const [avaliacao, setAvaliacao] = useState<FichaAvaliacao | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  
  const [notas, setNotas] = useState<Record<number, string>>({});
  const [observacoes, setObservacoes] = useState<Record<number, string>>({});
  const [observacoesGerais, setObservacoesGerais] = useState('');

  useEffect(() => {
    if (uuid) {
      carregarAvaliacao(uuid);
    }
  }, [uuid]);

  const carregarAvaliacao = async (fichaUuid: string) => {
    setLoading(true);
    setErro(null);

    try {
      const response = await fetch(`/api/v2/simulador/ficha/${fichaUuid}/avaliacao`);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      setAvaliacao(data.avaliacao);
      
      // Carregar notas e observações existentes
      const notasIniciais: Record<number, string> = {};
      const observacoesIniciais: Record<number, string> = {};
      
      data.avaliacao.manobras.forEach((manobra: Manobra) => {
        if (manobra.nota_atual !== null && manobra.nota_atual !== undefined) {
          notasIniciais[manobra.id] = manobra.nota_atual.toString();
        }
        if (manobra.observacoes_atual) {
          observacoesIniciais[manobra.id] = manobra.observacoes_atual;
        }
      });
      
      setNotas(notasIniciais);
      setObservacoes(observacoesIniciais);
      
    } catch (error) {
      console.error('Erro ao carregar avaliação:', error);
      setErro(`Erro ao carregar avaliação: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleNotaChange = (manobraId: number, nota: string) => {
    setNotas(prev => ({
      ...prev,
      [manobraId]: nota
    }));
  };

  const handleObservacaoChange = (manobraId: number, observacao: string) => {
    setObservacoes(prev => ({
      ...prev,
      [manobraId]: observacao
    }));
  };

  const calcularResultados = () => {
    const manobrasAvaliadas = avaliacao?.manobras.filter(m => 
      notas[m.id] && notas[m.id] !== 'NR'
    ) || [];
    
    if (manobrasAvaliadas.length === 0) {
      return { notaFinal: null, conceito: null, temNotaBaixa: false };
    }
    
    const notasNumericas = manobrasAvaliadas
      .map(m => parseFloat(notas[m.id]))
      .filter(nota => !isNaN(nota));
    
    const notaFinal = notasNumericas.reduce((sum, nota) => sum + nota, 0) / notasNumericas.length;
    const temNotaBaixa = notasNumericas.some(nota => nota < 5);
    const conceito = temNotaBaixa ? 'REPROVADO' : 'APROVADO';
    
    return { notaFinal, conceito, temNotaBaixa };
  };

  const salvarAvaliacao = async (finalizar: boolean = false) => {
    if (!avaliacao || !uuid) return;

    setSaving(true);
    setErro(null);

    try {
      const manobrasParaSalvar = avaliacao.manobras.map(manobra => ({
        id: manobra.id,
        nota: notas[manobra.id] || 'NR',
        observacoes: observacoes[manobra.id] || ''
      }));

      const response = await fetch(`/api/v2/simulador/ficha/${uuid}/avaliar`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          manobras: manobrasParaSalvar,
          observacoes_gerais: observacoesGerais,
          finalizar: finalizar
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erro ao salvar avaliação');
      }

      const data = await response.json();
      
      if (finalizar) {
        alert(`✅ Avaliação finalizada com sucesso!\nResultado: ${data.ficha.conceito_final}\nNota: ${data.ficha.nota_final?.toFixed(1) || 'N/A'}`);
        navigate('/simulador/fichas');
      } else {
        alert('✅ Avaliação salva como rascunho');
      }

    } catch (error) {
      console.error('Erro ao salvar avaliação:', error);
      setErro(`Erro ao salvar: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    } finally {
      setSaving(false);
    }
  };

  const { notaFinal, conceito, temNotaBaixa } = calcularResultados();

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <span className="ml-3">Carregando avaliação...</span>
      </div>
    );
  }

  if (erro && !avaliacao) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 m-4">
        <div className="flex items-center">
          <div className="text-red-400 text-xl">❌</div>
          <div className="ml-3">
            <h3 className="text-red-800 font-medium">Erro ao carregar dados</h3>
            <p className="text-red-700 text-sm mt-1">{erro}</p>
          </div>
        </div>
        <div className="mt-3 space-x-3">
          <button 
            onClick={() => uuid && carregarAvaliacao(uuid)}
            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
          >
            🔄 Tentar Novamente
          </button>
          <button 
            onClick={() => navigate('/simulador/fichas')}
            className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700"
          >
            ← Voltar à Lista
          </button>
        </div>
      </div>
    );
  }

  if (!avaliacao) {
    return (
      <div className="text-center py-12">
        <div className="text-6xl mb-4">📝</div>
        <h3 className="text-xl font-medium text-gray-900 mb-2">Avaliação não encontrada</h3>
        <p className="text-gray-600 mb-6">A ficha solicitada não foi encontrada para avaliação</p>
        <button 
          onClick={() => navigate('/simulador/fichas')}
          className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
        >
          ← Voltar à Lista
        </button>
      </div>
    );
  }

  if (!avaliacao.pode_avaliar) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 m-4">
        <div className="flex items-center">
          <div className="text-yellow-400 text-xl">⚠️</div>
          <div className="ml-3">
            <h3 className="text-yellow-800 font-medium">Avaliação não permitida</h3>
            <p className="text-yellow-700 text-sm mt-1">
              Esta ficha não pode ser avaliada no status atual: {avaliacao.ficha.status_workflow}
            </p>
          </div>
        </div>
        <button 
          onClick={() => navigate('/simulador/fichas')}
          className="mt-3 bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700"
        >
          ← Voltar à Lista
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            📝 Avaliar Ficha
          </h1>
          <p className="text-gray-600 mt-1">
            {avaliacao.ficha.colaborador} • {avaliacao.ficha.simulador} • {avaliacao.ficha.data_sessao}
          </p>
        </div>
        <button 
          onClick={() => navigate('/simulador/fichas')}
          className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200"
        >
          ← Voltar
        </button>
      </div>

      {/* Erro de salvamento */}
      {erro && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <div className="text-red-400">❌</div>
            <p className="text-red-700 ml-2">{erro}</p>
          </div>
        </div>
      )}

      {/* Resultado Calculado */}
      {notaFinal !== null && (
        <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mb-6">
          <h2 className="text-lg font-semibold mb-3 text-gray-900">📊 Resultado Calculado</h2>
          <div className="flex items-center gap-6">
            <div>
              <span className="text-sm text-gray-500">Nota Final:</span>
              <div className={`text-3xl font-bold ${
                notaFinal >= 7 ? 'text-green-600' :
                notaFinal >= 5 ? 'text-yellow-600' : 'text-red-600'
              }`}>
                {notaFinal.toFixed(1)}
              </div>
            </div>
            <div>
              <span className="text-sm text-gray-500">Conceito:</span>
              <div className={`text-xl font-bold ${
                conceito === 'APROVADO' ? 'text-green-600' : 'text-red-600'
              }`}>
                {conceito}
              </div>
              {temNotaBaixa && (
                <div className="text-xs text-red-500 mt-1">
                  ⚠️ Possui nota(s) &lt; 5
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Manobras para Avaliação */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4 text-gray-900">
          🎮 Manobras para Avaliação ({avaliacao.manobras.length})
        </h2>

        <div className="space-y-6">
          {avaliacao.manobras.map((manobra) => (
            <div key={manobra.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-1">
                    {manobra.codigo} - {manobra.nome}
                  </h3>
                  <span className="inline-block px-2 py-1 text-xs bg-blue-100 text-blue-600 rounded">
                    {manobra.categoria}
                  </span>
                  <div className="text-xs text-gray-500 mt-1">
                    Pontuação mínima: {manobra.pontuacao_minima}
                  </div>
                  {manobra.criterios_aprovacao && (
                    <div className="text-sm text-blue-600 mt-2">
                      📋 {manobra.criterios_aprovacao}
                    </div>
                  )}
                </div>
                
                <div className="ml-4 flex-shrink-0">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nota
                  </label>
                  <select
                    value={notas[manobra.id] || ''}
                    onChange={(e) => handleNotaChange(manobra.id, e.target.value)}
                    className="w-20 border border-gray-300 rounded-md px-2 py-1 text-center"
                  >
                    <option value="">-</option>
                    <option value="NR">NR</option>
                    {[1,2,3,4,5,6,7,8,9,10].map(n => (
                      <option key={n} value={n}>{n}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Observações
                </label>
                <textarea
                  value={observacoes[manobra.id] || ''}
                  onChange={(e) => handleObservacaoChange(manobra.id, e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                  rows={2}
                  placeholder="Observações sobre a execução desta manobra..."
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Observações Gerais */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 mb-6">
        <h2 className="text-lg font-semibold mb-3 text-gray-900">📝 Observações Gerais</h2>
        <textarea
          value={observacoesGerais}
          onChange={(e) => setObservacoesGerais(e.target.value)}
          className="w-full border border-gray-300 rounded-md px-3 py-2"
          rows={4}
          placeholder="Observações gerais sobre a sessão de simulador..."
        />
      </div>

      {/* Botões de Ação */}
      <div className="flex gap-3 justify-end">
        <button
          onClick={() => salvarAvaliacao(false)}
          disabled={saving}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
        >
          {saving ? '💾 Salvando...' : '💾 Salvar Rascunho'}
        </button>
        
        <button
          onClick={() => salvarAvaliacao(true)}
          disabled={saving}
          className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 disabled:bg-gray-400"
        >
          {saving ? '✅ Finalizando...' : '✅ Finalizar Avaliação'}
        </button>
      </div>
    </div>
  );
};

export default AvaliarFichaSimulador;
