import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { 
  Gamepad2, 
  Plus, 
  Filter, 
  BarChart3, 
  Calendar,
  Settings,
  Users,
  ClipboardCheck,
  AlertTriangle,
  CheckCircle,
  TrendingUp
} from 'lucide-react';
import Button from '../../components/Button';
import Card from '../../components/Card';

interface Simulador {
  id: number;
  nome: string;
  codigo_identificacao: string;
  tipo_simulador: string;
  aeronave_base: string;
  empresa_local: string;
  status: string;
}

interface EstatisticasDashboard {
  total_simuladores: number;
  simuladores_ativos: number;
  sessoes_agendadas: number;
  fichas_pendentes: number;
  taxa_utilizacao: number;
}

const SimuladoresDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [simuladores, setSimuladores] = useState<Simulador[]>([]);
  const [estatisticas, setEstatisticas] = useState<EstatisticasDashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [filtroStatus, setFiltroStatus] = useState<string>('todos');
  const [filtroTipo, setFiltroTipo] = useState<string>('todos');

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      setLoading(true);
      
      // Carregar simuladores
      const responseSimuladores = await fetch('/api/v2/simuladores/equipamentos');
      const dataSimuladores = await responseSimuladores.json();
      
      if (dataSimuladores.success) {
        setSimuladores(dataSimuladores.data || []);
      }

      // Carregar estatísticas (mock por enquanto)
      const estatisticasMock: EstatisticasDashboard = {
        total_simuladores: dataSimuladores.data?.length || 3,
        simuladores_ativos: dataSimuladores.data?.filter((s: Simulador) => s.status === 'ATIVO').length || 3,
        sessoes_agendadas: 12,
        fichas_pendentes: 8,
        taxa_utilizacao: 85
      };
      
      setEstatisticas(estatisticasMock);
      
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const simuladoresFiltrados = simuladores.filter(sim => {
    const matchStatus = filtroStatus === 'todos' || sim.status === filtroStatus;
    const matchTipo = filtroTipo === 'todos' || sim.tipo_simulador === filtroTipo;
    return matchStatus && matchTipo;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ATIVO': return 'text-green-600 bg-green-100';
      case 'MANUTENCAO': return 'text-yellow-600 bg-yellow-100';
      case 'INATIVO': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case 'FFS': return '🎮';
      case 'FNPT-I': return '🖥️';
      case 'FNPT-II': return '💻';
      default: return '⚙️';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-gray-600">Carregando dashboard...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
        <div className="flex items-center space-x-4 mb-4 sm:mb-0">
          <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl shadow-lg">
            <Gamepad2 className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Simuladores</h1>
            <p className="text-gray-600">Gestão completa de equipamentos e treinamentos</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="secondary"
            onClick={() => navigate('/agendamento')}
            className="flex items-center"
          >
            <Calendar className="w-4 h-4 mr-2" />
            Agendar Sessão
          </Button>
          <Button
            onClick={() => navigate('/simuladores/equipamentos/novo')}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Simulador
          </Button>
        </div>
      </div>

      {/* Cards de Estatísticas */}
      {estatisticas && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-700">Total Simuladores</p>
                <p className="text-2xl font-bold text-blue-900">{estatisticas.total_simuladores}</p>
              </div>
              <div className="p-3 bg-blue-500 rounded-lg">
                <Gamepad2 className="w-6 h-6 text-white" />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-700">Ativos</p>
                <p className="text-2xl font-bold text-green-900">{estatisticas.simuladores_ativos}</p>
              </div>
              <div className="p-3 bg-green-500 rounded-lg">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-700">Sessões Agendadas</p>
                <p className="text-2xl font-bold text-purple-900">{estatisticas.sessoes_agendadas}</p>
              </div>
              <div className="p-3 bg-purple-500 rounded-lg">
                <Calendar className="w-6 h-6 text-white" />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-orange-700">Fichas Pendentes</p>
                <p className="text-2xl font-bold text-orange-900">{estatisticas.fichas_pendentes}</p>
              </div>
              <div className="p-3 bg-orange-500 rounded-lg">
                <ClipboardCheck className="w-6 h-6 text-white" />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-indigo-50 to-indigo-100 border-indigo-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-indigo-700">Taxa Utilização</p>
                <p className="text-2xl font-bold text-indigo-900">{estatisticas.taxa_utilizacao}%</p>
              </div>
              <div className="p-3 bg-indigo-500 rounded-lg">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Filtros */}
      <Card className="p-6 mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-4">
            <Filter className="w-5 h-5 text-gray-500" />
            <span className="font-medium text-gray-700">Filtros:</span>
            
            <select
              value={filtroStatus}
              onChange={(e) => setFiltroStatus(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="todos">Todos os Status</option>
              <option value="ATIVO">Ativo</option>
              <option value="MANUTENCAO">Manutenção</option>
              <option value="INATIVO">Inativo</option>
            </select>

            <select
              value={filtroTipo}
              onChange={(e) => setFiltroTipo(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="todos">Todos os Tipos</option>
              <option value="FFS">FFS</option>
              <option value="FNPT-I">FNPT-I</option>
              <option value="FNPT-II">FNPT-II</option>
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant="secondary"
              onClick={() => navigate('/simuladores/relatorios')}
              className="flex items-center"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Relatórios
            </Button>
            <Button
              variant="secondary"
              onClick={() => navigate('/simuladores/configuracoes')}
              className="flex items-center"
            >
              <Settings className="w-4 h-4 mr-2" />
              Configurações
            </Button>
          </div>
        </div>
      </Card>

      {/* Grid de Simuladores */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {simuladoresFiltrados.map((simulador) => (
          <div 
            key={simulador.id} 
            className="p-6 hover:shadow-lg transition-all duration-200 cursor-pointer border-l-4 border-l-blue-500 bg-white rounded-lg border border-gray-200 shadow-sm"
            onClick={() => navigate(`/simuladores/equipamentos/${simulador.id}`)}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="text-2xl">
                  {getTipoIcon(simulador.tipo_simulador)}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{simulador.nome}</h3>
                  <p className="text-sm text-gray-500">{simulador.codigo_identificacao}</p>
                </div>
              </div>
              
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(simulador.status)}`}>
                {simulador.status}
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Tipo:</span>
                <span className="text-sm font-medium text-gray-900">{simulador.tipo_simulador}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Aeronave:</span>
                <span className="text-sm font-medium text-gray-900">{simulador.aeronave_base}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Local:</span>
                <span className="text-sm font-medium text-gray-900">{simulador.empresa_local}</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/agendamento?simulador=${simulador.id}`);
                  }}
                  className="flex items-center"
                >
                  <Calendar className="w-4 h-4 mr-1" />
                  Agendar
                </Button>
                
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/simuladores/equipamentos/${simulador.id}/sessoes`);
                  }}
                  className="flex items-center"
                >
                  <Users className="w-4 h-4 mr-1" />
                  Sessões
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Estado vazio */}
      {simuladoresFiltrados.length === 0 && (
        <Card className="p-12 text-center">
          <div className="flex flex-col items-center space-y-4">
            <div className="p-6 bg-gray-100 rounded-full">
              <AlertTriangle className="w-12 h-12 text-gray-400" />
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhum simulador encontrado
              </h3>
              <p className="text-gray-600 mb-4">
                Não há simuladores que correspondam aos filtros selecionados.
              </p>
              <Button
                onClick={() => {
                  setFiltroStatus('todos');
                  setFiltroTipo('todos');
                }}
                variant="secondary"
              >
                Limpar Filtros
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Ações Rápidas */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div 
          className="p-6 hover:shadow-lg transition-all duration-200 cursor-pointer bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 bg-white rounded-lg border border-gray-200 shadow-sm"
          onClick={() => navigate('/agendamento')}
        >
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-blue-500 rounded-lg">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-blue-900">Agendar Sessão</h3>
              <p className="text-sm text-blue-700">Nova sessão de treinamento</p>
            </div>
          </div>
        </div>

        <div 
          className="p-6 hover:shadow-lg transition-all duration-200 cursor-pointer bg-gradient-to-br from-green-50 to-green-100 border-green-200 bg-white rounded-lg border border-gray-200 shadow-sm"
          onClick={() => navigate('/simuladores/fichas')}
        >
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-green-500 rounded-lg">
              <ClipboardCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-green-900">Fichas Pendentes</h3>
              <p className="text-sm text-green-700">Avaliar treinamentos</p>
            </div>
          </div>
        </div>

        <div 
          className="p-6 hover:shadow-lg transition-all duration-200 cursor-pointer bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200 bg-white rounded-lg border border-gray-200 shadow-sm"
          onClick={() => navigate('/simuladores/templates')}
        >
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-purple-500 rounded-lg">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-purple-900">Templates</h3>
              <p className="text-sm text-purple-700">Gerenciar modelos</p>
            </div>
          </div>
        </div>

        <div 
          className="p-6 hover:shadow-lg transition-all duration-200 cursor-pointer bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200 bg-white rounded-lg border border-gray-200 shadow-sm"
          onClick={() => navigate('/simuladores/relatorios')}
        >
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-orange-500 rounded-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-orange-900">Relatórios</h3>
              <p className="text-sm text-orange-700">Análises e métricas</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SimuladoresDashboard;
