import React, { useState, useEffect } from 'react';
import { Plus, FileText, Edit, Trash2, Search } from 'lucide-react';

import Button from '../../components/Button';
import Card from '../../components/Card';
import Modal from '../../components/Modal';
import TemplateForm from '../../components/simuladores/TemplateForm';

interface Template {
  id: number;
  nome: string;
  categoria: string;
  duracao_minutos: number;
  descricao: string;
  aeronave_aplicavel: string;
  nota_minima: number;
  ativo: boolean;
  created_at: string;
  total_manobras?: number;
}

const Templates: React.FC = () => {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [templateEditando, setTemplateEditando] = useState<Template | null>(null);
  const [filtroCategoria, setFiltroCategoria] = useState('');
  const [buscaNome, setBuscaNome] = useState('');

  useEffect(() => {
    carregarTemplates();
  }, []);

  const carregarTemplates = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/v2/simuladores/templates');
      const data = await response.json();
      
      if (data.success) {
        setTemplates(data.data || []);
      } else {
        console.error('Erro ao carregar templates:', data.error);
      }
    } catch (error) {
      console.error('Erro na requisição:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCriarTemplate = async (dados: any) => {
    try {
      const response = await fetch('/api/v2/simuladores/templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dados)
      });

      const result = await response.json();
      
      if (response.ok && result.success) {
        alert('Template criado com sucesso!');
        setShowForm(false);
        carregarTemplates();
      } else {
        alert(`Erro ao criar template: ${result.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error('Erro ao criar template:', error);
      alert('Erro de conexão ao criar template');
    }
  };

  const handleEditarTemplate = async (dados: any) => {
    if (!templateEditando) return;

    try {
      const response = await fetch(`/api/v2/simuladores/templates/${templateEditando.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dados)
      });

      const result = await response.json();
      
      if (response.ok && result.success) {
        alert('Template atualizado com sucesso!');
        setTemplateEditando(null);
        carregarTemplates();
      } else {
        alert(`Erro ao atualizar template: ${result.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error('Erro ao atualizar template:', error);
      alert('Erro de conexão ao atualizar template');
    }
  };

  const handleExcluirTemplate = async (template: Template) => {
    if (!confirm(`Deseja realmente excluir o template "${template.nome}"?`)) {
      return;
    }

    try {
      const response = await fetch(`/api/v2/simuladores/templates/${template.id}`, {
        method: 'DELETE'
      });

      const result = await response.json();
      
      if (response.ok && result.success) {
        alert('Template excluído com sucesso!');
        carregarTemplates();
      } else {
        alert(`Erro ao excluir template: ${result.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error('Erro ao excluir template:', error);
      alert('Erro de conexão ao excluir template');
    }
  };

  const templatesFiltrados = templates.filter(template => {
    const matchNome = template.nome.toLowerCase().includes(buscaNome.toLowerCase());
    const matchCategoria = !filtroCategoria || template.categoria === filtroCategoria;
    return matchNome && matchCategoria;
  });

  const categorias = [...new Set(templates.map(t => t.categoria))];

  const getCategoriaColor = (categoria: string) => {
    const cores: Record<string, string> = {
      'CHECK': 'bg-blue-100 text-blue-800',
      'TREINAMENTO': 'bg-green-100 text-green-800',
      'EMERGENCIA': 'bg-red-100 text-red-800',
      'PROFICIENCIA': 'bg-purple-100 text-purple-800',
      'RECORRENTE': 'bg-yellow-100 text-yellow-800'
    };
    return cores[categoria] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center justify-center h-64">
          <div className="flex items-center gap-3">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
            <span className="text-gray-600">Carregando templates...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Templates de Treinamento</h1>
          <p className="text-gray-600 mt-1">
            Gerencie os templates de sessões de simulador
          </p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus size={20} className="mr-2" />
          Novo Template
        </Button>
      </div>

      {/* Filtros */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <input
              type="text"
              placeholder="Buscar templates..."
              value={buscaNome}
              onChange={(e) => setBuscaNome(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
        <div className="sm:w-48">
          <select
            value={filtroCategoria}
            onChange={(e) => setFiltroCategoria(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Todas as categorias</option>
            {categorias.map(categoria => (
              <option key={categoria} value={categoria}>{categoria}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Grid de Templates */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templatesFiltrados.map((template) => (
          <Card key={template.id} className="p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <FileText className="text-blue-600" size={24} />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 leading-tight">
                    {template.nome}
                  </h3>
                  <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium mt-1 ${getCategoriaColor(template.categoria)}`}>
                    {template.categoria}
                  </span>
                </div>
              </div>
              <div className="flex gap-1">
                <button
                  onClick={() => setTemplateEditando(template)}
                  className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                  title="Editar template"
                >
                  <Edit size={16} />
                </button>
                <button
                  onClick={() => handleExcluirTemplate(template)}
                  className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                  title="Excluir template"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            
            <p className="text-gray-600 text-sm mb-4 line-clamp-2">
              {template.descricao || 'Sem descrição disponível'}
            </p>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Duração:</span>
                <div className="font-medium">{template.duracao_minutos}min</div>
              </div>
              <div>
                <span className="text-gray-500">Nota mín:</span>
                <div className="font-medium">{template.nota_minima}</div>
              </div>
              <div>
                <span className="text-gray-500">Aeronave:</span>
                <div className="font-medium">{template.aeronave_aplicavel || 'Todas'}</div>
              </div>
              <div>
                <span className="text-gray-500">Manobras:</span>
                <div className="font-medium">{template.total_manobras || 0}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {templatesFiltrados.length === 0 && (
        <div className="text-center py-12">
          <FileText size={48} className="mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {templates.length === 0 ? 'Nenhum template encontrado' : 'Nenhum template corresponde aos filtros'}
          </h3>
          <p className="text-gray-500 mb-4">
            {templates.length === 0 
              ? 'Crie seu primeiro template de treinamento para começar.'
              : 'Tente ajustar os filtros de busca.'
            }
          </p>
          {templates.length === 0 && (
            <Button onClick={() => setShowForm(true)}>
              <Plus size={20} className="mr-2" />
              Criar Primeiro Template
            </Button>
          )}
        </div>
      )}

      {/* Modal Novo Template */}
      <Modal 
        isOpen={showForm} 
        onClose={() => setShowForm(false)}
        title="Novo Template"
      >
        <TemplateForm 
          onSubmit={handleCriarTemplate}
          onCancel={() => setShowForm(false)}
        />
      </Modal>

      {/* Modal Editar Template */}
      <Modal 
        isOpen={!!templateEditando} 
        onClose={() => setTemplateEditando(null)}
        title="Editar Template"
      >
        {templateEditando && (
          <TemplateForm 
            template={templateEditando}
            onSubmit={handleEditarTemplate}
            onCancel={() => setTemplateEditando(null)}
          />
        )}
      </Modal>
    </div>
  );
};

export default Templates;
