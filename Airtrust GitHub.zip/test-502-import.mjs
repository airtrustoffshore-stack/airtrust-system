#!/usr/bin/env node

/**
 * SCRIPT DE TESTE PARA DIAGNÓSTICO DE 502 NA IMPORTAÇÃO DE CERTIFICAÇÕES
 * 
 * Este script testa os endpoints de importação para identificar a causa do erro 502
 * e valida se a nova implementação robusta resolve o problema.
 */

import fs from 'fs';
import https from 'https';
import http from 'http';

// ✅ CONFIGURAÇÃO DOS ENDPOINTS A TESTAR
const BASE_URL = 'https://ql6vqscnjd7u6.mocha.app';
const ENDPOINTS_TO_TEST = [
  {
    name: 'Histórico Certificações (Original)',
    path: '/api/v2/historico-certificacoes/batch-import',
    method: 'POST'
  },
  {
    name: 'Import Certificações Batch',
    path: '/api/v2/import-certificacoes-batch/import-planilha-batch',
    method: 'POST'
  },
  {
    name: 'Certificações Import Robust (Novo)',
    path: '/api/v2/certificacoes-import-robust/import-robust',
    method: 'POST'
  }
];

// ✅ GERAR CSV DE TESTE COM DIFERENTES TAMANHOS
function gerarCSVTeste(numLinhas = 50) {
  let csv = 'funcionario_matricula,treinamento_codigo,data_conclusao,instrutor,nota_final,data_vencimento,observacoes\\n';
  
  for (let i = 1; i <= numLinhas; i++) {
    const matricula = String(i).padStart(5, '0');
    const treinamento = `TRN-${String(i % 10).padStart(3, '0')}`;
    const dataConclusao = `2024-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 28) + 1).padStart(2, '0')}`;
    const instrutor = `Instrutor ${i % 5 + 1}`;
    const nota = (7 + (i % 3)).toFixed(1);
    const dataVencimento = `2025-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 28) + 1).padStart(2, '0')}`;
    const obs = `Observação linha ${i}`;
    
    csv += `${matricula},${treinamento},${dataConclusao},${instrutor},${nota},${dataVencimento},${obs}\\n`;
  }
  
  return csv;
}

// ✅ FUNÇÃO PARA FAZER REQUISIÇÃO HTTP/HTTPS
function makeRequest(url, options, data = null) {
  return new Promise((resolve, reject) => {
    const isHttps = url.startsWith('https:');
    const client = isHttps ? https : http;
    
    console.log(`📡 [REQUEST] ${options.method} ${url}`);
    console.log(`📊 [REQUEST] Headers:`, options.headers);
    if (data) {
      console.log(`📦 [REQUEST] Data size: ${data.length} bytes`);
    }
    
    const startTime = Date.now();
    
    const req = client.request(url, options, (res) => {
      const chunks = [];
      
      console.log(`📡 [RESPONSE] Status: ${res.statusCode} ${res.statusMessage}`);
      console.log(`📡 [RESPONSE] Headers:`, res.headers);
      
      res.on('data', (chunk) => {
        chunks.push(chunk);
      });
      
      res.on('end', () => {
        const responseTime = Date.now() - startTime;
        const body = Buffer.concat(chunks).toString();
        
        console.log(`⏱️ [RESPONSE] Time: ${responseTime}ms`);
        console.log(`📦 [RESPONSE] Body size: ${body.length} bytes`);
        
        // Tentar parse JSON
        let parsedBody;
        try {
          parsedBody = JSON.parse(body);
          console.log(`✅ [RESPONSE] JSON válido`);
        } catch (error) {
          console.log(`❌ [RESPONSE] Não é JSON válido - provavelmente HTML`);
          parsedBody = { _raw_html: body };
        }
        
        resolve({
          statusCode: res.statusCode,
          statusMessage: res.statusMessage,
          headers: res.headers,
          body: parsedBody,
          responseTime,
          isJson: typeof parsedBody === 'object' && !parsedBody._raw_html
        });
      });
    });
    
    req.on('error', (error) => {
      const responseTime = Date.now() - startTime;
      console.error(`❌ [REQUEST] Error after ${responseTime}ms:`, error.message);
      reject(error);
    });
    
    req.on('timeout', () => {
      const responseTime = Date.now() - startTime;
      console.error(`⏰ [REQUEST] Timeout after ${responseTime}ms`);
      req.destroy();
      reject(new Error('Request timeout'));
    });
    
    if (data) {
      req.write(data);
    }
    
    req.end();
  });
}

// ✅ FUNÇÃO PARA CRIAR FORM DATA MULTIPART
function createMultipartFormData(csvContent, fileName = 'test-certificacoes.csv') {
  const boundary = '----formdata-mocha-' + Math.random().toString(36).substr(2, 16);
  
  let formData = '';
  formData += `--${boundary}\\r\\n`;
  formData += `Content-Disposition: form-data; name="file"; filename="${fileName}"\\r\\n`;
  formData += `Content-Type: text/csv\\r\\n\\r\\n`;
  formData += csvContent;
  formData += `\\r\\n--${boundary}--\\r\\n`;
  
  return {
    data: formData,
    contentType: `multipart/form-data; boundary=${boundary}`
  };
}

// ✅ TESTAR UM ENDPOINT ESPECÍFICO
async function testarEndpoint(endpoint, csvContent) {
  console.log(`\\n🔥 ====================================`);
  console.log(`🔥 TESTANDO: ${endpoint.name}`);
  console.log(`🔥 ====================================`);
  
  try {
    const { data, contentType } = createMultipartFormData(csvContent);
    
    const options = {
      method: endpoint.method,
      headers: {
        'Content-Type': contentType,
        'Content-Length': Buffer.byteLength(data),
        'Accept': 'application/json',
        'User-Agent': 'Mocha-Test-502-Diagnostics/1.0'
      },
      timeout: 60000 // 60 segundos
    };
    
    const url = `${BASE_URL}${endpoint.path}`;
    const result = await makeRequest(url, options, data);
    
    console.log(`\\n📊 [RESULTADO] ${endpoint.name}:`);
    console.log(`  - Status: ${result.statusCode} ${result.statusMessage}`);
    console.log(`  - Tempo resposta: ${result.responseTime}ms`);
    console.log(`  - É JSON: ${result.isJson}`);
    console.log(`  - Content-Type: ${result.headers['content-type']}`);
    
    if (result.isJson) {
      console.log(`  - Success: ${result.body.success}`);
      if (result.body.success) {
        console.log(`  - Linhas processadas: ${result.body.linhas_processadas || 'N/A'}`);
        console.log(`  - Importadas com sucesso: ${result.body.importadas_com_sucesso || 'N/A'}`);
        console.log(`  - Total batches: ${result.body.total_batches || 'N/A'}`);
      } else {
        console.log(`  - Erro: ${result.body.error || result.body.message || 'Erro não especificado'}`);
      }
    } else {
      console.log(`  - ❌ RESPOSTA HTML DETECTADA - POSSÍVEL 502`);
      const bodyPreview = result.body._raw_html.substring(0, 200);
      console.log(`  - Preview: ${bodyPreview}...`);
    }
    
    return {
      endpoint: endpoint.name,
      status: result.statusCode,
      responseTime: result.responseTime,
      isJson: result.isJson,
      success: result.isJson && result.body.success,
      error: result.isJson ? (result.body.error || result.body.message) : 'HTML_RESPONSE_502',
      details: result.body
    };
    
  } catch (error) {
    console.error(`❌ [ERRO] ${endpoint.name}: ${error.message}`);
    return {
      endpoint: endpoint.name,
      status: 'ERROR',
      responseTime: 0,
      isJson: false,
      success: false,
      error: error.message,
      details: null
    };
  }
}

// ✅ EXECUTAR TODOS OS TESTES
async function executarTodosTestes() {
  console.log('🚀 ===================================================');
  console.log('🚀 DIAGNÓSTICO COMPLETO - ERRO 502 IMPORTAÇÃO');
  console.log('🚀 ===================================================');
  console.log(`🕐 Início: ${new Date().toISOString()}`);
  
  const resultados = [];
  
  // Teste com diferentes tamanhos de arquivo
  const tamanhosArquivo = [10, 50, 100, 200];
  
  for (const tamanho of tamanhosArquivo) {
    console.log(`\\n📁 ==========================================`);
    console.log(`📁 TESTANDO COM ARQUIVO DE ${tamanho} LINHAS`);
    console.log(`📁 ==========================================`);
    
    const csvContent = gerarCSVTeste(tamanho);
    console.log(`📊 CSV gerado: ${csvContent.split('\\n').length - 1} linhas de dados + header`);
    
    for (const endpoint of ENDPOINTS_TO_TEST) {
      const resultado = await testarEndpoint(endpoint, csvContent);
      resultado.tamanho_arquivo = tamanho;
      resultados.push(resultado);
      
      // Delay entre testes para não sobrecarregar
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  }
  
  // ✅ RELATÓRIO FINAL
  console.log(`\\n🎯 =======================================`);
  console.log(`🎯 RELATÓRIO FINAL - DIAGNÓSTICO 502`);
  console.log(`🎯 =======================================`);
  
  const relatorio = {
    timestamp: new Date().toISOString(),
    total_testes: resultados.length,
    sucessos: resultados.filter(r => r.success).length,
    falhas: resultados.filter(r => !r.success).length,
    respostas_html: resultados.filter(r => !r.isJson).length,
    status_502: resultados.filter(r => r.status === 502).length,
    tempo_medio: Math.round(resultados.reduce((acc, r) => acc + r.responseTime, 0) / resultados.length),
    resultados_por_endpoint: {},
    recomendacoes: []
  };
  
  // Agrupar por endpoint
  ENDPOINTS_TO_TEST.forEach(endpoint => {
    const resultadosEndpoint = resultados.filter(r => r.endpoint === endpoint.name);
    relatorio.resultados_por_endpoint[endpoint.name] = {
      total_testes: resultadosEndpoint.length,
      sucessos: resultadosEndpoint.filter(r => r.success).length,
      falhas: resultadosEndpoint.filter(r => !r.success).length,
      respostas_html: resultadosEndpoint.filter(r => !r.isJson).length,
      tempo_medio: Math.round(resultadosEndpoint.reduce((acc, r) => acc + r.responseTime, 0) / resultadosEndpoint.length),
      funciona_arquivos_pequenos: resultadosEndpoint.filter(r => r.tamanho_arquivo <= 50 && r.success).length > 0,
      funciona_arquivos_grandes: resultadosEndpoint.filter(r => r.tamanho_arquivo >= 100 && r.success).length > 0
    };
  });
  
  // Gerar recomendações
  if (relatorio.respostas_html > 0) {
    relatorio.recomendacoes.push('CRÍTICO: Endpoints retornando HTML ao invés de JSON - possível erro 502');
  }
  
  if (relatorio.status_502 > 0) {
    relatorio.recomendacoes.push('CRÍTICO: Status 502 detectado - problema de infraestrutura ou timeout');
  }
  
  const endpointRobusto = relatorio.resultados_por_endpoint['Certificações Import Robust (Novo)'];
  if (endpointRobusto && endpointRobusto.sucessos > 0) {
    relatorio.recomendacoes.push('SOLUÇÃO: Endpoint robusto funcionando - usar /api/v2/certificacoes-import-robust/import-robust');
  }
  
  if (relatorio.tempo_medio > 30000) {
    relatorio.recomendacoes.push('OTIMIZAÇÃO: Tempo de resposta alto - considerar batches menores');
  }
  
  console.log(JSON.stringify(relatorio, null, 2));
  
  // Salvar relatório em arquivo
  const relatorioFile = `relatorio-teste-502-${Date.now()}.json`;
  fs.writeFileSync(relatorioFile, JSON.stringify(relatorio, null, 2));
  console.log(`\\n💾 Relatório salvo em: ${relatorioFile}`);
  
  console.log(`\\n🏁 Diagnóstico concluído: ${new Date().toISOString()}`);
}

// ✅ EXECUTAR O SCRIPT
if (import.meta.url === `file://${process.argv[1]}`) {
  executarTodosTestes().catch(error => {
    console.error('💥 Erro fatal no diagnóstico:', error);
    process.exit(1);
  });
}
