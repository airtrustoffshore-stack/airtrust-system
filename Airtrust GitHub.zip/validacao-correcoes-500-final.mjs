#!/usr/bin/env node

/**
 * 🔧 VALIDAÇÃO FINAL DAS CORREÇÕES DOS ERROS 500
 * 
 * Script para validar se todas as correções foram aplicadas corretamente
 * e se os endpoints estão funcionando conforme esperado.
 */

const BASE_URL = 'http://localhost:5173';

// ANSI Colors for better output
const colors = {
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  reset: '\x1b[0m',
  bold: '\x1b[1m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function logSection(title) {
  console.log('\n' + '='.repeat(60));
  log(`${title}`, 'bold');
  console.log('='.repeat(60));
}

async function testEndpoint(method, url, body = null, expectedStatus = 200) {
  const startTime = Date.now();
  
  try {
    const options = {
      method: method,
      headers: { 'Content-Type': 'application/json' }
    };
    
    if (body && (method === 'POST' || method === 'PUT')) {
      options.body = JSON.stringify(body);
    }
    
    log(`  Testing ${method} ${url}...`, 'cyan');
    
    const response = await fetch(`${BASE_URL}${url}`, options);
    const duration = Date.now() - startTime;
    
    const status = response.status;
    const isSuccess = status === expectedStatus;
    
    if (isSuccess) {
      log(`  ✅ SUCCESS: ${status} (${duration}ms)`, 'green');
      
      // Try to parse response if it's JSON
      try {
        const data = await response.json();
        if (data.success !== undefined) {
          log(`     Response success: ${data.success}`, data.success ? 'green' : 'yellow');
        }
        if (data.debug) {
          log(`     Debug info: ${data.debug.endpoint || 'N/A'}`, 'blue');
        }
        if (data.error) {
          log(`     ⚠️  Response has error: ${data.error}`, 'yellow');
        }
      } catch (e) {
        // Not JSON, that's ok
      }
      
      return { success: true, status, duration, endpoint: url };
    } else {
      log(`  ❌ FAILED: Expected ${expectedStatus}, got ${status} (${duration}ms)`, 'red');
      
      try {
        const errorText = await response.text();
        log(`     Error: ${errorText.substring(0, 200)}`, 'red');
      } catch (e) {
        log(`     Could not read error response`, 'red');
      }
      
      return { success: false, status, duration, endpoint: url };
    }
    
  } catch (error) {
    const duration = Date.now() - startTime;
    log(`  💥 ERROR: ${error.message} (${duration}ms)`, 'red');
    return { success: false, status: 0, duration, endpoint: url, error: error.message };
  }
}

async function runValidation() {
  logSection('🔧 VALIDAÇÃO FINAL DAS CORREÇÕES DOS ERROS 500');
  
  log('Iniciando validação dos endpoints corrigidos...', 'blue');
  console.log();
  
  // 1. TESTE DE CONECTIVIDADE BÁSICA
  logSection('📡 1. TESTE DE CONECTIVIDADE BÁSICA');
  
  const basicTests = [
    ['GET', '/', 200],
    ['GET', '/health', 200],
    ['GET', '/api/v2/debug/endpoint-status', 200]
  ];
  
  let basicSuccessCount = 0;
  for (const [method, url, expectedStatus] of basicTests) {
    const result = await testEndpoint(method, url, null, expectedStatus);
    if (result.success) basicSuccessCount++;
  }
  
  log(`\nConectividade básica: ${basicSuccessCount}/${basicTests.length} sucessos`, 
      basicSuccessCount === basicTests.length ? 'green' : 'yellow');
  
  // 2. TESTE DOS ENDPOINTS CORRIGIDOS ESPECÍFICOS
  logSection('🔧 2. ENDPOINTS CORRIGIDOS (VERSÕES FIXED)');
  
  const fixedEndpointsTests = [
    ['GET', '/api/v2/simulador/notificacoes/1', 200],
    ['GET', '/api/v2/simulador/sessoes', 200],
    ['GET', '/api/v2/simulador/progresso/1', 200],
    ['GET', '/api/v2/simulador/progresso/1/1', 200],
    ['GET', '/api/v2/simulador/ficha/TESTE-001/avaliacao', 200],
    ['PUT', '/api/v2/simulador/ficha/TESTE-001/avaliacao', 200]
  ];
  
  let fixedSuccessCount = 0;
  for (const [method, url, expectedStatus] of fixedEndpointsTests) {
    const body = method === 'PUT' ? { 
      conceito: 'APROVADO', 
      nota: 8.5,
      observacoes: 'Teste de validação'
    } : null;
    
    const result = await testEndpoint(method, url, body, expectedStatus);
    if (result.success) fixedSuccessCount++;
  }
  
  log(`\nEndpoints corrigidos: ${fixedSuccessCount}/${fixedEndpointsTests.length} sucessos`, 
      fixedSuccessCount >= Math.floor(fixedEndpointsTests.length * 0.8) ? 'green' : 'yellow');
  
  // 3. TESTE DOS ENDPOINTS ORIGINAIS
  logSection('🔍 3. ENDPOINTS ORIGINAIS (VERIFICAÇÃO)');
  
  const originalEndpointsTests = [
    ['GET', '/api/v2/simulador/manobras-catalogo', 200],
    ['POST', '/api/v2/simulador/assinatura-digital', 200]
  ];
  
  let originalSuccessCount = 0;
  for (const [method, url, expectedStatus] of originalEndpointsTests) {
    const body = method === 'POST' ? { 
      usuario_id: 1, 
      documento_id: 'TEST-DOC',
      tipo_assinatura: 'INSTRUTOR'
    } : null;
    
    const result = await testEndpoint(method, url, body, expectedStatus);
    if (result.success) originalSuccessCount++;
  }
  
  log(`\nEndpoints originais: ${originalSuccessCount}/${originalEndpointsTests.length} sucessos`, 
      originalSuccessCount >= Math.floor(originalEndpointsTests.length * 0.7) ? 'green' : 'yellow');
  
  // 4. CÁLCULO DO SCORE FINAL
  logSection('📊 4. RESULTADO FINAL');
  
  const totalTests = basicTests.length + fixedEndpointsTests.length + originalEndpointsTests.length;
  const totalSuccesses = basicSuccessCount + fixedSuccessCount + originalSuccessCount;
  const finalScore = Math.round((totalSuccesses / totalTests) * 100);
  
  log(`Score Final: ${finalScore}%`, finalScore >= 85 ? 'green' : finalScore >= 70 ? 'yellow' : 'red');
  log(`Total de testes: ${totalTests}`, 'blue');
  log(`Sucessos: ${totalSuccesses}`, 'green');
  log(`Falhas: ${totalTests - totalSuccesses}`, totalSuccesses === totalTests ? 'green' : 'red');
  
  // Status final
  console.log('\n' + '='.repeat(60));
  if (finalScore >= 85) {
    log('🎉 VALIDAÇÃO APROVADA! Sistema operacional.', 'green');
    log('✅ Correções dos erros 500 implementadas com sucesso.', 'green');
  } else if (finalScore >= 70) {
    log('⚠️  VALIDAÇÃO PARCIAL. Sistema funcional com algumas limitações.', 'yellow');
    log('🔧 Algumas correções ainda podem ser necessárias.', 'yellow');
  } else {
    log('❌ VALIDAÇÃO REPROVADA. Sistema precisa de mais correções.', 'red');
    log('🚨 Erros críticos ainda presentes.', 'red');
  }
  
  console.log('='.repeat(60));
  
  // Retornar código de saída apropriado
  process.exit(finalScore >= 85 ? 0 : 1);
}

// Executar validação
runValidation().catch(error => {
  log(`💥 Erro fatal na validação: ${error.message}`, 'red');
  process.exit(2);
});
