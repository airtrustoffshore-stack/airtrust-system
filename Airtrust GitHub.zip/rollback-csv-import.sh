#!/bin/bash
echo "🚨 ROLLBACK M4.9 - CSV Import System"
BACKUP_TAG=$(git tag -l "pre-csv-import-*" | tail -n1)
echo "Revertendo para tag: $BACKUP_TAG"
git reset --hard $BACKUP_TAG
curl -s http://localhost:5173/api/v2/system/health | jq '.status'
echo "✅ Rollback concluído"
