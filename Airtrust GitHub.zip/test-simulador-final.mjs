#!/usr/bin/env node

/**
 * 🧪 TESTE COMPLETO DO MÓDULO SIMULADOR - VALIDAÇÃO FINAL
 * 
 * Este script executa testes reais em todas as funcionalidades
 * para validar se o módulo simulador está 100% funcional
 */

const BASE_URL = process.env.TEST_URL || 'http://localhost:5173';

const testes = [
  {
    nome: '🔍 Listar Fichas',
    endpoint: '/api/v2/simulador/fichas',
    metodo: 'GET',
    critico: true
  },
  {
    nome: '🎮 Listar Simuladores',
    endpoint: '/api/v2/simulador/simuladores',
    metodo: 'GET',
    critico: true
  },
  {
    nome: '📋 Listar Templates',
    endpoint: '/api/v2/simulador/templates',
    metodo: 'GET',
    critico: true
  },
  {
    nome: '👥 Listar Funcionários',
    endpoint: '/api/v2/funcionarios',
    metodo: 'GET',
    critico: true
  },
  {
    nome: '⚙️ Listar Manobras',
    endpoint: '/api/v2/simulador/manobras',
    metodo: 'GET',
    critico: false
  },
  {
    nome: '📊 Estatísticas',
    endpoint: '/api/v2/simulador/estatisticas',
    metodo: 'GET',
    critico: false
  }
];

const testeCreacao = {
  nome: '✅ Criar Agendamento',
  endpoint: '/api/v2/simulador/agendamento',
  metodo: 'POST',
  dados: {
    data_inicio: '21/09/2025',
    hora_inicio: '14:00',
    data_fim: '21/09/2025',
    hora_fim: '16:00',
    simulador_id: '1',
    instrutor_id: '1',
    colaborador_aluno_id: '1',
    funcao_na_sessao: 'PIC',
    observacoes: 'Teste automático final'
  },
  critico: true
};

async function executarTeste(teste) {
  try {
    console.log(`🔄 Testando: ${teste.nome}...`);
    
    const options = {
      method: teste.metodo,
      headers: { 'Content-Type': 'application/json' }
    };
    
    if (teste.dados) {
      options.body = JSON.stringify(teste.dados);
    }
    
    const response = await fetch(`${BASE_URL}${teste.endpoint}`, options);
    const data = await response.json();
    
    const sucesso = response.ok;
    const status = response.status;
    
    if (sucesso) {
      console.log(`✅ ${teste.nome}: ${status} OK`);
      
      // Log extra info para endpoints importantes
      if (teste.endpoint.includes('fichas') && data.fichas) {
        console.log(`   📋 Total de fichas: ${data.fichas.length}`);
      }
      if (teste.endpoint.includes('simuladores') && data.simuladores) {
        console.log(`   🎮 Total de simuladores: ${data.simuladores.length}`);
      }
      if (teste.endpoint.includes('templates') && data.templates) {
        console.log(`   📋 Total de templates: ${data.templates.length}`);
      }
      if (teste.endpoint.includes('agendamento') && data.agendamento) {
        console.log(`   🎯 Ficha criada: ${data.agendamento.ficha_uuid}`);
      }
    } else {
      console.log(`❌ ${teste.nome}: ${status} ERRO`);
      if (data.error) {
        console.log(`   💬 Erro: ${data.error}`);
      }
    }
    
    return {
      nome: teste.nome,
      status,
      sucesso,
      critico: teste.critico,
      dados: data
    };
    
  } catch (error) {
    console.log(`❌ ${teste.nome}: ERRO DE CONEXÃO`);
    console.log(`   💬 ${error.message}`);
    
    return {
      nome: teste.nome,
      status: 'ERRO',
      sucesso: false,
      critico: teste.critico,
      erro: error.message
    };
  }
}

async function executarTodosOsTestes() {
  console.log('🚀 INICIANDO VALIDAÇÃO FINAL DO MÓDULO SIMULADOR');
  console.log('=' .repeat(60));
  
  const resultados = [];
  
  // Executar testes de leitura
  for (const teste of testes) {
    const resultado = await executarTeste(teste);
    resultados.push(resultado);
    await new Promise(resolve => setTimeout(resolve, 500)); // Delay entre testes
  }
  
  // Executar teste de criação
  const resultadoCriacao = await executarTeste(testeCreacao);
  resultados.push(resultadoCriacao);
  
  console.log('\n' + '=' .repeat(60));
  console.log('📊 RESULTADO FINAL DA VALIDAÇÃO:');
  console.log('=' .repeat(60));
  
  const sucessos = resultados.filter(r => r.sucesso).length;
  const total = resultados.length;
  const percentual = Math.round((sucessos / total) * 100);
  
  // Verificar testes críticos
  const testesCapiticos = resultados.filter(r => r.critico);
  const sucessosCriticos = testesCapiticos.filter(r => r.sucesso).length;
  const totalCriticos = testesCapiticos.length;
  const percentualCriticos = Math.round((sucessosCriticos / totalCriticos) * 100);
  
  console.log(`🎯 Score Geral: ${sucessos}/${total} (${percentual}%)`);
  console.log(`🔥 Score Crítico: ${sucessosCriticos}/${totalCriticos} (${percentualCriticos}%)`);
  
  console.log('\n📋 Detalhes por Teste:');
  resultados.forEach(resultado => {
    const icon = resultado.sucesso ? '✅' : '❌';
    const critico = resultado.critico ? '🔥' : '⚡';
    console.log(`${icon} ${critico} ${resultado.nome}: ${resultado.status}`);
  });
  
  console.log('\n' + '=' .repeat(60));
  
  if (percentualCriticos >= 100) {
    console.log('🎉 MÓDULO SIMULADOR 100% FUNCIONAL!');
    console.log('✅ Todas as funcionalidades críticas estão operacionais');
    console.log('✅ Interface de listagem funcionando');
    console.log('✅ Formulário de agendamento funcionando');
    console.log('✅ Endpoints principais funcionando');
    console.log('✅ Sistema pronto para produção!');
  } else if (percentualCriticos >= 80) {
    console.log('⚠️  MÓDULO SIMULADOR PARCIALMENTE FUNCIONAL');
    console.log('⚠️  Algumas funcionalidades críticas falharam');
    console.log('⚠️  Revisar problemas antes de ir para produção');
  } else {
    console.log('❌ MÓDULO SIMULADOR COM PROBLEMAS GRAVES');
    console.log('❌ Muitas funcionalidades críticas falharam');
    console.log('❌ Não recomendado para produção');
  }
  
  console.log('\n🏁 Validação concluída!');
  
  return {
    percentual,
    percentualCriticos,
    resultados,
    aprovado: percentualCriticos >= 100
  };
}

// Executar se chamado diretamente
if (import.meta.url === `file://${process.argv[1]}`) {
  executarTodosOsTestes().catch(console.error);
}

export default executarTodosOsTestes;
