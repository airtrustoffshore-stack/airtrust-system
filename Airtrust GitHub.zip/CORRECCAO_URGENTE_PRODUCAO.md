# 🚨 CORREÇÃO URGENTE - Problema de Exclusão em Produção

## PROBLEMA IDENTIFICADO
Exclusões funcionam em desenvolvimento mas falham em produção devido a divergências de schema/deployment.

## SOLUÇÃO IMEDIATA (Execute os passos abaixo)

### 1. Deploy Forçado da Versão Atual
```bash
# No seu ambiente local, execute:
npm run build
wrangler deploy --env production
```

### 2. Verificar Schema de Produção
```bash
# Verificar se tabela tem campo deleted_at
wrangler d1 execute airtrust --command "PRAGMA table_info(funcionarios)"
```

### 3. Se Campo deleted_at Estiver Faltando
```bash
# Adicionar campo deleted_at (APENAS se não existir)
wrangler d1 execute airtrust --command "ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP"
```

### 4. Aplicar Índices de Performance
```bash
wrangler d1 execute airtrust --command "CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at)"
```

### 5. Limpeza de Dados Inconsistentes  
```bash
wrangler d1 execute airtrust --command "UPDATE funcionarios SET deleted_at = NULL WHERE deleted_at = ''"
```

### 6. Deploy Final
```bash
wrangler deploy
```

## TESTE PÓS-CORREÇÃO

1. Acesse: https://pwfo2d76v2u7u.mocha.app
2. Vá em Funcionários
3. Tente excluir um funcionário
4. Deve funcionar com mensagem "Funcionário removido com sucesso"

## DIAGNÓSTICO ADICIONAL

Se ainda não funcionar:

### Verificar Logs
```bash
wrangler tail
```

### Comparar Schema Dev vs Prod
```bash
# Development
wrangler d1 execute airtrust-dev --command "PRAGMA table_info(funcionarios)"

# Production  
wrangler d1 execute airtrust --command "PRAGMA table_info(funcionarios)"
```

### Verificar Health Check
```bash
curl -s https://pwfo2d76v2u7u.mocha.app/api/v2/system/health | jq
```

## SCRIPTS CRIADOS PARA VOCÊ

- `scripts/sync-production-schema.sql` - Para sincronizar schema
- `scripts/production-fix-deploy.sh` - Script automático (se tiver wrangler configurado)

## CAUSA RAIZ IDENTIFICADA

O problema estava na diferença entre:
- **Desenvolvimento**: Schema completo com deleted_at
- **Produção**: Possivelmente faltando campo deleted_at ou índices

## CONTATO DE EMERGÊNCIA

Se precisar de ajuda adicional:
1. Compartilhe output dos comandos acima
2. Verifique se mesmo usuário/permissões entre dev e prod
3. Force refresh no browser (Ctrl+F5)

---
**Status**: ✅ Solução pronta para aplicação
**Tempo estimado**: 5-10 minutos
**Backup necessário**: Automático (wrangler cria snapshots)
