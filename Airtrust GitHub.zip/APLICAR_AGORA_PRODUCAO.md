# 🚨 CORREÇÃO URGENTE - APLICAR AGORA EM PRODUÇÃO

## ⚠️ PROBLEMA CONFIRMADO:
- ✅ DELETE funciona em desenvolvimento  
- ❌ DELETE quebrado em produção após deploy
- 🎯 Causa: Schema divergente entre ambientes

## 🔥 SOLUÇÃO IMEDIATA - EXECUTE AGORA:

### PASSO 1: BACKUP DE SEGURANÇA (OBRIGATÓRIO)
```bash
wrangler d1 backup create airtrust --name "emergency-fix-$(date +%Y%m%d-%H%M%S)"
```

### PASSO 2: VERIFICAR SCHEMA ATUAL EM PRODUÇÃO
```bash
wrangler d1 execute airtrust --command "PRAGMA table_info(funcionarios)"
```

**Cole aqui o resultado para verificar se `deleted_at` existe:**
```
[COLE RESULTADO AQUI]
```

### PASSO 3: APLICAR CORREÇÃO DE SCHEMA
```bash
# Se deleted_at NÃO aparecer no resultado acima, execute:
wrangler d1 execute airtrust --command "ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP"

# Para outras tabelas críticas:
wrangler d1 execute airtrust --command "ALTER TABLE funcoes ADD COLUMN deleted_at TIMESTAMP"
wrangler d1 execute airtrust --command "ALTER TABLE catalogo_treinamentos_v2 ADD COLUMN deleted_at TIMESTAMP"  
wrangler d1 execute airtrust --command "ALTER TABLE historico_certificacoes_v2 ADD COLUMN deleted_at TIMESTAMP"
```

### PASSO 4: APLICAR SCRIPT DE CORREÇÃO COMPLETO
```bash
wrangler d1 execute airtrust --file=scripts/emergency-production-fix.sql
```

### PASSO 5: REDEPLOY APÓS CORREÇÃO
```bash
wrangler deploy
```

### PASSO 6: TESTE IMEDIATO
```bash
# Verificar se sistema responde:
curl -s https://pwfo2d76v2u7u.mocha.app/api/v2/system/health

# Verificar schema corrigido:
wrangler d1 execute airtrust --command "PRAGMA table_info(funcionarios)"
```

## 🧪 TESTE FINAL NA INTERFACE:

1. Acesse: https://pwfo2d76v2u7u.mocha.app
2. Vá em **Funcionários**
3. Tente **excluir** um funcionário
4. Deve aparecer: **"Funcionário removido com sucesso"**

## ✅ RESULTADOS ESPERADOS:

**Schema deve conter:**
- ✅ `deleted_at` TIMESTAMP
- ✅ `funcao` TEXT NOT NULL  
- ✅ Todos os campos necessários

**Funcionamento deve ser:**
- ✅ DELETE retorna HTTP 200
- ✅ Mensagem "Funcionário removido com sucesso"
- ✅ Funcionário some da lista
- ✅ `deleted_at` preenchido no banco

## 🚨 SE AINDA NÃO FUNCIONAR:

### Diagnóstico Adicional:
```bash
# Verificar logs em tempo real:
wrangler tail

# Comparar schema dev vs prod:
wrangler d1 execute airtrust --command "SELECT sql FROM sqlite_master WHERE name = 'funcionarios'"
```

### Cache/CDN:
- Force refresh: **Ctrl+F5**
- Limpe cache do browser
- Aguarde 2-3 minutos para propagação

## 📊 RELATÓRIO OBRIGATÓRIO:

Após aplicar, cole aqui os resultados:

**1. Schema produção após correção:**
```bash
wrangler d1 execute airtrust --command "PRAGMA table_info(funcionarios)"
```
Resultado: [COLE AQUI]

**2. Teste de exclusão:**
- Interface funcionou? ✅ SIM / ❌ NÃO
- Mensagem exibida: [COLE AQUI]
- HTTP status: [COLE AQUI]

**3. Validação banco:**
```bash
wrangler d1 execute airtrust --command "SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE deleted_at IS NULL) as ativos FROM funcionarios"
```
Resultado: [COLE AQUI]

## ⏰ TEMPO ESTIMADO: 5-10 minutos

Execute **AGORA** e reporte resultados!
