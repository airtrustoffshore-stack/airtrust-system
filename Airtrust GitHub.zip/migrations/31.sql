
-- MÓDULO 5: SIMULADORES - Tabelas de Catálogo Enterprise-Grade

-- 1. Simuladores (Versão Enterprise Auditável)
CREATE TABLE simuladores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    codigo_identificacao TEXT UNIQUE NOT NULL,  -- Ex: "SIM-001-AW139"
    tipo_simulador TEXT NOT NULL,               -- FNPT-I, FNPT-II, FFS
    aeronave_base TEXT NOT NULL,
    empresa_local TEXT NOT NULL,
    certificacao_anac TEXT,                     
    status TEXT DEFAULT 'ATIVO' CHECK(status IN ('ATIVO', 'MANUTENCAO', 'INATIVO')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by TEXT,
    deleted_at TIMESTAMP
);

-- 2. Manobras Catálogo (Versão Robusta N:N - SEM coluna ciclo)
CREATE TABLE manobras_catalogo (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manobra_id_codigo TEXT UNIQUE NOT NULL,     -- Ex: "M-101.A"
    nome_manobra TEXT NOT NULL,
    descricao_detalhada TEXT,                   
    categoria TEXT NOT NULL,
    criterios_aprovacao TEXT,                   -- Metadado crucial
    pontuacao_minima INTEGER DEFAULT 5,         -- Regra < 5
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by TEXT,
    deleted_at TIMESTAMP
);

-- 3. Ciclos (A Correção N:N)
CREATE TABLE ciclos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero_ciclo INTEGER UNIQUE NOT NULL, -- 1, 2, ou 3
    nome TEXT NOT NULL,                  -- Ex: "Ciclo Ano 1"
    descricao TEXT
);

-- Dados iniciais dos ciclos
INSERT INTO ciclos (numero_ciclo, nome, descricao) VALUES 
(1, 'Ciclo Ano 1 (Periódico)', 'Primeiro ano do ciclo de treinamento periódico'),
(2, 'Ciclo Ano 2 (Periódico)', 'Segundo ano do ciclo de treinamento periódico'),
(3, 'Ciclo Ano 3 (Periódico)', 'Terceiro ano do ciclo de treinamento periódico');

-- 4. Manobras Catálogo Ciclos (Tabela Join N:N)
CREATE TABLE manobras_catalogo_ciclos (
    manobra_catalogo_id INTEGER NOT NULL, -- FK (lógica) para manobras_catalogo.id
    ciclo_id INTEGER NOT NULL,            -- FK (lógica) para ciclos.id
    PRIMARY KEY (manobra_catalogo_id, ciclo_id)
);

-- 5. Sessões Template (Os Modelos de Sessão)
CREATE TABLE sessoes_template (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    treinamento_codigo TEXT NOT NULL,  -- Chave (lógica) para catalogo_treinamentos_v2.codigo
    numero_sessao INTEGER NOT NULL,    -- Ex: 1, 2, 3...
    nome_sessao TEXT NOT NULL,         -- Ex: "Sessão 1 - IFR e Emergências"
    descricao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by TEXT,
    UNIQUE(treinamento_codigo, numero_sessao)
);

-- 6. Sessões Template Manobras (A Ligação Template <-> Manobras)
CREATE TABLE sessoes_template_manobras (
    sessao_template_id INTEGER NOT NULL,  -- FK (lógica) para sessoes_template.id
    manobra_catalogo_id INTEGER NOT NULL, -- FK (lógica) para manobras_catalogo.id
    PRIMARY KEY (sessao_template_id, manobra_catalogo_id)
);

-- 7. Auditoria Simulador (Tabela de Suporte)
CREATE TABLE auditoria_simulador (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ficha_uuid TEXT,                            -- O ID da Ficha (da Tabela 5.5)
    usuario_id INTEGER,
    acao TEXT NOT NULL,                         -- Ex: "ASSINATURA_INSTRUTOR", "REPROVADO_POR_NOTA"
    detalhes_acao TEXT,                         -- JSON com detalhes (ex: {nota: 3, manobra: 'M-101.A'})
    ip_origem TEXT,
    timestamp_acao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. Notificações Simulador (Tabela de Suporte)
CREATE TABLE notificacoes_simulador (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ficha_uuid TEXT NOT NULL,
    destinatario_id INTEGER NOT NULL,           -- ID do funcionário (aluno, instrutor, etc.)
    tipo_notificacao TEXT NOT NULL CHECK(
        tipo_notificacao IN (
            'SESSAO_AGENDADA', 'PENDENTE_ASSINATURA_ALUNO', 'SESSAO_CONCLUIDA_APROVADA', 'SESSAO_REPROVADA'
        )
    ),
    mensagem TEXT NOT NULL,
    lida BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para performance
CREATE INDEX idx_simuladores_codigo ON simuladores(codigo_identificacao);
CREATE INDEX idx_simuladores_status ON simuladores(status);
CREATE INDEX idx_manobras_codigo ON manobras_catalogo(manobra_id_codigo);
CREATE INDEX idx_manobras_ativo ON manobras_catalogo(ativo);
CREATE INDEX idx_sessoes_template_codigo ON sessoes_template(treinamento_codigo);
CREATE INDEX idx_auditoria_ficha ON auditoria_simulador(ficha_uuid);
CREATE INDEX idx_notificacoes_destinatario ON notificacoes_simulador(destinatario_id);
CREATE INDEX idx_notificacoes_lida ON notificacoes_simulador(lida);
