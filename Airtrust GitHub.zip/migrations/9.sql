
-- Adicionar as licenças médicas e proficiências ao catálogo existente
INSERT INTO catalogo_treinamentos_v2 (codigo, nome, categoria, periodicidade_meses, ativo, descricao) 
VALUES
    ('CMA', 'Certificado Médico Aeronáutico', 'LICENCA_MEDICA', 12, 1, 'Certificado médico obrigatório para exercer atividades aeronáuticas'),
    ('ASO', 'Atestado de Saúde Ocupacional', 'LICENCA_MEDICA', 12, 1, 'Atestado de saúde ocupacional conforme NR-7'),
    ('ICAO', 'Nível de Inglês ICAO', 'PROFICIENCIA', 36, 1, 'Proficiência em inglês aeronáutico conforme padrão ICAO');
