
INSERT INTO user_profiles_v2 (user_id, funcionario_id, user_name, perfil, equipe, ativo) VALUES
('default_admin', NULL, 'Administrador do Sistema', 'ADMIN', 'TI', 1);

INSERT INTO user_permissions_v2 (user_id, modulo, acao, permitido) VALUES
('default_admin', 'aeronaves', 'READ', 1),
('default_admin', 'aeronaves', 'CREATE', 1),
('default_admin', 'aeronaves', 'UPDATE', 1),
('default_admin', 'aeronaves', 'DELETE', 1);
