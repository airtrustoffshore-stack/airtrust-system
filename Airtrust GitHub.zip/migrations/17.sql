
-- Limpar dados antigos de Base64 e preparar para GitHub storage
ALTER TABLE certificado_anexos_v2 DROP COLUMN arquivo_data;
ALTER TABLE certificado_anexos_v2 DROP COLUMN content_type;

-- Adicionar nova coluna para URLs do GitHub
ALTER TABLE certificado_anexos_v2 ADD COLUMN arquivo_github_url TEXT;
