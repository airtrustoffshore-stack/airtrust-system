
-- Inserir dados de teste para o catálogo de treinamentos
INSERT INTO catalogo_treinamentos_v2 (codigo, nome, descricao, categoria, periodicidade_meses, instrutor_obrigatorio, nota_minima, carga_horaria, ativo) VALUES
('SGV-001', 'Segurança de Voo Básica', 'Treinamento introdutório sobre procedimentos de segurança', 'SEGURANÇA', 12, 1, 7.0, 8, 1),
('CRM-001', 'Crew Resource Management', 'Gerenciamento de recursos da tripulação', 'OPERACIONAL', 24, 1, 8.0, 16, 1),
('SMS-001', 'Safety Management System', 'Sistema de gerenciamento de segurança', 'COMPLIANCE', 36, 1, 7.5, 24, 1),
('EMG-001', 'Procedimentos de Emergência', 'Resposta a situações de emergência', 'EMERGÊNCIA', 6, 1, 9.0, 4, 1),
('MNT-001', 'Manutenção Preventiva', 'Procedimentos de manutenção', 'MANUTENÇÃO', 12, 0, 7.0, 12, 1);

-- Inserir alguns dados de teste para histórico de certificações
INSERT INTO historico_certificacoes_v2 (funcionario_id, treinamento_id, data_conclusao, data_vencimento, instrutor, nota_final, status) VALUES
(1, 1, '2024-01-15', '2025-01-15', 'Instrutor Silva', 8.5, 'ATIVO'),
(1, 2, '2024-02-20', '2026-02-20', 'Instrutor Costa', 9.0, 'ATIVO'),
(2, 1, '2024-03-10', '2025-03-10', 'Instrutor Santos', 7.8, 'ATIVO');
