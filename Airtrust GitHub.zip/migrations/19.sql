
-- Adicionar campo tipo_vencimento para especificar como calcular vencimento
ALTER TABLE catalogo_treinamentos_v2 ADD COLUMN tipo_vencimento TEXT DEFAULT 'FINAL_MES' CHECK (tipo_vencimento IN ('DIA_EXATO', 'FINAL_MES'));
