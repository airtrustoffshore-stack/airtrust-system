
-- FASE 1: Inserir dados básicos de teste para auditoria do Módulo 5

-- 1. Criar ciclos se não existirem
INSERT OR IGNORE INTO ciclos (numero_ciclo, nome, descricao) VALUES 
(1, 'Ciclo Básico', 'Ciclo básico de treinamento'),
(2, 'Ciclo Intermediário', 'Ciclo intermediário de treinamento'),
(3, 'Ciclo Avançado', 'Ciclo avançado de treinamento');

-- 2. Criar simulador SIM-TESTE
INSERT INTO simuladores (
  nome, codigo_identificacao, tipo_simulador, aeronave_base, 
  empresa_local, certificacao_anac, status, created_by
) VALUES (
  'Simulador de Teste', 'SIM-TESTE', 'FNPT-II', 'A320', 
  'Centro de Treinamento', 'ANAC-001', 'ATIVO', 'AUDITORIA'
);

-- 3. Criar manobra M-TESTE
INSERT INTO manobras_catalogo (
  manobra_id_codigo, nome_manobra, descricao_detalhada, categoria,
  criterios_aprovacao, pontuacao_minima, ativo, created_by
) VALUES (
  'M-TESTE', 'Manobra de Teste', 'Manobra para auditoria do sistema',
  'CATEGORIA_TESTE', 'Execução adequada conforme procedimentos', 5, 1, 'AUDITORIA'
);

-- 4. Associar manobra aos ciclos 1 e 3
INSERT INTO manobras_catalogo_ciclos (manobra_catalogo_id, ciclo_id)
SELECT mc.id, c.id 
FROM manobras_catalogo mc, ciclos c 
WHERE mc.manobra_id_codigo = 'M-TESTE' 
AND c.numero_ciclo IN (1, 3);

-- 5. Verificar se treinamentos existem, se não criar
INSERT OR IGNORE INTO catalogo_treinamentos_v2 (
  codigo, nome, descricao, categoria, periodicidade_meses, 
  instrutor_obrigatorio, nota_minima, carga_horaria, ativo
) VALUES 
('REC-A', 'Recorrente A', 'Treinamento recorrente tipo A', 'SIMULADOR', 6, 1, 7.0, 8, 1),
('CHK-B', 'Check B', 'Treinamento de check tipo B', 'SIMULADOR', 12, 1, 7.0, 4, 1);

-- 6. Criar templates de sessão
INSERT INTO sessoes_template (
  treinamento_codigo, numero_sessao, nome_sessao, descricao, created_by
) VALUES 
('REC-A', 1, 'TEMPLATE-TESTE', 'Template para auditoria do sistema', 'AUDITORIA'),
('CHK-B', 1, 'TEMPLATE-B', 'Template B para testes', 'AUDITORIA');

-- 7. Associar manobra M-TESTE ao TEMPLATE-TESTE
INSERT INTO sessoes_template_manobras (sessao_template_id, manobra_catalogo_id)
SELECT st.id, mc.id 
FROM sessoes_template st, manobras_catalogo mc 
WHERE st.nome_sessao = 'TEMPLATE-TESTE' 
AND mc.manobra_id_codigo = 'M-TESTE';

-- 8. Garantir que funcionários de teste existam
INSERT OR IGNORE INTO funcionarios (
  nome, matricula, cpf, funcao, status, is_instrutor, is_checador
) VALUES 
('Instrutor Teste', 'INST010', '11111111111', 'INSTRUTOR', 'ATIVO', 1, 0),
('Checador Teste', 'CHECK015', '22222222222', 'CHECADOR', 'ATIVO', 0, 1),
('Aluno PIC Teste', 'PIC020', '33333333333', 'PILOTO', 'ATIVO', 0, 0),
('Aluno SIC Teste', 'SIC021', '44444444444', 'COPILOTO', 'ATIVO', 0, 0);
