
INSERT INTO user_permissions_v2 (user_id, modulo, acao, permitido) VALUES
('admin', 'aeronaves', 'READ', 1),
('admin', 'aeronaves', 'CREATE', 1),
('admin', 'aeronaves', 'UPDATE', 1),
('admin', 'aeronaves', 'DELETE', 1)
ON CONFLICT(user_id, modulo, acao) DO UPDATE SET permitido = 1;
