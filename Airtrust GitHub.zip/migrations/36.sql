
-- Adicionar tabela de assinaturas digitais se não existir
CREATE TABLE IF NOT EXISTS fichas_assinaturas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ficha_id INTEGER NOT NULL,
  tipo_assinatura TEXT NOT NULL CHECK(tipo_assinatura IN ('INSTRUTOR', 'ALUNO', 'CHECADOR')),
  usuario_id INTEGER NOT NULL,
  nome_completo TEXT NOT NULL,
  certificado_digital TEXT,
  timestamp TIMESTAMP NOT NULL,
  ip_origem TEXT,
  user_agent TEXT,
  hash_auditoria TEXT NOT NULL,
  protocolo TEXT UNIQUE NOT NULL,
  status TEXT DEFAULT 'VALIDA' CHECK(status IN ('VALIDA', 'REVOGADA')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Adicionar tabela de notificações email se não existir
CREATE TABLE IF NOT EXISTS notificacoes_email (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  destinatario_email TEXT NOT NULL,
  assunto TEXT NOT NULL,
  corpo_mensagem TEXT NOT NULL,
  tipo_notificacao TEXT NOT NULL,
  ficha_uuid TEXT,
  enviado BOOLEAN DEFAULT FALSE,
  data_envio TIMESTAMP,
  tentativas INTEGER DEFAULT 0,
  erro_envio TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_fichas_assinaturas_ficha_id ON fichas_assinaturas(ficha_id);
CREATE INDEX IF NOT EXISTS idx_fichas_assinaturas_protocolo ON fichas_assinaturas(protocolo);
CREATE INDEX IF NOT EXISTS idx_notificacoes_email_ficha_uuid ON notificacoes_email(ficha_uuid);
CREATE INDEX IF NOT EXISTS idx_notificacoes_email_enviado ON notificacoes_email(enviado);
