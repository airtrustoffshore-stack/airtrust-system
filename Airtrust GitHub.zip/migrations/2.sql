CREATE TABLE user_profiles_v2 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL UNIQUE,
    funcionario_id INTEGER UNIQUE,
    user_name TEXT NOT NULL,
    perfil TEXT NOT NULL CHECK (perfil IN ('ADMIN', 'COMPLIANCE', 'GESTOR', 'FUNCIONARIO')),
    equipe TEXT,
    ativo INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_permissions_v2 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    modulo TEXT NOT NULL,
    acao TEXT NOT NULL,
    permitido INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, modulo, acao)
);

CREATE INDEX IF NOT EXISTS idx_profiles_v2_user_id ON user_profiles_v2(user_id);