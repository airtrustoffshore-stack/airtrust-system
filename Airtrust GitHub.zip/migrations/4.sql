
-- ETAPA 2.1: SCHEMA - Criação das 4 tabelas do Módulo 2

-- Catálogo de Treinamentos
CREATE TABLE catalogo_treinamentos_v2 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo TEXT NOT NULL UNIQUE,
  nome TEXT NOT NULL,
  descricao TEXT,
  categoria TEXT NOT NULL,
  periodicidade_meses INTEGER,
  instrutor_obrigatorio BOOLEAN DEFAULT 0,
  nota_minima REAL DEFAULT 7.0,
  carga_horaria INTEGER,
  ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP
);

-- Histórico de Certificações
CREATE TABLE historico_certificacoes_v2 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  funcionario_id INTEGER NOT NULL,
  treinamento_id INTEGER NOT NULL,
  data_conclusao DATE NOT NULL,
  data_vencimento DATE,
  instrutor TEXT,
  nota_final REAL,
  observacoes TEXT,
  certificado_url TEXT,
  status TEXT DEFAULT 'ATIVO',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP
);

-- Anexos de Certificados
CREATE TABLE certificado_anexos_v2 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  historico_id INTEGER NOT NULL,
  nome_arquivo TEXT NOT NULL,
  url_arquivo TEXT NOT NULL,
  tipo_arquivo TEXT,
  tamanho_bytes INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Status de Compliance
CREATE TABLE compliance_status_v2 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  funcionario_id INTEGER NOT NULL,
  treinamento_id INTEGER NOT NULL,
  status TEXT NOT NULL,
  data_ultima_certificacao DATE,
  data_vencimento DATE,
  dias_para_vencimento INTEGER,
  historico_certificacao_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(funcionario_id, treinamento_id)
);

-- Índices para Performance
CREATE INDEX idx_catalogo_treinamentos_codigo ON catalogo_treinamentos_v2(codigo);
CREATE INDEX idx_catalogo_treinamentos_categoria ON catalogo_treinamentos_v2(categoria);
CREATE INDEX idx_historico_funcionario_id ON historico_certificacoes_v2(funcionario_id);
CREATE INDEX idx_historico_treinamento_id ON historico_certificacoes_v2(treinamento_id);
CREATE INDEX idx_historico_data_vencimento ON historico_certificacoes_v2(data_vencimento);
CREATE INDEX idx_anexos_historico_id ON certificado_anexos_v2(historico_id);
CREATE INDEX idx_compliance_funcionario_id ON compliance_status_v2(funcionario_id);
CREATE INDEX idx_compliance_status ON compliance_status_v2(status);
CREATE INDEX idx_compliance_vencimento ON compliance_status_v2(data_vencimento);
