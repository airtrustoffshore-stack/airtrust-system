
-- Adicionar colunas para armazenamento BASE64 na tabela certificado_anexos_v2
ALTER TABLE certificado_anexos_v2 ADD COLUMN arquivo_data TEXT;
ALTER TABLE certificado_anexos_v2 ADD COLUMN content_type TEXT DEFAULT 'application/pdf';
