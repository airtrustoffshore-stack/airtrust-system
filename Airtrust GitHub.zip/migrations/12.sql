
INSERT OR REPLACE INTO user_permissions_v2 (user_id, modulo, acao, permitido) VALUES
('1', 'aeronaves', 'READ', 1),
('1', 'aeronaves', 'CREATE', 1),
('1', 'aeronaves', 'UPDATE', 1),
('1', 'aeronaves', 'DELETE', 1);
