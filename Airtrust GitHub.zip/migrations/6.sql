
ALTER TABLE compliance_status_v2 ADD COLUMN item_type TEXT DEFAULT 'TREINAMENTO';
ALTER TABLE compliance_status_v2 ADD COLUMN item_name TEXT;
UPDATE compliance_status_v2 SET item_type = 'TREINAMENTO' WHERE item_type IS NULL;
