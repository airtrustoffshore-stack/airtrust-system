-- Popular dados adicionais para sistema completo

-- Inserir mais funcionários instrutor/checador se necessário
INSERT OR IGNORE INTO funcionarios (id, nome, matricula, cpf, funcao, status, is_instrutor, is_checador, created_at, updated_at) VALUES
(21, 'José Roberto Silva', 'INST002', '98765432100', 'INSTRUTOR_SENIOR', 'ATIVO', 1, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(22, 'Ana Paula Santos', 'INST003', '12312312399', 'INSTRUTORA', 'ATIVO', 1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(23, 'Fernando Lima Costa', 'CHECK001', '45645645699', 'CHECADOR', 'ATIVO', 0, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Adicionar mais manobras para diversificar testes
INSERT OR IGNORE INTO manobras_catalogo (id, manobra_id_codigo, nome_manobra, descricao_detalhada, categoria, criterios_aprovacao, pontuacao_minima, ativo, created_at, created_by) VALUES
(9, 'MB-09', 'Pouso de Emergência', 'Execução de pouso em condições anormais', 'EMERGENCIA', 'Controle da aeronave, decisões corretas', 6, 1, CURRENT_TIMESTAMP, 'SISTEMA'),
(10, 'MB-10', 'Recuperação de Estol', 'Identificação e recuperação de estol', 'EMERGENCIA', 'Reconhecimento imediato, ações corretas', 7, 1, CURRENT_TIMESTAMP, 'SISTEMA'),
(11, 'MB-11', 'Voo por Instrumentos', 'Navegação exclusivamente por instrumentos', 'NAVEGACAO', 'Precisão na navegação, interpretação', 6, 1, CURRENT_TIMESTAMP, 'SISTEMA'),
(12, 'MB-12', 'Coordenação Tripulação', 'Trabalho em equipe na cabine', 'CRM', 'Comunicação efetiva, liderança', 5, 1, CURRENT_TIMESTAMP, 'SISTEMA');

-- Criar mais fichas de teste com diferentes status
INSERT OR IGNORE INTO fichas_sessao (id, ficha_uuid, agendamento_slot_id, colaborador_id_aluno, funcao_na_sessao, sessao_template_id, ciclo_executado, status_workflow, resultado_final, nota_final, created_at, created_by) VALUES
(4, 'FICHA-TEST-004', 1, 6, 'SIC', 1, 1, 'CONCLUIDA', 'APROVADO', 8, CURRENT_TIMESTAMP, 'SISTEMA'),
(5, 'FICHA-TEST-005', 2, 7, 'PIC', 2, 2, 'REPROVADA', 'REPROVADO', 4, CURRENT_TIMESTAMP, 'SISTEMA'),
(6, 'FICHA-TEST-006', 3, 8, 'PIC', 1, 1, 'PENDENTE_INSTRUTOR_FINAL', NULL, NULL, CURRENT_TIMESTAMP, 'SISTEMA');

-- Adicionar avaliações para as fichas
INSERT OR IGNORE INTO fichas_manobras_executadas (ficha_id, manobra_catalogo_id, nota, observacoes) VALUES
-- FICHA-TEST-004 (APROVADO)
(4, 2, 8, 'Decolagem bem executada'),
(4, 3, 9, 'Subida excelente'),
(4, 4, 7, 'Aproximação adequada'),
(4, 5, 8, 'Pouso controlado'),
-- FICHA-TEST-005 (REPROVADO)
(5, 2, 4, 'Falhas na decolagem'),
(5, 3, 3, 'Subida irregular'),
(5, 9, 2, 'Emergência mal gerenciada'),
(5, 10, 5, 'Recuperação lenta');

-- Adicionar auditoria para as notas
INSERT OR IGNORE INTO auditoria_manobras (ficha_manobras_executadas_id, usuario_id, acao, valor_anterior, valor_novo, ip_origem, created_at) VALUES
(13, 1, 'NOTA_SALVA', NULL, '8', '127.0.0.1', CURRENT_TIMESTAMP),
(14, 1, 'NOTA_SALVA', NULL, '9', '127.0.0.1', CURRENT_TIMESTAMP),
(15, 1, 'NOTA_SALVA', NULL, '7', '127.0.0.1', CURRENT_TIMESTAMP),
(16, 1, 'NOTA_SALVA', NULL, '8', '127.0.0.1', CURRENT_TIMESTAMP),
(17, 1, 'NOTA_SALVA', NULL, '4', '127.0.0.1', CURRENT_TIMESTAMP),
(18, 1, 'NOTA_SALVA', NULL, '3', '127.0.0.1', CURRENT_TIMESTAMP),
(19, 1, 'NOTA_SALVA', NULL, '2', '127.0.0.1', CURRENT_TIMESTAMP),
(20, 1, 'NOTA_SALVA', NULL, '5', '127.0.0.1', CURRENT_TIMESTAMP);
