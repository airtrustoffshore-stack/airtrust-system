-- 🇧🇷 LIMPEZA E POPULATION SEGURA DE DADOS DE TESTE - PADRÃO BRASILEIRO
-- Primeiro limpar dados existentes, depois inserir novos dados

-- 1. LIMPEZA DE DADOS EXISTENTES (em ordem segura)
DELETE FROM manobras_executadas_individual WHERE sessao_participante_id IN (SELECT id FROM sessao_participantes);
DELETE FROM sessao_participantes;
DELETE FROM sessoes_simulador;
DELETE FROM progresso_treinamento_individual;
DELETE FROM fichas_manobras_executadas;
DELETE FROM fichas_sessao;
DELETE FROM agendamento_slots;
DELETE FROM sessoes_template_manobras;
DELETE FROM sessoes_template;
DELETE FROM manobras_catalogo_ciclos;
DELETE FROM ciclos;
DELETE FROM manobras_catalogo;
DELETE FROM funcionarios WHERE matricula LIKE 'INST%' OR matricula LIKE 'P00%';
DELETE FROM simuladores WHERE codigo_identificacao LIKE 'SIM-%';

-- 2. INSERIR SIMULADORES DE TESTE
INSERT INTO simuladores (nome, codigo_identificacao, tipo_simulador, aeronave_base, empresa_local, certificacao_anac, status, created_by) VALUES
('Simulador Boeing 737-800 #1', 'SIM-B738-01', 'FULL_FLIGHT', 'Boeing 737-800', 'Centro de Treinamento AirTrust SP', 'ANAC-SIM-2023-001', 'ATIVO', 'SISTEMA_POPULATION'),
('Simulador Boeing 737-800 #2', 'SIM-B738-02', 'FULL_FLIGHT', 'Boeing 737-800', 'Centro de Treinamento AirTrust SP', 'ANAC-SIM-2023-002', 'ATIVO', 'SISTEMA_POPULATION'),
('Simulador Airbus A320 #1', 'SIM-A320-01', 'FULL_FLIGHT', 'Airbus A320', 'Centro de Treinamento AirTrust RJ', 'ANAC-SIM-2023-003', 'ATIVO', 'SISTEMA_POPULATION');

-- 3. INSERIR FUNCIONÁRIOS DE TESTE
INSERT INTO funcionarios (nome, matricula, email, funcao, base, contrato, telefone, status, is_instrutor, is_checador, aeronave_principal, data_admissao, guerra, anv, nivel_icao, nivel_icao_data_vencimento, nivel_icao_status) VALUES
-- Instrutores
('Carlos Alberto Santos', 'INST001', 'carlos.santos@airtrust.com.br', 'Instrutor de Simulador', 'SAO PAULO', 'CLT', '(11) 99999-1001', 'ATIVO', 1, 1, 'B737', '2020-03-15', 'CHARLIE', 'PPCA123456', 'NÍVEL 4', '2025-12-31', 'VÁLIDO'),
('Maria Silva Oliveira', 'INST002', 'maria.oliveira@airtrust.com.br', 'Instrutor Senior', 'RIO DE JANEIRO', 'CLT', '(21) 99999-1002', 'ATIVO', 1, 1, 'A320', '2019-05-10', 'MARIA', 'PPMA987654', 'NÍVEL 5', '2025-12-31', 'VÁLIDO'),
-- Tripulantes/Alunos
('João Pedro Lima', 'P001', 'joao.lima@airtrust.com.br', 'Primeiro Oficial', 'SAO PAULO', 'CLT', '(11) 99999-2001', 'ATIVO', 0, 0, 'B737', '2023-01-12', 'JOAO', 'PPJL111222', 'NÍVEL 3', '2025-06-30', 'VÁLIDO'),
('Ana Paula Ferreira', 'P002', 'ana.ferreira@airtrust.com.br', 'Comandante', 'RIO DE JANEIRO', 'CLT', '(21) 99999-2002', 'ATIVO', 0, 0, 'A320', '2021-07-05', 'ANA', 'PPAF333444', 'NÍVEL 4', '2025-08-15', 'VÁLIDO'),
('Pedro Henrique Souza', 'P003', 'pedro.souza@airtrust.com.br', 'Primeiro Oficial', 'SAO PAULO', 'CLT', '(11) 99999-2003', 'ATIVO', 0, 0, 'B737', '2022-09-18', 'PEDRO', 'PPPS555666', 'NÍVEL 3', '2025-09-30', 'VÁLIDO');

-- 4. INSERIR CATÁLOGO DE MANOBRAS
INSERT INTO manobras_catalogo (manobra_id_codigo, nome_manobra, descricao_detalhada, categoria, criterios_aprovacao, pontuacao_minima, ativo, created_by) VALUES
-- Manobras Básicas
('MB-01', 'Decolagem Normal', 'Decolagem em condições normais de pista e vento', 'DECOLAGEM', 'Execução correta dos procedimentos', 5, 1, 'SISTEMA_POPULATION'),
('MB-02', 'Subida Inicial', 'Procedimento de subida após decolagem', 'SUBIDA', 'Manutenção da trajetória correta', 5, 1, 'SISTEMA_POPULATION'),
('MB-03', 'Aproximação Visual', 'Aproximação visual para pouso', 'APROXIMACAO', 'Trajetória estável, alinhamento', 5, 1, 'SISTEMA_POPULATION'),
('MB-04', 'Pouso Normal', 'Pouso em condições normais', 'POUSO', 'Toque suave, centralização', 5, 1, 'SISTEMA_POPULATION'),
-- Manobras Intermediárias
('MI-01', 'Aproximação ILS', 'Aproximação por instrumentos ILS', 'APROXIMACAO', 'Seguimento preciso dos instrumentos', 6, 1, 'SISTEMA_POPULATION'),
('MI-02', 'Go Around', 'Procedimento de arremetida', 'EMERGENCIA', 'Execução correta do procedimento', 6, 1, 'SISTEMA_POPULATION'),
-- Manobras Avançadas
('MA-01', 'Falha de Motor', 'Simulação de falha de motor', 'EMERGENCIA', 'Manutenção do controle', 7, 1, 'SISTEMA_POPULATION'),
('MA-02', 'Pouso de Emergência', 'Pouso com falha de sistemas', 'EMERGENCIA', 'Gerenciamento da emergência', 7, 1, 'SISTEMA_POPULATION');

-- 5. INSERIR CICLOS
INSERT INTO ciclos (numero_ciclo, nome, descricao) VALUES
(1, 'Ciclo Básico', 'Manobras fundamentais'),
(2, 'Ciclo Intermediário', 'Manobras de complexidade média'),
(3, 'Ciclo Avançado', 'Manobras avançadas e emergências');

-- 6. RELACIONAMENTO MANOBRAS × CICLOS
INSERT INTO manobras_catalogo_ciclos (manobra_catalogo_id, ciclo_id) VALUES
-- Ciclo 1 - Básico (IDs 1-4)
(1, 1), (2, 1), (3, 1), (4, 1),
-- Ciclo 2 - Intermediário (IDs 5-6)
(5, 2), (6, 2),
-- Ciclo 3 - Avançado (IDs 7-8)
(7, 3), (8, 3);

-- 7. TEMPLATES DE SESSÃO
INSERT INTO sessoes_template (treinamento_codigo, numero_sessao, nome_sessao, descricao, created_by) VALUES
('TRE-INICIAL-B737', 1, 'Sessão Básica 1', 'Manobras básicas de decolagem e pouso', 'SISTEMA_POPULATION'),
('TRE-INICIAL-B737', 2, 'Sessão Intermediária', 'Aproximações por instrumentos', 'SISTEMA_POPULATION'),
('TRE-PERIODICO-B737', 1, 'Recorrente - Emergências', 'Treinamento de emergências', 'SISTEMA_POPULATION');

-- 8. RELACIONAMENTO TEMPLATES × MANOBRAS
INSERT INTO sessoes_template_manobras (sessao_template_id, manobra_catalogo_id) VALUES
-- Template 1 (Sessão Básica)
(1, 1), (1, 2), (1, 3), (1, 4),
-- Template 2 (Sessão Intermediária)
(2, 5), (2, 6),
-- Template 3 (Emergências)
(3, 7), (3, 8);

-- 9. AGENDAMENTOS/SLOTS DE TESTE
INSERT INTO agendamento_slots (simulador_id, colaborador_id_instrutor, data_inicio, data_fim, status_slot, created_by) VALUES
(1, 1, datetime('now', '-1 day'), datetime('now', '-1 day', '+2 hours'), 'CONCLUIDO', 'SISTEMA_POPULATION'),
(2, 2, datetime('now', '+1 hour'), datetime('now', '+3 hours'), 'AGENDADO', 'SISTEMA_POPULATION'),
(1, 1, datetime('now', '+4 hours'), datetime('now', '+6 hours'), 'AGENDADO', 'SISTEMA_POPULATION');

-- 10. FICHAS DE SESSÃO
INSERT INTO fichas_sessao (ficha_uuid, agendamento_slot_id, colaborador_id_aluno, funcao_na_sessao, sessao_template_id, ciclo_executado, status_workflow, resultado_final, created_by) VALUES
('FICHA-TEST-001', 1, 3, 'PIC', 1, 1, 'CONCLUIDA', 'APROVADO', 'SISTEMA_POPULATION'),
('FICHA-TEST-002', 2, 4, 'SIC', 2, 2, 'PENDENTE_ALUNO', NULL, 'SISTEMA_POPULATION'),
('FICHA-TEST-003', 3, 5, 'PIC', 1, 1, 'RASCUNHO', NULL, 'SISTEMA_POPULATION');

-- 11. MANOBRAS EXECUTADAS (ALGUMAS NOTAS DE EXEMPLO)
INSERT INTO fichas_manobras_executadas (ficha_id, manobra_catalogo_id, nota, observacoes) VALUES
-- Ficha 1 (João Pedro - Concluída)
(1, 1, 8, 'Decolagem bem executada'),
(1, 2, 7, 'Subida dentro dos parâmetros'),
(1, 3, 9, 'Aproximação visual excelente'),
(1, 4, 8, 'Pouso suave e centralizado'),
-- Ficha 2 (Ana Paula - Parcialmente preenchida)
(2, 5, 8, 'ILS bem seguido'),
(2, 6, 7, 'Go-around executado corretamente');
-- Ficha 3 fica sem notas para teste
