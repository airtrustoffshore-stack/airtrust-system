
-- Inserir alguns templates de sessão de exemplo
INSERT INTO sessoes_template (treinamento_codigo, numero_sessao, nome_sessao, descricao, created_by) VALUES
('REC-A', 1, 'Sessão 1 - Procedimentos Normais', 'Decolagem, subida, cruzeiro e aproximação normal', 'SISTEMA'),
('REC-A', 2, 'Sessão 2 - Emergências Básicas', 'Falhas de motor, despressurização e pouso de emergência', 'SISTEMA'),
('REC-A', 3, 'Sessão 3 - Check Final', 'Avaliação completa de competências', 'SISTEMA'),
('CHK-B', 1, 'Sessão 1 - IFR Avançado', 'Procedimentos IFR complexos e navegação', 'SISTEMA'),
('CHK-B', 2, 'Sessão 2 - Emergências Avançadas', 'Múltiplas falhas e cenários complexos', 'SISTEMA'),
('CHK-B', 3, 'Sessão 3 - Avaliação Final', 'Check ride completo', 'SISTEMA'),
('CRM-001', 1, 'Sessão 1 - Comunicação', 'Técnicas de comunicação em cabine', 'SISTEMA'),
('CRM-001', 2, 'Sessão 2 - Tomada de Decisão', 'Processos de decisão sob pressão', 'SISTEMA'),
('CRM-001', 3, 'Sessão 3 - Liderança', 'Exercícios de liderança e trabalho em equipe', 'SISTEMA');
