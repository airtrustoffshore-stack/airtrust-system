-- Adicionar templates básicos para SGV-001 (Simulador de Voo Genérico)
INSERT OR IGNORE INTO sessoes_template (treinamento_codigo, numero_sessao, nome_sessao, descricao, created_by)
VALUES 
  ('SGV-001', 1, 'Procedimentos Básicos', 'Sessão inicial com procedimentos fundamentais de voo', 'SISTEMA'),
  ('SGV-001', 2, 'Manobras Avançadas', 'Sessão com manobras complexas e situações de emergência', 'SISTEMA');

-- Adicionar templates básicos para SMS-001 (Sistema de Manutenção e Segurança)  
INSERT OR IGNORE INTO sessoes_template (treinamento_codigo, numero_sessao, nome_sessao, descricao, created_by)
VALUES
  ('SMS-001', 1, 'Segurança Operacional', 'Fundamentos de segurança e procedimentos operacionais', 'SISTEMA'),
  ('SMS-001', 2, 'Manutenção Preventiva', 'Procedimentos de manutenção e inspeção de segurança', 'SISTEMA'),
  ('SMS-001', 3, 'Gerenciamento de Riscos', 'Identificação e mitigação de riscos operacionais', 'SISTEMA');