
-- Criar tabela de aeronaves (catálogo)
CREATE TABLE aeronaves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo TEXT UNIQUE NOT NULL,
  nome TEXT NOT NULL,
  fabricante TEXT,
  categoria TEXT,
  ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Criar tabela para relacionamento N:N entre funcionários e aeronaves
CREATE TABLE funcionarios_aeronaves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  funcionario_id INTEGER NOT NULL,
  aeronave_codigo TEXT NOT NULL,
  data_habilitacao DATE,
  status TEXT DEFAULT 'ATIVO' CHECK (status IN ('ATIVO', 'INATIVO', 'SUSPENSA')),
  observacoes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(funcionario_id, aeronave_codigo)
);

-- Inserir aeronaves padrão
INSERT INTO aeronaves (codigo, nome, fabricante, categoria) VALUES 
('AW139', 'AgustaWestland AW139', 'Leonardo', 'HELICOPTERO'),
('SK76', 'Sikorsky S-76', 'Sikorsky', 'HELICOPTERO'),
('EC130', 'Eurocopter EC130', 'Airbus', 'HELICOPTERO'),
('R44', 'Robinson R44', 'Robinson', 'HELICOPTERO'),
('AS350', 'Eurocopter AS350', 'Airbus', 'HELICOPTERO');

-- Índices para performance
CREATE INDEX idx_func_aeronaves_funcionario ON funcionarios_aeronaves(funcionario_id);
CREATE INDEX idx_func_aeronaves_aeronave ON funcionarios_aeronaves(aeronave_codigo);
CREATE INDEX idx_aeronaves_codigo ON aeronaves(codigo);
