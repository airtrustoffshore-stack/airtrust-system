CREATE TABLE funcoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL UNIQUE,
    descricao TEXT,
    categoria TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

CREATE TABLE funcionarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    matricula TEXT UNIQUE,
    cpf TEXT UNIQUE,
    codigo_anac TEXT,
    funcao TEXT NOT NULL,
    base TEXT,
    contrato TEXT,
    telefone TEXT,
    email TEXT UNIQUE,
    status TEXT DEFAULT 'ATIVO',
    cma_numero TEXT,
    cma_data_vencimento DATE,
    cma_status TEXT,
    aso_data_vencimento DATE,
    nivel_icao TEXT,
    nivel_icao_data_vencimento DATE,
    nivel_icao_status TEXT,
    is_instrutor INTEGER DEFAULT 0,
    is_checador INTEGER DEFAULT 0,
    aeronave_principal TEXT,
    avatar TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_funcionarios_matricula ON funcionarios(matricula);
CREATE INDEX IF NOT EXISTS idx_funcionarios_funcao ON funcionarios(funcao);
CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at);