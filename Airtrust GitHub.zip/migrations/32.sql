
-- Tabela de slots de agendamento (calendário de duplas)
CREATE TABLE agendamento_slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    simulador_id INTEGER NOT NULL,
    colaborador_id_instrutor INTEGER NOT NULL,
    colaborador_id_checador INTEGER,
    data_inicio TIMESTAMP NOT NULL,
    data_fim TIMESTAMP NOT NULL,
    status_slot TEXT DEFAULT 'AGENDADO' CHECK(status_slot IN ('AGENDADO', 'EM_ANDAMENTO', 'CONCLUIDO', 'CANCELADO')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by TEXT
);

CREATE INDEX idx_agendamento_slots_datas ON agendamento_slots(data_inicio, data_fim);
CREATE INDEX idx_agendamento_slots_instrutor ON agendamento_slots(colaborador_id_instrutor);

-- Super-tabela de fichas de sessão individual
CREATE TABLE fichas_sessao (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ficha_uuid TEXT UNIQUE NOT NULL,
    agendamento_slot_id INTEGER NOT NULL,
    colaborador_id_aluno INTEGER NOT NULL,
    funcao_na_sessao TEXT NOT NULL DEFAULT 'PIC' CHECK(funcao_na_sessao IN ('PIC', 'SIC')),
    sessao_template_id INTEGER NOT NULL,
    ciclo_executado INTEGER NOT NULL,
    status_workflow TEXT NOT NULL DEFAULT 'RASCUNHO' CHECK(
        status_workflow IN (
            'RASCUNHO',
            'PENDENTE_ALUNO',
            'PENDENTE_INSTRUTOR_FINAL',
            'PENDENTE_CHECK',
            'CONCLUIDA',
            'REPROVADA'
        )
    ),
    resultado_final TEXT CHECK(resultado_final IN ('APROVADO', 'REPROVADO', NULL)),
    nota_final DECIMAL(3,1),
    assinatura_aluno_timestamp TIMESTAMP,
    assinatura_aluno_ip TEXT,
    assinatura_instrutor_timestamp TIMESTAMP,
    assinatura_final_instrutor_timestamp TIMESTAMP,
    assinatura_checador_timestamp TIMESTAMP,
    pdf_rascunho_url TEXT,
    pdf_final_url TEXT,
    observacoes_instrutor TEXT,
    observacoes_aluno TEXT,
    certificacao_automatica_executada BOOLEAN DEFAULT FALSE,
    certificacao_automatica_timestamp TIMESTAMP,
    certificacao_automatica_erro TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by TEXT,
    deleted_at TIMESTAMP
);

CREATE INDEX idx_fichas_sessao_uuid ON fichas_sessao(ficha_uuid);
CREATE INDEX idx_fichas_sessao_aluno_status ON fichas_sessao(colaborador_id_aluno, status_workflow);
CREATE INDEX idx_fichas_sessao_slot ON fichas_sessao(agendamento_slot_id);

-- Tabela de manobras executadas com notas
CREATE TABLE fichas_manobras_executadas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ficha_id INTEGER NOT NULL,
    manobra_catalogo_id INTEGER NOT NULL,
    nota INTEGER NOT NULL CHECK(nota >= 1 AND nota <= 10),
    observacoes TEXT
);

CREATE INDEX idx_fichas_manobras_ficha ON fichas_manobras_executadas(ficha_id);
