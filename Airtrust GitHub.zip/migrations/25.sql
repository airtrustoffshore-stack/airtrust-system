
-- Migration para garantir sincronização completa dev-prod
-- Corrigir possíveis diferenças entre ambientes

-- Garantir índices para performance em soft delete (são criados apenas se não existirem)
CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at);
CREATE INDEX IF NOT EXISTS idx_funcoes_deleted_at ON funcoes(deleted_at);
CREATE INDEX IF NOT EXISTS idx_catalogo_treinamentos_deleted_at ON catalogo_treinamentos_v2(deleted_at);  
CREATE INDEX IF NOT EXISTS idx_historico_certificacoes_deleted_at ON historico_certificacoes_v2(deleted_at);

-- Garantir que registros ativos tenham deleted_at = NULL (não vazio)
UPDATE funcionarios SET deleted_at = NULL WHERE deleted_at = '';
UPDATE funcoes SET deleted_at = NULL WHERE deleted_at = '';
UPDATE catalogo_treinamentos_v2 SET deleted_at = NULL WHERE deleted_at = '';
UPDATE historico_certificacoes_v2 SET deleted_at = NULL WHERE deleted_at = '';

-- Garantir que consultas de soft delete funcionem corretamente
-- (Esta migration é safe e idempotente)
