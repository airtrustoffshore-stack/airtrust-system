
-- Criar tabela de auditoria para manobras
CREATE TABLE auditoria_manobras (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ficha_manobras_executadas_id INTEGER NOT NULL,
  usuario_id INTEGER NOT NULL,
  acao TEXT NOT NULL,
  valor_anterior TEXT,
  valor_novo TEXT,
  ip_origem TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índice para auditoria de manobras
CREATE INDEX idx_auditoria_manobras_ficha ON auditoria_manobras 
  (ficha_manobras_executadas_id, created_at DESC);

-- Índice para performance nas consultas existentes da tabela fichas_manobras_executadas
CREATE INDEX idx_fichas_manobras_ficha_id ON fichas_manobras_executadas (ficha_id);
CREATE INDEX idx_fichas_manobras_catalogo_id ON fichas_manobras_executadas (manobra_catalogo_id);
