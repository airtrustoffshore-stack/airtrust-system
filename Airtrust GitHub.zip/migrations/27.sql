-- LIMPEZA DE DADOS INCONSISTENTES: Executar EXATAMENTE como especificado

-- 1. REMOVER funcionários com matrícula inválida ou inexistente
DELETE FROM funcionarios 
WHERE matricula IN ('03000', '00000') 
   OR LENGTH(matricula) > 5
   OR matricula LIKE '%[^0-9]%';

-- 2. REMOVER certificações órfãs (sem funcionário válido) se houver referências
DELETE FROM historico_certificacoes_v2 
WHERE funcionario_id NOT IN (
  SELECT id FROM funcionarios WHERE deleted_at IS NULL
);

-- 3. CRIAR índices para performance
CREATE INDEX IF NOT EXISTS idx_historico_cert_funcionario_treinamento ON historico_certificacoes_v2(funcionario_id, treinamento_id);
CREATE INDEX IF NOT EXISTS idx_funcionarios_matricula ON funcionarios(matricula);
CREATE INDEX IF NOT EXISTS idx_catalogo_codigo ON catalogo_treinamentos_v2(codigo);