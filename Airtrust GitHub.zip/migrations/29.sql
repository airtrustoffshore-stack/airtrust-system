
-- Criar tabela de auditoria de limpeza para documentar a remoção de dados de exemplo
CREATE TABLE IF NOT EXISTS auditoria_limpeza_dados (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  operacao TEXT NOT NULL,
  tabela_afetada TEXT NOT NULL,
  registros_removidos INTEGER DEFAULT 0,
  registros_atualizados INTEGER DEFAULT 0,
  criterio_remocao TEXT,
  data_execucao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  usuario_responsavel TEXT DEFAULT 'SISTEMA_LIMPEZA',
  status_operacao TEXT DEFAULT 'CONCLUIDA',
  observacoes TEXT
);

-- Registrar a limpeza executada
INSERT INTO auditoria_limpeza_dados (
  operacao, 
  tabela_afetada, 
  registros_removidos, 
  criterio_remocao, 
  observacoes
) VALUES 
('LIMPEZA_DEMO_DATA', 'funcionarios', 5, 'Remoção de funcionários de exemplo por matrícula P001, C001, M001, I001, P002', 'Limpeza total conforme padrão AirTrust - dados de demonstração removidos'),
('LIMPEZA_DEMO_DATA', 'catalogo_treinamentos_v2', 8, 'Remoção de treinamentos de exemplo por código SGV-001, CRM-001, SMS-001, EMG-001, MNT-001, CMA, ASO, ICAO', 'Limpeza total conforme padrão AirTrust - dados de demonstração removidos'),
('LIMPEZA_DEMO_DATA', 'historico_certificacoes_v2', 0, 'Remoção de certificações relacionadas aos funcionários de exemplo', 'Dados de certificação de exemplo removidos'),
('LIMPEZA_DEMO_DATA', 'compliance_status_v2', 0, 'Remoção de status de compliance relacionados aos funcionários de exemplo', 'Dados de compliance de exemplo removidos');

-- Criar índice para consultas de auditoria
CREATE INDEX IF NOT EXISTS idx_auditoria_limpeza_data_execucao ON auditoria_limpeza_dados(data_execucao);
CREATE INDEX IF NOT EXISTS idx_auditoria_limpeza_tabela ON auditoria_limpeza_dados(tabela_afetada);
