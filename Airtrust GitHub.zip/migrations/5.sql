
-- Inserir algumas funções básicas
INSERT INTO funcoes (nome, descricao, categoria) VALUES 
('PILOTO', 'Piloto em comando e copiloto', 'TRIPULACAO_TECNICA'),
('COMISSARIO', 'Comissário de bordo', 'TRIPULACAO_CABINE'),
('MECANICO', 'Técnico de manutenção aeronáutica', 'MANUTENCAO'),
('INSTRUTOR_VOO', 'Instrutor de voo e simulador', 'INSTRUCAO'),
('DESPACHANTE_VOO', 'Despachante operacional de voo', 'OPERACOES');

-- Inserir alguns funcionários de teste
INSERT INTO funcionarios (nome, matricula, funcao, base, telefone, email, status, is_instrutor, is_checador, aeronave_principal) VALUES 
('Ricardo Silva Santos', 'P001', 'PILOTO', 'SBGR', '(11) 99999-1234', 'ricardo.silva@airtrust.com', 'ATIVO', 1, 0, 'A320'),
('Maria Oliveira Costa', 'C001', 'COMISSARIO', 'SBGR', '(11) 99999-5678', 'maria.oliveira@airtrust.com', 'ATIVO', 0, 0, NULL),
('João Pedro Lima', 'M001', 'MECANICO', 'SBGR', '(11) 99999-9012', 'joao.lima@airtrust.com', 'ATIVO', 0, 1, 'A320'),
('Ana Paula Ferreira', 'P002', 'PILOTO', 'SBSP', '(11) 99999-3456', 'ana.ferreira@airtrust.com', 'ATIVO', 1, 1, 'B737'),
('Carlos Eduardo Souza', 'I001', 'INSTRUTOR_VOO', 'SBGR', '(11) 99999-7890', 'carlos.souza@airtrust.com', 'ATIVO', 1, 1, 'A320');
