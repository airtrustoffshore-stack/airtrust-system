-- Inserir templates para treinamentos sem templates
INSERT INTO sessoes_template (treinamento_codigo, numero_sessao, nome_sessao, descricao, created_by) VALUES
-- SGV-001 (Segurança de Voo Básica)
('SGV-001', 1, 'Sessão 1 - Fundamentos de Segurança', 'Conceitos básicos de segurança operacional', 'SISTEMA_AUDITORIA'),
('SGV-001', 2, 'Sessão 2 - Procedimentos de Emergência', 'Simulação de emergências e procedimentos', 'SISTEMA_AUDITORIA'),

-- SMS-001 (Safety Management System)  
('SMS-001', 1, 'Sessão 1 - Implementação SMS', 'Implementação do sistema de gerenciamento de segurança', 'SISTEMA_AUDITORIA'),
('SMS-001', 2, 'Sessão 2 - Análise de Riscos', 'Metodologias de identificação e análise de riscos', 'SISTEMA_AUDITORIA'),
('SMS-001', 3, 'Sessão 3 - Auditoria e Monitoramento', 'Processos de auditoria interna e monitoramento contínuo', 'SISTEMA_AUDITORIA'),

-- EMG-001 (Procedimentos de Emergência)
('EMG-001', 1, 'Sessão 1 - Emergências em Voo', 'Simulação de emergências durante o voo', 'SISTEMA_AUDITORIA'),
('EMG-001', 2, 'Sessão 2 - Evacuação de Emergência', 'Procedimentos de evacuação e abandono da aeronave', 'SISTEMA_AUDITORIA'),

-- MNT-001 (Manutenção Preventiva)
('MNT-001', 1, 'Sessão 1 - Inspeções Programadas', 'Procedimentos de manutenção preventiva', 'SISTEMA_AUDITORIA'),
('MNT-001', 2, 'Sessão 2 - Documentação Técnica', 'Preenchimento de documentação de manutenção', 'SISTEMA_AUDITORIA');