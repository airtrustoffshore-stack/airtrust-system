
-- CRIAR TABELA CERTIFICAÇÕES V3 COM SISTEMA REVOLUCIONÁRIO DE IDs AUTOMÁTICOS
CREATE TABLE certificacoes_v3 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  certificacao_id TEXT UNIQUE NOT NULL,     -- CERT-YYMMDD-XXXXX
  funcionario_matricula TEXT NOT NULL,      -- 00300, 00001, etc.
  treinamento_codigo TEXT NOT NULL,         -- CMA-001, ICAO-001, etc.
  
  -- Dados principais
  data_conclusao DATE NOT NULL,
  data_vencimento DATE,
  instrutor TEXT,
  local_realizacao TEXT,
  nota_final REAL,
  observacoes TEXT,
  
  -- Controle inteligente
  status TEXT DEFAULT 'ATIVO',             -- ATIVO, VENCIDO, CANCELADO
  certificacao_anterior_id TEXT,           -- Para renovações
  tipo_operacao TEXT DEFAULT 'NOVA',       -- NOVA, RENOVACAO, REVALIDACAO
  
  -- Compliance automático
  compliance_status TEXT DEFAULT 'VALIDO',
  dias_para_vencimento INTEGER,            -- Calculado automaticamente
  
  -- Auditoria
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (funcionario_matricula) REFERENCES funcionarios(matricula)
);

-- Índices para performance
CREATE INDEX idx_certificacoes_v3_funcionario ON certificacoes_v3(funcionario_matricula);
CREATE INDEX idx_certificacoes_v3_treinamento ON certificacoes_v3(treinamento_codigo);
CREATE INDEX idx_certificacoes_v3_data_vencimento ON certificacoes_v3(data_vencimento);
CREATE INDEX idx_certificacoes_v3_compliance ON certificacoes_v3(compliance_status, dias_para_vencimento);
CREATE INDEX idx_certificacoes_v3_id_search ON certificacoes_v3(certificacao_id);
