
-- Adicionar campos obrigatórios da planilha na tabela funcionários
ALTER TABLE funcionarios ADD COLUMN anv TEXT; -- Tipo de aeronave (AW139, SK76, etc.)
ALTER TABLE funcionarios ADD COLUMN data_nascimento DATE;
ALTER TABLE funcionarios ADD COLUMN licenca_aeronautica TEXT; -- PCH, PLAH + número
ALTER TABLE funcionarios ADD COLUMN codigo_canac TEXT;
ALTER TABLE funcionarios ADD COLUMN codigo_sispat TEXT;
ALTER TABLE funcionarios ADD COLUMN codigo_prestserv TEXT;
ALTER TABLE funcionarios ADD COLUMN data_admissao DATE;

-- Garantir que matrícula seja única e não nula
CREATE UNIQUE INDEX IF NOT EXISTS idx_funcionarios_matricula ON funcionarios(matricula);
