
-- Índices para otimização SQL do módulo de simuladores

-- Índices para agendamento_slots (consultas de conflito e busca por data)
CREATE INDEX IF NOT EXISTS idx_agendamento_slots_simulador_data ON agendamento_slots(simulador_id, data_inicio, data_fim);
CREATE INDEX IF NOT EXISTS idx_agendamento_slots_status ON agendamento_slots(status_slot);
CREATE INDEX IF NOT EXISTS idx_agendamento_slots_instrutor ON agendamento_slots(colaborador_id_instrutor);
CREATE INDEX IF NOT EXISTS idx_agendamento_slots_data_inicio ON agendamento_slots(data_inicio);

-- Índices para fichas_sessao (consultas de workflow e relacionamentos)
CREATE INDEX IF NOT EXISTS idx_fichas_sessao_slot ON fichas_sessao(agendamento_slot_id);
CREATE INDEX IF NOT EXISTS idx_fichas_sessao_aluno ON fichas_sessao(colaborador_id_aluno);
CREATE INDEX IF NOT EXISTS idx_fichas_sessao_status ON fichas_sessao(status_workflow);
CREATE INDEX IF NOT EXISTS idx_fichas_sessao_template ON fichas_sessao(sessao_template_id);
CREATE INDEX IF NOT EXISTS idx_fichas_sessao_uuid ON fichas_sessao(ficha_uuid);
CREATE INDEX IF NOT EXISTS idx_fichas_sessao_certificacao ON fichas_sessao(certificacao_automatica_executada);

-- Índices para manobras_catalogo (consultas de categoria e status)
CREATE INDEX IF NOT EXISTS idx_manobras_catalogo_categoria ON manobras_catalogo(categoria);
CREATE INDEX IF NOT EXISTS idx_manobras_catalogo_ativo ON manobras_catalogo(ativo);
CREATE INDEX IF NOT EXISTS idx_manobras_catalogo_codigo ON manobras_catalogo(manobra_id_codigo);

-- Índices para matriz sessoes_template_manobras (junções frequentes)
CREATE INDEX IF NOT EXISTS idx_sessoes_template_manobras_sessao ON sessoes_template_manobras(sessao_template_id);
CREATE INDEX IF NOT EXISTS idx_sessoes_template_manobras_manobra ON sessoes_template_manobras(manobra_catalogo_id);

-- Índices para auditoria_simulador (consultas por ficha e data)
CREATE INDEX IF NOT EXISTS idx_auditoria_simulador_ficha ON auditoria_simulador(ficha_uuid);
CREATE INDEX IF NOT EXISTS idx_auditoria_simulador_usuario ON auditoria_simulador(usuario_id);
CREATE INDEX IF NOT EXISTS idx_auditoria_simulador_timestamp ON auditoria_simulador(timestamp_acao);
CREATE INDEX IF NOT EXISTS idx_auditoria_simulador_acao ON auditoria_simulador(acao);

-- Índices para simuladores (consultas de status)
CREATE INDEX IF NOT EXISTS idx_simuladores_status ON simuladores(status);
CREATE INDEX IF NOT EXISTS idx_simuladores_codigo ON simuladores(codigo_identificacao);

-- Índices para funcionarios (consultas de instrução e checagem)
CREATE INDEX IF NOT EXISTS idx_funcionarios_instrutor ON funcionarios(is_instrutor);
CREATE INDEX IF NOT EXISTS idx_funcionarios_checador ON funcionarios(is_checador);

-- Índices compostos para consultas complexas
CREATE INDEX IF NOT EXISTS idx_fichas_completa ON fichas_sessao(status_workflow, resultado_final, certificacao_automatica_executada);
CREATE INDEX IF NOT EXISTS idx_agendamento_completo ON agendamento_slots(simulador_id, status_slot, data_inicio);
