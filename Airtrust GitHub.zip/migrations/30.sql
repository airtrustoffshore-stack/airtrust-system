
-- Adicionar campos ausentes na tabela funcionarios
ALTER TABLE funcionarios ADD COLUMN guerra TEXT;

-- Criar tabela de log para auditoria de importação
CREATE TABLE import_funcionarios_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id TEXT NOT NULL,
  linha_csv INTEGER,
  funcionario_nome TEXT,
  funcionario_matricula TEXT,
  status TEXT NOT NULL, -- SUCCESS, ERROR, WARNING
  campo_nao_mapeado TEXT,
  erro_detalhado TEXT,
  dados_originais TEXT,
  dados_processados TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para performance
CREATE INDEX idx_import_log_batch ON import_funcionarios_log(batch_id);
CREATE INDEX idx_import_log_status ON import_funcionarios_log(status);
