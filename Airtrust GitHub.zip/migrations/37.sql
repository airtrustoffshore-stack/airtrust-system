
-- Nova modelagem para Sistema de Controle Individual de Treinamentos por Tripulante

-- Tabela principal de sessões (sem dados de tripulantes)
CREATE TABLE sessoes_simulador (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sessao_uuid TEXT UNIQUE NOT NULL,
  data_inicio TIMESTAMP NOT NULL,
  data_fim TIMESTAMP NOT NULL,
  simulador_id INTEGER NOT NULL,
  instrutor_id INTEGER NOT NULL,
  status_geral TEXT DEFAULT 'AGENDADA' CHECK(status_geral IN ('AGENDADA', 'EM_ANDAMENTO', 'CONCLUIDA')),
  observacoes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by INTEGER
);

-- Tabela de participantes individuais (cada tripulante com seu treinamento)
CREATE TABLE sessao_participantes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sessao_id INTEGER NOT NULL,
  colaborador_id INTEGER NOT NULL,
  treinamento_id INTEGER NOT NULL,
  template_sessao_id INTEGER,
  funcao_na_sessao TEXT NOT NULL CHECK(funcao_na_sessao IN ('PIC', 'SIC', 'DUAL')),
  sessao_numero INTEGER NOT NULL,
  total_sessoes_treinamento INTEGER NOT NULL,
  status_individual TEXT DEFAULT 'PENDENTE' CHECK(status_individual IN ('PENDENTE', 'APROVADO', 'REPROVADO')),
  conceito_individual TEXT CHECK(conceito_individual IN ('APROVADO', 'REPROVADO', NULL)),
  data_conclusao_individual TIMESTAMP,
  observacoes_individuais TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (sessao_id, colaborador_id)
);

-- Tabela para controlar progresso geral de cada tripulante em cada treinamento
CREATE TABLE progresso_treinamento_individual (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  colaborador_id INTEGER NOT NULL,
  treinamento_id INTEGER NOT NULL,
  sessoes_concluidas INTEGER DEFAULT 0,
  total_sessoes_necessarias INTEGER NOT NULL,
  status_treinamento TEXT DEFAULT 'EM_ANDAMENTO' CHECK(status_treinamento IN ('EM_ANDAMENTO', 'CONCLUIDO', 'REPROVADO')),
  data_inicio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  data_conclusao TIMESTAMP,
  certificacao_gerada_id INTEGER,
  UNIQUE (colaborador_id, treinamento_id)
);

-- Tabela de manobras executadas (individual por participante)
CREATE TABLE manobras_executadas_individual (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sessao_participante_id INTEGER NOT NULL,
  manobra_catalogo_id INTEGER NOT NULL,
  nota TEXT NOT NULL CHECK (nota IN ('1','2','3','4','5','6','7','8','9','10','NR')),
  nota_anterior TEXT CHECK (nota_anterior IN ('1','2','3','4','5','6','7','8','9','10','NR')),
  data_nota_anterior TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (sessao_participante_id, manobra_catalogo_id)
);

-- Índices para performance
CREATE INDEX idx_sessao_participantes_colaborador ON sessao_participantes (colaborador_id, treinamento_id);
CREATE INDEX idx_progresso_individual ON progresso_treinamento_individual (colaborador_id, status_treinamento);
CREATE INDEX idx_manobras_individual ON manobras_executadas_individual (sessao_participante_id);
CREATE INDEX idx_sessoes_simulador_uuid ON sessoes_simulador (sessao_uuid);
CREATE INDEX idx_sessoes_simulador_data ON sessoes_simulador (data_inicio, data_fim);
