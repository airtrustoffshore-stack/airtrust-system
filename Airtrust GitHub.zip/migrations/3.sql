CREATE TABLE auditoria_avancada_v2 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sessao_id TEXT,
    usuario_id TEXT,
    usuario_nome TEXT,
    ip_address TEXT,
    user_agent TEXT,
    acao TEXT NOT NULL,
    recurso TEXT NOT NULL,
    recurso_id TEXT,
    dados_antes TEXT,
    dados_depois TEXT,
    resultado TEXT DEFAULT 'SUCCESS', 
    duracao_ms INTEGER, 
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    nivel_criticidade TEXT DEFAULT 'MEDIO'
);

CREATE INDEX IF NOT EXISTS idx_auditoria_v2_recurso ON auditoria_avancada_v2(recurso, recurso_id);