
-- HOTFIX M4.17 - Permitir funcoes administrativas
INSERT OR IGNORE INTO funcoes (nome, descricao, categoria) 
VALUES ('ADMIN_SEM_FUNCAO', 'Funcionário administrativo sem função operacional específica', 'ADMINISTRATIVO');
