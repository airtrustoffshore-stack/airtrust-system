
INSERT INTO user_permissions_v2 (user_id, modulo, acao, permitido) VALUES
('DEV_SYSTEM_ADMIN', 'aeronaves', 'READ', 1),
('DEV_SYSTEM_ADMIN', 'aeronaves', 'CREATE', 1),
('DEV_SYSTEM_ADMIN', 'aeronaves', 'UPDATE', 1),
('DEV_SYSTEM_ADMIN', 'aeronaves', 'DELETE', 1)
ON CONFLICT(user_id, modulo, acao) DO UPDATE SET permitido = 1;
