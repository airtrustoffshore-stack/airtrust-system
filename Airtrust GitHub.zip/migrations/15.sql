
ALTER TABLE catalogo_treinamentos_v2 ADD COLUMN obrigatorio_funcoes TEXT;
