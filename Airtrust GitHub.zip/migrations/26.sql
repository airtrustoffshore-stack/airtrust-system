
-- ✅ CRIAR TABELA PASTA VIRTUAL SE NÃO EXISTIR
CREATE TABLE IF NOT EXISTS pasta_virtual (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  funcionario_id INTEGER NOT NULL,
  tipo_documento TEXT NOT NULL,
  nome_arquivo TEXT NOT NULL,
  caminho_arquivo TEXT NOT NULL,
  certificacao_id INTEGER NULL,
  descricao TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT NULL
);

-- ✅ ADICIONAR ÍNDICES PARA PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_pasta_virtual_funcionario ON pasta_virtual(funcionario_id);
CREATE INDEX IF NOT EXISTS idx_pasta_virtual_certificacao ON pasta_virtual(certificacao_id);
CREATE INDEX IF NOT EXISTS idx_pasta_virtual_tipo ON pasta_virtual(tipo_documento);
