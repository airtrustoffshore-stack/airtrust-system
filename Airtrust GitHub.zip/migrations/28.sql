
-- Criar tabela pasta_virtual_sync_log se não existir
CREATE TABLE IF NOT EXISTS pasta_virtual_sync_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  funcionario_id INTEGER NOT NULL,
  historico_cert_id INTEGER NOT NULL,
  arquivo_original_url TEXT NOT NULL,
  arquivo_pasta_virtual_url TEXT,
  nome_arquivo_auditavel TEXT NOT NULL,
  funcionario_nome TEXT NOT NULL,
  funcionario_matricula TEXT NOT NULL,
  treinamento_nome TEXT NOT NULL,
  treinamento_codigo TEXT NOT NULL,
  data_conclusao DATE,
  data_vencimento DATE,
  status_sincronizacao TEXT DEFAULT 'PENDENTE',
  tamanho_bytes INTEGER,
  hash_md5 TEXT,
  hash_sha256 TEXT,
  data_sincronizacao TIMESTAMP,
  tentativas_sincronizacao INTEGER DEFAULT 0,
  max_tentativas INTEGER DEFAULT 3,
  erro_ultimo TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP,
  UNIQUE(historico_cert_id)
);

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_pasta_virtual_sync_funcionario ON pasta_virtual_sync_log(funcionario_id);
CREATE INDEX IF NOT EXISTS idx_pasta_virtual_sync_status ON pasta_virtual_sync_log(status_sincronizacao);
CREATE INDEX IF NOT EXISTS idx_pasta_virtual_sync_vencimento ON pasta_virtual_sync_log(data_vencimento);
CREATE INDEX IF NOT EXISTS idx_pasta_virtual_sync_historico ON pasta_virtual_sync_log(historico_cert_id);
