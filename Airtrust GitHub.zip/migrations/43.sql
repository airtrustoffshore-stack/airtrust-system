
-- SCHEMA COMPLETO DO MÓDULO SIMULADORES

-- 1. ATUALIZAR TABELA SIMULADORES EXISTENTE
ALTER TABLE simuladores ADD COLUMN fabricante TEXT;
ALTER TABLE simuladores ADD COLUMN modelo TEXT;
ALTER TABLE simuladores ADD COLUMN configuracao_tecnica TEXT;

-- 2. TEMPLATES DE SESSÃO
CREATE TABLE IF NOT EXISTS simulador_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  codigo TEXT UNIQUE NOT NULL,
  categoria TEXT NOT NULL,
  duracao_minutos INTEGER NOT NULL,
  descricao TEXT,
  aeronave_aplicavel TEXT,
  nota_minima REAL DEFAULT 7.0,
  ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. CATÁLOGO DE MANOBRAS ATUALIZADO
CREATE TABLE IF NOT EXISTS simulador_manobras (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo TEXT UNIQUE NOT NULL,
  nome TEXT NOT NULL,
  categoria TEXT NOT NULL,
  descricao TEXT,
  pontuacao_maxima INTEGER DEFAULT 10,
  pontuacao_minima INTEGER DEFAULT 5,
  criterios_avaliacao TEXT,
  ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. MATRIZ TEMPLATE x MANOBRAS
CREATE TABLE IF NOT EXISTS template_manobras (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  template_id INTEGER NOT NULL,
  manobra_id INTEGER NOT NULL,
  obrigatoria BOOLEAN DEFAULT 1,
  peso_avaliacao INTEGER DEFAULT 1,
  ordem_execucao INTEGER,
  observacoes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(template_id, manobra_id)
);

-- 5. CICLOS DE TRABALHO ATUALIZADO
CREATE TABLE IF NOT EXISTS simulador_ciclos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_ciclo INTEGER NOT NULL,
  nome TEXT NOT NULL,
  descricao TEXT,
  data_inicio DATE,
  data_fim DATE,
  ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. SLOTS DE DISPONIBILIDADE ATUALIZADO
CREATE TABLE IF NOT EXISTS simulador_slots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  simulador_id INTEGER NOT NULL,
  data_inicio DATETIME NOT NULL,
  data_fim DATETIME NOT NULL,
  status TEXT DEFAULT 'DISPONIVEL',
  ciclo_id INTEGER,
  observacoes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. SESSÕES/AGENDAMENTOS ATUALIZADO
CREATE TABLE IF NOT EXISTS simulador_sessoes_v2 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uuid TEXT UNIQUE NOT NULL,
  simulador_id INTEGER NOT NULL,
  template_id INTEGER NOT NULL,
  instrutor_id INTEGER NOT NULL,
  ciclo_id INTEGER,
  data_inicio DATETIME NOT NULL,
  data_fim DATETIME NOT NULL,
  status TEXT DEFAULT 'AGENDADO',
  observacoes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. PARTICIPANTES DA SESSÃO ATUALIZADO
CREATE TABLE IF NOT EXISTS sessao_participantes_v2 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sessao_id INTEGER NOT NULL,
  funcionario_id INTEGER NOT NULL,
  funcao_sessao TEXT NOT NULL,
  status TEXT DEFAULT 'ATIVO',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(sessao_id, funcionario_id)
);

-- 9. FICHAS DE AVALIAÇÃO ATUALIZADO
CREATE TABLE IF NOT EXISTS simulador_fichas_v2 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uuid TEXT UNIQUE NOT NULL,
  sessao_id INTEGER NOT NULL,
  participante_id INTEGER NOT NULL,
  status TEXT DEFAULT 'EM_ANDAMENTO',
  nota_final REAL,
  observacoes_gerais TEXT,
  avaliado_por INTEGER,
  avaliado_em DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 10. AVALIAÇÃO POR MANOBRA ATUALIZADO
CREATE TABLE IF NOT EXISTS ficha_manobras_v2 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ficha_id INTEGER NOT NULL,
  manobra_id INTEGER NOT NULL,
  pontuacao REAL,
  status TEXT DEFAULT 'PENDENTE',
  observacoes TEXT,
  avaliado_em DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(ficha_id, manobra_id)
);

-- ÍNDICES PARA PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_simulador_templates_codigo ON simulador_templates(codigo);
CREATE INDEX IF NOT EXISTS idx_simulador_manobras_codigo ON simulador_manobras(codigo);
CREATE INDEX IF NOT EXISTS idx_template_manobras_template ON template_manobras(template_id);
CREATE INDEX IF NOT EXISTS idx_simulador_slots_simulador ON simulador_slots(simulador_id);
CREATE INDEX IF NOT EXISTS idx_simulador_sessoes_uuid ON simulador_sessoes_v2(uuid);
CREATE INDEX IF NOT EXISTS idx_simulador_fichas_uuid ON simulador_fichas_v2(uuid);
