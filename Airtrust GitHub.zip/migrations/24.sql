
-- Criar tabela de relacionamento funcionário-aeronave usando tabela aeronaves existente
CREATE TABLE IF NOT EXISTS funcionario_aeronaves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  funcionario_id INTEGER NOT NULL,
  aeronave_id INTEGER NOT NULL,
  data_qualificacao DATE,
  status TEXT DEFAULT 'ATIVO',
  observacoes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(funcionario_id, aeronave_id)
);

CREATE INDEX idx_funcionario_aeronaves_funcionario ON funcionario_aeronaves(funcionario_id);
CREATE INDEX idx_funcionario_aeronaves_aeronave ON funcionario_aeronaves(aeronave_id);
