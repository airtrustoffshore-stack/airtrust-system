
CREATE TABLE catalogo_aeronaves (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT NOT NULL UNIQUE,
    nome TEXT NOT NULL,
    fabricante TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

INSERT INTO catalogo_aeronaves (codigo, nome, fabricante) VALUES 
('A320', 'Airbus A320', 'Airbus'),
('B738', 'Boeing 737-800', 'Boeing'),
('EC145', 'Eurocopter EC145', 'Airbus Helicopters'),
('B777', 'Boeing 777', 'Boeing'),
('A330', 'Airbus A330', 'Airbus');
