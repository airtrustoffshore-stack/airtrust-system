
-- Migrar dados existentes do campo aeronave_principal para funcionarios_aeronaves
INSERT INTO funcionarios_aeronaves (funcionario_id, aeronave_codigo, status, created_at, updated_at)
SELECT 
  id as funcionario_id,
  aeronave_principal as aeronave_codigo,
  'ATIVO' as status,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM funcionarios 
WHERE aeronave_principal IS NOT NULL AND aeronave_principal != '';

-- Processar funcionários com múltiplas aeronaves no campo anv (separadas por /)
INSERT OR IGNORE INTO funcionarios_aeronaves (funcionario_id, aeronave_codigo, status, created_at, updated_at)
SELECT 
  f.id as funcionario_id,
  TRIM(aeronave.value) as aeronave_codigo,
  'ATIVO' as status,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM funcionarios f,
json_each('["' || REPLACE(COALESCE(f.anv, ''), '/', '","') || '"]') as aeronave
WHERE f.anv IS NOT NULL 
  AND f.anv != '' 
  AND TRIM(aeronave.value) != '';
