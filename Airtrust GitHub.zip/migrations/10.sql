
INSERT INTO catalogo_treinamentos_v2 (codigo, nome, categoria, periodicidade_meses, ativo) 
VALUES
    ('CMA', 'Certificado Médico Aeronáutico', 'LICENCA_MEDICA', 12, 1),
    ('ASO', 'Atestado de Saúde Ocupacional', 'LICENCA_MEDICA', 12, 1),
    ('ICAO', 'Nível de Inglês ICAO', 'PROFICIENCIA', 36, 1)
ON CONFLICT(codigo) DO UPDATE SET
    nome = excluded.nome,
    categoria = excluded.categoria,
    periodicidade_meses = excluded.periodicidade_meses,
    ativo = 1,
    updated_at = CURRENT_TIMESTAMP;
