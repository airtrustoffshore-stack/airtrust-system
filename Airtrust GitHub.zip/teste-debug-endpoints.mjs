#!/usr/bin/env node

/**
 * 🔧 SCRIPT DE DEBUG DOS ENDPOINTS IMPLEMENTADOS
 */

const BASE_URL = 'http://localhost:5173';

console.log('🔧 TESTANDO ENDPOINTS SIMPLES PRIMEIRO');

// Teste básico
try {
  console.log('1. Testando health check...');
  const health = await fetch(`${BASE_URL}/health`);
  console.log(`   Status: ${health.status}`);
  
  if (health.ok) {
    const data = await health.json();
    console.log(`   ✅ Health OK: ${data.status}`);
  } else {
    const text = await health.text();
    console.log(`   ❌ Health error: ${text.substring(0, 100)}...`);
  }
} catch (e) {
  console.log(`   💥 Erro: ${e.message}`);
}

// Teste endpoint raiz
try {
  console.log('\n2. Testando endpoint raiz...');
  const root = await fetch(`${BASE_URL}/`);
  console.log(`   Status: ${root.status}`);
  
  if (root.ok) {
    const data = await root.json();
    console.log(`   ✅ Root OK: ${data.message?.substring(0, 50)}...`);
  } else {
    const text = await root.text();
    console.log(`   ❌ Root error: ${text.substring(0, 100)}...`);
  }
} catch (e) {
  console.log(`   💥 Erro: ${e.message}`);
}

// Teste endpoint simulador básico
try {
  console.log('\n3. Testando GET simuladores...');
  const sim = await fetch(`${BASE_URL}/api/v2/simuladores`);
  console.log(`   Status: ${sim.status}`);
  
  if (sim.ok) {
    const data = await sim.json();
    console.log(`   ✅ Simuladores OK`);
  } else {
    const text = await sim.text();
    console.log(`   ❌ Simuladores error: ${text.substring(0, 200)}...`);
  }
} catch (e) {
  console.log(`   💥 Erro: ${e.message}`);
}

// Teste endpoint diagnóstico
try {
  console.log('\n4. Testando diagnóstico...');
  const diag = await fetch(`${BASE_URL}/api/v2/simulador/diagnostico-fichas`);
  console.log(`   Status: ${diag.status}`);
  
  if (diag.ok) {
    const data = await diag.json();
    console.log(`   ✅ Diagnóstico OK: ${data.endpoints?.length} endpoints`);
  } else {
    const text = await diag.text();
    console.log(`   ❌ Diagnóstico error: ${text.substring(0, 200)}...`);
  }
} catch (e) {
  console.log(`   💥 Erro: ${e.message}`);
}

console.log('\n5. Testando novos endpoints críticos...');

const endpointsCriticos = [
  '/api/v2/simulador/manobras/matriz',
  '/api/v2/simulador/templates',
  '/api/v2/simulador/agendamento/test'
];

for (const endpoint of endpointsCriticos) {
  try {
    console.log(`\n   Testando ${endpoint}...`);
    const resp = await fetch(`${BASE_URL}${endpoint}`);
    console.log(`   Status: ${resp.status}`);
    
    const contentType = resp.headers.get('content-type');
    console.log(`   Content-Type: ${contentType}`);
    
    if (contentType?.includes('application/json')) {
      try {
        const data = await resp.json();
        console.log(`   ✅ JSON válido: ${data.success !== undefined ? 'success=' + data.success : 'estrutura OK'}`);
      } catch (e) {
        console.log(`   ❌ JSON inválido: ${e.message}`);
      }
    } else {
      const text = await resp.text();
      if (text.includes('<!DOCTYPE html>')) {
        console.log(`   ❌ Retornando HTML (erro de servidor)`);
      } else {
        console.log(`   📄 Texto: ${text.substring(0, 100)}...`);
      }
    }
  } catch (e) {
    console.log(`   💥 Erro de rede: ${e.message}`);
  }
}
