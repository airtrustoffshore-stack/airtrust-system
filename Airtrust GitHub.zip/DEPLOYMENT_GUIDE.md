# 🚀 Guia de Deployment AirTrust - Sistema Seguro Enterprise

## 📋 Visão Geral

O AirTrust utiliza um sistema de deployment **Blue-Green** enterprise-grade com:
- **Credenciais seguras** embebidas no código
- **Zero downtime** durante deployments
- **Rollback automático** em caso de falhas
- **Monitoramento contínuo** de saúde do sistema
- **Múltiplos ambientes** isolados

## 🔧 Setup Inicial

### 1. Configuração Automática
```bash
# Execute o setup completo (uma vez apenas)
./scripts/setup-airtrust-secure.sh
```

Este comando:
- ✅ Verifica pré-requisitos (Node.js 18+, npm)
- ✅ Instala dependências
- ✅ Configura scripts de deployment
- ✅ Cria ambiente de desenvolvimento
- ✅ Executa testes básicos
- ✅ Torna scripts executáveis

### 2. Verificação de Produção
```bash
# Execute checklist antes de qualquer deploy para produção
./scripts/production-checklist.sh
```

## 🚀 Comandos de Deployment

### Deployment Básico
```bash
# Deploy automático (blue-green)
./scripts/deploy-airtrust.sh deploy

# Verificar status atual
./scripts/deploy-airtrust.sh status

# Rollback de emergência
./scripts/deploy-airtrust.sh rollback

# Validar sistema
./scripts/deploy-airtrust.sh validate
```

### Operações de Backup
```bash
# Backup manual
./scripts/deploy-airtrust.sh backup

# Exportar produção (Blue)
./scripts/export-prod-blue.sh

# Importar para Green
./scripts/import-to-green.sh backup-file.sql
```

### Ajuda e Informações
```bash
# Ver todos os comandos disponíveis
./scripts/deploy-airtrust.sh help

# Ver checklist completo
./scripts/production-checklist.sh
```

## 🏗️ Arquitetura de Ambientes

### Development
- **Worker**: `airtrust-dev`
- **Database**: `airtrust-dev-db`
- **URL**: `airtrust-dev.workers.dev`
- **Propósito**: Desenvolvimento e testes locais

### Staging
- **Worker**: `airtrust-staging`
- **Database**: `airtrust-staging-db`
- **URL**: `staging.airtrust.app`
- **Propósito**: Testes antes da produção

### Production Blue/Green
- **Blue Worker**: `airtrust-blue`
- **Green Worker**: `airtrust-green`
- **URLs**: 
  - Principal: `airtrust.app` (aponta para ativo)
  - Blue: `blue.airtrust.app`
  - Green: `green.airtrust.app`

## 🔄 Processo de Deployment

### 1. **Preparação**
```bash
# Verificar se sistema está pronto
./scripts/production-checklist.sh

# Status atual
./scripts/deploy-airtrust.sh status
```

### 2. **Execução Automática**
```bash
./scripts/deploy-airtrust.sh deploy
```

**O sistema executa automaticamente:**
1. 🔍 **Detecta ambiente ativo** (Blue ou Green)
2. 📦 **Cria backup** do ambiente de destino
3. 🏗️ **Build do projeto** com validações
4. 🚀 **Deploy para ambiente inativo** (Green se Blue estiver ativo)
5. 🔍 **Validação completa** com health checks
6. 🔄 **Switch de tráfego** para novo ambiente
7. 📊 **Monitoramento** de estabilidade

### 3. **Validação Automática**
- Health checks HTTP/200
- Verificação de integridade de dados
- Performance check (<500ms)
- Validação de APIs críticas

### 4. **Rollback Automático**
- Se validação falhar → rollback automático
- Se sistema degradar → rollback manual disponível
- Tempo de rollback: 30-60 segundos

## 🛡️ Recursos de Segurança

### Configuração Segura
- ✅ **Credenciais embebidas** com criptografia AES-256
- ✅ **Ambientes isolados** com configurações específicas
- ✅ **Validação automática** de integridade
- ✅ **Auditoria completa** de deployments

### Monitoramento
- 📊 **Health checks** automáticos
- 🔍 **Performance monitoring** contínuo
- 📝 **Logs de auditoria** detalhados
- 🚨 **Alertas automáticos** em caso de problemas

## 📊 Endpoints de Monitoramento

### Health Check Melhorado
```bash
curl https://airtrust.app/api/v2/system/health
```

**Resposta:**
```json
{
  "overall_status": "HEALTHY",
  "checks": [
    {
      "check_name": "database_connection",
      "status": "HEALTHY",
      "response_time_ms": 45,
      "details": "Database connection successful"
    }
  ],
  "environment": "production",
  "timestamp": "2025-09-14T03:53:44Z",
  "deployment_info": {
    "version": "1.0.0",
    "deployment_id": "deploy_1726282424",
    "uptime_seconds": 3600
  }
}
```

### Informações do Sistema
```bash
curl https://airtrust.app/api/v2/system/info
```

## 🚨 Troubleshooting

### Deploy Falhou
```bash
# 1. Verificar logs
./scripts/deploy-airtrust.sh status

# 2. Validar build
npm run build

# 3. Executar checklist
./scripts/production-checklist.sh

# 4. Verificar saúde
curl https://airtrust.app/api/v2/system/health
```

### Sistema Degradado
```bash
# 1. Health check detalhado
curl -s https://airtrust.app/api/v2/system/health | jq '.'

# 2. Rollback se necessário
./scripts/deploy-airtrust.sh rollback

# 3. Verificar ambiente anterior
./scripts/deploy-airtrust.sh validate
```

### Rollback de Emergência
```bash
# Rollback imediato (30-60 segundos)
./scripts/deploy-airtrust.sh rollback

# Verificar se rollback funcionou
./scripts/deploy-airtrust.sh status
curl https://airtrust.app/api/v2/system/health
```

## 📈 Métricas e Monitoramento

### Performance Targets
- **Response Time**: < 200ms (média)
- **Availability**: > 99.9%
- **Error Rate**: < 0.1%
- **Health Check**: < 500ms

### Alertas Automáticos
- ❌ Health check falha por 2+ minutos
- ⚠️ Response time > 1000ms por 5+ minutos
- 🔥 Error rate > 1% por 3+ minutos
- 💾 Database queries > 2000ms

## 🔐 Configuração de Produção

### Wrangler Multi-Ambiente
O sistema usa `wrangler.production.toml` com configurações para:
- **Development**: Desenvolvimento local
- **Staging**: Testes de pré-produção
- **Blue**: Produção ativa
- **Green**: Produção standby

### Deploy Manual (Avançado)
```bash
# Deploy específico para Blue
wrangler deploy --env blue --config wrangler.production.toml

# Deploy específico para Green  
wrangler deploy --env green --config wrangler.production.toml

# Deploy para Staging
wrangler deploy --env staging --config wrangler.production.toml
```

## 🎯 Checklist de Produção

O sistema inclui verificação automática baseada em `docs/PRODUCTION_READY_CHECKLIST.md`:

### Critérios Críticos
- ✅ **Testes Automatizados** (>85% coverage)
- ✅ **Performance** (build sem erros)
- ✅ **Segurança** (auth/auth implementado)
- ✅ **Monitoramento** (health checks ativos)
- ✅ **Documentação** (APIs documentadas)

### Aprovação Automática
- **80%+ aprovação**: ✅ Aprovado para produção
- **60-79% aprovação**: ⚠️ Aprovado com restrições
- **<60% aprovação**: ❌ Não aprovado

## 🆘 Contatos de Emergência

### Escalação
1. **Tech Lead**: Primeiro contato para problemas técnicos
2. **DevOps**: Problemas de infraestrutura e deployment
3. **Plantão**: Emergências fora do horário comercial

### Procedimentos de Emergência
1. **Identificar problema**: Health checks, logs, métricas
2. **Avaliar impacto**: Usuários afetados, serviços comprometidos
3. **Rollback**: Se deployment recente causou problema
4. **Escalação**: Notificar equipe conforme severidade
5. **Post-mortem**: Documentar incidente e melhorias

## 📚 Recursos Adicionais

- **Código fonte**: Estrutura modular em `src/`
- **Scripts**: Automação em `scripts/`
- **Documentação**: APIs em `openapi.yaml`
- **Configuração**: Ambientes em `wrangler.production.toml`
- **Monitoramento**: Dashboards em `/api/v2/system/`

---

**🚀 Sistema AirTrust - Deployment Enterprise-Grade com Segurança Máxima**

*Para suporte técnico, consulte a documentação completa ou execute `./scripts/deploy-airtrust.sh help`*
