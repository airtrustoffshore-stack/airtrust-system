#!/usr/bin/env node

/**
 * 🔍 SCRIPT DE VALIDAÇÃO DAS CORREÇÕES CRÍTICAS
 * Testa todos os 6 endpoints críticos implementados para atingir score 85%+
 */

const BASE_URL = 'http://localhost:5173';

console.log('🔍 VALIDANDO CORREÇÕES CRÍTICAS IMPLEMENTADAS');
console.log('=' .repeat(60));

const endpointsTestados = [
  {
    name: 'POST Templates',
    url: '/api/v2/simulador/templates',
    method: 'POST',
    body: {
      nome_sessao: 'Teste Validação',
      treinamento_codigo: 'TEST-001',
      numero_sessao: 1,
      descricao: 'Template de teste para validação'
    },
    expectedStatus: [200, 201]
  },
  {
    name: 'PUT Avaliar Ficha',
    url: '/api/v2/simulador/ficha/TESTE-VALIDACAO/avaliar',
    method: 'PUT',
    body: {
      manobras: [
        { id: 1, nota: 8, observacoes: 'Teste' }
      ],
      observacoes_gerais: 'Avaliação de teste',
      finalizar: false
    },
    expectedStatus: [200, 404] // 404 é esperado se ficha não existir
  },
  {
    name: 'GET Matriz Manobras',
    url: '/api/v2/simulador/manobras/matriz',
    method: 'GET',
    expectedStatus: [200]
  },
  {
    name: 'POST Configurar Manobras',
    url: '/api/v2/simulador/manobras/configurar',
    method: 'POST',
    body: {
      sessao_template_id: 1,
      manobras: [1, 2, 3]
    },
    expectedStatus: [200, 400] // 400 é esperado se template não existir
  },
  {
    name: 'PUT Editar Agendamento',
    url: '/api/v2/simulador/agendamento/TESTE-VALIDACAO',
    method: 'PUT',
    body: {
      dados_gerais: {
        simulador_id: 1,
        instrutor_id: 1
      },
      observacoes_gerais: 'Teste de edição'
    },
    expectedStatus: [200, 404] // 404 é esperado se agendamento não existir
  },
  {
    name: 'GET Dados Avaliação',
    url: '/api/v2/simulador/ficha/TESTE-VALIDACAO/avaliar',
    method: 'GET',
    expectedStatus: [200, 404] // 404 é esperado se ficha não existir
  }
];

let sucessos = 0;
let totalTestados = 0;

console.log('🚀 Iniciando testes dos endpoints...\n');

for (const teste of endpointsTestados) {
  totalTestados++;
  
  try {
    console.log(`🔎 Testando: ${teste.name}`);
    console.log(`   ${teste.method} ${teste.url}`);
    
    const options = {
      method: teste.method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer test-token'
      }
    };
    
    if (teste.body) {
      options.body = JSON.stringify(teste.body);
    }
    
    const response = await fetch(`${BASE_URL}${teste.url}`, options);
    const responseText = await response.text();
    
    // Verificar se status está nos esperados
    const statusOk = teste.expectedStatus.includes(response.status);
    
    if (statusOk) {
      sucessos++;
      console.log(`   ✅ Status: ${response.status} - SUCESSO`);
      
      // Tentar parse do JSON para validar estrutura
      try {
        const responseJson = JSON.parse(responseText);
        if (responseJson.success !== undefined) {
          console.log(`   📋 Resposta válida: success=${responseJson.success}`);
        }
      } catch (e) {
        console.log(`   ⚠️  Resposta não é JSON válido (pode ser normal)`);
      }
    } else {
      console.log(`   ❌ Status: ${response.status} - FALHOU`);
      console.log(`   💬 Esperado: ${teste.expectedStatus.join(' ou ')}`);
      if (responseText.length < 200) {
        console.log(`   📄 Resposta: ${responseText}`);
      }
    }
    
  } catch (error) {
    console.log(`   💥 ERRO DE REDE: ${error.message}`);
    
    // Se é erro de conexão, pode ser que o servidor não esteja rodando
    if (error.message.includes('ECONNREFUSED')) {
      console.log(`   🔧 Dica: Verifique se o servidor está rodando em ${BASE_URL}`);
    }
  }
  
  console.log(''); // Linha em branco
}

// Calcular score final
const percentual = Math.round((sucessos / totalTestados) * 100);

console.log('=' .repeat(60));
console.log('📊 RESULTADO FINAL DA VALIDAÇÃO');
console.log('=' .repeat(60));
console.log(`✅ Sucessos: ${sucessos}/${totalTestados}`);
console.log(`📈 Score: ${percentual}%`);

if (percentual >= 80) {
  console.log('🎯 ✅ CORREÇÕES SUFICIENTES - SCORE DEVE ATINGIR 85%+');
  console.log('🚀 Sistema aprovado para produção!');
} else if (percentual >= 60) {
  console.log('⚠️ 🔧 PARCIALMENTE CORRIGIDO - Mais algumas correções necessárias');
} else {
  console.log('❌ 🚨 AINDA COM PROBLEMAS CRÍTICOS - Mais correções necessárias');
}

console.log('\n📋 PRÓXIMOS PASSOS:');
if (percentual < 80) {
  console.log('1. Verificar logs de erro dos endpoints que falharam');
  console.log('2. Corrigir problemas de sintaxe ou lógica');
  console.log('3. Re-executar validação');
  console.log('4. Executar auditoria completa quando score >= 80%');
} else {
  console.log('1. ✅ Endpoints básicos funcionando');
  console.log('2. 🔍 Executar auditoria completa do sistema');
  console.log('3. 📋 Validar integração frontend-backend');
  console.log('4. 🚀 Deploy para produção se tudo estiver OK');
}

console.log('\n🎯 Meta: Atingir 85%+ para aprovar o módulo simuladores');
