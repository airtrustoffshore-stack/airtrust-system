// 🔍 SCRIPTS DE AUDITORIA CRÍTICA - AIRTRUST
// Executar no console do navegador em /simuladores

console.log('🚨 INICIANDO AUDITORIA CRÍTICA AIRTRUST');
console.log('=' .repeat(50));

// SCRIPT 1: Teste Real dos Ícones
const testeRealIcones = async () => {
  console.log('🔍 TESTE REAL DOS ÍCONES');
  
  const fichas = ['FICHA-TEST-003', 'FICHA-TEST-006'];
  
  for (const uuid of fichas) {
    try {
      const response = await fetch(`/api/v2/simulador/ficha/${uuid}`);
      console.log(`${uuid}: ${response.status} - ${response.ok ? 'OK' : 'ERRO'}`);
      
      if (!response.ok) {
        const error = await response.text();
        console.log(`Erro: ${error}`);
      } else {
        const data = await response.json();
        console.log(`Dados: Colaborador ${data.ficha?.colaborador?.nome}, Status: ${data.ficha?.status_workflow}`);
      }
    } catch (error) {
      console.log(`${uuid}: ERRO DE REDE - ${error.message}`);
    }
  }
  console.log('');
};

// SCRIPT 2: Teste dos Templates
const testeTemplates = async () => {
  console.log('📝 TESTE DOS TEMPLATES');
  
  const codigos = ['SGV-001', 'SMS-001'];
  
  for (const codigo of codigos) {
    try {
      const response = await fetch(`/api/v2/simulador-templates/treinamento/${codigo}`);
      console.log(`${codigo}: ${response.status} - ${response.ok ? 'OK' : 'ERRO'}`);
      
      if (response.ok) {
        const data = await response.json();
        console.log(`Templates: ${data.total} encontrados para ${data.treinamento?.nome}`);
        data.templates?.forEach(t => {
          console.log(`  - Sessão ${t.numero_sessao}: ${t.nome}`);
        });
      } else {
        const error = await response.text();
        console.log(`Erro: ${error}`);
      }
    } catch (error) {
      console.log(`${codigo}: ERRO DE REDE - ${error.message}`);
    }
  }
  console.log('');
};

// SCRIPT 3: Teste do Formulário
const testeFormulario = () => {
  console.log('📋 TESTE DO FORMULÁRIO DE AGENDAMENTO');
  
  // Verificar se estamos na página certa
  const currentPath = window.location.pathname;
  console.log(`URL atual: ${currentPath}`);
  
  // Tentar navegar para agendamento
  if (!currentPath.includes('agendamento')) {
    console.log('Navegando para /simuladores/agendamento...');
    window.location.href = '/simuladores/agendamento';
    return;
  }
  
  // Verificar elementos do formulário
  const formulario = document.querySelector('form');
  const dropdowns = document.querySelectorAll('select');
  const inputs = document.querySelectorAll('input');
  
  console.log(`Formulário encontrado: ${formulario ? 'SIM' : 'NÃO'}`);
  console.log(`Dropdowns encontrados: ${dropdowns.length}`);
  console.log(`Inputs encontrados: ${inputs.length}`);
  
  // Verificar campo "Treinamento"
  const campoTreinamento = document.querySelector('[name*="treinamento"], [placeholder*="treinamento"], [id*="treinamento"]');
  console.log(`Campo Treinamento: ${campoTreinamento ? 'ENCONTRADO' : 'NÃO ENCONTRADO'}`);
  
  if (campoTreinamento) {
    console.log(`Tipo do campo: ${campoTreinamento.tagName}, Name: ${campoTreinamento.name || 'sem nome'}`);
  }
  
  console.log('');
};

// SCRIPT 4: Auditoria Implacável
const auditoriaImplacavel = async () => {
  console.log('⚡ AUDITORIA IMPLACÁVEL - TODOS OS TESTES');
  console.log('=' .repeat(40));
  
  await testeRealIcones();
  await testeTemplates();
  testeFormulario();
  
  console.log('🏁 AUDITORIA FINALIZADA');
  console.log(`Timestamp: ${new Date().toISOString()}`);
  console.log('Copie este output completo para o relatório de auditoria.');
};

// Executar auditoria completa
auditoriaImplacavel();
