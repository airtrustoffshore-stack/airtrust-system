# 🔒 AIRTRUST PRODUCTION POLICY - ZERO DEMO DATA TOLERANCE

## POLÍTICA OFICIAL DE DADOS EM PRODUÇÃO

**REGRA FUNDAMENTAL:** É terminantemente proibida a inserção, manutenção ou deploy de qualquer dado fictício, de teste, demo ou exemplo no sistema AirTrust em ambientes de produção, staging ou published.

## ❌ DADOS ESTRITAMENTE PROIBIDOS

### Nomes Fictícios Banidos
- Maria Oliveira Costa
- Ricardo Silva Santos  
- João Pedro Lima
- Ana Paula Ferreira
- Carlos Eduardo Souza
- funcionario_test
- teste_funcionario
- demo_user
- mock_user
- example_user

### Matrículas Fictícias Banidas
- C001, C002, C003, C004, C005
- SGV-001, TEST-001, DEMO-001, MOCK-001

### Padrões de Código Proibidos
- `seedData`, `devData`, `populateDemo`
- `mockFuncionarios`, `exemploFuncionarios`
- Arrays hardcoded com dados fictícios
- SQL INSERT com dados de exemplo
- Funções de povoamento automático

## 🛡️ SISTEMAS DE PROTEÇÃO IMPLEMENTADOS

### 1. Middleware de Bloqueio (`demo-data-blocker.ts`)
- **Ativo 24/7** em todas as requisições
- Bloqueia POST/PUT com dados proibidos
- Retorna HTTP 403 com política violation
- Auditoria automática do banco

### 2. Script CI/CD (`ci-demo-data-prevention.sh`)
- **Obrigatório no pipeline**
- Aborta publish/merge se detectar dados demo
- Verifica código fonte e SQL statements
- Zero tolerância - falha = build cancelado

### 3. API de Auditoria (`/api/v2/audit/*`)
- `GET /audit/demo-data` - Auditoria completa
- `POST /audit/cleanup-demo-data` - Limpeza emergencial
- `GET /audit/blank-state-status` - Verificação de estado limpo

## 📋 CHECKLIST OBRIGATÓRIO PARA RELEASES

Antes de qualquer deploy/publish/merge, TODOS os itens devem estar ✅:

### Código Fonte
- [ ] Script `ci-demo-data-prevention.sh` executado com sucesso
- [ ] Zero matches para nomes/matrículas proibidas
- [ ] Nenhum array/objeto hardcoded com dados fictícios
- [ ] Nenhuma função de seed/populate ativa

### Base de Dados
- [ ] Auditoria `/api/v2/audit/demo-data` retorna `status: "PASSED"`
- [ ] Zero registros com nomes proibidos
- [ ] Blank state confirmado ou apenas dados reais
- [ ] Certificações e compliance sem dados órfãos

### Build e Deploy
- [ ] `npm run build` executa sem erros
- [ ] Middleware de bloqueio ativo
- [ ] Servidor responde corretamente
- [ ] Interface mostra blank state quando sem dados

### Pós-Deploy
- [ ] Teste manual de tentativa de inserção de dados demo (deve falhar)
- [ ] Verificação de logs sem dados fictícios
- [ ] Confirmação que apenas dados importados/cadastrados aparecem

## 🚨 PROCEDIMENTO DE EMERGÊNCIA

Se dados de teste forem detectados em produção:

1. **STOP IMEDIATO** - Pausar operações de entrada de dados
2. **AUDITORIA** - `GET /api/v2/audit/demo-data`
3. **LIMPEZA** - `POST /api/v2/audit/cleanup-demo-data`
4. **VERIFICAÇÃO** - Confirmar blank state
5. **ANÁLISE** - Investigar como dados demo chegaram à produção
6. **CORREÇÃO** - Fortalecer bloqueios e auditorias

## 📖 PADRÃO DE DADOS ACEITÁVEIS

### ✅ DADOS PERMITIDOS
- Dados reais importados via CSV pelo usuário
- Funcionários reais cadastrados manualmente
- Treinamentos criados pela equipe
- Certificações reais com documentos válidos
- Configurações e catálogos específicos da empresa

### ❌ DADOS PROIBIDOS
- Qualquer nome, matrícula ou informação fictícia
- Arrays/objetos hardcoded no código
- Seeds automáticos durante migrations
- Dados de exemplo em documentação que rode em produção
- Fallbacks que criem dados fictícios

## 🎯 RESPONSABILIDADES

### Desenvolvedores
- Seguir esta política em 100% do código
- Executar checklist antes de commits
- Usar apenas blank state como padrão
- Revisar PRs para detectar violações

### DevOps/CI/CD
- Configurar pipeline com `ci-demo-data-prevention.sh`
- Bloquear deploys que violem a política
- Monitorar auditorias pós-deploy
- Alertar sobre violações detectadas

### Gestores de Produto
- Validar que dados em produção são reais
- Coordenar importações de dados legítimos
- Revisar catálogos e configurações
- Aprovar apenas dados corporativos válidos

## 📞 CONTATO E DÚVIDAS

Em caso de dúvidas sobre esta política:
1. Consulte este documento
2. Execute auditoria `/api/v2/audit/demo-data`
3. Verifique logs do middleware de bloqueio
4. Escale para equipe de arquitetura se necessário

---

**ESTA POLÍTICA É OBRIGATÓRIA E NÃO NEGOCIÁVEL**

**VIOLAÇÕES RESULTAM EM DEPLOY BLOQUEADO E INVESTIGAÇÃO**

**AIRTRUST = ZERO DEMO DATA TOLERANCE**
