#!/usr/bin/env node

/**
 * 🔥 SCRIPT DE AUDITORIA EXTREMAMENTE RIGOROSA
 * Executa TODOS os testes solicitados na auditoria impiedosa
 * Tolerância ZERO para falhas
 */

// Usar fetch nativo do Node.js 18+

const BASE_URL = 'http://localhost:5173';
const timestamp = new Date().toISOString();

console.log('🔥 AUDITORIA EXTREMAMENTE RIGOROSA INICIADA');
console.log('⏰ Timestamp:', timestamp);
console.log('🌐 URL Base:', BASE_URL);
console.log('🚫 TOLERÂNCIA ZERO PARA FALHAS');
console.log('=' * 80);

// Variáveis globais para estatísticas
let endpointsTestados = 0;
let endpointsComSucesso = 0;
let problemasEncontrados = [];
let evidenciasReais = [];

function registrarProblema(categoria, descricao, evidencia = null) {
    problemasEncontrados.push({
        categoria,
        descricao,
        evidencia,
        timestamp: new Date().toISOString()
    });
    console.log(`❌ PROBLEMA CRÍTICO: ${categoria} - ${descricao}`);
}

function registrarEvidencia(tipo, dados) {
    evidenciasReais.push({
        tipo,
        dados,
        timestamp: new Date().toISOString()
    });
}

/**
 * TESTE 1: AUDITORIA COMPLETA DE ENDPOINTS
 * Testa CADA endpoint individualmente com payloads reais
 */
async function auditoriaEndpointsImplacavel() {
    console.log('\n🎯 EXECUTANDO AUDITORIA IMPLACÁVEL DE ENDPOINTS');
    console.log('📋 TESTANDO CADA ENDPOINT INDIVIDUALMENTE...');
    
    const endpoints = [
        // ENDPOINTS BÁSICOS
        { metodo: 'GET', url: '/api/v2/simulador/simuladores', esperado: 'lista de simuladores' },
        { metodo: 'GET', url: '/api/v2/simulador/funcionarios', esperado: 'lista de funcionários categorizados' },
        { metodo: 'GET', url: '/api/v2/treinamentos/listar', esperado: 'lista de treinamentos ativos' },
        
        // ENDPOINTS DE TEMPLATES
        { metodo: 'GET', url: '/api/v2/simulador/templates', esperado: 'lista de templates' },
        { metodo: 'GET', url: '/api/v2/simulador/templates/treinamento/1', esperado: 'templates do treinamento 1' },
        { metodo: 'POST', url: '/api/v2/simulador/templates', esperado: 'criar template' },
        
        // ENDPOINTS DE FICHAS INDIVIDUAIS  
        { metodo: 'GET', url: '/api/v2/simulador/ficha/FICHA-TEST-003', esperado: 'dados da ficha específica' },
        { metodo: 'GET', url: '/api/v2/simulador/ficha/FICHA-TEST-003/avaliacao', esperado: 'dados para avaliar ficha' },
        { metodo: 'PUT', url: '/api/v2/simulador/ficha/FICHA-TEST-003/avaliar', esperado: 'salvar avaliação' },
        
        // ENDPOINTS DE MANOBRAS  
        { metodo: 'GET', url: '/api/v2/simulador/manobras', esperado: 'catálogo de manobras' },
        { metodo: 'GET', url: '/api/v2/simulador/manobras/matriz', esperado: 'matriz de manobras' },
        { metodo: 'POST', url: '/api/v2/simulador/manobras/configurar', esperado: 'configurar manobras da sessão' },
        { metodo: 'PUT', url: '/api/v2/simulador/manobras/atualizar', esperado: 'atualizar configuração de manobras' },
        
        // ENDPOINTS DE AGENDAMENTO
        { metodo: 'GET', url: '/api/v2/simulador/agendamentos', esperado: 'lista de agendamentos' },
        { metodo: 'POST', url: '/api/v2/simulador/agendamento', esperado: 'criar agendamento' },
        { metodo: 'PUT', url: '/api/v2/simulador/agendamento/FICHA-TEST-003', esperado: 'editar agendamento' },
        { metodo: 'DELETE', url: '/api/v2/simulador/agendamento/FICHA-TEST-003', esperado: 'excluir agendamento' }
    ];
    
    const resultados = [];
    
    for (let i = 0; i < endpoints.length; i++) {
        const endpoint = endpoints[i];
        const startTime = Date.now();
        endpointsTestados++;
        
        console.log(`\n🔬 TESTE ${i+1}/${endpoints.length}: ${endpoint.metodo} ${endpoint.url}`);
        console.log(`📋 Esperado: ${endpoint.esperado}`);
        
        try {
            let response;
            let requestBody = null;
            
            if (endpoint.metodo === 'GET') {
                response = await fetch(BASE_URL + endpoint.url);
            } else if (endpoint.metodo === 'POST') {
                requestBody = {
                    teste_auditoria: true,
                    timestamp: new Date().toISOString(),
                    endpoint_testado: endpoint.url
                };
                
                // Payloads específicos para cada endpoint
                if (endpoint.url.includes('/templates')) {
                    requestBody = {
                        treinamento_codigo: 'AUDIT-001',
                        numero_sessao: 1,
                        nome_sessao: 'Template Teste Auditoria Extrema',
                        descricao: 'Template criado durante auditoria rigorosa',
                        manobras: [1, 2, 3]
                    };
                } else if (endpoint.url.includes('/agendamento')) {
                    requestBody = {
                        data_inicio: '25/09/2024',
                        hora_inicio: '14:00',
                        data_fim: '25/09/2024',
                        hora_fim: '16:00',
                        simulador_id: '1',
                        instrutor_id: '1',
                        colaborador_aluno_id: '1',
                        template_sessao_id: '1',
                        funcao_na_sessao: 'PIC',
                        observacoes: `Teste Auditoria Extrema ${timestamp}`
                    };
                } else if (endpoint.url.includes('/configurar')) {
                    requestBody = {
                        sessao_template_id: 1,
                        manobras: [1, 2, 3, 4],
                        treinamento_codigo: 'AUDIT-001'
                    };
                }
                
                response = await fetch(BASE_URL + endpoint.url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(requestBody)
                });
            } else if (endpoint.metodo === 'PUT') {
                requestBody = {
                    teste_auditoria: true,
                    timestamp: new Date().toISOString(),
                    endpoint_testado: endpoint.url
                };
                
                // Payloads específicos para PUT
                if (endpoint.url.includes('/avaliar')) {
                    requestBody = {
                        manobras_executadas: [
                            { manobra_id: 1, nota: 8, observacoes: 'Teste auditoria' },
                            { manobra_id: 2, nota: 7, observacoes: 'Teste auditoria' }
                        ],
                        observacoes_instrutor: 'Avaliação teste auditoria extrema',
                        resultado_final: 'APROVADO'
                    };
                } else if (endpoint.url.includes('/atualizar')) {
                    requestBody = {
                        sessao_template_id: 1,
                        manobras: [1, 2, 5, 6]
                    };
                } else if (endpoint.url.includes('/agendamento')) {
                    requestBody = {
                        data_inicio: '26/09/2024',
                        hora_inicio: '15:00',
                        observacoes: 'Agendamento editado durante auditoria'
                    };
                }
                
                response = await fetch(BASE_URL + endpoint.url, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(requestBody)
                });
            } else if (endpoint.metodo === 'DELETE') {
                response = await fetch(BASE_URL + endpoint.url, { method: 'DELETE' });
            }
            
            const endTime = Date.now();
            const tempo = endTime - startTime;
            
            let dados;
            let temDados = false;
            let quantidadeDados = 0;
            let tipoResposta = 'N/A';
            let errorMessage = null;
            
            try {
                const responseText = await response.text();
                
                try {
                    dados = JSON.parse(responseText);
                    tipoResposta = typeof dados;
                    
                    if (Array.isArray(dados)) {
                        temDados = dados.length > 0;
                        quantidadeDados = dados.length;
                    } else if (dados && typeof dados === 'object') {
                        const chaves = Object.keys(dados);
                        temDados = chaves.length > 0;
                        quantidadeDados = chaves.length;
                        
                        // Verificar se tem dados úteis específicos
                        if (dados.data && Array.isArray(dados.data)) {
                            temDados = dados.data.length > 0;
                            quantidadeDados = dados.data.length;
                        } else if (dados.success || dados.template || dados.agendamento) {
                            temDados = true;
                        }
                        
                        // Capturar mensagem de erro se houver
                        if (dados.error) {
                            errorMessage = dados.error;
                        }
                    }
                } catch (parseError) {
                    console.log(`❌ ERRO AO PARSEAR JSON: ${parseError.message}`);
                    console.log(`📄 Response raw: ${responseText.substring(0, 200)}...`);
                    registrarProblema('ENDPOINT_JSON_ERROR', `${endpoint.url} retorna JSON inválido`, {
                        parseError: parseError.message,
                        responseText: responseText.substring(0, 500)
                    });
                    errorMessage = 'JSON inválido';
                }
            } catch (textError) {
                console.log(`❌ ERRO AO LER RESPONSE: ${textError.message}`);
                registrarProblema('ENDPOINT_READ_ERROR', `${endpoint.url} falha ao ler response`, textError.message);
                errorMessage = 'Falha ao ler response';
            }
            
            const resultado = {
                endpoint: `${endpoint.metodo} ${endpoint.url}`,
                status: response.status,
                ok: response.ok,
                tempo: `${tempo}ms`,
                temDados: temDados,
                quantidadeDados: quantidadeDados,
                tipoResposta: tipoResposta,
                esperado: endpoint.esperado,
                errorMessage: errorMessage,
                requestBody: requestBody,
                responseHeaders: Object.fromEntries(response.headers)
            };
            
            resultados.push(resultado);
            registrarEvidencia('ENDPOINT_TEST', resultado);
            
            if (response.ok && temDados) {
                console.log(`✅ SUCESSO TOTAL: ${response.status} - ${quantidadeDados} itens - ${tempo}ms`);
                endpointsComSucesso++;
            } else if (response.ok && !temDados) {
                console.log(`⚠️ SUCESSO MAS SEM DADOS ÚTEIS: ${response.status} - ${tempo}ms`);
                if (errorMessage) {
                    console.log(`   Erro retornado: ${errorMessage}`);
                }
                registrarProblema('ENDPOINT_NO_DATA', `${endpoint.url} retorna sucesso mas sem dados úteis`, resultado);
            } else {
                console.log(`❌ FALHA CRÍTICA: ${response.status} - ${errorMessage || 'Sem mensagem de erro'}`);
                console.log(`   Tempo de resposta: ${tempo}ms`);
                registrarProblema('ENDPOINT_ERROR', `${endpoint.url} retorna erro ${response.status}: ${errorMessage}`, resultado);
            }
            
        } catch (error) {
            console.log(`🔥 ERRO CRÍTICO DE REDE: ${error.message}`);
            registrarProblema('ENDPOINT_NETWORK_ERROR', `${endpoint.url} falha de conexão`, error.message);
            
            resultados.push({
                endpoint: `${endpoint.metodo} ${endpoint.url}`,
                status: 'ERRO_REDE',
                ok: false,
                erro: error.message,
                esperado: endpoint.esperado,
                tempo: 'N/A'
            });
        }
        
        // Aguardar 200ms entre requests para não sobrecarregar
        await new Promise(resolve => setTimeout(resolve, 200));
    }
    
    const percentualSucesso = Math.round((endpointsComSucesso / endpointsTestados) * 100);
    console.log('\n📊 ================ RESULTADOS DE ENDPOINTS ================');
    console.log('📈 ENDPOINTS TESTADOS:', endpointsTestados);
    console.log('✅ SUCESSOS TOTAIS:', endpointsComSucesso);
    console.log('❌ FALHAS:', endpointsTestados - endpointsComSucesso);
    console.log(`🎯 SCORE DE ENDPOINTS: ${percentualSucesso}%`);
    
    // Imprimir tabela detalhada
    console.log('\n📋 TABELA DETALHADA DE RESULTADOS:');
    console.log('Endpoint'.padEnd(50) + 'Status'.padEnd(10) + 'Dados'.padEnd(15) + 'Tempo'.padEnd(10) + 'Resultado');
    console.log('-'.repeat(100));
    
    resultados.forEach(r => {
        const endpoint = r.endpoint.padEnd(50);
        const status = String(r.status).padEnd(10);
        const dados = r.temDados ? `${r.quantidadeDados} itens`.padEnd(15) : 'Sem dados'.padEnd(15);
        const tempo = String(r.tempo).padEnd(10);
        const resultado = r.ok && r.temDados ? '✅ PASS' : r.ok ? '⚠️ WARN' : '❌ FAIL';
        
        console.log(endpoint + status + dados + tempo + resultado);
    });
    
    return { percentualSucesso, resultados, problemasEndpoints: problemasEncontrados.filter(p => p.categoria.includes('ENDPOINT')) };
}

/**
 * TESTE 2: AUDITORIA DE PERSISTÊNCIA DE DADOS
 * Verifica se os dados enviados são realmente salvos no banco
 */
async function auditoriaPersistenciaRigorosa() {
    console.log('\n💾 EXECUTANDO AUDITORIA RIGOROSA DE PERSISTÊNCIA');
    console.log('🗄️ TESTANDO SE DADOS SÃO REALMENTE SALVOS NO BANCO...');
    
    const timestampTeste = Date.now();
    let sucessos = 0;
    let totalTestes = 3;
    
    // TESTE 1: Criar template e verificar persistência
    console.log('\n🔬 TESTE 1: PERSISTÊNCIA DE TEMPLATE');
    try {
        const templateTeste = {
            treinamento_codigo: `AUDIT-${timestampTeste}`,
            numero_sessao: 99,
            nome_sessao: `Template Auditoria Extrema ${timestampTeste}`,
            descricao: 'Template criado especificamente para auditoria de persistência',
            manobras: [1, 2, 3]
        };
        
        console.log('📤 Enviando template para criação...');
        const responseCreate = await fetch(BASE_URL + '/api/v2/simulador/templates', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(templateTeste)
        });
        
        if (responseCreate.ok) {
            const createResult = await responseCreate.json();
            console.log(`✅ Template criado com ID: ${createResult.template?.id}`);
            
            // Aguardar para garantir que foi persistido
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Tentar buscar de volta
            console.log('🔍 Verificando se template foi realmente salvo...');
            const responseGet = await fetch(BASE_URL + '/api/v2/simulador/templates');
            
            if (responseGet.ok) {
                const templates = await responseGet.json();
                const templateEncontrado = templates.data?.find(t => 
                    t.nome_sessao?.includes(`Template Auditoria Extrema ${timestampTeste}`)
                );
                
                if (templateEncontrado) {
                    console.log('✅ TEMPLATE CONFIRMADO NO BANCO - Persistência OK');
                    sucessos++;
                    registrarEvidencia('PERSISTENCE_SUCCESS', {
                        tipo: 'template',
                        enviado: templateTeste,
                        encontrado: templateEncontrado
                    });
                } else {
                    console.log('❌ TEMPLATE NÃO ENCONTRADO - Falha na persistência!');
                    registrarProblema('PERSISTENCE_TEMPLATE_NOT_SAVED', 'Template criado mas não persistido no banco', {
                        enviado: templateTeste,
                        templatesEncontrados: templates.data?.length || 0
                    });
                }
            } else {
                console.log('❌ Erro ao buscar templates para verificação');
                registrarProblema('PERSISTENCE_VERIFICATION_ERROR', 'Falha ao verificar persistência do template');
            }
        } else {
            const error = await responseCreate.json();
            console.log(`❌ Falha ao criar template: ${error.error}`);
            registrarProblema('PERSISTENCE_CREATE_ERROR', 'Falha ao criar template para teste', error);
        }
    } catch (error) {
        console.log(`❌ Erro no teste de template: ${error.message}`);
        registrarProblema('PERSISTENCE_TEMPLATE_EXCEPTION', 'Exceção no teste de persistência de template', error.message);
    }
    
    // TESTE 2: Configurar manobras e verificar persistência
    console.log('\n🔬 TESTE 2: PERSISTÊNCIA DE CONFIGURAÇÃO DE MANOBRAS');
    try {
        const configTeste = {
            sessao_template_id: 1,
            manobras: [1, 2, 3, 4, 5],
            treinamento_codigo: `AUDIT-MANOBRAS-${timestampTeste}`,
            numero_sessao: 88,
            nome_sessao: `Configuração Auditoria ${timestampTeste}`
        };
        
        console.log('📤 Enviando configuração de manobras...');
        const responseConfig = await fetch(BASE_URL + '/api/v2/simulador/manobras/configurar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(configTeste)
        });
        
        if (responseConfig.ok) {
            const configResult = await responseConfig.json();
            console.log(`✅ Configuração salva para template ID: ${configResult.template_id}`);
            
            // Aguardar para garantir persistência
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Verificar se configuração foi salva
            console.log('🔍 Verificando se configuração foi persistida...');
            const responseVerify = await fetch(BASE_URL + `/api/v2/simulador/manobras/template/${configResult.template_id}`);
            
            if (responseVerify.ok) {
                const templateConfig = await responseVerify.json();
                const manobrasSalvas = templateConfig.template?.manobras_configuradas?.length || 0;
                
                if (manobrasSalvas > 0) {
                    console.log(`✅ CONFIGURAÇÃO CONFIRMADA - ${manobrasSalvas} manobras persistidas`);
                    sucessos++;
                    registrarEvidencia('PERSISTENCE_SUCCESS', {
                        tipo: 'configuracao_manobras',
                        enviado: configTeste,
                        encontrado: templateConfig.template
                    });
                } else {
                    console.log('❌ CONFIGURAÇÃO NÃO PERSISTIDA - 0 manobras encontradas');
                    registrarProblema('PERSISTENCE_MANOBRAS_NOT_SAVED', 'Configuração de manobras não persistida', {
                        enviado: configTeste,
                        encontrado: templateConfig.template
                    });
                }
            } else {
                console.log('❌ Erro ao verificar configuração persistida');
                registrarProblema('PERSISTENCE_MANOBRAS_VERIFICATION_ERROR', 'Falha ao verificar persistência da configuração');
            }
        } else {
            const error = await responseConfig.json();
            console.log(`❌ Falha ao configurar manobras: ${error.error}`);
            registrarProblema('PERSISTENCE_MANOBRAS_CREATE_ERROR', 'Falha ao configurar manobras para teste', error);
        }
    } catch (error) {
        console.log(`❌ Erro no teste de manobras: ${error.message}`);
        registrarProblema('PERSISTENCE_MANOBRAS_EXCEPTION', 'Exceção no teste de configuração de manobras', error.message);
    }
    
    // TESTE 3: Criar agendamento e verificar persistência
    console.log('\n🔬 TESTE 3: PERSISTÊNCIA DE AGENDAMENTO');
    try {
        const agendamentoTeste = {
            data_inicio: '27/09/2024',
            hora_inicio: '10:00',
            data_fim: '27/09/2024',
            hora_fim: '12:00',
            simulador_id: '1',
            instrutor_id: '1',
            colaborador_aluno_id: '1',
            template_sessao_id: '1',
            funcao_na_sessao: 'PIC',
            observacoes: `Agendamento Auditoria Extrema ${timestampTeste}`,
            teste_auditoria: true
        };
        
        console.log('📤 Enviando agendamento para criação...');
        const responseCreate = await fetch(BASE_URL + '/api/v2/simulador/agendamento', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(agendamentoTeste)
        });
        
        if (responseCreate.ok) {
            const createResult = await responseCreate.json();
            console.log(`✅ Agendamento criado: ${createResult.agendamento?.ficha_uuid || 'ID não retornado'}`);
            
            // Aguardar para garantir persistência
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Verificar se agendamento foi salvo
            console.log('🔍 Verificando se agendamento foi persistido...');
            const responseGet = await fetch(BASE_URL + '/api/v2/simulador/agendamentos');
            
            if (responseGet.ok) {
                const agendamentos = await responseGet.json();
                const agendamentoEncontrado = agendamentos.data?.find(a => 
                    a.observacoes?.includes(`Agendamento Auditoria Extrema ${timestampTeste}`)
                );
                
                if (agendamentoEncontrado) {
                    console.log('✅ AGENDAMENTO CONFIRMADO NO BANCO - Persistência OK');
                    sucessos++;
                    registrarEvidencia('PERSISTENCE_SUCCESS', {
                        tipo: 'agendamento',
                        enviado: agendamentoTeste,
                        encontrado: agendamentoEncontrado
                    });
                } else {
                    console.log('❌ AGENDAMENTO NÃO ENCONTRADO - Falha na persistência!');
                    registrarProblema('PERSISTENCE_AGENDAMENTO_NOT_SAVED', 'Agendamento criado mas não persistido', {
                        enviado: agendamentoTeste,
                        agendamentosEncontrados: agendamentos.data?.length || 0
                    });
                }
            } else {
                console.log('❌ Erro ao buscar agendamentos para verificação');
                registrarProblema('PERSISTENCE_AGENDAMENTO_VERIFICATION_ERROR', 'Falha ao verificar persistência do agendamento');
            }
        } else {
            const error = await responseCreate.json();
            console.log(`❌ Falha ao criar agendamento: ${error.error}`);
            registrarProblema('PERSISTENCE_AGENDAMENTO_CREATE_ERROR', 'Falha ao criar agendamento para teste', error);
        }
    } catch (error) {
        console.log(`❌ Erro no teste de agendamento: ${error.message}`);
        registrarProblema('PERSISTENCE_AGENDAMENTO_EXCEPTION', 'Exceção no teste de persistência de agendamento', error.message);
    }
    
    const percentualPersistencia = Math.round((sucessos / totalTestes) * 100);
    console.log('\n💾 ================ RESULTADOS DE PERSISTÊNCIA ================');
    console.log('🧪 TESTES REALIZADOS:', totalTestes);
    console.log('✅ SUCESSOS:', sucessos);
    console.log('❌ FALHAS:', totalTestes - sucessos);
    console.log(`🎯 SCORE DE PERSISTÊNCIA: ${percentualPersistencia}%`);
    
    return { percentualPersistencia, sucessos, totalTestes };
}

/**
 * RELATÓRIO FINAL EXTREMAMENTE DETALHADO
 */
async function gerarRelatorioFinalImplacavel(scoreEndpoints, scorePersistencia, resultadosEndpoints) {
    console.log('\n📋 ================ RELATÓRIO FINAL EXTREMAMENTE DETALHADO ================');
    
    const scoreGeral = Math.round((scoreEndpoints + scorePersistencia) / 2);
    const statusFinal = scoreGeral >= 85 ? '✅ MÓDULO APROVADO' : '❌ MÓDULO REPROVADO';
    
    console.log('🎯 VEREDICTO FINAL:');
    console.log(`   Score Geral: ${scoreGeral}%`);
    console.log(`   Score Endpoints: ${scoreEndpoints}%`);
    console.log(`   Score Persistência: ${scorePersistencia}%`);
    console.log(`   Status: ${statusFinal}`);
    console.log(`   Meta Necessária: 85%`);
    console.log(`   Problemas Encontrados: ${problemasEncontrados.length}`);
    
    // Agrupar problemas por categoria
    const problemasPorCategoria = {};
    problemasEncontrados.forEach(p => {
        if (!problemasPorCategoria[p.categoria]) {
            problemasPorCategoria[p.categoria] = [];
        }
        problemasPorCategoria[p.categoria].push(p);
    });
    
    console.log('\n🚨 PROBLEMAS CRÍTICOS POR CATEGORIA:');
    Object.entries(problemasPorCategoria).forEach(([categoria, problemas]) => {
        console.log(`\n📌 ${categoria} (${problemas.length} problemas):`);
        problemas.forEach((p, index) => {
            console.log(`   ${index + 1}. ${p.descricao}`);
            if (p.evidencia && typeof p.evidencia === 'object') {
                console.log(`      Evidência: ${JSON.stringify(p.evidencia).substring(0, 100)}...`);
            }
        });
    });
    
    // Salvar relatório detalhado em arquivo
    const relatorioCompleto = {
        timestamp: new Date().toISOString(),
        scores: {
            geral: scoreGeral,
            endpoints: scoreEndpoints,
            persistencia: scorePersistencia
        },
        status: statusFinal,
        estatisticas: {
            endpoints_testados: endpointsTestados,
            endpoints_com_sucesso: endpointsComSucesso,
            problemas_encontrados: problemasEncontrados.length
        },
        problemas_por_categoria: problemasPorCategoria,
        evidencias_reais: evidenciasReais,
        resultados_endpoints: resultadosEndpoints
    };
    
    console.log('\n💾 Salvando relatório completo em arquivo...');
    await import('fs/promises').then(async (fs) => {
        await fs.writeFile('relatorio-auditoria-extrema-completa.json', JSON.stringify(relatorioCompleto, null, 2));
        console.log('✅ Relatório salvo em: relatorio-auditoria-extrema-completa.json');
    });
    
    return relatorioCompleto;
}

/**
 * EXECUÇÃO PRINCIPAL
 */
async function main() {
    try {
        console.log('🔥 INICIANDO AUDITORIA EXTREMAMENTE RIGOROSA DO MÓDULO SIMULADOR');
        console.log('⚠️ Esta auditoria VAI ENCONTRAR TODOS OS PROBLEMAS sem exceção!');
        
        // Aguardar servidor estar pronto
        console.log('\n⏳ Verificando se servidor está ativo...');
        try {
            const healthCheck = await fetch(BASE_URL + '/');
            if (healthCheck.ok) {
                console.log('✅ Servidor ativo e respondendo');
            } else {
                console.log('⚠️ Servidor respondendo mas com possíveis problemas');
            }
        } catch (error) {
            console.log('❌ ERRO: Servidor não está respondendo!');
            console.log('   Certifique-se de que o Vite está rodando em localhost:5173');
            process.exit(1);
        }
        
        // Executar testes
        const { percentualSucesso: scoreEndpoints, resultados: resultadosEndpoints } = await auditoriaEndpointsImplacavel();
        const { percentualPersistencia: scorePersistencia } = await auditoriaPersistenciaRigorosa();
        
        // Gerar relatório final
        const relatorioFinal = await gerarRelatorioFinalImplacavel(scoreEndpoints, scorePersistencia, resultadosEndpoints);
        
        console.log('\n🎯 AUDITORIA EXTREMA FINALIZADA!');
        console.log(`   Resultado: ${relatorioFinal.status}`);
        console.log(`   Score Final: ${relatorioFinal.scores.geral}%`);
        console.log(`   Problemas Documentados: ${problemasEncontrados.length}`);
        
        // Exit code baseado no resultado
        process.exit(relatorioFinal.scores.geral >= 85 ? 0 : 1);
        
    } catch (error) {
        console.error('🔥 ERRO CRÍTICO NA AUDITORIA:', error);
        process.exit(1);
    }
}

// Executar
main();
