module.exports = {
  extends: 'lighthouse:default',
  settings: {
    formFactor: 'desktop',
    throttling: {
      rttMs: 40,
      throughputKbps: 10240,
      cpuSlowdownMultiplier: 1,
      requestLatencyMs: 0,
      downloadThroughputKbps: 0,
      uploadThroughputKbps: 0
    },
    screenEmulation: {
      mobile: false,
      width: 1350,
      height: 940,
      deviceScaleFactor: 1,
      disabled: false,
    },
    emulatedUserAgent: false,
    onlyCategories: ['performance', 'accessibility', 'best-practices', 'seo'],
  },
  audits: [
    'metrics/first-contentful-paint',
    'metrics/largest-contentful-paint',
    'metrics/cumulative-layout-shift',
    'metrics/total-blocking-time',
  ],
  categories: {
    'performance': {
      title: 'Performance',
      auditRefs: [
        {id: 'first-contentful-paint', weight: 3, group: 'metrics'},
        {id: 'largest-contentful-paint', weight: 3, group: 'metrics'},
        {id: 'cumulative-layout-shift', weight: 2, group: 'metrics'},
        {id: 'total-blocking-time', weight: 2, group: 'metrics'},
      ],
    },
  },
  groups: {
    'metrics': {
      title: 'Core Web Vitals',
    },
  },
};
