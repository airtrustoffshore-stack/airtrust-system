#!/usr/bin/env node

/**
 * 🧪 TESTE AUTOMATIZADO COMPLETO - IMPORTAÇÃO CERTIFICAÇÕES AIRTRUST
 * Executa testes com 5, 50 e 1000 linhas para validar endpoint
 */

import https from 'https';
import fs from 'fs';

const BASE_URL = 'https://ywafeao36o2iw.mocha.app';

console.log('🔥 === AUDITORIA COMPLETA - IMPORTAÇÃO CERTIFICAÇÕES AIRTRUST ===\n');

// 🧪 FUNÇÃO PARA FAZER REQUISIÇÃO HTTP
async function makeRequest(method, path, data = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'ywafeao36o2iw.mocha.app',
      port: 443,
      path: path,
      method: method,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        ...headers
      }
    };

    const req = https.request(options, (res) => {
      let responseBody = '';
      
      res.on('data', (chunk) => {
        responseBody += chunk;
      });

      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: responseBody,
          contentType: res.headers['content-type'] || 'unknown'
        });
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    if (data) {
      req.write(JSON.stringify(data));
    }

    req.end();
  });
}

// 🧪 GERAR DADOS DE TESTE
function generateTestData(numRecords) {
  const data = [];
  const baseDate = new Date('2024-01-01');
  
  for (let i = 1; i <= numRecords; i++) {
    const conclusao = new Date(baseDate.getTime() + (i * 24 * 60 * 60 * 1000));
    const vencimento = new Date(conclusao.getTime() + (365 * 24 * 60 * 60 * 1000));
    
    data.push({
      funcionario_matricula: `TEST${String(i).padStart(4, '0')}`,
      treinamento_codigo: `TREIN_${String(i % 10).padStart(2, '0')}`,
      data_conclusao: conclusao.toISOString().split('T')[0],
      data_vencimento: vencimento.toISOString().split('T')[0],
      instrutor: `Instrutor ${Math.ceil(i / 10)}`,
      nota_final: 7.0 + (Math.random() * 3),
      observacoes: `Teste automatizado linha ${i}`
    });
  }
  
  return data;
}

// 🧪 TESTE INDIVIDUAL
async function runTest(testName, endpoint, data, expectedStatus = 200) {
  console.log(`\n🧪 === TESTE: ${testName} ===`);
  console.log(`📍 Endpoint: ${endpoint}`);
  console.log(`📊 Dados: ${data ? `${Array.isArray(data.data) ? data.data.length : 'N/A'} registros` : 'Sem body'}`);
  
  const startTime = Date.now();
  
  try {
    const response = await makeRequest('POST', endpoint, data);
    const duration = Date.now() - startTime;
    
    console.log(`⏱️  Tempo resposta: ${duration}ms`);
    console.log(`📋 Status HTTP: ${response.statusCode}`);
    console.log(`🔍 Content-Type: ${response.contentType}`);
    
    // Verificar se é JSON válido
    let parsedBody;
    let isValidJSON = false;
    
    try {
      parsedBody = JSON.parse(response.body);
      isValidJSON = true;
      console.log(`✅ Resposta é JSON válido`);
    } catch (e) {
      console.log(`❌ Resposta NÃO é JSON válido`);
      console.log(`📄 Primeira linha da resposta: ${response.body.substring(0, 100)}...`);
    }
    
    // Verificar Content-Type
    const isJSONContentType = response.contentType.includes('application/json');
    console.log(`🏷️  Content-Type correto: ${isJSONContentType ? '✅' : '❌'} (${response.contentType})`);
    
    // Analisar resposta JSON
    if (isValidJSON && parsedBody) {
      console.log(`📈 Resumo resposta:`);
      console.log(`   - success: ${parsedBody.success}`);
      console.log(`   - linhas_processadas: ${parsedBody.linhas_processadas || 'N/A'}`);
      console.log(`   - importadas_com_sucesso: ${parsedBody.importadas_com_sucesso || 'N/A'}`);
      console.log(`   - erros: ${parsedBody.erros || 'N/A'}`);
      console.log(`   - processing_time_ms: ${parsedBody.processing_time_ms || 'N/A'}`);
      
      if (parsedBody.evidence) {
        console.log(`🔍 Evidências:`);
        console.log(`   - total_records_in_request: ${parsedBody.evidence.total_records_in_request || 'N/A'}`);
        console.log(`   - records_successfully_imported: ${parsedBody.evidence.records_successfully_imported || 'N/A'}`);
        console.log(`   - processing_evidence: ${parsedBody.evidence.processing_evidence || 'N/A'}`);
      }
    }
    
    return {
      success: isValidJSON && isJSONContentType && response.statusCode < 500,
      statusCode: response.statusCode,
      contentType: response.contentType,
      isValidJSON,
      response: parsedBody,
      duration,
      body: response.body
    };
    
  } catch (error) {
    console.log(`💥 ERRO: ${error.message}`);
    return {
      success: false,
      error: error.message,
      duration: Date.now() - startTime
    };
  }
}

// 🧪 EXECUTAR TODOS OS TESTES
async function runAllTests() {
  const results = [];
  
  console.log('🚀 Iniciando bateria de testes...\n');
  
  // ===== TESTE 1: ENDPOINT HEALTH CHECK =====
  console.log('\n📊 === TESTE PRELIMINAR: HEALTH CHECK ===');
  try {
    const healthResponse = await makeRequest('GET', '/health');
    console.log(`Health Check - Status: ${healthResponse.statusCode}`);
    console.log(`Health Check - Response: ${healthResponse.body.substring(0, 200)}...`);
  } catch (e) {
    console.log(`Health Check falhou: ${e.message}`);
  }
  
  // ===== TESTE 2: VERIFICAR ROTA BASE =====
  console.log('\n📊 === TESTE PRELIMINAR: ROTA BASE ===');
  try {
    const baseResponse = await makeRequest('GET', '/api/v2/historico-certificacoes');
    console.log(`Rota Base - Status: ${baseResponse.statusCode}`);
    console.log(`Rota Base - Content-Type: ${baseResponse.contentType}`);
    console.log(`Rota Base - Body (primeiros 100 chars): ${baseResponse.body.substring(0, 100)}...`);
  } catch (e) {
    console.log(`Rota Base falhou: ${e.message}`);
  }
  
  // ===== TESTE 3: STATUS ENDPOINT =====
  console.log('\n📊 === TESTE PRELIMINAR: STATUS ENDPOINT ===');
  try {
    const statusResponse = await makeRequest('GET', '/api/v2/historico-certificacoes/status');
    console.log(`Status Endpoint - Status: ${statusResponse.statusCode}`);
    console.log(`Status Endpoint - Content-Type: ${statusResponse.contentType}`);
    if (statusResponse.statusCode === 200) {
      console.log(`Status Endpoint - Body: ${statusResponse.body.substring(0, 300)}...`);
    }
  } catch (e) {
    console.log(`Status Endpoint falhou: ${e.message}`);
  }
  
  // ===== TESTE 4: DADOS VAZIOS =====
  const test1 = await runTest(
    'Dados Vazios',
    '/api/v2/historico-certificacoes/batch-import',
    { data: [] },
    400
  );
  results.push({ name: 'Dados Vazios', ...test1 });
  
  // ===== TESTE 5: 5 REGISTROS =====
  const test2 = await runTest(
    '5 Registros',
    '/api/v2/historico-certificacoes/batch-import',
    { data: generateTestData(5) }
  );
  results.push({ name: '5 Registros', ...test2 });
  
  // ===== TESTE 6: 50 REGISTROS =====
  const test3 = await runTest(
    '50 Registros',
    '/api/v2/historico-certificacoes/batch-import',
    { data: generateTestData(50) }
  );
  results.push({ name: '50 Registros', ...test3 });
  
  // ===== TESTE 7: FORMATO INVÁLIDO =====
  const test4 = await runTest(
    'Formato Inválido',
    '/api/v2/historico-certificacoes/batch-import',
    { invalid: 'format' },
    400
  );
  results.push({ name: 'Formato Inválido', ...test4 });
  
  // ===== RESULTADO FINAL =====
  console.log('\n🏁 === RESULTADO FINAL DA AUDITORIA ===');
  
  let totalTests = results.length;
  let successfulTests = results.filter(r => r.success).length;
  let failedTests = results.filter(r => !r.success).length;
  
  console.log(`📊 Total de testes: ${totalTests}`);
  console.log(`✅ Sucessos: ${successfulTests}`);
  console.log(`❌ Falhas: ${failedTests}`);
  
  results.forEach((result, index) => {
    const status = result.success ? '✅' : '❌';
    console.log(`${status} Teste ${index + 1}: ${result.name} - Status: ${result.statusCode || 'ERROR'} - Tempo: ${result.duration}ms`);
  });
  
  // ===== CHECKLIST AIRTRUST ENTERPRISE =====
  console.log('\n📋 === CHECKLIST AIRTRUST ENTERPRISE ===');
  
  const hasWorkingEndpoint = results.some(r => r.success && r.statusCode === 200);
  const alwaysJSON = results.every(r => r.isValidJSON || r.statusCode === 404);
  const noHTML502 = results.every(r => !r.body?.includes('<html>') && r.statusCode !== 502);
  
  console.log(`✅ Endpoint online e responde em JSON: ${hasWorkingEndpoint ? '✅' : '❌'}`);
  console.log(`✅ Nunca retorna HTML/502: ${noHTML502 ? '✅' : '❌'}`);
  console.log(`✅ Resposta sempre JSON: ${alwaysJSON ? '✅' : '❌'}`);
  
  if (!hasWorkingEndpoint) {
    console.log('\n🚨 ENDPOINT NÃO ESTÁ FUNCIONANDO!');
    console.log('Possíveis causas:');
    console.log('- Rota não registrada no worker index.ts');
    console.log('- Problema no deploy do worker');
    console.log('- Configuração de binding/env incorreta');
  }
  
  // Salvar log detalhado
  const logData = {
    timestamp: new Date().toISOString(),
    summary: {
      totalTests,
      successfulTests,
      failedTests,
      hasWorkingEndpoint,
      alwaysJSON,
      noHTML502
    },
    results: results
  };
  
  fs.writeFileSync('/tmp/audit-log.json', JSON.stringify(logData, null, 2));
  console.log('\n📄 Log detalhado salvo em: /tmp/audit-log.json');
  
  return logData;
}

// 🚀 EXECUTAR
runAllTests().catch(console.error);
