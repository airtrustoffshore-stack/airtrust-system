#!/bin/bash
echo "🚨 ROLLBACK M4.11 - Refatoração IA"
BACKUP_TAG=$(git tag -l "pre-ia-refactor-*" | tail -n1)
echo "Revertendo para: $BACKUP_TAG"
git reset --hard $BACKUP_TAG
npm run build
curl -s http://localhost:5173/api/v2/system/health | jq '.status'
echo "✅ Rollback IA concluído - Navegação restaurada"
