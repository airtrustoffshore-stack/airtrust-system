# 🚨 AIRTRUST - CORREÇÕES CRÍTICAS OBRIGATÓRIAS

> **STATUS ATUAL**: Sistema funcional com 3 problemas críticos que impedem uso em produção.

## ❌ PROBLEMAS CRÍTICOS (CORRIGIR URGENTE!)

### 🚨 PROBLEMA 1: IDs DAS CERTIFICAÇÕES INCORRETOS
- **Formato atual**: `00000-SGV-001-2025-01` ❌
- **Formato correto**: `00074-SGV-2024-01` ✅
- **Impacto**: Sistema inútil para auditoria
- **Solução**: Implementar função `gerarProximoIdCertificacao`

### 🚨 PROBLEMA 2: SISTEMA DE CERTIFICADOS QUEBRADO
- **Upload**: ✅ Funciona
- **Download**: ❌ PDF genérico "Modo Desenvolvimento"
- **Pasta Virtual**: ❌ Não integrada
- **Solução**: Corrigir download + integrar pasta virtual

### 🚨 PROBLEMA 3: UX RUIM EM EXCLUSÕES
- **Funcionários**: Dupla confirmação + erro
- **Treinamentos**: Pop-up desnecessário
- **Solução**: Uma confirmação + exclusão silenciosa

## ✅ O QUE ESTÁ FUNCIONANDO (NÃO QUEBRAR!)

- **Gestão de Funcionários**: CRUD completo
- **Catálogo de Treinamentos**: CRUD completo  
- **Dashboard**: KPIs, métricas, navegação
- **Sistema de Importação**: CSV funcional
- **Base de Dados**: 10 tabelas, integridade OK
- **APIs**: 47 endpoints funcionais

## 🔧 CORREÇÕES OBRIGATÓRIAS (NESTA ORDEM!)

### CORREÇÃO 1: Função de Geração de ID
```javascript
const gerarProximoIdCertificacao = async (colaboradorId, treinamentoId, dataConclusao, db) => {
  // 1. Buscar matrícula REAL do funcionário (5 dígitos)
  // 2. Buscar código REAL do treinamento
  // 3. Usar ANO da data de conclusão (não ano atual)
  // 4. Sequencial único por funcionário/treinamento/ano
  // Formato: XXXXX-CÓDIGO-AAAA-SS
  // Exemplo: 00074-SGV-2024-01
}
```

### CORREÇÃO 2: Download de Certificados
```javascript
app.get('/api/certificacoes/:id/download-certificado', async (c) => {
  // 1. Buscar certificação no banco
  // 2. Verificar arquivo_url
  // 3. Buscar arquivo REAL no R2
  // 4. Retornar arquivo original (NÃO PDF genérico!)
})
```

### CORREÇÃO 3: UX de Exclusões
```javascript
// Funcionários: uma confirmação apenas
const excluirFuncionario = async (id) => {
  if (confirm("Tem certeza?")) {
    await deleteAPI(id);
    await carregarLista(); // Atualizar silenciosamente
    // SEM POP-UP de sucesso
  }
}
```

## 📋 CHECKLIST ANTES DE DIZER "CONCLUÍDO"

- [ ] Função `gerarProximoIdCertificacao` implementada e testada
- [ ] Download de certificado retorna arquivo real
- [ ] Exclusão funcionário: uma confirmação apenas
- [ ] Exclusão treinamento: sem pop-up sucesso
- [ ] Pasta virtual integrada com ícone
- [ ] Funcionalidades existentes ainda funcionam
- [ ] Build sem erros

---
**Última atualização**: 2025-09-17  
**Status**: SISTEMA FUNCIONAL COM 3 PROBLEMAS CRÍTICOS
