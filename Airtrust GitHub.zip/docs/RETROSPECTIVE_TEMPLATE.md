# Retrospectiva do Módulo - AirTrust

**Módulo:** [Nome do Módulo]  
**Data de Execução:** [YYYY-MM-DD]  
**Duração Real:** [Xh Ym]  
**Executor:** [Nome do desenvolvedor/AI]  

---

## 📊 Métricas de Implementação

### Tempo
- **Estimado:** [Xh Ym]
- **Real:** [Xh Ym]
- **Variação:** [±X%]
- **Motivo da variação:** [Explicação se >20% de diferença]

### Código
- **Linhas adicionadas:** [X]
- **Linhas modificadas:** [X]
- **Linhas removidas:** [X]
- **Arquivos criados:** [X]
- **Arquivos modificados:** [X]

### Qualidade
- **Test Coverage:** [X%]
- **Lighthouse Score:** [X/100]
- **Build Time:** [Xs]
- **Bundle Size:** [X KB]

---

## ✅ Objetivos Alcançados

### Funcionalidades Implementadas
- [✅/❌] Objetivo 1
- [✅/❌] Objetivo 2  
- [✅/❌] Objetivo 3

### Critérios de Sucesso
- [✅/❌] Todos os testes passando
- [✅/❌] Performance target atingido
- [✅/❌] Acessibilidade validada
- [✅/❌] Segurança verificada
- [✅/❌] Documentação atualizada

---

## 🐛 Bugs Encontrados e Resolvidos

### Bugs Críticos
1. **[Bug Title]**
   - **Descrição:** [Breve descrição]
   - **Impacto:** [Alto/Médio/Baixo]
   - **Tempo para resolver:** [Xm]
   - **Root cause:** [Causa raiz]
   - **Prevenção:** [Como evitar no futuro]

### Bugs Menores
1. **[Bug Title]**
   - **Descrição:** [Breve descrição]
   - **Tempo para resolver:** [Xm]

---

## 🎯 Lições Aprendidas

### O que funcionou bem? ⭐
1. **[Aspecto positivo 1]**
   - Descrição: [Por que funcionou bem]
   - Aplicar em: [Próximos módulos similares]

2. **[Aspecto positivo 2]**
   - Descrição: [Por que funcionou bem]
   - Aplicar em: [Próximos módulos similares]

### O que não funcionou? ⚠️
1. **[Problema 1]**
   - Descrição: [O que deu errado]
   - Impacto: [Como afetou o desenvolvimento]
   - Solução: [Como foi resolvido]

2. **[Problema 2]**
   - Descrição: [O que deu errado]
   - Impacto: [Como afetou o desenvolvimento]
   - Solução: [Como foi resolvido]

---

## 🔄 Melhorias para Próximos Módulos

### Processo
- [ ] **[Melhoria 1]** - [Descrição da ação]
- [ ] **[Melhoria 2]** - [Descrição da ação]
- [ ] **[Melhoria 3]** - [Descrição da ação]

### Ferramentas
- [ ] **[Ferramenta/Config]** - [Para que serve]
- [ ] **[Ferramenta/Config]** - [Para que serve]

### Documentação
- [ ] **[Doc faltante]** - [Prioridade: Alta/Média/Baixa]
- [ ] **[Doc desatualizada]** - [Prioridade: Alta/Média/Baixa]

---

## 📈 Análise de Riscos

### Riscos que se materializaram
1. **[Risco 1]**
   - **Probabilidade prevista:** [Alta/Média/Baixa]
   - **Impacto real:** [Descrição]
   - **Mitigação aplicada:** [Como foi resolvido]

### Riscos para próximos módulos
1. **[Risco potencial 1]**
   - **Probabilidade:** [Alta/Média/Baixa]
   - **Impacto potencial:** [Descrição]
   - **Mitigação proposta:** [Como prevenir/resolver]

---

## 🚀 Próximos Passos

### Imediato (próximas 24h)
- [ ] [Ação 1]
- [ ] [Ação 2]

### Curto prazo (próxima semana)
- [ ] [Ação 1]
- [ ] [Ação 2]

### Médio prazo (próximo mês)
- [ ] [Ação 1]
- [ ] [Ação 2]

---

## 💡 Insights Técnicos

### Arquitetura
- **Decisões arquiteturais tomadas:** [Lista das principais decisões]
- **Trade-offs feitos:** [Decisões de compromisso e justificativa]
- **Débito técnico criado:** [Se houver, com plano de resolução]

### Performance
- **Otimizações aplicadas:** [Lista de otimizações]
- **Bottlenecks identificados:** [Gargalos encontrados]
- **Métricas before/after:** [Comparação de performance]

### Segurança
- **Vulnerabilidades identificadas:** [Se houver]
- **Medidas de segurança implementadas:** [Lista de medidas]
- **Auditorias realizadas:** [Testes de segurança executados]

---

## 🎭 Feedback da Equipe

### Desenvolvedor/AI
**Satisfação geral:** [1-10]  
**Comentários:** [Feedback sobre o processo, ferramentas, clareza de requisitos]

### QA (se aplicável)
**Qualidade do código:** [1-10]  
**Facilidade de teste:** [1-10]  
**Comentários:** [Feedback sobre testabilidade e qualidade]

### Product Owner (se aplicável)
**Alinhamento com requisitos:** [1-10]  
**Usabilidade:** [1-10]  
**Comentários:** [Feedback sobre produto final]

---

## 📋 Action Items

| Item | Responsável | Prazo | Prioridade |
|------|-------------|-------|------------|
| [Ação 1] | [Nome] | [Data] | [Alta/Média/Baixa] |
| [Ação 2] | [Nome] | [Data] | [Alta/Média/Baixa] |
| [Ação 3] | [Nome] | [Data] | [Alta/Média/Baixa] |

---

## 📚 Recursos Úteis Descobertos

### Links/Documentação
- [Recurso 1]: [URL] - [Descrição do que ajudou]
- [Recurso 2]: [URL] - [Descrição do que ajudou]

### Ferramentas
- [Ferramenta 1] - [Como ajudou no desenvolvimento]
- [Ferramenta 2] - [Como ajudou no desenvolvimento]

---

**Assinatura:** [Nome do autor]  
**Data da retrospectiva:** [YYYY-MM-DD]  
**Próxima retrospectiva:** [YYYY-MM-DD]
